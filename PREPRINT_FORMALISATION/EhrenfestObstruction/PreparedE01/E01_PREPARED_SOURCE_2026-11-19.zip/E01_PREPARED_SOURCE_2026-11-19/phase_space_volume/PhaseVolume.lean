import MethbokeAddon.EhrenfestObstruction.PhaseSpace
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace

/-!
# Canonical finite phase-space volume and orthonormal coordinates

This uses Mathlib's native Lebesgue volume of a real finite-dimensional
inner-product space. It is a measure on coefficient phase space, distinct
from the physical unit-cube spatial measure appearing in Parseval identities.
-/

set_option autoImplicit false

open MeasureTheory

namespace MethbokeAddon.EhrenfestObstruction

noncomputable section

def phaseVolume (N : ℕ) : Measure (GalerkinPhase N) := volume

def phaseCoordinatesMeasurableEquiv (N : ℕ) :
    GalerkinPhase N ≃ᵐ
      EuclideanSpace ℝ (Fin (Module.finrank ℝ (GalerkinPhase N))) :=
  (phaseCoordinates N).toMeasurableEquiv

theorem phaseCoordinatesMeasurableEquiv_apply (N : ℕ) (z : GalerkinPhase N) :
    phaseCoordinatesMeasurableEquiv N z = phaseCoordinates N z := rfl

theorem phaseCoordinatesMeasurableEquiv_symm_apply (N : ℕ)
    (x : EuclideanSpace ℝ (Fin (Module.finrank ℝ (GalerkinPhase N)))) :
    (phaseCoordinatesMeasurableEquiv N).symm x = (phaseCoordinates N).symm x := rfl

theorem phaseCoordinates_measurePreserving (N : ℕ) :
    MeasurePreserving (phaseCoordinates N) (phaseVolume N) volume :=
  (phaseCoordinates N).measurePreserving

theorem phaseCoordinates_symm_measurePreserving (N : ℕ) :
    MeasurePreserving (phaseCoordinates N).symm volume (phaseVolume N) :=
  (phaseCoordinates N).symm.measurePreserving

theorem phaseCoordinates_map_volume (N : ℕ) :
    Measure.map (phaseCoordinates N) (phaseVolume N) = volume :=
  (phaseCoordinates_measurePreserving N).map_eq

theorem phaseVolume_eq_map_coordinates_symm (N : ℕ) :
    phaseVolume N = Measure.map (phaseCoordinates N).symm volume :=
  (phaseCoordinates_symm_measurePreserving N).map_eq.symm

/-- The phase measure is unchanged by every real linear isometry of the phase. -/
theorem phaseVolume_map_linearIsometry (N : ℕ)
    (f : GalerkinPhase N ≃ₗᵢ[ℝ] GalerkinPhase N) :
    Measure.map f (phaseVolume N) = phaseVolume N := f.measurePreserving.map_eq

end

end MethbokeAddon.EhrenfestObstruction
