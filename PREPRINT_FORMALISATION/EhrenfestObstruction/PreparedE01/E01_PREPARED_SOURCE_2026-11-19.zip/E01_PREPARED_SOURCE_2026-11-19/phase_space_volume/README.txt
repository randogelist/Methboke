E01 PHASE-VOLUME ADAPTER -- PREPARED SOURCE ONLY

PhaseVolume.lean defines the measure as Mathlib's native volume on the real
finite-dimensional inner-product phase space. Native linear isometry measure
preservation proves that phaseCoordinates and its inverse preserve this
volume, gives both pushforward formulas, and proves invariance under every
real linear isometry of the phase.

This is coefficient phase-space Lebesgue measure. It is distinct from the
physical spatial measure on unitCube in T^3. No physical/phase measures are
silently identified, and no nonlinear flow measure preservation is assumed.

Exact source:
  Mathlib pin db584cd6d46c92f209a44c0f1c829460d327499d
  Mathlib/MeasureTheory/Measure/Haar/InnerProductSpace.lean
    LinearIsometryEquiv.toMeasurableEquiv (line 38)
    LinearIsometryEquiv.measurePreserving (line 151)
  source blob ec56bf802a75333ff66105c940eed9bf271fb6e1

7 theorem proofs, 2 definitions, 9 independently stated consumer examples,
9 named axiom queries. No local Lean/Lake/kernel execution, external CI,
publication, opaque analytic ports, or new axioms. Formal acceptance remains
pending authorized external cached verification.
