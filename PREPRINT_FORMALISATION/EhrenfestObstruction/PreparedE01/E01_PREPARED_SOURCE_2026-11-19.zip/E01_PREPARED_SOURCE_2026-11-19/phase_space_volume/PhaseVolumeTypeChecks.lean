import MethbokeAddon.EhrenfestObstruction.PhaseVolume

set_option autoImplicit false
open MeasureTheory

namespace MethbokeAddon.EhrenfestObstruction.PhaseVolumeTypeChecks

example (N : ℕ) : phaseVolume N = (volume : Measure (GalerkinPhase N)) := rfl

example (N : ℕ) :
    GalerkinPhase N ≃ᵐ EuclideanSpace ℝ (Fin (Module.finrank ℝ (GalerkinPhase N))) :=
  phaseCoordinatesMeasurableEquiv N

example (N : ℕ) (z : GalerkinPhase N) :
    phaseCoordinatesMeasurableEquiv N z = phaseCoordinates N z :=
  phaseCoordinatesMeasurableEquiv_apply N z

example (N : ℕ) (x : EuclideanSpace ℝ (Fin (Module.finrank ℝ (GalerkinPhase N)))) :
    (phaseCoordinatesMeasurableEquiv N).symm x = (phaseCoordinates N).symm x :=
  phaseCoordinatesMeasurableEquiv_symm_apply N x

example (N : ℕ) : MeasurePreserving (phaseCoordinates N) (phaseVolume N) volume :=
  phaseCoordinates_measurePreserving N

example (N : ℕ) : MeasurePreserving (phaseCoordinates N).symm volume (phaseVolume N) :=
  phaseCoordinates_symm_measurePreserving N

example (N : ℕ) : Measure.map (phaseCoordinates N) (phaseVolume N) = volume :=
  phaseCoordinates_map_volume N

example (N : ℕ) : phaseVolume N = Measure.map (phaseCoordinates N).symm volume :=
  phaseVolume_eq_map_coordinates_symm N

example (N : ℕ) (f : GalerkinPhase N ≃ₗᵢ[ℝ] GalerkinPhase N) :
    Measure.map f (phaseVolume N) = phaseVolume N := phaseVolume_map_linearIsometry N f

end MethbokeAddon.EhrenfestObstruction.PhaseVolumeTypeChecks

#print axioms MethbokeAddon.EhrenfestObstruction.phaseVolume
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinatesMeasurableEquiv
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinatesMeasurableEquiv_apply
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinatesMeasurableEquiv_symm_apply
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinates_measurePreserving
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinates_symm_measurePreserving
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinates_map_volume
#print axioms MethbokeAddon.EhrenfestObstruction.phaseVolume_eq_map_coordinates_symm
#print axioms MethbokeAddon.EhrenfestObstruction.phaseVolume_map_linearIsometry
