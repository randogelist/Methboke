import MethbokeAddon.EhrenfestObstruction.PhaseLeray
import MethbokeAddon.EhrenfestObstruction.PhaseBounds
import SingularClosure.GalerkinReality

/-!
Actual nonsymmetric finite transport on the native real Galerkin phase.
The first argument advects the second. No symmetric polarization is used.
The convolution, its real symmetry, and both linearities are explicit.

Prepared source only; external cached verification is still required.
-/

set_option autoImplicit false

open SingularClosure
open scoped BigOperators RealInnerProductSpace

namespace MethbokeAddon.EhrenfestObstruction
noncomputable section

/-- Literal finite Fourier convolution for `(a · ∇) b`. -/
def coefficientBilinearTransport (N : ℕ) (a b : FourierCoeff) : FourierCoeff :=
  fun k i => ∑ p ∈ cutoffModes N,
    (∑ j : Fin 3,
      a p j * (((2 * Real.pi * ((k j - p j : ℤ) : ℝ) : ℝ) : ℂ) * Complex.I)) *
        b (k - p) i

theorem coefficientBilinearTransport_diagonal (N : ℕ) (c : FourierCoeff) :
    coefficientBilinearTransport N c c = coefficientTransport N c := rfl

theorem coefficientBilinearTransport_add_left
    (N : ℕ) (a b c : FourierCoeff) :
    coefficientBilinearTransport N (a + b) c =
      coefficientBilinearTransport N a c + coefficientBilinearTransport N b c := by
  funext k i
  simp only [coefficientBilinearTransport, Pi.add_apply, add_mul,
    Finset.sum_add_distrib]

theorem coefficientBilinearTransport_add_right
    (N : ℕ) (a b c : FourierCoeff) :
    coefficientBilinearTransport N a (b + c) =
      coefficientBilinearTransport N a b + coefficientBilinearTransport N a c := by
  funext k i
  simp only [coefficientBilinearTransport, Pi.add_apply, mul_add,
    Finset.sum_add_distrib]

theorem coefficientBilinearTransport_smul_left
    (N : ℕ) (r : ℝ) (a b : FourierCoeff) :
    coefficientBilinearTransport N (r • a) b =
      r • coefficientBilinearTransport N a b := by
  funext k i
  simp only [coefficientBilinearTransport, Pi.smul_apply, Complex.real_smul,
    Finset.mul_sum, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro p hp
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem coefficientBilinearTransport_smul_right
    (N : ℕ) (r : ℝ) (a b : FourierCoeff) :
    coefficientBilinearTransport N a (r • b) =
      r • coefficientBilinearTransport N a b := by
  funext k i
  simp only [coefficientBilinearTransport, Pi.smul_apply, Complex.real_smul,
    Finset.mul_sum, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro p hp
  apply Finset.sum_congr rfl
  intro j hj
  ring

/-- Reality follows by reindexing the actual cutoff by frequency negation. -/
theorem coefficientBilinearTransport_reality
    (N : ℕ) (a b : FourierCoeff)
    (ha : SpectralReality a) (hb : SpectralReality b) :
    SpectralReality (coefficientBilinearTransport N a b) := by
  classical
  intro k i
  let term : Frequency → Frequency → ℂ := fun q p =>
    (∑ j : Fin 3, a p j *
      (((2 * Real.pi * ((q j - p j : ℤ) : ℝ) : ℝ) : ℂ) * Complex.I)) * b (q - p) i
  have hterm (p : Frequency) : term (-k) (-p) = star (term k p) := by
    have hsub : -k - -p = -(k - p) := by abel
    dsimp [term]
    rw [hsub, hb]
    simp only [Complex.star_def, map_mul, map_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro j hj
    rw [ha]
    simp only [Complex.star_def, map_mul, Complex.conj_ofReal, Complex.conj_I,
      Pi.neg_apply]
    push_cast
    ring
  change (∑ p ∈ cutoffModes N, term (-k) p) =
    star (∑ p ∈ cutoffModes N, term k p)
  rw [star_sum]
  apply Finset.sum_nbij' (fun p => -p) (fun p => -p)
    (fun p hp => cutoffModes_neg_mem hp) (fun p hp => cutoffModes_neg_mem hp)
  · intro p hp
    simp
  · intro p hp
    simp
  · intro p hp
    simpa only [neg_neg] using hterm (-p)

/-- The actual retained, unprojected convolution in the ambient Hilbert space. -/
def phaseRawTransport (N : ℕ) (a b : GalerkinPhase N) : GalerkinPhaseAmbient N :=
  WithLp.toLp 2 (fun ki =>
    coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N b) ki.1.val ki.2)

theorem phaseRawTransport_coeff (N : ℕ) (a b : GalerkinPhase N) :
    hilbertCoeff N (phaseRawTransport N a b) =
      cutoffCoeff N (coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N b)) := by
  funext k i
  by_cases hk : k ∈ cutoffModes N <;>
    simp [phaseRawTransport, hilbertCoeff, extendFiniteState, cutoffCoeff, hk]

theorem phaseRawTransport_reality (N : ℕ) (a b : GalerkinPhase N) :
    SpectralReality (hilbertCoeff N (phaseRawTransport N a b)) := by
  rw [phaseRawTransport_coeff]
  exact cutoffCoeff_preserves_reality N
    (coefficientBilinearTransport_reality N (phaseCoeff N a) (phaseCoeff N b)
      (phaseCoeff_reality N a) (phaseCoeff_reality N b))

theorem phaseRawTransport_add_left (N : ℕ) (a b c : GalerkinPhase N) :
    phaseRawTransport N (a + b) c = phaseRawTransport N a c + phaseRawTransport N b c := by
  ext ki
  change coefficientBilinearTransport N (phaseCoeff N (a + b)) (phaseCoeff N c)
      ki.1.val ki.2 =
    coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N c) ki.1.val ki.2 +
      coefficientBilinearTransport N (phaseCoeff N b) (phaseCoeff N c) ki.1.val ki.2
  simp only [map_add, coefficientBilinearTransport_add_left, Pi.add_apply]

theorem phaseRawTransport_add_right (N : ℕ) (a b c : GalerkinPhase N) :
    phaseRawTransport N a (b + c) = phaseRawTransport N a b + phaseRawTransport N a c := by
  ext ki
  change coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N (b + c))
      ki.1.val ki.2 =
    coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N b) ki.1.val ki.2 +
      coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N c) ki.1.val ki.2
  simp only [map_add, coefficientBilinearTransport_add_right, Pi.add_apply]

theorem phaseRawTransport_smul_left (N : ℕ) (r : ℝ) (a b : GalerkinPhase N) :
    phaseRawTransport N (r • a) b = r • phaseRawTransport N a b := by
  ext ki
  change coefficientBilinearTransport N (phaseCoeff N (r • a)) (phaseCoeff N b)
      ki.1.val ki.2 =
    r • coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N b) ki.1.val ki.2
  simp only [map_smul, coefficientBilinearTransport_smul_left, Pi.smul_apply]

theorem phaseRawTransport_smul_right (N : ℕ) (r : ℝ) (a b : GalerkinPhase N) :
    phaseRawTransport N a (r • b) = r • phaseRawTransport N a b := by
  ext ki
  change coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N (r • b))
      ki.1.val ki.2 =
    r • coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N b) ki.1.val ki.2
  simp only [map_smul, coefficientBilinearTransport_smul_right, Pi.smul_apply]

/-- The nonsymmetric transport, followed by the actual orthogonal phase projection. -/
def phaseTransport (N : ℕ) (a b : GalerkinPhase N) : GalerkinPhase N :=
  phaseProjection N (phaseRawTransport N a b)

/-- This projection is exactly the native modewise Leray convolution even
off the diagonal, because the raw transport's reality was proved above. -/
theorem phaseTransport_coeff (N : ℕ) (a b : GalerkinPhase N) :
    phaseCoeff N (phaseTransport N a b) =
      cutoffCoeff N (fun k => coefficientLeray k
        (coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N b) k)) := by
  change hilbertCoeff N (phaseProjection N (phaseRawTransport N a b)).val = _
  rw [phaseProjection_coe_eq_ambientLeray_of_reality N (phaseRawTransport N a b)
    (phaseRawTransport_reality N a b), ambientLeray_coeff, phaseRawTransport_coeff]
  funext k i
  by_cases hk : k ∈ cutoffModes N
  · simp only [lerayFourierCoeff, cutoffCoeff, if_pos hk]
  · simp only [lerayFourierCoeff, cutoffCoeff, if_neg hk]
    exact congrFun (coefficientLeray_zero k) i

theorem phaseTransport_add_left (N : ℕ) (a b c : GalerkinPhase N) :
    phaseTransport N (a + b) c = phaseTransport N a c + phaseTransport N b c := by
  simp only [phaseTransport, phaseRawTransport_add_left, map_add]

theorem phaseTransport_add_right (N : ℕ) (a b c : GalerkinPhase N) :
    phaseTransport N a (b + c) = phaseTransport N a b + phaseTransport N a c := by
  simp only [phaseTransport, phaseRawTransport_add_right, map_add]

theorem phaseTransport_smul_left (N : ℕ) (r : ℝ) (a b : GalerkinPhase N) :
    phaseTransport N (r • a) b = r • phaseTransport N a b := by
  simp only [phaseTransport, phaseRawTransport_smul_left, map_smul]

theorem phaseTransport_smul_right (N : ℕ) (r : ℝ) (a b : GalerkinPhase N) :
    phaseTransport N a (r • b) = r • phaseTransport N a b := by
  simp only [phaseTransport, phaseRawTransport_smul_right, map_smul]

/-- The actual transport, packaged as a real bilinear map. -/
def phaseTransportLinear (N : ℕ) :
    GalerkinPhase N →ₗ[ℝ] GalerkinPhase N →ₗ[ℝ] GalerkinPhase N where
  toFun a :=
    { toFun := phaseTransport N a
      map_add' := phaseTransport_add_right N a
      map_smul' := fun r b => phaseTransport_smul_right N r a b }
  map_add' a b := by
    apply LinearMap.ext
    intro c
    exact phaseTransport_add_left N a b c
  map_smul' r a := by
    apply LinearMap.ext
    intro b
    exact phaseTransport_smul_left N r a b

theorem phaseTransportLinear_apply (N : ℕ) (a b : GalerkinPhase N) :
    phaseTransportLinear N a b = phaseTransport N a b := rfl

/-- Its diagonal is the negative actual inviscid NSE vector field. -/
theorem phaseTransport_diagonal (N : ℕ) (z : GalerkinPhase N) :
    phaseTransport N z z = -phaseRhs 0 N z := by
  apply phaseCoeff_injective N
  rw [phaseTransport_coeff, map_neg, phaseRhs_coeff,
    coefficientBilinearTransport_diagonal]
  funext k i
  by_cases hk : k ∈ cutoffModes N <;>
    simp [cutoffCoeff, hk, galerkinRhs]

/-- Actual diagonal energy cancellation, inherited from the native ODE identity. -/
theorem phaseTransport_diagonal_energy_zero (N : ℕ) (z : GalerkinPhase N) :
    inner ℝ z (phaseTransport N z z) = 0 := by
  rw [phaseTransport_diagonal, inner_neg_right, phaseRhs_inviscid_radial_zero, neg_zero]

/-- The native NSE operator now has the literal Stokes-plus-bilinear form. -/
theorem phaseRhs_eq_stokes_sub_transport (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    phaseRhs ν N z = (-ν) • phaseStokes N z - phaseTransport N z z := by
  rw [phaseRhs_stokes_split, phaseTransport_diagonal]
  simp only [sub_neg_eq_add]

end
end MethbokeAddon.EhrenfestObstruction
