import MethbokeAddon.EhrenfestObstruction.PhaseTransport
import MethbokeAddon.EhrenfestObstruction.PhaseSynthesis
import SingularClosure.PhysicalBilinear

/-!
The diagonal transport pairing is the actual physical cube integral.
Its cancellation follows from the literal finite Fourier convolution and
the native real, solenoidal phase constraints.

Prepared source only; external cached verification is still required.
-/

set_option autoImplicit false

open Set MeasureTheory SingularClosure
open scoped BigOperators RealInnerProductSpace

namespace MethbokeAddon.EhrenfestObstruction
noncomputable section

/-- The actual finite physical convection has zero energy pairing. -/
theorem phaseSynthesis_convection_energy_zero (N : ℕ) (z : GalerkinPhase N) :
    (∫ x in unitCube,
      inner ℝ (phaseSynthesis N z x) (convection (phaseSynthesis N z) x)) = 0 := by
  unfold phaseSynthesis
  rw [integral_finiteSynthesis_pairing N (phaseCoeff N z)
    (convection (finiteSynthesis N (phaseCoeff N z)))
    (convection_continuous (finiteSynthesis_contDiff N (phaseCoeff N z))),
    datumFourierCoeff_convection_finiteSynthesis N (phaseCoeff N z)
      (phaseCoeff_support N z) (phaseCoeff_reality N z)]
  have h := congrArg Complex.re
    (coefficientTransport_complex_energy_zero N (phaseCoeff N z)
      (phaseCoeff_support N z) (phaseCoeff_reality N z) (phaseCoeff_solenoidal N z))
  simpa only [Complex.re_sum, Complex.zero_re] using h

/-- The native phase-space diagonal pairing agrees with the actual physical
transport integral, whose cancellation was proved independently above. -/
theorem phaseTransport_diagonal_energy_eq_physical (N : ℕ) (z : GalerkinPhase N) :
    inner ℝ z (phaseTransport N z z) =
      ∫ x in unitCube,
        inner ℝ (phaseSynthesis N z x) (convection (phaseSynthesis N z) x) := by
  rw [phaseTransport_diagonal_energy_zero, phaseSynthesis_convection_energy_zero]

end
end MethbokeAddon.EhrenfestObstruction
