import MethbokeAddon.EhrenfestObstruction.PhaseTransportPhysical

set_option autoImplicit false
open Set MeasureTheory SingularClosure
open scoped BigOperators RealInnerProductSpace
open MethbokeAddon.EhrenfestObstruction

example (N : ℕ) (z : GalerkinPhase N) :
    (∫ x in unitCube,
      inner ℝ (phaseSynthesis N z x) (convection (phaseSynthesis N z) x)) = 0 :=
  phaseSynthesis_convection_energy_zero N z

example (N : ℕ) (z : GalerkinPhase N) :
    inner ℝ z (phaseTransport N z z) =
      ∫ x in unitCube,
        inner ℝ (phaseSynthesis N z x) (convection (phaseSynthesis N z) x) :=
  phaseTransport_diagonal_energy_eq_physical N z

#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_convection_energy_zero
#print axioms MethbokeAddon.EhrenfestObstruction.phaseTransport_diagonal_energy_eq_physical
