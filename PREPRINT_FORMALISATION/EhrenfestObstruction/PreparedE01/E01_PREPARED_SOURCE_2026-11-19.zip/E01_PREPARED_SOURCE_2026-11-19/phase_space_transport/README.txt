Prepared supplemental E01 source: PhaseTransport

Status: SOURCE-PREPARED ONLY. No local Lean, Lake, kernel, CI, or repository
publication was run. External cached compiler and axiom checks are required.

Files:
  PhaseTransport.lean              21 public theorem candidates, 4 definitions
  PhaseTransportTypeChecks.lean    21 full theorem-type consumers plus one
                                  explicit bundled-bilinear-map type consumer
  declarations.txt                 ordered inventory of all 21 theorem names
  PhaseTransportAudit.lean         21 named theorem axiom queries plus the
                                  phaseTransportLinear definition query
  PhaseTransportPhysical.lean      2 physical diagonal-pairing theorem candidates
  PhaseTransportPhysicalAudit.lean 2 exact consumers and 2 named axiom queries
  physical_declarations.txt        ordered inventory of both physical theorems

The audit query files are prepared source only. None of their queries has
been executed locally.

Concrete construction:
  coefficientBilinearTransport N a b is the literal nonsymmetric convolution
  for (a dot grad)b. Its diagonal is definitionally coefficientTransport N a.
  The first argument is the advecting field. No symmetric polarization is used.

  phaseRawTransport is its literal retained Fourier array in the native
  GalerkinPhaseAmbient. Its reality is derived by frequency-negation reindexing.
  phaseTransport is the actual native orthogonal phaseProjection applied to
  this array. PhaseLeray identifies this with the literal modewise Leray map.

Main exported consumers:
  phaseTransportLinear N :
    GalerkinPhase N →ₗ[ℝ] GalerkinPhase N →ₗ[ℝ] GalerkinPhase N
  (The Lean type uses curried LinearMap arrows, not ContinuousLinearMap arrows.)

  phaseTransport_coeff identifies every off-diagonal coefficient with
    cutoffCoeff N (fun k => coefficientLeray k
      (coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N b) k)).

  phaseTransport_diagonal : B_N(z,z) = -phaseRhs 0 N z.
  phaseTransport_diagonal_energy_zero : inner real z (B_N(z,z)) = 0.
  phaseRhs_eq_stokes_sub_transport :
    phaseRhs nu N z = (-nu) smul phaseStokes N z - B_N(z,z).

  phaseSynthesis_convection_energy_zero proves the literal cube integral
    integral inner_real (phaseSynthesis z) (convection (phaseSynthesis z)) = 0.
  phaseTransport_diagonal_energy_eq_physical identifies this physical integral
    with the native phase inner product inner_real z (B_N(z,z)).

Dependencies:
  Finalized phase_space/PhaseSpace.lean and PhaseBounds.lean (unchanged).
  Supplemental phase_space_leray/PhaseLeray.lean, using frozen exact exports:
    ambientLeray_coeff
    phaseProjection_coe_eq_ambientLeray_of_reality
  Native SingularClosure.GalerkinReality, inspected at Methboke revision
    5b1d5e89754e82bb3867daefa1af4f887cadd33b.
  The raw-reality proof is the native coefficientTransport_reality proof
  generalized to two independently real coefficient inputs.

No abstract bilinear-map assumption or assumed cancellation is introduced.
