import MethbokeAddon.EhrenfestObstruction.PhaseTransport

set_option autoImplicit false
open SingularClosure
open scoped BigOperators RealInnerProductSpace
open MethbokeAddon.EhrenfestObstruction

example (N : ℕ) (c : FourierCoeff) :
    coefficientBilinearTransport N c c = coefficientTransport N c :=
  coefficientBilinearTransport_diagonal N c

example (N : ℕ) (a b c : FourierCoeff) :
    coefficientBilinearTransport N (a + b) c =
      coefficientBilinearTransport N a c + coefficientBilinearTransport N b c :=
  coefficientBilinearTransport_add_left N a b c

example (N : ℕ) (a b c : FourierCoeff) :
    coefficientBilinearTransport N a (b + c) =
      coefficientBilinearTransport N a b + coefficientBilinearTransport N a c :=
  coefficientBilinearTransport_add_right N a b c

example (N : ℕ) (r : ℝ) (a b : FourierCoeff) :
    coefficientBilinearTransport N (r • a) b = r • coefficientBilinearTransport N a b :=
  coefficientBilinearTransport_smul_left N r a b

example (N : ℕ) (r : ℝ) (a b : FourierCoeff) :
    coefficientBilinearTransport N a (r • b) = r • coefficientBilinearTransport N a b :=
  coefficientBilinearTransport_smul_right N r a b

example (N : ℕ) (a b : FourierCoeff)
    (ha : SpectralReality a) (hb : SpectralReality b) :
    SpectralReality (coefficientBilinearTransport N a b) :=
  coefficientBilinearTransport_reality N a b ha hb

example (N : ℕ) (a b : GalerkinPhase N) :
    hilbertCoeff N (phaseRawTransport N a b) =
      cutoffCoeff N (coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N b)) :=
  phaseRawTransport_coeff N a b

example (N : ℕ) (a b : GalerkinPhase N) :
    SpectralReality (hilbertCoeff N (phaseRawTransport N a b)) :=
  phaseRawTransport_reality N a b

example (N : ℕ) (a b c : GalerkinPhase N) :
    phaseRawTransport N (a + b) c = phaseRawTransport N a c + phaseRawTransport N b c :=
  phaseRawTransport_add_left N a b c

example (N : ℕ) (a b c : GalerkinPhase N) :
    phaseRawTransport N a (b + c) = phaseRawTransport N a b + phaseRawTransport N a c :=
  phaseRawTransport_add_right N a b c

example (N : ℕ) (r : ℝ) (a b : GalerkinPhase N) :
    phaseRawTransport N (r • a) b = r • phaseRawTransport N a b :=
  phaseRawTransport_smul_left N r a b

example (N : ℕ) (r : ℝ) (a b : GalerkinPhase N) :
    phaseRawTransport N a (r • b) = r • phaseRawTransport N a b :=
  phaseRawTransport_smul_right N r a b

example (N : ℕ) (a b : GalerkinPhase N) :
    phaseCoeff N (phaseTransport N a b) =
      cutoffCoeff N (fun k => coefficientLeray k
        (coefficientBilinearTransport N (phaseCoeff N a) (phaseCoeff N b) k)) :=
  phaseTransport_coeff N a b

example (N : ℕ) (a b c : GalerkinPhase N) :
    phaseTransport N (a + b) c = phaseTransport N a c + phaseTransport N b c :=
  phaseTransport_add_left N a b c

example (N : ℕ) (a b c : GalerkinPhase N) :
    phaseTransport N a (b + c) = phaseTransport N a b + phaseTransport N a c :=
  phaseTransport_add_right N a b c

example (N : ℕ) (r : ℝ) (a b : GalerkinPhase N) :
    phaseTransport N (r • a) b = r • phaseTransport N a b :=
  phaseTransport_smul_left N r a b

example (N : ℕ) (r : ℝ) (a b : GalerkinPhase N) :
    phaseTransport N a (r • b) = r • phaseTransport N a b :=
  phaseTransport_smul_right N r a b

example (N : ℕ) (a b : GalerkinPhase N) :
    phaseTransportLinear N a b = phaseTransport N a b :=
  phaseTransportLinear_apply N a b

example (N : ℕ) (z : GalerkinPhase N) :
    phaseTransport N z z = -phaseRhs 0 N z :=
  phaseTransport_diagonal N z

example (N : ℕ) (z : GalerkinPhase N) :
    inner ℝ z (phaseTransport N z z) = 0 :=
  phaseTransport_diagonal_energy_zero N z

example (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    phaseRhs ν N z = (-ν) • phaseStokes N z - phaseTransport N z z :=
  phaseRhs_eq_stokes_sub_transport ν N z

/-- An additional expected-type consumer checks the bundled bilinear map itself. -/
example (N : ℕ) : GalerkinPhase N →ₗ[ℝ] GalerkinPhase N →ₗ[ℝ] GalerkinPhase N :=
  phaseTransportLinear N
