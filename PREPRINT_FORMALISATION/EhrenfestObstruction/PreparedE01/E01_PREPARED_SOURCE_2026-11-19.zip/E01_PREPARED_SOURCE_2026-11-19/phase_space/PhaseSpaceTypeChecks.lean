import MethbokeAddon.EhrenfestObstruction.PhaseSynthesis

/-! Independently stated consumer types for authorized external verification. -/

set_option autoImplicit false

open Set MeasureTheory SingularClosure
open scoped BigOperators ContDiff

namespace MethbokeAddon.EhrenfestObstruction.PhaseSpaceTypeChecks

example (N : ℕ) : FiniteDimensional ℝ (GalerkinPhase N) :=
  galerkinPhase_finiteDimensional N

example (N : ℕ) :
    GalerkinPhase N ≃ₗᵢ[ℝ]
      EuclideanSpace ℝ (Fin (Module.finrank ℝ (GalerkinPhase N))) :=
  phaseCoordinates N

example (N : ℕ) (z : GalerkinPhase N) : ‖phaseCoordinates N z‖ = ‖z‖ :=
  phaseCoordinates_norm N z

example (N : ℕ) (z : GalerkinPhase N) :
    (phaseCoordinates N).symm (phaseCoordinates N z) = z :=
  phaseCoordinates_symm_apply N z

example (N : ℕ) : GalerkinPhaseAmbient N →L[ℝ] GalerkinPhase N :=
  phaseProjection N

example (N : ℕ) (z : GalerkinPhaseAmbient N) :
    (phaseProjection N z).val = z ↔ z ∈ invariantGalerkinSubspace N :=
  phaseProjection_fixed_iff N z

example (N : ℕ) (z : GalerkinPhase N) : phaseProjection N z.val = z :=
  phaseProjection_apply N z

example (N : ℕ) : GalerkinPhase N →ₗ[ℝ] FourierCoeff := phaseCoeff N

example (N : ℕ) (z : GalerkinPhase N)
    (k : ↥(cutoffModes N)) (i : Fin 3) :
    phaseCoeff N z k.val i = z.val (k, i) := phaseCoeff_apply N z k i

example (N : ℕ) (z : GalerkinPhase N)
    (k : Frequency) (hk : k ∉ cutoffModes N) (i : Fin 3) :
    phaseCoeff N z k i = 0 := phaseCoeff_support N z k hk i

example (N : ℕ) (z : GalerkinPhase N) : SpectralReality (phaseCoeff N z) :=
  phaseCoeff_reality N z

example (N : ℕ) (z : GalerkinPhase N) : SpectralSolenoidal (phaseCoeff N z) :=
  phaseCoeff_solenoidal N z

example (N : ℕ) (z : GalerkinPhase N) : SpectralMeanZero (phaseCoeff N z) :=
  phaseCoeff_meanZero N z

example (N : ℕ) (z : GalerkinPhase N) :
    cutoffCoeff N (phaseCoeff N z) = phaseCoeff N z := phaseCoeff_cutoff N z

example (N : ℕ) : Function.Injective (phaseCoeff N) := phaseCoeff_injective N

example (N : ℕ) (z : GalerkinPhase N) :
    coefficientEnergy N (phaseCoeff N z) = ‖z‖ ^ 2 := phaseCoeff_energy_eq_norm_sq N z

example (N : ℕ) (z : GalerkinPhase N) :
    (∑ i : Fin (Module.finrank ℝ (GalerkinPhase N)), (phaseCoordinates N z i) ^ 2) =
      coefficientEnergy N (phaseCoeff N z) := phaseCoordinates_energy N z

example (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    (phaseRhs ν N z).val = hilbertGalerkinRhs ν N z.val := phaseRhs_coe ν N z

example (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    phaseCoeff N (phaseRhs ν N z) = cutoffCoeff N (galerkinRhs ν N (phaseCoeff N z)) :=
  phaseRhs_coeff ν N z

example (ν : ℝ) (N : ℕ) : ContDiff ℝ ∞ (phaseRhs ν N) := phaseRhs_contDiff ν N

example (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRhs ν N z) =
      -ν * coefficientDissipation N (phaseCoeff N z) := phaseRhs_radial_energy ν N z

example (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRhs 0 N z) = 0 := phaseRhs_inviscid_radial_zero N z

example (ν : ℝ) (hν : 0 ≤ ν) (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRhs ν N z) ≤ 0 := phaseRhs_dissipative ν hν N z

example (N : ℕ) (z : GalerkinPhase N) :
    phaseSynthesis N z = finiteSynthesis N (phaseCoeff N z) := rfl

example (N : ℕ) (z : GalerkinPhase N) : ContDiff ℝ ∞ (phaseSynthesis N z) :=
  phaseSynthesis_smooth N z

example (N : ℕ) (z : GalerkinPhase N) : SpatialPeriodic (phaseSynthesis N z) :=
  phaseSynthesis_periodic N z

example (N : ℕ) (z : GalerkinPhase N) (x : Vec) :
    divergence (phaseSynthesis N z) x = 0 := phaseSynthesis_divergence_free N z x

example (N : ℕ) (z : GalerkinPhase N) :
    datumFourierCoeff (phaseSynthesis N z) = phaseCoeff N z :=
  datumFourierCoeff_phaseSynthesis N z

example (N : ℕ) : Function.Injective (phaseSynthesis N) := phaseSynthesis_injective N

example (N : ℕ) (z : GalerkinPhase N) : MeanZero (phaseSynthesis N z) :=
  phaseSynthesis_meanZero N z

example (N : ℕ) (z : GalerkinPhase N) : SmoothSigmaZero (phaseSynthesis N z) :=
  phaseSynthesis_smoothSigmaZero N z

example (N : ℕ) (z : GalerkinPhase N) :
    physicalEnergy (phaseSynthesis N z) = ‖z‖ ^ 2 := phaseSynthesis_physicalEnergy N z

example (N : ℕ) (z : GalerkinPhase N) :
    (∫ x in unitCube, ‖phaseSynthesis N z x‖ ^ 2) = ‖z‖ ^ 2 :=
  phaseSynthesis_integral_norm_sq N z

example (N : ℕ) (z : GalerkinPhase N) :
    (∫ x in unitCube, gradientSquareDensity (phaseSynthesis N z) x) =
      coefficientDissipation N (phaseCoeff N z) := phaseSynthesis_gradient_energy N z

end MethbokeAddon.EhrenfestObstruction.PhaseSpaceTypeChecks

#print axioms MethbokeAddon.EhrenfestObstruction.galerkinPhase_finiteDimensional
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinates
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinates_norm
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinates_symm_apply
#print axioms MethbokeAddon.EhrenfestObstruction.phaseProjection
#print axioms MethbokeAddon.EhrenfestObstruction.phaseProjection_fixed_iff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseProjection_apply
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff_apply
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff_support
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff_reality
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff_solenoidal
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff_meanZero
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff_cutoff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff_injective
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff_energy_eq_norm_sq
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoordinates_energy
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_coe
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_contDiff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_radial_energy
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_inviscid_radial_zero
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_dissipative
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_smooth
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_periodic
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_divergence_free
#print axioms MethbokeAddon.EhrenfestObstruction.datumFourierCoeff_phaseSynthesis
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_injective
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_meanZero
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_smoothSigmaZero
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_physicalEnergy
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_integral_norm_sq
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_gradient_energy
