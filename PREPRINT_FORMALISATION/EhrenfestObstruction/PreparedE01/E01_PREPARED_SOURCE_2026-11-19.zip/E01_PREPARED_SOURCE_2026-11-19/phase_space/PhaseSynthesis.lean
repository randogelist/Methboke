import MethbokeAddon.EhrenfestObstruction.PhaseSpace
import SingularClosure.CriticalGalerkin

/-!
# Physical realization of the actual finite Galerkin phase space

Fourier coefficients are recovered by actual cube integration. The physical
synthesis is injective, smooth, periodic, solenoidal and mean zero. Its
physical squared L2 norm is precisely the inherited phase-space norm square.
All statements concern finite Fourier sums and actual physical integrals.
-/

set_option autoImplicit false

open Set MeasureTheory SingularClosure
open scoped BigOperators ContDiff

namespace MethbokeAddon.EhrenfestObstruction

noncomputable section

/-- The actual real trigonometric polynomial corresponding to a phase point. -/
def phaseSynthesis (N : ℕ) (z : GalerkinPhase N) : Field :=
  finiteSynthesis N (phaseCoeff N z)

theorem phaseSynthesis_smooth (N : ℕ) (z : GalerkinPhase N) :
    ContDiff ℝ ∞ (phaseSynthesis N z) :=
  finiteSynthesis_contDiff N (phaseCoeff N z)

theorem phaseSynthesis_periodic (N : ℕ) (z : GalerkinPhase N) :
    SpatialPeriodic (phaseSynthesis N z) :=
  finiteSynthesis_periodic N (phaseCoeff N z)

theorem phaseSynthesis_divergence_free (N : ℕ) (z : GalerkinPhase N) (x : Vec) :
    divergence (phaseSynthesis N z) x = 0 :=
  finiteSynthesis_divergence_free N (phaseCoeff N z) (phaseCoeff_solenoidal N z) x

/-- Literal cube Fourier integration recovers all zero-extended coefficients. -/
theorem datumFourierCoeff_phaseSynthesis (N : ℕ) (z : GalerkinPhase N) :
    datumFourierCoeff (phaseSynthesis N z) = phaseCoeff N z := by
  change datumFourierCoeff (finiteSynthesis N (phaseCoeff N z)) = _
  rw [criticalGalerkin_datumFourierCoeff_finiteSynthesis N (phaseCoeff N z)
    (phaseCoeff_reality N z), phaseCoeff_cutoff]

theorem phaseSynthesis_injective (N : ℕ) : Function.Injective (phaseSynthesis N) := by
  intro z w h
  apply phaseCoeff_injective N
  have hc := congrArg datumFourierCoeff h
  simpa only [datumFourierCoeff_phaseSynthesis] using hc

theorem phaseSynthesis_meanZero (N : ℕ) (z : GalerkinPhase N) :
    MeanZero (phaseSynthesis N z) := by
  have hi : IntegrableOn (phaseSynthesis N z) unitCube volume :=
    (phaseSynthesis_smooth N z).continuous.continuousOn.integrableOn_compact
      isCompact_unitCube
  refine ⟨hi, ?_⟩
  ext i
  have hz := congrFun (congrFun (datumFourierCoeff_phaseSynthesis N z) 0) i
  rw [datumFourierCoeff_zero hi i, phaseCoeff_meanZero N z i] at hz
  have hr := congrArg Complex.re hz
  simpa using hr

theorem phaseSynthesis_smoothSigmaZero (N : ℕ) (z : GalerkinPhase N) :
    SmoothSigmaZero (phaseSynthesis N z) :=
  ⟨phaseSynthesis_smooth N z, phaseSynthesis_periodic N z,
    phaseSynthesis_divergence_free N z, phaseSynthesis_meanZero N z⟩

theorem phaseSynthesis_physicalEnergy (N : ℕ) (z : GalerkinPhase N) :
    physicalEnergy (phaseSynthesis N z) = ‖z‖ ^ 2 := by
  change physicalEnergy (finiteSynthesis N (phaseCoeff N z)) = _
  rw [FINITE_PHYSICAL_ENERGY_PARSEVAL N (phaseCoeff N z) (phaseCoeff_reality N z),
    phaseCoeff_energy_eq_norm_sq]

theorem phaseSynthesis_integral_norm_sq (N : ℕ) (z : GalerkinPhase N) :
    (∫ x in unitCube, ‖phaseSynthesis N z x‖ ^ 2) = ‖z‖ ^ 2 := by
  rw [← physicalEnergy_eq_integral_norm_sq, phaseSynthesis_physicalEnergy]

theorem phaseSynthesis_gradient_energy (N : ℕ) (z : GalerkinPhase N) :
    (∫ x in unitCube, gradientSquareDensity (phaseSynthesis N z) x) =
      coefficientDissipation N (phaseCoeff N z) :=
  FINITE_PHYSICAL_REAL_ENSTROPHY_PARSEVAL N (phaseCoeff N z) (phaseCoeff_reality N z)

end

end MethbokeAddon.EhrenfestObstruction
