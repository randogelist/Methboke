import MethbokeAddon.EhrenfestObstruction.PhaseMultipliers
import SingularClosure.PeriodicPoincare

/-! The actual bounded positive self-adjoint Stokes operator at a finite cutoff.
The upper spectral bound uses the native nonzero Euclidean cutoff ball.
This bounded finite-dimensional operator is separate from the later unbounded
transport generator in the quantum realization. -/

set_option autoImplicit false

open SingularClosure
open scoped BigOperators

namespace MethbokeAddon.EhrenfestObstruction

noncomputable section

def phaseStokesSymbol (k : Frequency) : ℝ :=
  (2 * Real.pi) ^ 2 * (galerkinFreqSq k : ℝ)

theorem phaseStokesSymbol_even (k : Frequency) :
    phaseStokesSymbol (-k) = phaseStokesSymbol k := by
  simp [phaseStokesSymbol, galerkinFreqSq]

theorem phaseStokesSymbol_nonneg (k : Frequency) : 0 ≤ phaseStokesSymbol k := by
  have hk : 0 ≤ (galerkinFreqSq k : ℝ) := by
    exact_mod_cast galerkinFreqSq_nonneg k
  exact mul_nonneg (sq_nonneg _) hk

/-- Justified by the Euclidean radius in the native cutoff, not its enumerating cube. -/
def phaseLambdaMax (N : ℕ) : ℝ := (2 * Real.pi) ^ 2 * (N : ℝ) ^ 2

theorem phaseLambdaMax_nonneg (N : ℕ) : 0 ≤ phaseLambdaMax N :=
  mul_nonneg (sq_nonneg _) (sq_nonneg _)

theorem phaseStokesSymbol_le_lambdaMax (N : ℕ) (k : Frequency)
    (hk : k ∈ cutoffModes N) : phaseStokesSymbol k ≤ phaseLambdaMax N := by
  have hfreq : (galerkinFreqSq k : ℝ) ≤ (N : ℝ) ^ 2 := by
    exact_mod_cast ((mem_cutoffModes_iff N k).mp hk).2.2
  exact mul_le_mul_of_nonneg_left hfreq (sq_nonneg _)

def phaseStokes (N : ℕ) : GalerkinPhase N →L[ℝ] GalerkinPhase N :=
  phaseRealMultiplier N phaseStokesSymbol phaseStokesSymbol_even

theorem phaseStokes_coeff (N : ℕ) (z : GalerkinPhase N) :
    phaseCoeff N (phaseStokes N z) =
      spectralMultiplier (fun k => (phaseStokesSymbol k : ℂ)) (phaseCoeff N z) :=
  phaseRealMultiplier_coeff N phaseStokesSymbol phaseStokesSymbol_even z

theorem phaseStokes_selfAdjoint (N : ℕ) : IsSelfAdjoint (phaseStokes N) :=
  phaseRealMultiplier_selfAdjoint N phaseStokesSymbol phaseStokesSymbol_even

theorem phaseStokes_quadratic (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseStokes N z) =
      coefficientDissipation N (phaseCoeff N z) := by
  change inner (𝕜 := ℝ) z
    (phaseRealMultiplier N phaseStokesSymbol phaseStokesSymbol_even z) = _
  rw [phaseRealMultiplier_quadratic, Fintype.sum_prod_type]
  calc
    (∑ k : ↥(cutoffModes N), ∑ i : Fin 3,
        phaseStokesSymbol k.val * ‖z.val (k, i)‖ ^ 2) =
        ∑ k : ↥(cutoffModes N), ∑ i : Fin 3,
          (2 * Real.pi) ^ 2 * (galerkinFreqSq k.val : ℝ) *
            Complex.normSq (phaseCoeff N z k.val i) := by
      apply Finset.sum_congr rfl
      intro k hk
      apply Finset.sum_congr rfl
      intro i hi
      simp only [phaseStokesSymbol, phaseCoeff_apply, Complex.normSq_eq_norm_sq]
    _ = coefficientDissipation N (phaseCoeff N z) :=
      Finset.sum_coe_sort (cutoffModes N)
        (fun k => ∑ i : Fin 3, (2 * Real.pi) ^ 2 * (galerkinFreqSq k : ℝ) *
          Complex.normSq (phaseCoeff N z k i))

theorem phaseStokes_nonneg (N : ℕ) (z : GalerkinPhase N) :
    0 ≤ inner (𝕜 := ℝ) z (phaseStokes N z) := by
  rw [phaseStokes_quadratic]
  exact coefficientDissipation_nonneg N (phaseCoeff N z)

theorem phaseStokes_poincare (N : ℕ) (z : GalerkinPhase N) :
    4 * Real.pi ^ 2 * ‖z‖ ^ 2 ≤ inner (𝕜 := ℝ) z (phaseStokes N z) := by
  rw [phaseStokes_quadratic, ← phaseCoeff_energy_eq_norm_sq]
  exact COEFFICIENT_POINCARE N (phaseCoeff N z)

theorem phaseStokes_pos_of_ne_zero (N : ℕ) (z : GalerkinPhase N) (hz : z ≠ 0) :
    0 < inner (𝕜 := ℝ) z (phaseStokes N z) := by
  have hnorm : 0 < ‖z‖ := norm_pos_iff.mpr hz
  have hgap : 0 < 4 * Real.pi ^ 2 * ‖z‖ ^ 2 := by positivity
  exact hgap.trans_le (phaseStokes_poincare N z)

theorem phaseStokes_quadratic_le_lambdaMax (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseStokes N z) ≤ phaseLambdaMax N * ‖z‖ ^ 2 :=
  phaseRealMultiplier_quadratic_le N phaseStokesSymbol phaseStokesSymbol_even
    (phaseLambdaMax N) (phaseStokesSymbol_le_lambdaMax N) z

theorem phaseStokes_opNorm_le_lambdaMax (N : ℕ) :
    ‖phaseStokes N‖ ≤ phaseLambdaMax N := by
  apply phaseRealMultiplier_opNorm_le N phaseStokesSymbol phaseStokesSymbol_even
    (phaseLambdaMax N) (phaseLambdaMax_nonneg N)
  intro k hk
  rw [abs_of_nonneg (phaseStokesSymbol_nonneg k)]
  exact phaseStokesSymbol_le_lambdaMax N k hk

theorem phaseRhs_stokes_energy (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRhs ν N z) =
      -ν * inner (𝕜 := ℝ) z (phaseStokes N z) := by
  rw [phaseRhs_radial_energy, phaseStokes_quadratic]

end

end MethbokeAddon.EhrenfestObstruction
