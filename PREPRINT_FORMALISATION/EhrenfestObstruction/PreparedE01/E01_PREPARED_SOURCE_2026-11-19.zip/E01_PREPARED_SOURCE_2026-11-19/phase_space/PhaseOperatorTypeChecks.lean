import MethbokeAddon.EhrenfestObstruction.PhaseCutoffs
import MethbokeAddon.EhrenfestObstruction.PhaseBounds

/-! Exact consumer propositions for the retained E01 operator supplement. -/

set_option autoImplicit false
open Set Metric SingularClosure
open scoped BigOperators ContDiff

namespace MethbokeAddon.EhrenfestObstruction.PhaseOperatorTypeChecks

example (N : ℕ) (m : Frequency → ℂ) (z : GalerkinPhaseAmbient N) :
    hilbertCoeff N (phaseMultiplierHilbert N m z) = spectralMultiplier m (hilbertCoeff N z) :=
  phaseMultiplierHilbert_coeff N m z

example (N : ℕ) (m : Frequency → ℂ) (hm : ∀ k, m (-k) = star (m k))
    (z : GalerkinPhase N) :
    phaseMultiplierHilbert N m z.val ∈ invariantGalerkinSubspace N :=
  phaseMultiplierHilbert_mem N m hm z

example (N : ℕ) (m : Frequency → ℂ) (hm : ∀ k, m (-k) = star (m k)) :
    GalerkinPhase N →ₗ[ℝ] GalerkinPhase N := phaseMultiplierLinear N m hm

example (N : ℕ) (m : Frequency → ℂ) (hm : ∀ k, m (-k) = star (m k)) :
    GalerkinPhase N →L[ℝ] GalerkinPhase N := phaseMultiplier N m hm

example (N : ℕ) (m : Frequency → ℂ) (hm : ∀ k, m (-k) = star (m k))
    (z : GalerkinPhase N) (ki : ↥(cutoffModes N) × Fin 3) :
    (phaseMultiplier N m hm z).val ki = m ki.1.val * z.val ki :=
  phaseMultiplier_apply N m hm z ki

example (N : ℕ) (m : Frequency → ℂ) (hm : ∀ k, m (-k) = star (m k))
    (z : GalerkinPhase N) :
    phaseCoeff N (phaseMultiplier N m hm z) = spectralMultiplier m (phaseCoeff N z) :=
  phaseMultiplier_coeff N m hm z

example (N : ℕ) (m n : Frequency → ℂ)
    (hm : ∀ k, m (-k) = star (m k)) (hn : ∀ k, n (-k) = star (n k))
    (z : GalerkinPhase N) :
    phaseMultiplier N m hm (phaseMultiplier N n hn z) =
      phaseMultiplier N n hn (phaseMultiplier N m hm z) :=
  phaseMultiplier_commute N m n hm hn z

example (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k) (k : Frequency) :
    (m (-k) : ℂ) = star (m k : ℂ) := phaseRealSymbol_reality m hm k

example (N : ℕ) (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k) :
    GalerkinPhase N →L[ℝ] GalerkinPhase N := phaseRealMultiplier N m hm

example (N : ℕ) (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k)
    (z : GalerkinPhase N) (ki : ↥(cutoffModes N) × Fin 3) :
    (phaseRealMultiplier N m hm z).val ki = m ki.1.val • z.val ki :=
  phaseRealMultiplier_apply N m hm z ki

example (N : ℕ) (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k)
    (z : GalerkinPhase N) :
    phaseCoeff N (phaseRealMultiplier N m hm z) =
      spectralMultiplier (fun k => (m k : ℂ)) (phaseCoeff N z) :=
  phaseRealMultiplier_coeff N m hm z

example (N : ℕ) (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k) :
    IsSelfAdjoint (phaseRealMultiplier N m hm) := phaseRealMultiplier_selfAdjoint N m hm

example (N : ℕ) (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k)
    (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRealMultiplier N m hm z) =
      ∑ ki : ↥(cutoffModes N) × Fin 3, m ki.1.val * ‖z.val ki‖ ^ 2 :=
  phaseRealMultiplier_quadratic N m hm z

example (N : ℕ) (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k)
    (hpos : ∀ k ∈ cutoffModes N, 0 ≤ m k) (z : GalerkinPhase N) :
    0 ≤ inner (𝕜 := ℝ) z (phaseRealMultiplier N m hm z) :=
  phaseRealMultiplier_nonneg N m hm hpos z

example (N : ℕ) (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k)
    (M : ℝ) (hbound : ∀ k ∈ cutoffModes N, m k ≤ M) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRealMultiplier N m hm z) ≤ M * ‖z‖ ^ 2 :=
  phaseRealMultiplier_quadratic_le N m hm M hbound z

example (N : ℕ) (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k)
    (M : ℝ) (hM : 0 ≤ M) (hbound : ∀ k ∈ cutoffModes N, |m k| ≤ M)
    (z : GalerkinPhase N) :
    ‖phaseRealMultiplier N m hm z‖ ≤ M * ‖z‖ :=
  phaseRealMultiplier_norm_le N m hm M hM hbound z

example (N : ℕ) (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k)
    (M : ℝ) (hM : 0 ≤ M) (hbound : ∀ k ∈ cutoffModes N, |m k| ≤ M) :
    ‖phaseRealMultiplier N m hm‖ ≤ M := phaseRealMultiplier_opNorm_le N m hm M hM hbound

example (k : Frequency) : phaseStokesSymbol (-k) = phaseStokesSymbol k :=
  phaseStokesSymbol_even k

example (k : Frequency) : 0 ≤ phaseStokesSymbol k := phaseStokesSymbol_nonneg k

example (N : ℕ) : phaseLambdaMax N = (2 * Real.pi) ^ 2 * (N : ℝ) ^ 2 := rfl

example (N : ℕ) : 0 ≤ phaseLambdaMax N := phaseLambdaMax_nonneg N

example (N : ℕ) (k : Frequency) (hk : k ∈ cutoffModes N) :
    phaseStokesSymbol k ≤ phaseLambdaMax N := phaseStokesSymbol_le_lambdaMax N k hk

example (N : ℕ) : GalerkinPhase N →L[ℝ] GalerkinPhase N := phaseStokes N

example (N : ℕ) (z : GalerkinPhase N) :
    phaseCoeff N (phaseStokes N z) =
      spectralMultiplier (fun k => (phaseStokesSymbol k : ℂ)) (phaseCoeff N z) :=
  phaseStokes_coeff N z

example (N : ℕ) : IsSelfAdjoint (phaseStokes N) := phaseStokes_selfAdjoint N

example (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseStokes N z) = coefficientDissipation N (phaseCoeff N z) :=
  phaseStokes_quadratic N z

example (N : ℕ) (z : GalerkinPhase N) :
    0 ≤ inner (𝕜 := ℝ) z (phaseStokes N z) := phaseStokes_nonneg N z

example (N : ℕ) (z : GalerkinPhase N) :
    4 * Real.pi ^ 2 * ‖z‖ ^ 2 ≤ inner (𝕜 := ℝ) z (phaseStokes N z) :=
  phaseStokes_poincare N z

example (N : ℕ) (z : GalerkinPhase N) (hz : z ≠ 0) :
    0 < inner (𝕜 := ℝ) z (phaseStokes N z) := phaseStokes_pos_of_ne_zero N z hz

example (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseStokes N z) ≤ phaseLambdaMax N * ‖z‖ ^ 2 :=
  phaseStokes_quadratic_le_lambdaMax N z

example (N : ℕ) : ‖phaseStokes N‖ ≤ phaseLambdaMax N := phaseStokes_opNorm_le_lambdaMax N

example (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRhs ν N z) = -ν * inner (𝕜 := ℝ) z (phaseStokes N z) :=
  phaseRhs_stokes_energy ν N z

example (M : ℕ) (k : Frequency) : phaseCutoffSymbol M (-k) = phaseCutoffSymbol M k :=
  phaseCutoffSymbol_even M k

example (N M : ℕ) : GalerkinPhase N →L[ℝ] GalerkinPhase N := phaseCutoff N M

example (N M : ℕ) (z : GalerkinPhase N) :
    phaseCoeff N (phaseCutoff N M z) = cutoffCoeff M (phaseCoeff N z) := phaseCutoff_coeff N M z

example (N : ℕ) (z : GalerkinPhase N) : phaseCutoff N N z = z := phaseCutoff_same N z

example (N M : ℕ) (z : GalerkinPhase N) :
    phaseCutoff N M (phaseCutoff N M z) = phaseCutoff N M z := phaseCutoff_idempotent N M z

example (N M : ℕ) : IsSelfAdjoint (phaseCutoff N M) := phaseCutoff_selfAdjoint N M

example (N M : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) (phaseCutoff N M z) (z - phaseCutoff N M z) = 0 :=
  phaseCutoff_orthogonal_residual N M z

example (N M : ℕ) : ‖phaseCutoff N M‖ ≤ 1 := phaseCutoff_opNorm_le_one N M

example (N M : ℕ) (z : GalerkinPhase N) :
    phaseCutoff N M (phaseStokes N z) = phaseStokes N (phaseCutoff N M z) :=
  phaseCutoff_stokes_commute N M z

example (N : ℕ) (j : Fin 3) : GalerkinPhase N →L[ℝ] GalerkinPhase N := phaseDerivative N j

example (N : ℕ) (j : Fin 3) (z : GalerkinPhase N) :
    phaseCoeff N (phaseDerivative N j z) =
      spectralMultiplier (derivativeSymbol j) (phaseCoeff N z) := phaseDerivative_coeff N j z

example (N : ℕ) (j : Fin 3) (z : GalerkinPhase N) :
    phaseSynthesis N (phaseDerivative N j z) = coordinateDerivative (phaseSynthesis N z) j :=
  phaseDerivative_synthesis N j z

example (N M : ℕ) (j : Fin 3) (z : GalerkinPhase N) :
    phaseCutoff N M (phaseDerivative N j z) = phaseDerivative N j (phaseCutoff N M z) :=
  phaseCutoff_derivative_commute N M j z

example (N : ℕ) (j : Fin 3) (z : GalerkinPhase N) :
    phaseStokes N (phaseDerivative N j z) = phaseDerivative N j (phaseStokes N z) :=
  phaseStokes_derivative_commute N j z

example (N : ℕ) (z : GalerkinPhase N) : phaseSynthesis N (-z) = -phaseSynthesis N z :=
  phaseSynthesis_neg N z

example (N : ℕ) (z : GalerkinPhase N) :
    laplacian (phaseSynthesis N z) = phaseSynthesis N (-phaseStokes N z) :=
  phaseLaplacian_synthesis N z

example (N : ℕ) (z : GalerkinPhase N) :
    phaseSynthesis N (phaseStokes N z) = -laplacian (phaseSynthesis N z) :=
  phaseStokes_synthesis N z

example (ν : ℝ) (N : ℕ) (R : ℝ) :
    ∃ K : ℝ≥0, LipschitzOnWith K (phaseRhs ν N) (closedBall (0 : GalerkinPhase N) R) :=
  phaseRhs_lipschitzOn_closedBall ν N R

example (N : ℕ) (z : GalerkinPhase N) :
    coefficientDissipation N (phaseCoeff N z) ≤ phaseLambdaMax N * ‖z‖ ^ 2 :=
  phaseDissipation_le_lambdaMax_energy N z

example (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    phaseRhs ν N z = (-ν) • phaseStokes N z + phaseRhs 0 N z := phaseRhs_stokes_split ν N z

example (ν : ℝ) (hν : 0 ≤ ν) (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (-phaseRhs ν N z) ≤ (ν * phaseLambdaMax N) * ‖z‖ ^ 2 :=
  phaseRhs_reverse_radial_le ν hν N z

end MethbokeAddon.EhrenfestObstruction.PhaseOperatorTypeChecks

#print axioms MethbokeAddon.EhrenfestObstruction.phaseMultiplierHilbert_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseMultiplierHilbert_mem
#print axioms MethbokeAddon.EhrenfestObstruction.phaseMultiplierLinear
#print axioms MethbokeAddon.EhrenfestObstruction.phaseMultiplier
#print axioms MethbokeAddon.EhrenfestObstruction.phaseMultiplier_apply
#print axioms MethbokeAddon.EhrenfestObstruction.phaseMultiplier_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseMultiplier_commute
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealSymbol_reality
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealMultiplier
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealMultiplier_apply
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealMultiplier_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealMultiplier_selfAdjoint
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealMultiplier_quadratic
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealMultiplier_nonneg
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealMultiplier_quadratic_le
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealMultiplier_norm_le
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRealMultiplier_opNorm_le
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokesSymbol_even
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokesSymbol_nonneg
#print axioms MethbokeAddon.EhrenfestObstruction.phaseLambdaMax
#print axioms MethbokeAddon.EhrenfestObstruction.phaseLambdaMax_nonneg
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokesSymbol_le_lambdaMax
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_selfAdjoint
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_quadratic
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_nonneg
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_poincare
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_pos_of_ne_zero
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_quadratic_le_lambdaMax
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_opNorm_le_lambdaMax
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_stokes_energy
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoffSymbol_even
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoff_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoff_same
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoff_idempotent
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoff_selfAdjoint
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoff_orthogonal_residual
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoff_opNorm_le_one
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoff_stokes_commute
#print axioms MethbokeAddon.EhrenfestObstruction.phaseDerivative
#print axioms MethbokeAddon.EhrenfestObstruction.phaseDerivative_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseDerivative_synthesis
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCutoff_derivative_commute
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_derivative_commute
#print axioms MethbokeAddon.EhrenfestObstruction.phaseSynthesis_neg
#print axioms MethbokeAddon.EhrenfestObstruction.phaseLaplacian_synthesis
#print axioms MethbokeAddon.EhrenfestObstruction.phaseStokes_synthesis
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_lipschitzOn_closedBall
#print axioms MethbokeAddon.EhrenfestObstruction.phaseDissipation_le_lambdaMax_energy
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_stokes_split
#print axioms MethbokeAddon.EhrenfestObstruction.phaseRhs_reverse_radial_le
