import MethbokeAddon.EhrenfestObstruction.PhaseSpace
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Tactic.Ring

/-! Actual finite Fourier multipliers on the native real Galerkin phase.
The symbol parity hypotheses are explicit algebraic identities; the concrete
Stokes, cutoff and derivative instances prove them from their definitions. -/

set_option autoImplicit false

open SingularClosure
open scoped BigOperators

namespace MethbokeAddon.EhrenfestObstruction

noncomputable section

def phaseMultiplierHilbert (N : ℕ) (m : Frequency → ℂ)
    (z : GalerkinPhaseAmbient N) : GalerkinPhaseAmbient N :=
  WithLp.toLp 2 (fun ki => m ki.1.val * z ki)

theorem phaseMultiplierHilbert_coeff (N : ℕ) (m : Frequency → ℂ)
    (z : GalerkinPhaseAmbient N) :
    hilbertCoeff N (phaseMultiplierHilbert N m z) =
      spectralMultiplier m (hilbertCoeff N z) := by
  funext k i
  by_cases hk : k ∈ cutoffModes N <;>
    simp [phaseMultiplierHilbert, hilbertCoeff, extendFiniteState, spectralMultiplier, hk]

theorem phaseMultiplierHilbert_mem (N : ℕ) (m : Frequency → ℂ)
    (hm : ∀ k, m (-k) = star (m k)) (z : GalerkinPhase N) :
    phaseMultiplierHilbert N m z.val ∈ invariantGalerkinSubspace N := by
  change SpectralReality (hilbertCoeff N (phaseMultiplierHilbert N m z.val)) ∧
    SpectralSolenoidal (hilbertCoeff N (phaseMultiplierHilbert N m z.val))
  rw [phaseMultiplierHilbert_coeff]
  constructor
  · intro k i
    simp only [spectralMultiplier, hm k, z.property.1 k i, Complex.star_def, map_mul]
  · intro k
    change (∑ i : Fin 3, (k i : ℂ) *
      (m k * hilbertCoeff N z.val k i)) = 0
    have hsum : (∑ i : Fin 3, (k i : ℂ) *
        (m k * hilbertCoeff N z.val k i)) =
        m k * ∑ i : Fin 3, (k i : ℂ) * hilbertCoeff N z.val k i := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro i hi
      ring
    rw [hsum, z.property.2 k, mul_zero]

def phaseMultiplierLinear (N : ℕ) (m : Frequency → ℂ)
    (hm : ∀ k, m (-k) = star (m k)) : GalerkinPhase N →ₗ[ℝ] GalerkinPhase N where
  toFun z := ⟨phaseMultiplierHilbert N m z.val, phaseMultiplierHilbert_mem N m hm z⟩
  map_add' z w := by
    apply Subtype.ext
    ext ki
    change m ki.1.val * (z.val ki + w.val ki) =
      m ki.1.val * z.val ki + m ki.1.val * w.val ki
    exact mul_add _ _ _
  map_smul' r z := by
    apply Subtype.ext
    ext ki
    change m ki.1.val * (r • z.val ki) = r • (m ki.1.val * z.val ki)
    exact mul_smul_comm _ _ _

/-- The concrete multiplier is bounded because its domain is finite dimensional. -/
def phaseMultiplier (N : ℕ) (m : Frequency → ℂ)
    (hm : ∀ k, m (-k) = star (m k)) : GalerkinPhase N →L[ℝ] GalerkinPhase N :=
  (phaseMultiplierLinear N m hm).toContinuousLinearMap

theorem phaseMultiplier_apply (N : ℕ) (m : Frequency → ℂ)
    (hm : ∀ k, m (-k) = star (m k)) (z : GalerkinPhase N)
    (ki : ↥(cutoffModes N) × Fin 3) :
    (phaseMultiplier N m hm z).val ki = m ki.1.val * z.val ki := rfl

theorem phaseMultiplier_coeff (N : ℕ) (m : Frequency → ℂ)
    (hm : ∀ k, m (-k) = star (m k)) (z : GalerkinPhase N) :
    phaseCoeff N (phaseMultiplier N m hm z) = spectralMultiplier m (phaseCoeff N z) :=
  phaseMultiplierHilbert_coeff N m z.val

/-- Scalar Fourier multipliers commute on the same actual phase space. -/
theorem phaseMultiplier_commute (N : ℕ) (m n : Frequency → ℂ)
    (hm : ∀ k, m (-k) = star (m k)) (hn : ∀ k, n (-k) = star (n k))
    (z : GalerkinPhase N) :
    phaseMultiplier N m hm (phaseMultiplier N n hn z) =
      phaseMultiplier N n hn (phaseMultiplier N m hm z) := by
  apply phaseCoeff_injective N
  simp only [phaseMultiplier_coeff]
  funext k i
  simp only [spectralMultiplier]
  ring

theorem phaseRealSymbol_reality (m : Frequency → ℝ) (hm : ∀ k, m (-k) = m k)
    (k : Frequency) : (m (-k) : ℂ) = star (m k : ℂ) := by
  rw [hm k]
  simp

def phaseRealMultiplier (N : ℕ) (m : Frequency → ℝ)
    (hm : ∀ k, m (-k) = m k) : GalerkinPhase N →L[ℝ] GalerkinPhase N :=
  phaseMultiplier N (fun k => (m k : ℂ)) (phaseRealSymbol_reality m hm)

theorem phaseRealMultiplier_apply (N : ℕ) (m : Frequency → ℝ)
    (hm : ∀ k, m (-k) = m k) (z : GalerkinPhase N)
    (ki : ↥(cutoffModes N) × Fin 3) :
    (phaseRealMultiplier N m hm z).val ki = m ki.1.val • z.val ki := by
  change (m ki.1.val : ℂ) * z.val ki = m ki.1.val • z.val ki
  rw [Complex.real_smul]

theorem phaseRealMultiplier_coeff (N : ℕ) (m : Frequency → ℝ)
    (hm : ∀ k, m (-k) = m k) (z : GalerkinPhase N) :
    phaseCoeff N (phaseRealMultiplier N m hm z) =
      spectralMultiplier (fun k => (m k : ℂ)) (phaseCoeff N z) :=
  phaseMultiplier_coeff N _ _ z

/-- Actual bounded-operator self-adjointness, derived from the coordinate formula. -/
theorem phaseRealMultiplier_selfAdjoint (N : ℕ) (m : Frequency → ℝ)
    (hm : ∀ k, m (-k) = m k) : IsSelfAdjoint (phaseRealMultiplier N m hm) := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  intro z w
  change inner (𝕜 := ℝ) (phaseRealMultiplier N m hm z).val w.val =
    inner (𝕜 := ℝ) z.val (phaseRealMultiplier N m hm w).val
  rw [PiLp.inner_apply, PiLp.inner_apply]
  apply Finset.sum_congr rfl
  intro ki hki
  rw [phaseRealMultiplier_apply, phaseRealMultiplier_apply]
  simp only [inner_smul_left, inner_smul_right, star_trivial]

theorem phaseRealMultiplier_quadratic (N : ℕ) (m : Frequency → ℝ)
    (hm : ∀ k, m (-k) = m k) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRealMultiplier N m hm z) =
      ∑ ki : ↥(cutoffModes N) × Fin 3, m ki.1.val * ‖z.val ki‖ ^ 2 := by
  change inner (𝕜 := ℝ) z.val (phaseRealMultiplier N m hm z).val = _
  rw [PiLp.inner_apply]
  apply Finset.sum_congr rfl
  intro ki hki
  rw [phaseRealMultiplier_apply, inner_smul_right, real_inner_self_eq_norm_sq]

theorem phaseRealMultiplier_nonneg (N : ℕ) (m : Frequency → ℝ)
    (hm : ∀ k, m (-k) = m k) (hpos : ∀ k ∈ cutoffModes N, 0 ≤ m k)
    (z : GalerkinPhase N) : 0 ≤ inner (𝕜 := ℝ) z (phaseRealMultiplier N m hm z) := by
  rw [phaseRealMultiplier_quadratic]
  exact Finset.sum_nonneg (fun ki _ => mul_nonneg (hpos ki.1.val ki.1.property)
    (sq_nonneg ‖z.val ki‖))

theorem phaseRealMultiplier_quadratic_le (N : ℕ) (m : Frequency → ℝ)
    (hm : ∀ k, m (-k) = m k) (M : ℝ)
    (hbound : ∀ k ∈ cutoffModes N, m k ≤ M) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRealMultiplier N m hm z) ≤ M * ‖z‖ ^ 2 := by
  rw [phaseRealMultiplier_quadratic]
  change _ ≤ M * ‖z.val‖ ^ 2
  rw [EuclideanSpace.norm_sq_eq, Finset.mul_sum]
  exact Finset.sum_le_sum (fun ki _ =>
    mul_le_mul_of_nonneg_right (hbound ki.1.val ki.1.property) (sq_nonneg ‖z.val ki‖))

theorem phaseRealMultiplier_norm_le (N : ℕ) (m : Frequency → ℝ)
    (hm : ∀ k, m (-k) = m k) (M : ℝ) (hM : 0 ≤ M)
    (hbound : ∀ k ∈ cutoffModes N, |m k| ≤ M) (z : GalerkinPhase N) :
    ‖phaseRealMultiplier N m hm z‖ ≤ M * ‖z‖ := by
  have hsq : ‖phaseRealMultiplier N m hm z‖ ^ 2 ≤ (M * ‖z‖) ^ 2 := by
    change ‖(phaseRealMultiplier N m hm z).val‖ ^ 2 ≤ (M * ‖z.val‖) ^ 2
    rw [EuclideanSpace.norm_sq_eq, mul_pow, EuclideanSpace.norm_sq_eq, Finset.mul_sum]
    apply Finset.sum_le_sum
    intro ki hki
    rw [phaseRealMultiplier_apply, norm_smul, Real.norm_eq_abs, mul_pow]
    have hmabs := hbound ki.1.val ki.1.property
    have hmsq : |m ki.1.val| ^ 2 ≤ M ^ 2 := by
      nlinarith [abs_nonneg (m ki.1.val)]
    exact mul_le_mul_of_nonneg_right hmsq (sq_nonneg ‖z.val ki‖)
  have hright : 0 ≤ M * ‖z‖ := mul_nonneg hM (norm_nonneg z)
  nlinarith [norm_nonneg (phaseRealMultiplier N m hm z)]

theorem phaseRealMultiplier_opNorm_le (N : ℕ) (m : Frequency → ℝ)
    (hm : ∀ k, m (-k) = m k) (M : ℝ) (hM : 0 ≤ M)
    (hbound : ∀ k ∈ cutoffModes N, |m k| ≤ M) :
    ‖phaseRealMultiplier N m hm‖ ≤ M :=
  (phaseRealMultiplier N m hm).opNorm_le_bound hM
    (phaseRealMultiplier_norm_le N m hm M hM hbound)

end

end MethbokeAddon.EhrenfestObstruction
