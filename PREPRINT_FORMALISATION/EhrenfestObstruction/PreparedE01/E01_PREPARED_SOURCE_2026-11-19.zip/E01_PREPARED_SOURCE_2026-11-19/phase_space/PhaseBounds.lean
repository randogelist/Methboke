import MethbokeAddon.EhrenfestObstruction.PhaseStokes

/-! Derived finite-cutoff Lipschitz and reverse-energy estimates.
These estimates do not themselves assert existence of a complete smooth flow. -/

set_option autoImplicit false

open Set Metric SingularClosure
open scoped ContDiff

namespace MethbokeAddon.EhrenfestObstruction

noncomputable section

theorem phaseRhs_lipschitzOn_closedBall (ν : ℝ) (N : ℕ) (R : ℝ) :
    ∃ K : ℝ≥0, LipschitzOnWith K (phaseRhs ν N)
      (closedBall (0 : GalerkinPhase N) R) := by
  have hC1 : ContDiff ℝ 1 (phaseRhs ν N) :=
    (phaseRhs_contDiff ν N).of_le (by norm_num)
  exact (hC1.contDiffOn (s := closedBall (0 : GalerkinPhase N) R)).exists_lipschitzOnWith
    one_ne_zero (convex_closedBall _ _) (isCompact_closedBall _ _)

theorem phaseDissipation_le_lambdaMax_energy (N : ℕ) (z : GalerkinPhase N) :
    coefficientDissipation N (phaseCoeff N z) ≤ phaseLambdaMax N * ‖z‖ ^ 2 := by
  rw [← phaseStokes_quadratic]
  exact phaseStokes_quadratic_le_lambdaMax N z

/-- Exact viscous/inviscid decomposition of the actual NSE polynomial. -/
theorem phaseRhs_stokes_split (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    phaseRhs ν N z = (-ν) • phaseStokes N z + phaseRhs 0 N z := by
  apply Subtype.ext
  ext ki
  change (phaseRhs ν N z).val ki =
    (-ν) • (phaseStokes N z).val ki + (phaseRhs 0 N z).val ki
  have hs := phaseRealMultiplier_apply N phaseStokesSymbol phaseStokesSymbol_even z ki
  change (phaseStokes N z).val ki = phaseStokesSymbol ki.1.val • z.val ki at hs
  rw [phaseRhs_coe, phaseRhs_coe, hs]
  change galerkinRhs ν N (hilbertCoeff N z.val) ki.1.val ki.2 =
    (-ν) • (phaseStokesSymbol ki.1.val • z.val ki) +
      galerkinRhs 0 N (hilbertCoeff N z.val) ki.1.val ki.2
  simp only [galerkinRhs, hilbertCoeff_apply, phaseStokesSymbol, Complex.real_smul,
    Complex.ofReal_mul, Complex.ofReal_neg, Complex.ofReal_zero, zero_mul, neg_zero]
  ring

theorem phaseRhs_reverse_radial_le (ν : ℝ) (hν : 0 ≤ ν) (N : ℕ)
    (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (-phaseRhs ν N z) ≤
      (ν * phaseLambdaMax N) * ‖z‖ ^ 2 := by
  rw [inner_neg_right, phaseRhs_stokes_energy, neg_mul, neg_neg]
  have h := mul_le_mul_of_nonneg_left (phaseStokes_quadratic_le_lambdaMax N z) hν
  simpa only [mul_assoc] using h

end

end MethbokeAddon.EhrenfestObstruction
