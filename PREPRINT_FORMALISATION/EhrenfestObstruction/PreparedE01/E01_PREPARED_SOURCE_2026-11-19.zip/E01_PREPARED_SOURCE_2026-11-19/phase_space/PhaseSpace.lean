import SingularClosure.GalerkinInvariant
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Tactic.Linarith

/-!
# The actual finite real Galerkin phase space

This adapter reuses the native invariant real submodule of finite complex
Fourier arrays. It does not replace the NSE vector field by an arbitrary
polynomial, and introduces no existence, invariance, or energy proof ports.

These are foundational E01 identities. They do not construct a complete
two-sided flow or a self-adjoint transport generator.
-/

set_option autoImplicit false

open Set SingularClosure
open scoped BigOperators ContDiff

namespace MethbokeAddon.EhrenfestObstruction

noncomputable section

/-- Native finite complex coefficient Hilbert space, regarded over the reals. -/
abbrev GalerkinPhaseAmbient (N : ℕ) := GalerkinHilbertState N

/-- The native real subspace with conjugate symmetry and zero Fourier divergence. -/
abbrev GalerkinPhase (N : ℕ) := InvariantGalerkinState N

theorem galerkinPhase_finiteDimensional (N : ℕ) :
    FiniteDimensional ℝ (GalerkinPhase N) := by
  infer_instance

/-- Isometric real coordinates, with dimension equal to the actual real rank. -/
def phaseCoordinates (N : ℕ) :
    GalerkinPhase N ≃ₗᵢ[ℝ]
      EuclideanSpace ℝ (Fin (Module.finrank ℝ (GalerkinPhase N))) :=
  (stdOrthonormalBasis ℝ (GalerkinPhase N)).repr

theorem phaseCoordinates_norm (N : ℕ) (z : GalerkinPhase N) :
    ‖phaseCoordinates N z‖ = ‖z‖ :=
  (phaseCoordinates N).norm_map z

theorem phaseCoordinates_symm_apply (N : ℕ) (z : GalerkinPhase N) :
    (phaseCoordinates N).symm (phaseCoordinates N z) = z :=
  (phaseCoordinates N).symm_apply_apply z

/-- Orthogonal projection onto the actual real solenoidal subspace. -/
def phaseProjection (N : ℕ) : GalerkinPhaseAmbient N →L[ℝ] GalerkinPhase N :=
  (invariantGalerkinSubspace N).orthogonalProjectionOnto

theorem phaseProjection_fixed_iff (N : ℕ) (z : GalerkinPhaseAmbient N) :
    (phaseProjection N z).val = z ↔ z ∈ invariantGalerkinSubspace N := by
  exact (invariantGalerkinSubspace N).starProjection_eq_self_iff

theorem phaseProjection_apply (N : ℕ) (z : GalerkinPhase N) :
    phaseProjection N z.val = z := by
  apply Subtype.ext
  exact (phaseProjection_fixed_iff N z.val).mpr z.property

/-- Literal zero extension of the retained Fourier coefficients. -/
def phaseCoeff (N : ℕ) : GalerkinPhase N →ₗ[ℝ] FourierCoeff where
  toFun z := hilbertCoeff N z.val
  map_add' z w := hilbertCoeff_add N z.val w.val
  map_smul' r z := hilbertCoeff_smul N r z.val

theorem phaseCoeff_apply (N : ℕ) (z : GalerkinPhase N)
    (k : ↥(cutoffModes N)) (i : Fin 3) :
    phaseCoeff N z k.val i = z.val (k, i) :=
  hilbertCoeff_apply N z.val k i

theorem phaseCoeff_support (N : ℕ) (z : GalerkinPhase N)
    (k : Frequency) (hk : k ∉ cutoffModes N) (i : Fin 3) :
    phaseCoeff N z k i = 0 :=
  hilbertCoeff_support N z.val k hk i

theorem phaseCoeff_reality (N : ℕ) (z : GalerkinPhase N) :
    SpectralReality (phaseCoeff N z) := z.property.1

theorem phaseCoeff_solenoidal (N : ℕ) (z : GalerkinPhase N) :
    SpectralSolenoidal (phaseCoeff N z) := z.property.2

theorem phaseCoeff_meanZero (N : ℕ) (z : GalerkinPhase N) :
    SpectralMeanZero (phaseCoeff N z) := by
  intro i
  exact phaseCoeff_support N z 0 (cutoffModes_zero_not_mem N) i

theorem phaseCoeff_cutoff (N : ℕ) (z : GalerkinPhase N) :
    cutoffCoeff N (phaseCoeff N z) = phaseCoeff N z := by
  funext k i
  by_cases hk : k ∈ cutoffModes N
  · exact cutoffCoeff_apply_of_mem (phaseCoeff N z) hk i
  · rw [cutoffCoeff_apply_of_not_mem (phaseCoeff N z) hk i,
      phaseCoeff_support N z k hk i]

theorem phaseCoeff_injective (N : ℕ) : Function.Injective (phaseCoeff N) := by
  intro z w h
  apply Subtype.ext
  ext ki
  have hc := congrFun (congrFun h ki.1.val) ki.2
  simpa only [phaseCoeff_apply] using hc

/-- The inherited real Hilbert norm is the exact finite coefficient energy. -/
theorem phaseCoeff_energy_eq_norm_sq (N : ℕ) (z : GalerkinPhase N) :
    coefficientEnergy N (phaseCoeff N z) = ‖z‖ ^ 2 := by
  symm
  change ‖z.val‖ ^ 2 = coefficientEnergy N (phaseCoeff N z)
  rw [EuclideanSpace.norm_sq_eq, Fintype.sum_prod_type]
  calc
    (∑ k : ↥(cutoffModes N), ∑ i : Fin 3, ‖z.val (k, i)‖ ^ 2) =
        ∑ k : ↥(cutoffModes N), ∑ i : Fin 3,
          Complex.normSq (phaseCoeff N z k.val i) := by
      apply Finset.sum_congr rfl
      intro k hk
      apply Finset.sum_congr rfl
      intro i hi
      rw [phaseCoeff_apply, Complex.normSq_eq_norm_sq]
    _ = coefficientEnergy N (phaseCoeff N z) :=
      Finset.sum_coe_sort (cutoffModes N)
        (fun k => ∑ i : Fin 3, Complex.normSq (phaseCoeff N z k i))

theorem phaseCoordinates_energy (N : ℕ) (z : GalerkinPhase N) :
    (∑ i : Fin (Module.finrank ℝ (GalerkinPhase N)),
      (phaseCoordinates N z i) ^ 2) = coefficientEnergy N (phaseCoeff N z) := by
  rw [← EuclideanSpace.real_norm_sq_eq, phaseCoordinates_norm,
    phaseCoeff_energy_eq_norm_sq]

/-- The actual native polynomial NSE field, with its proved tangency. -/
abbrev phaseRhs (ν : ℝ) (N : ℕ) : GalerkinPhase N → GalerkinPhase N :=
  invariantGalerkinRhs ν N

theorem phaseRhs_coe (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    (phaseRhs ν N z).val = hilbertGalerkinRhs ν N z.val :=
  invariantGalerkinRhs_coe ν N z

theorem phaseRhs_coeff (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    phaseCoeff N (phaseRhs ν N z) =
      cutoffCoeff N (galerkinRhs ν N (phaseCoeff N z)) := by
  change hilbertCoeff N (invariantGalerkinRhs ν N z).val =
    cutoffCoeff N (galerkinRhs ν N (hilbertCoeff N z.val))
  rw [invariantGalerkinRhs_coe, hilbertCoeff_rhs]

theorem phaseRhs_contDiff (ν : ℝ) (N : ℕ) :
    ContDiff ℝ ∞ (phaseRhs ν N) :=
  contDiff_invariantGalerkinRhs ν N

/-- Exact radial energy balance, stronger than a dissipativity inequality.
It holds for every real viscosity parameter. -/
theorem phaseRhs_radial_energy (ν : ℝ) (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRhs ν N z) =
      -ν * coefficientDissipation N (phaseCoeff N z) := by
  rw [invariantGalerkinRhs_inner]
  have hz := coefficientNonlinearPower_eq_zero N (hilbertCoeff N z.val)
    (hilbertCoeff_support N z.val) z.property.1 z.property.2
  have hr := coefficientEnergy_rate_split ν N (hilbertCoeff N z.val)
  rw [hz, mul_zero, sub_zero] at hr
  simp only [← Finset.mul_sum] at hr
  change (∑ k ∈ cutoffModes N, ∑ i : Fin 3,
      (star (hilbertCoeff N z.val k i) *
        galerkinRhs ν N (hilbertCoeff N z.val) k i).re) =
    -ν * coefficientDissipation N (hilbertCoeff N z.val)
  linarith

theorem phaseRhs_inviscid_radial_zero (N : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) z (phaseRhs 0 N z) = 0 := by
  simpa using phaseRhs_radial_energy 0 N z

theorem phaseRhs_dissipative (ν : ℝ) (hν : 0 ≤ ν) (N : ℕ)
    (z : GalerkinPhase N) : inner (𝕜 := ℝ) z (phaseRhs ν N z) ≤ 0 :=
  invariantGalerkinRhs_dissipative ν hν N z

end

end MethbokeAddon.EhrenfestObstruction
