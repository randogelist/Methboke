import MethbokeAddon.EhrenfestObstruction.PhaseStokes
import MethbokeAddon.EhrenfestObstruction.PhaseSynthesis
import SingularClosure.FiniteHessian

/-! Orthogonal finite cutoffs and literal coordinate derivatives on the real
phase space. Commutation is proved from scalar Fourier multiplication. -/

set_option autoImplicit false

open SingularClosure
open scoped BigOperators

namespace MethbokeAddon.EhrenfestObstruction

noncomputable section

def phaseCutoffSymbol (M : ℕ) (k : Frequency) : ℝ :=
  if k ∈ cutoffModes M then 1 else 0

theorem phaseCutoffSymbol_even (M : ℕ) (k : Frequency) :
    phaseCutoffSymbol M (-k) = phaseCutoffSymbol M k := by
  by_cases hk : k ∈ cutoffModes M
  · simp [phaseCutoffSymbol, hk, cutoffModes_neg_mem hk]
  · have hnk : -k ∉ cutoffModes M := by
      intro h
      exact hk (by simpa using cutoffModes_neg_mem h)
    simp [phaseCutoffSymbol, hk, hnk]

/-- Cutoff M acting inside phase N; no relation between M and N is assumed. -/
def phaseCutoff (N M : ℕ) : GalerkinPhase N →L[ℝ] GalerkinPhase N :=
  phaseRealMultiplier N (phaseCutoffSymbol M) (phaseCutoffSymbol_even M)

theorem phaseCutoff_coeff (N M : ℕ) (z : GalerkinPhase N) :
    phaseCoeff N (phaseCutoff N M z) = cutoffCoeff M (phaseCoeff N z) := by
  change phaseCoeff N
    (phaseRealMultiplier N (phaseCutoffSymbol M) (phaseCutoffSymbol_even M) z) = _
  rw [phaseRealMultiplier_coeff]
  funext k i
  by_cases hk : k ∈ cutoffModes M <;>
    simp [spectralMultiplier, phaseCutoffSymbol, cutoffCoeff, hk]

theorem phaseCutoff_same (N : ℕ) (z : GalerkinPhase N) : phaseCutoff N N z = z := by
  apply phaseCoeff_injective N
  rw [phaseCutoff_coeff, phaseCoeff_cutoff]

theorem phaseCutoff_idempotent (N M : ℕ) (z : GalerkinPhase N) :
    phaseCutoff N M (phaseCutoff N M z) = phaseCutoff N M z := by
  apply phaseCoeff_injective N
  simp only [phaseCutoff_coeff, cutoffCoeff_idempotent]

theorem phaseCutoff_selfAdjoint (N M : ℕ) : IsSelfAdjoint (phaseCutoff N M) :=
  phaseRealMultiplier_selfAdjoint N (phaseCutoffSymbol M) (phaseCutoffSymbol_even M)

theorem phaseCutoff_orthogonal_residual (N M : ℕ) (z : GalerkinPhase N) :
    inner (𝕜 := ℝ) (phaseCutoff N M z) (z - phaseCutoff N M z) = 0 := by
  calc
    _ = inner (𝕜 := ℝ) z (phaseCutoff N M (z - phaseCutoff N M z)) :=
      (phaseCutoff_selfAdjoint N M).isSymmetric z (z - phaseCutoff N M z)
    _ = 0 := by
      rw [map_sub, phaseCutoff_idempotent, sub_self, inner_zero_right]

theorem phaseCutoff_opNorm_le_one (N M : ℕ) : ‖phaseCutoff N M‖ ≤ 1 := by
  apply phaseRealMultiplier_opNorm_le N (phaseCutoffSymbol M) (phaseCutoffSymbol_even M)
    1 zero_le_one
  intro k hk
  by_cases hkm : k ∈ cutoffModes M <;> simp [phaseCutoffSymbol, hkm]

theorem phaseCutoff_stokes_commute (N M : ℕ) (z : GalerkinPhase N) :
    phaseCutoff N M (phaseStokes N z) = phaseStokes N (phaseCutoff N M z) :=
  phaseMultiplier_commute N
    (fun k => (phaseCutoffSymbol M k : ℂ)) (fun k => (phaseStokesSymbol k : ℂ))
    (phaseRealSymbol_reality _ (phaseCutoffSymbol_even M))
    (phaseRealSymbol_reality _ phaseStokesSymbol_even) z

/-- The exact physical coordinate derivative, represented on finite phase space. -/
def phaseDerivative (N : ℕ) (j : Fin 3) : GalerkinPhase N →L[ℝ] GalerkinPhase N :=
  phaseMultiplier N (derivativeSymbol j) (derivativeSymbol_reality j)

theorem phaseDerivative_coeff (N : ℕ) (j : Fin 3) (z : GalerkinPhase N) :
    phaseCoeff N (phaseDerivative N j z) =
      spectralMultiplier (derivativeSymbol j) (phaseCoeff N z) :=
  phaseMultiplier_coeff N _ _ z

theorem phaseDerivative_synthesis (N : ℕ) (j : Fin 3) (z : GalerkinPhase N) :
    phaseSynthesis N (phaseDerivative N j z) = coordinateDerivative (phaseSynthesis N z) j := by
  change finiteSynthesis N (phaseCoeff N (phaseDerivative N j z)) =
    coordinateDerivative (finiteSynthesis N (phaseCoeff N z)) j
  rw [phaseDerivative_coeff, finiteSynthesis_coordinateDerivative]

theorem phaseCutoff_derivative_commute (N M : ℕ) (j : Fin 3) (z : GalerkinPhase N) :
    phaseCutoff N M (phaseDerivative N j z) =
      phaseDerivative N j (phaseCutoff N M z) :=
  phaseMultiplier_commute N (fun k => (phaseCutoffSymbol M k : ℂ)) (derivativeSymbol j)
    (phaseRealSymbol_reality _ (phaseCutoffSymbol_even M)) (derivativeSymbol_reality j) z

theorem phaseStokes_derivative_commute (N : ℕ) (j : Fin 3) (z : GalerkinPhase N) :
    phaseStokes N (phaseDerivative N j z) = phaseDerivative N j (phaseStokes N z) :=
  phaseMultiplier_commute N (fun k => (phaseStokesSymbol k : ℂ)) (derivativeSymbol j)
    (phaseRealSymbol_reality _ phaseStokesSymbol_even) (derivativeSymbol_reality j) z

theorem phaseSynthesis_neg (N : ℕ) (z : GalerkinPhase N) :
    phaseSynthesis N (-z) = -phaseSynthesis N z := by
  funext x
  ext i
  simp [phaseSynthesis, finiteSynthesis, Finset.sum_neg_distrib]

theorem phaseLaplacian_synthesis (N : ℕ) (z : GalerkinPhase N) :
    laplacian (phaseSynthesis N z) = phaseSynthesis N (-phaseStokes N z) := by
  change laplacian (finiteSynthesis N (phaseCoeff N z)) =
    finiteSynthesis N (phaseCoeff N (-phaseStokes N z))
  rw [finiteSynthesis_laplacian, map_neg, phaseStokes_coeff]
  congr 1
  funext k i
  simp [laplacianCoefficient, spectralMultiplier, phaseStokesSymbol, laplacianFrequency]

/-- The bounded phase operator is precisely the physical negative Laplacian. -/
theorem phaseStokes_synthesis (N : ℕ) (z : GalerkinPhase N) :
    phaseSynthesis N (phaseStokes N z) = -laplacian (phaseSynthesis N z) := by
  have h := phaseLaplacian_synthesis N z
  rw [phaseSynthesis_neg] at h
  have hn := congrArg (fun f : Field => -f) h
  simpa only [neg_neg] using hn.symm

end

end MethbokeAddon.EhrenfestObstruction
