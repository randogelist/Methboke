E01 INVERSE COEFFICIENT AND INITIAL-STATE ADAPTER -- SOURCE ONLY

PhaseInitialState constructs the literal retained Hilbert array from a
Fourier coefficient family satisfying reality and solenoidality. Its exact
coefficients are cutoffCoeff N c. A two-way characterization proves that
phaseCoeff's image is precisely the supported real-solenoidal coefficients.

For an actual smooth physical datum, native Fourier reality and solenoidality
derive all constructor conditions. phaseInitialState_coeff is the literal
physical Fourier cutoff, synthesis is the actual finite Fourier sum, and its
energy is bounded by the original physical energy using finite physical Bessel.

There is no claim yet that a complete two-sided flow is identified with the
canonical Galerkin orbit. The later canonical lane must instantiate N=n+1 and
use actual ODE uniqueness. No initial bound is taken as a proof port.

6 theorem proofs, 2 definitions, 8 exact consumer types and 8 axiom queries.
No local Lean/Lake/kernel/CI execution or external publication. Existing
finalized source files are unchanged. Acceptance awaits matching authorized
external cached compilation and auditing.
