import MethbokeAddon.EhrenfestObstruction.PhaseInitialState

set_option autoImplicit false
open SingularClosure

namespace MethbokeAddon.EhrenfestObstruction.PhaseInitialStateTypeChecks

example (N : ℕ) (c : FourierCoeff) (hreal : SpectralReality c)
    (hsol : SpectralSolenoidal c) : GalerkinPhase N := phaseFromCoeff N c hreal hsol

example (N : ℕ) (c : FourierCoeff) (hreal : SpectralReality c) (hsol : SpectralSolenoidal c) :
    phaseCoeff N (phaseFromCoeff N c hreal hsol) = cutoffCoeff N c :=
  phaseFromCoeff_coeff N c hreal hsol

example (N : ℕ) (z : GalerkinPhase N) :
    phaseFromCoeff N (phaseCoeff N z) (phaseCoeff_reality N z)
      (phaseCoeff_solenoidal N z) = z := phaseFromCoeff_phaseCoeff N z

example (N : ℕ) (c : FourierCoeff) :
    (∃ z : GalerkinPhase N, phaseCoeff N z = c) ↔
      (∀ k : Frequency, k ∉ cutoffModes N → ∀ i : Fin 3, c k i = 0) ∧
        SpectralReality c ∧ SpectralSolenoidal c := phaseCoeff_characterization N c

example (N : ℕ) (a : Field) (ha : SmoothSigmaZero a) : GalerkinPhase N := phaseInitialState N a ha

example (N : ℕ) (a : Field) (ha : SmoothSigmaZero a) :
    phaseCoeff N (phaseInitialState N a ha) = cutoffCoeff N (datumFourierCoeff a) :=
  phaseInitialState_coeff N a ha

example (N : ℕ) (a : Field) (ha : SmoothSigmaZero a) :
    phaseSynthesis N (phaseInitialState N a ha) = finiteSynthesis N (datumFourierCoeff a) :=
  phaseInitialState_synthesis N a ha

example (N : ℕ) (a : Field) (ha : SmoothSigmaZero a) :
    ‖phaseInitialState N a ha‖ ^ 2 ≤ physicalEnergy a := phaseInitialState_energy_le N a ha

end MethbokeAddon.EhrenfestObstruction.PhaseInitialStateTypeChecks

#print axioms MethbokeAddon.EhrenfestObstruction.phaseFromCoeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseFromCoeff_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseFromCoeff_phaseCoeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseCoeff_characterization
#print axioms MethbokeAddon.EhrenfestObstruction.phaseInitialState
#print axioms MethbokeAddon.EhrenfestObstruction.phaseInitialState_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.phaseInitialState_synthesis
#print axioms MethbokeAddon.EhrenfestObstruction.phaseInitialState_energy_le
