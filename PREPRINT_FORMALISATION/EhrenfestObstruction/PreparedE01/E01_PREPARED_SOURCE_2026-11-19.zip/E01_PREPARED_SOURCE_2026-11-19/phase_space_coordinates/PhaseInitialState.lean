import MethbokeAddon.EhrenfestObstruction.PhaseSynthesis
import SingularClosure.InitialCutoffBounds

/-! The inverse coefficient adapter and actual Fourier-projected initial state.
All constructor hypotheses are the defining finite real-solenoidal constraints.
For smooth physical data those constraints are derived by native Fourier identities. -/

set_option autoImplicit false
open SingularClosure
open scoped ContDiff

namespace MethbokeAddon.EhrenfestObstruction

noncomputable section

def phaseFromCoeff (N : ℕ) (c : FourierCoeff)
    (hreal : SpectralReality c) (hsol : SpectralSolenoidal c) : GalerkinPhase N :=
  ⟨WithLp.toLp 2 (fun ki => c ki.1.val ki.2), by
    have he : hilbertCoeff N (WithLp.toLp 2 (fun ki => c ki.1.val ki.2)) =
        cutoffCoeff N c := by
      funext k i
      by_cases hk : k ∈ cutoffModes N <;>
        simp [hilbertCoeff, extendFiniteState, cutoffCoeff, hk]
    change SpectralReality (hilbertCoeff N _) ∧ SpectralSolenoidal (hilbertCoeff N _)
    rw [he]
    exact ⟨cutoffCoeff_preserves_reality N hreal, cutoffCoeff_preserves_solenoidal N hsol⟩⟩

theorem phaseFromCoeff_coeff (N : ℕ) (c : FourierCoeff)
    (hreal : SpectralReality c) (hsol : SpectralSolenoidal c) :
    phaseCoeff N (phaseFromCoeff N c hreal hsol) = cutoffCoeff N c := by
  funext k i
  by_cases hk : k ∈ cutoffModes N <;>
    simp [phaseFromCoeff, phaseCoeff, hilbertCoeff, extendFiniteState, cutoffCoeff, hk]

theorem phaseFromCoeff_phaseCoeff (N : ℕ) (z : GalerkinPhase N) :
    phaseFromCoeff N (phaseCoeff N z) (phaseCoeff_reality N z)
      (phaseCoeff_solenoidal N z) = z := by
  apply phaseCoeff_injective N
  rw [phaseFromCoeff_coeff, phaseCoeff_cutoff]

theorem phaseCoeff_characterization (N : ℕ) (c : FourierCoeff) :
    (∃ z : GalerkinPhase N, phaseCoeff N z = c) ↔
      (∀ k : Frequency, k ∉ cutoffModes N → ∀ i : Fin 3, c k i = 0) ∧
        SpectralReality c ∧ SpectralSolenoidal c := by
  constructor
  · rintro ⟨z, rfl⟩
    exact ⟨phaseCoeff_support N z, phaseCoeff_reality N z, phaseCoeff_solenoidal N z⟩
  · rintro ⟨hsupp, hreal, hsol⟩
    refine ⟨phaseFromCoeff N c hreal hsol, ?_⟩
    rw [phaseFromCoeff_coeff]
    funext k i
    by_cases hk : k ∈ cutoffModes N
    · exact cutoffCoeff_apply_of_mem c hk i
    · rw [cutoffCoeff_apply_of_not_mem c hk i, hsupp k hk i]

/-- The actual initial phase vector, using physical Fourier integrals. -/
def phaseInitialState (N : ℕ) (a : Field) (ha : SmoothSigmaZero a) : GalerkinPhase N :=
  phaseFromCoeff N (datumFourierCoeff a) (datumFourierCoeff_reality a)
    (smoothSigmaZero_fourier_solenoidal ha)

theorem phaseInitialState_coeff (N : ℕ) (a : Field) (ha : SmoothSigmaZero a) :
    phaseCoeff N (phaseInitialState N a ha) = cutoffCoeff N (datumFourierCoeff a) :=
  phaseFromCoeff_coeff N _ _ _

theorem phaseInitialState_synthesis (N : ℕ) (a : Field) (ha : SmoothSigmaZero a) :
    phaseSynthesis N (phaseInitialState N a ha) = finiteSynthesis N (datumFourierCoeff a) := by
  change finiteSynthesis N (phaseCoeff N (phaseInitialState N a ha)) = _
  rw [phaseInitialState_coeff, finiteSynthesis_cutoffCoeff]

theorem phaseInitialState_energy_le (N : ℕ) (a : Field) (ha : SmoothSigmaZero a) :
    ‖phaseInitialState N a ha‖ ^ 2 ≤ physicalEnergy a := by
  calc
    _ = physicalEnergy (phaseSynthesis N (phaseInitialState N a ha)) :=
      (phaseSynthesis_physicalEnergy N (phaseInitialState N a ha)).symm
    _ = physicalEnergy (finiteSynthesis N (datumFourierCoeff a)) := by
      rw [phaseInitialState_synthesis]
    _ = coefficientEnergy N (datumFourierCoeff a) :=
      FINITE_PHYSICAL_ENERGY_PARSEVAL N _ (datumFourierCoeff_reality a)
    _ ≤ physicalEnergy a := FINITE_PHYSICAL_BESSEL N a ha.smooth.continuous

end

end MethbokeAddon.EhrenfestObstruction
