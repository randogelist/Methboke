E01 AMBIENT LERAY SUPPLEMENT -- PREPARED SOURCE ONLY

FILES
  PhaseLeray.lean
  PhaseLerayTypeChecks.lean

No local Lean, Lake, kernel audit, external CI, or publishing was performed.
No finalized phase_space candidate was modified for this supplement.

ACTUAL MODEL
  Ambient space: the native finite complex Hilbert coefficient array,
  regarded over R. The new ambientSolenoidalSubspace imposes only literal
  complex Fourier divergence zero. It does not impose conjugate symmetry.

  ambientLerayValue is the literal native coefficientLeray at each retained
  mode. Its zero extension is exactly native lerayFourierCoeff. Using the
  existing coefficientLeray_pairing theorem, its residual is proved
  orthogonal to EVERY solenoidal ambient vector. Projection uniqueness
  proves ambientLerayValue = the actual native orthogonal projection.

CONSEQUENCES
  Bounded real-linear ambientLeray with exact pointwise coefficient formula.
  Range precisely the solenoidal subspace; fixed-point characterization.
  Idempotence, self-adjointness and operator norm <=1.
  Preservation of conjugate symmetry, derived from native Leray reality.
  Agreement with native phaseProjection for conjugate-symmetric input.
  Commutation with every scalar Fourier multiplier on the FULL ambient
  space, including concrete cutoffs and coordinate derivatives.

ESSENTIAL BOUNDARY
  The phaseProjection identity explicitly requires input conjugate symmetry.
  It is NOT asserted for arbitrary complex arrays, since phaseProjection
  also projects onto the real Fourier constraint. The bilinear transport
  consumer must prove actual raw-convolution reality before using this bridge.
  No complete flow, half-density unitary group, or unbounded generator is
  asserted by this finite-dimensional orthogonal-projection supplement.

PINNED SOURCE BASIS
  randogelist/Methboke 9ae4429b9c218c109bddaac2f993f1cc5bd66aa8:
    GalerkinInvariant: exact native ambient and invariant phase spaces.
    GalerkinAlgebra: coefficientLeray_pairing, actual coefficient formula.
    LerayL2Contraction: lerayFourierCoeff_solenoidal and _reality.
    FourierSobolevOperators: coefficientLeray_smul_arg.
  Mathlib db584cd6d46c92f209a44c0f1c829460d327499d:
    Analysis/InnerProductSpace/Projection/Basic.lean:
      eq_starProjection_of_mem_of_inner_eq_zero (line 173),
      starProjection_eq_self_iff, range_starProjection, starProjection_norm_le.
    Analysis/InnerProductSpace/Adjoint.lean:
      isSelfAdjoint_starProjection.

17 theorem proofs, 3 definitions, 20 independently stated consumer examples
and 20 named axiom queries. Every new acceptance status remains SOURCE_ONLY
until matching authorized external cached compilation and auditing.
