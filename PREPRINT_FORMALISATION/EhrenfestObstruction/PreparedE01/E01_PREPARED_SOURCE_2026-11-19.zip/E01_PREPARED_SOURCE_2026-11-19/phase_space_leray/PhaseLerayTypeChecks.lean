import MethbokeAddon.EhrenfestObstruction.PhaseLeray

/-! Exact independent consumer types and axiom queries for external verification. -/

set_option autoImplicit false
open SingularClosure

namespace MethbokeAddon.EhrenfestObstruction.PhaseLerayTypeChecks

example (N : ℕ) : Submodule ℝ (GalerkinPhaseAmbient N) := ambientSolenoidalSubspace N

example (N : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLerayValue N z = WithLp.toLp 2
      (fun ki => coefficientLeray ki.1.val (hilbertCoeff N z ki.1.val) ki.2) := rfl

example (N : ℕ) (z : GalerkinPhaseAmbient N) :
    hilbertCoeff N (ambientLerayValue N z) = lerayFourierCoeff (hilbertCoeff N z) :=
  ambientLerayValue_coeff N z

example (N : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLerayValue N z ∈ ambientSolenoidalSubspace N := ambientLerayValue_mem N z

example (N : ℕ) (z w : GalerkinPhaseAmbient N)
    (hw : w ∈ ambientSolenoidalSubspace N) :
    inner (𝕜 := ℝ) (z - ambientLerayValue N z) w = 0 :=
  ambientLerayValue_residual_orthogonal N z w hw

example (N : ℕ) : GalerkinPhaseAmbient N →L[ℝ] GalerkinPhaseAmbient N := ambientLeray N

example (N : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLeray N z = ambientLerayValue N z := ambientLeray_eq_value N z

example (N : ℕ) (z : GalerkinPhaseAmbient N) (ki : ↥(cutoffModes N) × Fin 3) :
    ambientLeray N z ki = coefficientLeray ki.1.val (hilbertCoeff N z ki.1.val) ki.2 :=
  ambientLeray_apply N z ki

example (N : ℕ) (z : GalerkinPhaseAmbient N) :
    hilbertCoeff N (ambientLeray N z) = lerayFourierCoeff (hilbertCoeff N z) :=
  ambientLeray_coeff N z

example (N : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLeray N z = z ↔ SpectralSolenoidal (hilbertCoeff N z) := ambientLeray_fixed_iff N z

example (N : ℕ) : (ambientLeray N).range = ambientSolenoidalSubspace N := ambientLeray_range N

example (N : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLeray N (ambientLeray N z) = ambientLeray N z := ambientLeray_idempotent N z

example (N : ℕ) : IsSelfAdjoint (ambientLeray N) := ambientLeray_selfAdjoint N

example (N : ℕ) : ‖ambientLeray N‖ ≤ 1 := ambientLeray_opNorm_le_one N

example (N : ℕ) (z : GalerkinPhaseAmbient N)
    (hz : SpectralReality (hilbertCoeff N z)) :
    SpectralReality (hilbertCoeff N (ambientLeray N z)) := ambientLeray_reality N z hz

example (N : ℕ) (z w : GalerkinPhaseAmbient N)
    (hw : SpectralSolenoidal (hilbertCoeff N w)) :
    inner (𝕜 := ℝ) (z - ambientLeray N z) w = 0 := ambientLeray_residual_orthogonal N z w hw

example (N : ℕ) (z : GalerkinPhaseAmbient N)
    (hz : SpectralReality (hilbertCoeff N z)) :
    (phaseProjection N z).val = ambientLeray N z :=
  phaseProjection_coe_eq_ambientLeray_of_reality N z hz

example (N : ℕ) (m : Frequency → ℂ) (z : GalerkinPhaseAmbient N) :
    ambientLeray N (phaseMultiplierHilbert N m z) =
      phaseMultiplierHilbert N m (ambientLeray N z) := ambientLeray_commutes_multiplier N m z

example (N M : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLeray N (phaseMultiplierHilbert N (fun k => (phaseCutoffSymbol M k : ℂ)) z) =
      phaseMultiplierHilbert N (fun k => (phaseCutoffSymbol M k : ℂ)) (ambientLeray N z) :=
  ambientLeray_commutes_cutoff N M z

example (N : ℕ) (j : Fin 3) (z : GalerkinPhaseAmbient N) :
    ambientLeray N (phaseMultiplierHilbert N (derivativeSymbol j) z) =
      phaseMultiplierHilbert N (derivativeSymbol j) (ambientLeray N z) :=
  ambientLeray_commutes_derivative N j z

end MethbokeAddon.EhrenfestObstruction.PhaseLerayTypeChecks

#print axioms MethbokeAddon.EhrenfestObstruction.ambientSolenoidalSubspace
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLerayValue
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLerayValue_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLerayValue_mem
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLerayValue_residual_orthogonal
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_eq_value
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_apply
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_coeff
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_fixed_iff
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_range
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_idempotent
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_selfAdjoint
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_opNorm_le_one
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_reality
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_residual_orthogonal
#print axioms MethbokeAddon.EhrenfestObstruction.phaseProjection_coe_eq_ambientLeray_of_reality
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_commutes_multiplier
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_commutes_cutoff
#print axioms MethbokeAddon.EhrenfestObstruction.ambientLeray_commutes_derivative
