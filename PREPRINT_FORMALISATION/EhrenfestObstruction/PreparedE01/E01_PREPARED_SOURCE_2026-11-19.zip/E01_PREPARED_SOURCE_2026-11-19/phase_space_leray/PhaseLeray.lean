import MethbokeAddon.EhrenfestObstruction.PhaseCutoffs
import SingularClosure.FourierSobolevOperators
import Mathlib.Analysis.InnerProductSpace.Projection.Basic

/-!
# The literal ambient Leray operator is an orthogonal projection

The ambient space consists of all retained complex Fourier arrays regarded
over the reals. Its solenoidal subspace imposes only Fourier divergence zero.
The coefficient formula is proved equal to orthogonal projection using the
native exact Leray pairing identity. Reality is a separate hypothesis when
identifying this projection with the smaller native real phase projection.
-/

set_option autoImplicit false

open SingularClosure
open scoped BigOperators

namespace MethbokeAddon.EhrenfestObstruction

noncomputable section

def ambientSolenoidalSubspace (N : ℕ) : Submodule ℝ (GalerkinPhaseAmbient N) where
  carrier := {z | SpectralSolenoidal (hilbertCoeff N z)}
  zero_mem' := by
    change SpectralSolenoidal (hilbertCoeff N 0)
    rw [hilbertCoeff_zero]
    intro k
    simp
  add_mem' := by
    intro z w hz hw
    change SpectralSolenoidal (hilbertCoeff N (z + w))
    rw [hilbertCoeff_add]
    intro k
    simp only [Pi.add_apply, mul_add, Finset.sum_add_distrib, hz k, hw k, add_zero]
  smul_mem' := by
    intro r z hz
    change SpectralSolenoidal (hilbertCoeff N (r • z))
    rw [hilbertCoeff_smul]
    intro k
    simp only [Pi.smul_apply, mul_smul_comm, ← Finset.smul_sum, hz k, smul_zero]

/-- The literal coefficient formula, before proving orthogonal-projection equality. -/
def ambientLerayValue (N : ℕ) (z : GalerkinPhaseAmbient N) : GalerkinPhaseAmbient N :=
  WithLp.toLp 2 (fun ki =>
    coefficientLeray ki.1.val (hilbertCoeff N z ki.1.val) ki.2)

theorem ambientLerayValue_coeff (N : ℕ) (z : GalerkinPhaseAmbient N) :
    hilbertCoeff N (ambientLerayValue N z) = lerayFourierCoeff (hilbertCoeff N z) := by
  funext k i
  by_cases hk : k ∈ cutoffModes N
  · simp [ambientLerayValue, hilbertCoeff, extendFiniteState, lerayFourierCoeff, hk]
  · have hz : hilbertCoeff N z k = 0 := by
      funext j
      exact hilbertCoeff_support N z k hk j
    simp [ambientLerayValue, hilbertCoeff, extendFiniteState, lerayFourierCoeff,
      hk, hz, coefficientLeray_zero]

theorem ambientLerayValue_mem (N : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLerayValue N z ∈ ambientSolenoidalSubspace N := by
  change SpectralSolenoidal (hilbertCoeff N (ambientLerayValue N z))
  rw [ambientLerayValue_coeff]
  exact lerayFourierCoeff_solenoidal (hilbertCoeff N z)

/-- The longitudinal residual pairs to zero with every solenoidal ambient vector. -/
theorem ambientLerayValue_residual_orthogonal (N : ℕ)
    (z w : GalerkinPhaseAmbient N) (hw : w ∈ ambientSolenoidalSubspace N) :
    inner (𝕜 := ℝ) (z - ambientLerayValue N z) w = 0 := by
  rw [real_inner_comm, PiLp.inner_apply]
  simp only [Complex.inner, ← Complex.star_def, Fintype.sum_prod_type]
  change (∑ k : ↥(cutoffModes N), ∑ i : Fin 3,
    ((z (k, i) - coefficientLeray k.val (hilbertCoeff N z k.val) i) *
      star (w (k, i))).re) = 0
  apply Finset.sum_eq_zero
  intro k hk
  have hsol : (∑ i : Fin 3, (k.val i : ℂ) * w (k, i)) = 0 := by
    have h := hw k.val
    simpa only [hilbertCoeff_apply] using h
  have hpair := coefficientLeray_pairing k.val (fun i => w (k, i))
    (hilbertCoeff N z k.val) hsol
  have hz : (∑ i : Fin 3, star (w (k, i)) *
      (hilbertCoeff N z k.val i - coefficientLeray k.val (hilbertCoeff N z k.val) i)) = 0 := by
    simp_rw [mul_sub]
    rw [Finset.sum_sub_distrib, hpair, sub_self]
  simpa only [Complex.re_sum, Complex.zero_re, hilbertCoeff_apply, mul_comm] using
    congrArg Complex.re hz

/-- Bounded ambient Leray projection, identified below with its literal coefficient formula. -/
def ambientLeray (N : ℕ) : GalerkinPhaseAmbient N →L[ℝ] GalerkinPhaseAmbient N :=
  (ambientSolenoidalSubspace N).starProjection

theorem ambientLeray_eq_value (N : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLeray N z = ambientLerayValue N z :=
  (ambientSolenoidalSubspace N).eq_starProjection_of_mem_of_inner_eq_zero
    (ambientLerayValue_mem N z) (ambientLerayValue_residual_orthogonal N z)

theorem ambientLeray_apply (N : ℕ) (z : GalerkinPhaseAmbient N)
    (ki : ↥(cutoffModes N) × Fin 3) :
    ambientLeray N z ki = coefficientLeray ki.1.val (hilbertCoeff N z ki.1.val) ki.2 :=
  congrArg (fun w : GalerkinPhaseAmbient N => w ki) (ambientLeray_eq_value N z)

theorem ambientLeray_coeff (N : ℕ) (z : GalerkinPhaseAmbient N) :
    hilbertCoeff N (ambientLeray N z) = lerayFourierCoeff (hilbertCoeff N z) := by
  rw [ambientLeray_eq_value, ambientLerayValue_coeff]

theorem ambientLeray_fixed_iff (N : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLeray N z = z ↔ SpectralSolenoidal (hilbertCoeff N z) :=
  (ambientSolenoidalSubspace N).starProjection_eq_self_iff

theorem ambientLeray_range (N : ℕ) :
    (ambientLeray N).range = ambientSolenoidalSubspace N :=
  (ambientSolenoidalSubspace N).range_starProjection

theorem ambientLeray_idempotent (N : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLeray N (ambientLeray N z) = ambientLeray N z := by
  apply (ambientLeray_fixed_iff N _).mpr
  rw [ambientLeray_coeff]
  exact lerayFourierCoeff_solenoidal (hilbertCoeff N z)

theorem ambientLeray_selfAdjoint (N : ℕ) : IsSelfAdjoint (ambientLeray N) :=
  isSelfAdjoint_starProjection (ambientSolenoidalSubspace N)

theorem ambientLeray_opNorm_le_one (N : ℕ) : ‖ambientLeray N‖ ≤ 1 :=
  (ambientSolenoidalSubspace N).starProjection_norm_le

theorem ambientLeray_reality (N : ℕ) (z : GalerkinPhaseAmbient N)
    (hz : SpectralReality (hilbertCoeff N z)) :
    SpectralReality (hilbertCoeff N (ambientLeray N z)) := by
  rw [ambientLeray_coeff]
  exact lerayFourierCoeff_reality (hilbertCoeff N z) hz

theorem ambientLeray_residual_orthogonal (N : ℕ) (z w : GalerkinPhaseAmbient N)
    (hw : SpectralSolenoidal (hilbertCoeff N w)) :
    inner (𝕜 := ℝ) (z - ambientLeray N z) w = 0 := by
  rw [ambientLeray_eq_value]
  exact ambientLerayValue_residual_orthogonal N z w hw

/-- For real Fourier arrays the solenoidal projection is exactly the full
native real-phase projection. The reality hypothesis is essential here. -/
theorem phaseProjection_coe_eq_ambientLeray_of_reality (N : ℕ)
    (z : GalerkinPhaseAmbient N) (hz : SpectralReality (hilbertCoeff N z)) :
    (phaseProjection N z).val = ambientLeray N z := by
  change (invariantGalerkinSubspace N).starProjection z = ambientLeray N z
  apply (invariantGalerkinSubspace N).eq_starProjection_of_mem_of_inner_eq_zero
  · change SpectralReality (hilbertCoeff N (ambientLeray N z)) ∧
      SpectralSolenoidal (hilbertCoeff N (ambientLeray N z))
    refine ⟨ambientLeray_reality N z hz, ?_⟩
    rw [ambientLeray_coeff]
    exact lerayFourierCoeff_solenoidal (hilbertCoeff N z)
  · intro w hw
    exact ambientLeray_residual_orthogonal N z w hw.2

/-- Leray commutes with every scalar frequency multiplier on the full ambient space. -/
theorem ambientLeray_commutes_multiplier (N : ℕ) (m : Frequency → ℂ)
    (z : GalerkinPhaseAmbient N) :
    ambientLeray N (phaseMultiplierHilbert N m z) =
      phaseMultiplierHilbert N m (ambientLeray N z) := by
  ext ki
  rw [ambientLeray_apply, phaseMultiplierHilbert_coeff]
  change coefficientLeray ki.1.val
      (fun i => m ki.1.val * hilbertCoeff N z ki.1.val i) ki.2 =
    m ki.1.val * ambientLeray N z ki
  rw [ambientLeray_apply]
  simpa only [Pi.smul_apply, smul_eq_mul] using
    congrFun (coefficientLeray_smul_arg ki.1.val (m ki.1.val)
      (hilbertCoeff N z ki.1.val)) ki.2

theorem ambientLeray_commutes_cutoff (N M : ℕ) (z : GalerkinPhaseAmbient N) :
    ambientLeray N (phaseMultiplierHilbert N (fun k => (phaseCutoffSymbol M k : ℂ)) z) =
      phaseMultiplierHilbert N (fun k => (phaseCutoffSymbol M k : ℂ)) (ambientLeray N z) :=
  ambientLeray_commutes_multiplier N _ z

theorem ambientLeray_commutes_derivative (N : ℕ) (j : Fin 3)
    (z : GalerkinPhaseAmbient N) :
    ambientLeray N (phaseMultiplierHilbert N (derivativeSymbol j) z) =
      phaseMultiplierHilbert N (derivativeSymbol j) (ambientLeray N z) :=
  ambientLeray_commutes_multiplier N _ z

end

end MethbokeAddon.EhrenfestObstruction
