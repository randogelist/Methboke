"""Independent static JSON/text/hash review; never executes Lean, Lake or a kernel.

Run only after the exact-run archive, completed job metadata and logs have been
downloaded. No compilation or CI polling is performed by this script.
"""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil

B = Path(__file__).resolve().parent
E = B / 'evidence'
BASE = 'eb2a759847abdedfd8ee70d3fbb665f128228ee9'
SHA = 'b730e52ca1e4a661a83a09110378db542455097b'
RUN = 44651224180
BRANCH = 'codex/reorganize-nse-domains'
STANDARD = {'propext', 'Classical.choice', 'Quot.sound'}
OLD = B.parent / 'Methboke/audits/material-22431f03-accepted'
PREVIOUS = B.parent / 'comment_ci_evidence'
checks = 0

def check(value, message):
    global checks
    if not value:
        raise AssertionError(message)
    checks += 1

def read(path):
    return json.loads(path.read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def blob(text):
    data = text.encode()
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def norm(text):
    return ' '.join(text.split())

def tree(data):
    return {e['path']: (e['sha'], e['mode']) for e in data['tree'] if e['type'] == 'blob'}

sources = read(B / 'source-inputs.json')
check(sources['commit']['sha'] == SHA, 'fetched commit identity')
check([p['sha'] for p in sources['commit']['parents']] == [BASE], 'direct layout parent')
check(not sources['layout_tree']['truncated'] and not sources['tested_tree']['truncated'], 'complete Git trees')
check(sources['commit']['tree']['sha'] == sources['tested_tree']['sha'], 'commit/tree binding')
before = tree(sources['layout_tree'])
after = tree(sources['tested_tree'])
payload = read(B.parent / 'dedicated_ci_payload.json')
expected_changes = {entry['path'] for entry in payload}
changed = {p for p in set(before) | set(after) if before.get(p) != after.get(p)}
check(changed == expected_changes and len(changed) == 7, 'exact seven-file trigger/document change')
for entry in payload:
    check(after[entry['path']] == (blob(entry['content']), entry['mode']), 'pushed bytes ' + entry['path'])
workflow = next(e['content'] for e in payload if e['path'] == '.github/workflows/material.yml')
check(workflow == sources['old_workflow'].replace('branches: [main]', 'branches: [main, codex/reorganize-nse-domains]', 1), 'only workflow change is exact branch trigger')
check(blob(sources['old_workflow']) == before['.github/workflows/material.yml'][0], 'base workflow bytes')
protected = lambda p: p.startswith('Material/') or p == 'LEAN_CUTOUTS/Cutouts.lean' or (p.startswith('.github/') and p != '.github/workflows/material.yml')
check({p for p in before if protected(p)} == {p for p in after if protected(p)}, 'complete protected-path inventory')
for path in before:
    if protected(path):
        check(before[path] == after[path], 'unchanged proof/audit/runtime bytes ' + path)
accepted_tree = tree(read(PREVIOUS / 'source-inputs.json')['new_tree'])
accepted_document_differences = {
    path for path in after if protected(path) and after[path] != accepted_tree.get(path)
}
check(len(accepted_document_differences) == 16 and all(path.startswith('Material/') and path.endswith('/README.md') for path in accepted_document_differences), 'only sixteen historical Material README rebases since accepted source')
for path in after:
    if protected(path) and path not in accepted_document_differences:
        check(after[path] == accepted_tree.get(path), 'matches accepted comment-run source ' + path)

r = read(E / 'current.json')
expected = read(OLD / 'expected-manifests.json')
old_report = read(PREVIOUS / 'evidence/current.json')
old_endpoints = {e['id']: e for e in old_report['endpoints']}
check(r['commit'] == SHA and str(r['run_id']) == str(RUN), 'exact checkout/run')
check(r['run_url'] == f'https://github.com/randogelist/Methboke/actions/runs/{RUN}', 'exact run URL')
check(r['status'] == 'PASS' and r['all_endpoints_selected'] is True and r['fresh_required_audits'] is True and r['compiler_executed'] is True, 'full executed PASS')
check(r['toolchain'] == 'leanprover/lean4:v4.33.0', 'compiler pin')
check(r['compiler'] == old_report['compiler'], 'actual compiler identity')
check(r['mathlib_commit'] == 'db584cd6d46c92f209a44c0f1c829460d327499d', 'Mathlib pin')
check(r['build_configuration'] == old_report['build_configuration'], 'unchanged runtime build policy/configuration')
check(r['platform'] == old_report['platform'], 'Linux platform identity')
check(r['module_workers'] == r['lean_num_threads'] == 2, 'unchanged concurrency')
check(r['source_pin_integrity'] is True, 'source pin integrity')
check(r['verified_dependencies'] == old_report['verified_dependencies'], 'all exact clean dependency pins')
receipts = r['module_receipts']
metrics = r['metrics']
check(set(receipts) == set(old_report['module_receipts']) and len(receipts) == 411, 'exact 411-module inventory')
check(all(e['status'] == 'PASS' and isinstance(e['reused'], bool) for e in receipts.values()), 'every module passed')
check(metrics['module_count'] == 411, 'reported module count')
check(sum(e['reused'] for e in receipts.values()) == metrics['reused_module_count'], 'observed reused-module count')
check(sum(not e['reused'] for e in receipts.values()) == metrics['fresh_module_count'], 'observed fresh-module count')
check(metrics['fresh_module_count'] + metrics['reused_module_count'] == 411, 'module partition')
reused_identities_checked = 0
for module, receipt in receipts.items():
    check(re.fullmatch(r'[0-9a-f]{64}', receipt['identity']) is not None, module + ' receipt identity syntax')
    if receipt['reused']:
        previous_receipt = old_report['module_receipts'][module]
        check(r['compile_context'] == old_report['compile_context'], module + ' reused compiler/imported-object context')
        check(receipt['identity'] == previous_receipt['identity'], module + ' unchanged source/import closure identity')
        check(receipt['object_files'] == previous_receipt['object_files'] and receipt['olean_sha256'] == previous_receipt['olean_sha256'], module + ' exact reused compiler output hashes')
        reused_identities_checked += 1
check(metrics['target_loc'] == old_report['metrics']['target_loc'] == 50417, 'unchanged target LOC')
check(metrics['fresh_loc'] + metrics['reused_loc'] == metrics['target_loc'], 'LOC partition')
check(metrics['audit_fresh_count'] == 71 and metrics['audit_reused_count'] == 0, '71 fresh package audits')
actual = {e['id']: e for e in r['endpoints']}
check(len(actual) == len(r['endpoints']) == len(expected) == 71, '71 unique endpoint packages')
check(set(actual) == {e['id'] for e in expected}, 'exact package inventory')

def verify_log(record, names, label):
    check(record['status'] == 'PASS' and record['audit_origin_commit'] == SHA and record['audit_reused'] is False, label + ' fresh PASS')
    check(set(record['types']) == set(record['axioms']) == set(names), label + ' exact declared names')
    relative = Path(record['audit_log'])
    check(not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] == 'registry', label + ' safe log path')
    log = E / relative.relative_to('registry')
    check(digest(log) == record['audit_sha256'], label + ' raw log SHA256')
    text = log.read_text()
    check(not re.search(r'\bsorryAx\b|\bwarning\s*:.*\bsorry\b|\berror(?:\([^\n)]*\))?\s*:', text, re.I), label + ' no error/admission')
    sentinels = re.findall(r'^(TYPE_BEGIN|TYPE_END|AXIOMS_BEGIN|AXIOMS_END):(.*)$', text, re.M)
    check(sentinels == [(s, n) for n in names for s in ['TYPE_BEGIN', 'TYPE_END', 'AXIOMS_BEGIN', 'AXIOMS_END']], label + ' ordered raw coverage')
    for name in names:
        body = re.search(r'^TYPE_BEGIN:' + re.escape(name) + r'\n(.*?)\nTYPE_END:' + re.escape(name) + r'$', text, re.M | re.S).group(1)
        check(norm(body) == norm(record['types'][name]), name + ' raw type')
        body = re.search(r'^AXIOMS_BEGIN:' + re.escape(name) + r'\n(.*?)\nAXIOMS_END:' + re.escape(name) + r'$', text, re.M | re.S).group(1)
        match = re.fullmatch("'" + re.escape(name) + r"'\s+depends on axioms:\s*\[([^\]]*)\]", body.strip(), re.S)
        if match:
            deps = {re.sub(r'\.\{[^}]*\}', '', s.strip()) for s in match.group(1).split(',') if s.strip()}
        else:
            check(re.fullmatch("'" + re.escape(name) + r"'\s+does not depend on any axioms\.?", body.strip()) is not None, name + ' raw axiom grammar')
            deps = set()
        check(deps <= STANDARD and deps == set(record['axioms'][name]), name + ' approved exact axioms')

names_seen = []
for spec in expected:
    check(after[spec['path']][0] == spec['blob_sha'], spec['id'] + ' pinned manifest bytes')
    record = actual[spec['id']]
    names = [e['name'] for e in spec['declarations']]
    names_seen.extend(names)
    check(record['source_drift'] == [], spec['id'] + ' no source drift')
    check(set(spec['allowed_axioms']) == STANDARD, spec['id'] + ' standard axiom policy')
    check(record['declaration_count'] == len(names) == len(set(names)), spec['id'] + ' declaration count')
    check({k: norm(v) for k, v in record['types'].items()} == {k: norm(v) for k, v in old_endpoints[spec['id']]['types'].items()}, spec['id'] + ' unchanged accepted types')
    check(record['axioms'] == old_endpoints[spec['id']]['axioms'], spec['id'] + ' unchanged accepted axiom sets')
    verify_log(record, names, spec['id'])
check(len(names_seen) == len(set(names_seen)) == 448, '448 unique named declarations')
q = r['cutout']
verify_log(q, ['QuasiFeffermanB.QUASI_FEFFERMAN_B_COMPOSED'], 'standalone QFB')
check(q['source_sha256'] == old_report['cutout']['source_sha256'], 'unchanged QFB source SHA256')
check(q['types'] == old_report['cutout']['types'] and q['axioms'] == old_report['cutout']['axioms'], 'unchanged QFB theorem and axioms')
plan = read(E / 'run-plan.json')
check(plan['tested_revision'] == SHA and plan['requested_revision'] == SHA, 'runtime plan checkout identity')
check(set(plan['targets']) == set(actual) and len(plan['targets']) == 71, 'runtime plan full audit scope')
check(plan['fresh_required_audits'] is True and plan['local_lean_allowed'] is False and plan['mathlib_source_build_allowed'] is False, 'runtime plan execution boundaries')
for field in ['source_manifest_sha256', 'audit_policy_sha256', 'lean_toolchain', 'mathlib_revision']:
    check(plan[field] == read(PREVIOUS / 'evidence/run-plan.json')[field], 'unchanged runtime plan ' + field)

jobs = read(B / 'job-metadata.json')
job_map = {j['id']: j for j in jobs['jobs']}
for field, name in [('fast_job_id', 'Fast cached verification'), ('accepted_job_id', 'Material accepted')]:
    job = job_map[jobs[field]]
    check(job['run_id'] == RUN and job['name'] == name and job['status'] == 'completed' and job['conclusion'] == 'success', 'completed matching ' + name)
fast = gzip.decompress((B / 'fast-job.log.gz').read_bytes()).decode()
accept = (B / 'accepted-job.log').read_text()
check(SHA in fast, 'checkout SHA in runner log')
check('PRIMARY_ACCEPTED: true' in accept and 'PRIMARY_RESULT: success' in accept and 'PRIMARY_FAILURE_CLASS: NONE' in accept, 'terminal acceptance gate')
for step in ['publish_binary', 'published_identities', 'final_evidence']:
    check('id=worker.' + step + ';outcome=success;conclusion=success' in fast, step + ' completed')
check(re.search(r'Ran 183 tests', fast) is not None, '183 external controls')
meta = read(B / 'artifact-metadata.json')
check(meta['workflow_run']['id'] == RUN and meta['workflow_run']['head_sha'] == SHA and meta['workflow_run']['head_branch'] == BRANCH, 'artifact exact branch/run/commit')
check(not meta['expired'], 'artifact not expired')
check((B / 'evidence.zip').stat().st_size == meta['size_in_bytes'], 'artifact download size')
if meta.get('digest'):
    check('sha256:' + digest(B / 'evidence.zip') == meta['digest'], 'artifact upstream digest')

root = actual['EhrenfestObstructionRoot']
root_name = 'MethbokeAddon.EhrenfestObstruction.EHRENFEST_OBSTRUCTION'
for package in ['EhrenfestObstructionRoot', 'EhrenfestEventualEnstrophyBound']:
    shutil.copy2(E / actual[package]['audit_log'].removeprefix('registry/'), B / (package + '.log'))
shutil.copy2(E / 'current.json', B / 'current.json')
summary = {
    'schema_version': 1, 'status': 'BRANCH_CI_EXTERNAL_VERIFICATION_ACCEPTED',
    'review_kind': 'independent_static_text_json_hash_review', 'checks_passed': checks,
    'branch': BRANCH, 'layout_base_commit': BASE, 'tested_commit': SHA,
    'run_id': RUN, 'run_url': r['run_url'], 'job_id': jobs['fast_job_id'], 'accepted_job_id': jobs['accepted_job_id'],
    'toolchain': r['toolchain'], 'compiler': r['compiler'], 'mathlib_commit': r['mathlib_commit'],
    'platform': r['platform'], 'runner_label': 'ubuntu-24.04', 'metrics': metrics,
    'module_workers': r['module_workers'], 'lean_threads': r['lean_num_threads'],
    'dependency_cache_class': r['dependency_cache_class'], 'project_cache_class': r['project_cache_class'],
    'driver_seconds': r['total_seconds'], 'required_packages': 71, 'named_declaration_audits': 448,
    'fresh_qfb_cutout': True, 'external_controls_passed': 183, 'standard_axioms_only': True,
    'root_type': root['types'][root_name], 'root_axioms': root['axioms'][root_name],
    'proof_and_runtime_sources_unchanged': True, 'trigger_only_workflow_change': True,
    'historical_readme_rebases_since_accepted_source': sorted(accepted_document_differences),
    'reused_module_identities_checked': reused_identities_checked,
    'source_pin_integrity': True, 'all_expected_names_checked': True, 'all_audit_log_hashes_match': True,
    'final_gate': 'PASS', 'required_publication': 'PASS', 'new_theorems': 0,
    'stopped_witness_proved': False, 'full_operator_realization_proved': False, 'local_lean_executions': 0,
    'artifact_id': meta['id'], 'artifact_bytes': meta['size_in_bytes'], 'artifact_sha256': digest(B / 'evidence.zip'),
    'report_sha256': digest(E / 'current.json'), 'root_audit_sha256': root['audit_sha256'],
    'boundary': 'Revalidates the reorganized branch and unchanged conditional theorem. No new stopped-bound witness, unconditional obstruction, or operator realization is proved.'}
(B / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
independent = {key: summary[key] for key in ['schema_version', 'review_kind', 'tested_commit', 'run_id', 'checks_passed', 'local_lean_executions', 'artifact_sha256', 'report_sha256', 'root_audit_sha256', 'new_theorems', 'stopped_witness_proved', 'full_operator_realization_proved']}
independent.update(status='PASS', layout_base_commit=BASE, source_inputs_sha256=digest(B / 'source-inputs.json'),
                   review_script_sha256=digest(Path(__file__)), expected_inventory_sha256=digest(OLD / 'expected-manifests.json'),
                   accepted_job_log_sha256=digest(B / 'accepted-job.log'), compressed_fast_job_log_sha256=digest(B / 'fast-job.log.gz'),
                   scope='Exact branch/commit/source bytes; complete 411-module, 71-package, 448-name and standalone QFB audit coverage; standard axioms; artifact/log hashes; final acceptance/publication.')
(B / 'independent-review.json').write_text(json.dumps(independent, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(summary, indent=2, ensure_ascii=False))
