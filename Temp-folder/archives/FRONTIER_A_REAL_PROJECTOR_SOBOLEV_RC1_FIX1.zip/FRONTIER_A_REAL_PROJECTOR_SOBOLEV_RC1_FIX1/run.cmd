@echo off
setlocal EnableExtensions DisableDelayedExpansion
if not "%OS%"=="Windows_NT" exit /b 2
set "PKG=%~dp0"
set "KTF_SELF=%~f0"
set "MOD=FrontierCanonicalGradientBudgetRoot"
set "SRC_PIN=eb0c8f0e154b8b11c9816af00e236bd47144e1b11349c791cd424a02053988b6"
set "ZIP_PIN=7f450342fb32d517235756b25c92d5c7a30311c1573c28e5cc2a10ef7b672578"
set "TARGETS="
set "TOOLS=%SystemRoot%\System32"
set "CT=%SystemRoot%\System32\certutil.exe"
set "FS=%SystemRoot%\System32\findstr.exe"
set "KTF_WORK=%PKG%evidence\r2-%RANDOM%-%RANDOM%-%RANDOM%"
set "KTF_CACHE=%LOCALAPPDATA%\FrontierA\RC1_CanonicalGradient"
if defined FRONTIER_A_CACHE_ROOT set "KTF_CACHE=%FRONTIER_A_CACHE_ROOT%"
mkdir "%KTF_WORK%" 2>nul || exit /b 2
pushd "%KTF_WORK%" || exit /b 2
>result.txt echo RESULT=INCOMPLETE
echo PACKAGE=FRONTIER_A_REAL_PROJECTOR_SOBOLEV_RC1_FIX1
echo EVIDENCE="%KTF_WORK%"
echo [1/5] Checking pinned source and unpacking the native build inputs...
set "WHY=source_or_input_integrity"
copy /b "%PKG%%MOD%.lean" "canonical.lean" >nul || goto :fail
call :checkhash "canonical.lean" "%SRC_PIN%" "canonical.sha256" || goto :fail
copy /b "%PKG%payload.zip" "payload.zip" >nul || goto :fail
call :checkhash "payload.zip" "%ZIP_PIN%" "payload.sha256" || goto :fail
mkdir payload || goto :fail
"%TOOLS%\tar.exe" -xf payload.zip -C payload || goto :fail
fc /b "canonical.lean" "payload\%MOD%.lean" >nul || goto :fail
for %%S in ("payload\*.lean") do (
  fc /b "%%~fS" "%PKG%%%~nxS" >nul
  if errorlevel 1 goto :fail
)

echo [2/5] Selecting native Windows Lean 4.34.0-rc1 and one precompiled Mathlib tree...
set "WHY=compiler_lookup"
set "KTF_LEAN="
if defined LEAN_434_RC1_EXE set "KTF_LEAN=%LEAN_434_RC1_EXE%"
if not defined KTF_LEAN if defined LEAN_EXE set "KTF_LEAN=%LEAN_EXE%"
if not defined KTF_LEAN if defined ELAN_HOME call :lean_at "%ELAN_HOME%\toolchains\leanprover--lean4---v4.34.0-rc1\bin\lean.exe"
if not defined KTF_LEAN call :lean_at "%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.34.0-rc1\bin\lean.exe"
if not defined KTF_LEAN if defined CACHE_ROOT call :lean_at "%CACHE_ROOT%\LOCAL_COMPILER\lean-4.34.0-rc1\bin\lean.exe"
if not defined KTF_LEAN if defined MATHLIB_CACHE_ROOT call :lean_at "%MATHLIB_CACHE_ROOT%\LOCAL_COMPILER\lean-4.34.0-rc1\bin\lean.exe"
if not defined KTF_LEAN goto :fail
if not exist "%KTF_LEAN%" goto :fail
for %%L in ("%KTF_LEAN%") do set "KTF_LEAN=%%~fL"
for %%L in ("%KTF_LEAN%") do if exist "%%~dpLelan.exe" goto :fail
set "WHY=compiler_version_or_prefix"
"%KTF_LEAN%" --version >lean-version.log 2>&1 || goto :fail
type lean-version.log
"%FS%" /B /L /C:"Lean (version 4.34.0-rc1, x86_64-w64-windows-gnu," lean-version.log >nul || goto :fail
"%CT%" -hashfile "%KTF_LEAN%" SHA256 >compiler.sha256 2>&1 || goto :fail
"%KTF_LEAN%" --print-prefix >lean-prefix.log 2>&1 || goto :fail
set "LEAN_SYSROOT="
set /p "LEAN_SYSROOT="<lean-prefix.log
if not exist "%LEAN_SYSROOT%\lib\lean\Init.olean" goto :fail
set "PATH=%LEAN_SYSROOT%\bin;%PATH%"
set "KTF_ORIGINAL_PATH=%LEAN_PATH%"
set "KTF_BASE_PATH="
set "KTF_MLIB="
set "WHY=Mathlib_cache_set_MATHLIB_CACHE_ROOT"
type nul >"mathlib-roots.txt" || goto :fail
if not defined MATHLIB_OLEAN_ROOT if defined MATHLIB_LEAN_PATH set "MATHLIB_OLEAN_ROOT=%MATHLIB_LEAN_PATH%"
if not defined MATHLIB_OLEAN_ROOT if defined MATHLIB_OLEAN_PATH set "MATHLIB_OLEAN_ROOT=%MATHLIB_OLEAN_PATH%"
if not defined MATHLIB_OLEAN_ROOT if defined MATHLIB_CACHE_ROOT set "MATHLIB_OLEAN_ROOT=%MATHLIB_CACHE_ROOT%"
if not defined MATHLIB_OLEAN_ROOT goto :fail
call :select_cache "%MATHLIB_OLEAN_ROOT%"
if not defined KTF_MLIB goto :fail
:cache_selected
set "LEAN_PATH=%KTF_BASE_PATH%"
set KTF_LEAN >lean-executable.log
set KTF_BASE_PATH >lean-path.log
echo MATHLIB="%KTF_MLIB%"
"%CT%" -hashfile "%KTF_MLIB%" SHA256 >mathlib.sha256 2>&1 || goto :fail
set "NO_COLOR=1"

echo [3/5] Building the offline scheduler with Windows .NET Framework...
set "WHY=framework_csc_missing_or_failed"
set "KTF_CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%KTF_CSC%" set "KTF_CSC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%KTF_CSC%" goto :fail
"%KTF_CSC%" /nologo /optimize+ /target:exe /out:BuildR2.exe "payload\BuildR2.cs" "payload\BuildCache.cs" >helper-build.log 2>&1 || goto :fail
"%CT%" -hashfile BuildR2.exe SHA256 >helper.sha256 2>&1 || goto :fail
"%KTF_CSC%" /nologo /optimize+ /target:exe /out:AuditValidator.exe "payload\AuditValidator.cs" >>helper-build.log 2>&1 || goto :fail
"%KTF_WORK%\AuditValidator.exe" --self-test >>helper-build.log 2>&1 || goto :fail

>AuditR2.lean echo import %MOD%
>>AuditR2.lean echo set_option format.width 4096
>SignaturesR2.lean echo import %MOD%
>>SignaturesR2.lean echo set_option format.width 4096
type nul >target-names.txt
for /f "usebackq delims=" %%T in ("payload\targets.txt") do (
  >>AuditR2.lean echo #print axioms %%T
  >>SignaturesR2.lean echo #check %%T
  >>target-names.txt echo %%T
)
echo [4/5] Starting the module scheduler and the two fresh native imports...
set "WHY=module_build_or_import_audit_see_run-build.log"
"%KTF_WORK%\BuildR2.exe" || goto :fail
if not exist "out\%MOD%.olean" goto :fail
echo [5/5] Validating all named theorem-level axiom reports...
set "WHY=unknown_or_missing_axiom_report"
"%KTF_WORK%\AuditValidator.exe" target-names.txt run-audit.log normalized-audit.log >audit-validation.log 2>&1 || goto :fail
set "WHY=post_audit_identity"
fc /b "canonical.lean" "%PKG%%MOD%.lean" >nul || goto :fail
for %%S in ("payload\*.lean") do (
  fc /b "%%~fS" "%PKG%%%~nxS" >nul
  if errorlevel 1 goto :fail
)
>result.txt echo RESULT=PASS
>>result.txt echo SCOPE=PHYSICAL_TRANSFER_CONDITIONAL;PHYSICAL_REALIZATION_OPEN
>>result.txt echo CANONICAL_SHA256=%SRC_PIN%
>>result.txt echo BUILD_INPUTS_SHA256=%ZIP_PIN%
>>result.txt echo AXIOM_AUDIT=STANDARD_ONLY_414_NAMED_THEOREMS
>>result.txt echo FRONTIER_A_REAL_PROJECTOR_SOBOLEV:PASS
>>result.txt echo PHYSICAL_R3_FOURIER_HELICAL_REALIZATION=NOT_FORMALIZED
>>result.txt echo FEFFERMAN_A_REGULARITY=OPEN
>>result.txt echo RUN=PASS
type normalized-audit.log
type result.txt
echo EVIDENCE="%KTF_WORK%"
popd
exit /b 0

:fail
>result.txt echo RESULT=FAIL
>>result.txt echo RUN=FAIL
>>result.txt echo REASON=%WHY%
type result.txt
if exist helper-build.log type helper-build.log
if exist run-signatures.log type run-signatures.log
if exist audit-validation.log type audit-validation.log
if exist run-audit.log type run-audit.log
echo EVIDENCE="%KTF_WORK%"
popd
exit /b 1

:lean_at
if not exist "%~1" exit /b 0
if exist "%~dp1elan.exe" exit /b 0
if not exist "%~dp1..\lib\lean\Init.olean" exit /b 0
"%~1" --version >compiler-probe.log 2>&1 || exit /b 0
"%FS%" /B /L /C:"Lean (version 4.34.0-rc1, x86_64-w64-windows-gnu," compiler-probe.log >nul || exit /b 0
set "KTF_LEAN=%~f1"
exit /b 0

:try_env_mathlib
if /I not "%~1"=="%~f1" exit /b 0
if exist "%~f1\Mathlib.olean" call :select_cache "%~f1"
exit /b 0

:try_env_dep
if /I not "%~1"=="%~f1" exit /b 0
if exist "%~f1\." call :add_dep "%~f1"
exit /b 0

:select_cache
set "CAND=%~f1"
if exist "%CAND%\Mathlib.olean" (
 set "KTF_MLIB=%CAND%\Mathlib.olean"
 call :add_dep "%CAND%"
 for %%Q in ("%CAND%\..\..\..\..") do call :same_packages "%%~fQ"
 for %%Q in ("%CAND%\..\..\..\..\..\..\..") do call :same_packages "%%~fQ"
 exit /b 0
)
if exist "%CAND%\.lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean" (
 set "KTF_MLIB=%CAND%\.lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean"
 call :add_dep "%CAND%\.lake\packages\mathlib\.lake\build\lib\lean"
 call :same_packages "%CAND%"
 call :same_packages "%CAND%\.lake\packages\mathlib"
 exit /b 0
)
if exist "%CAND%\mathlib\.lake\build\lib\lean\Mathlib.olean" (
 set "KTF_MLIB=%CAND%\mathlib\.lake\build\lib\lean\Mathlib.olean"
 call :add_dep "%CAND%\mathlib\.lake\build\lib\lean"
 call :same_packages "%CAND%\mathlib"
 for /d %%Q in ("%CAND%\*") do if exist "%%~fQ\.lake\build\lib\lean\." call :add_dep "%%~fQ\.lake\build\lib\lean"
 call :same_packages "%CAND%"
 exit /b 0
)
if exist "%CAND%\.lake\build\lib\lean\Mathlib.olean" (
 set "KTF_MLIB=%CAND%\.lake\build\lib\lean\Mathlib.olean"
 call :add_dep "%CAND%\.lake\build\lib\lean"
 call :same_packages "%CAND%"
 for %%Q in ("%CAND%\..\..\..") do call :same_packages "%%~fQ"
)
exit /b 0

:same_packages
if exist "%~1\.lake\packages\." for /d %%Q in ("%~1\.lake\packages\*") do if exist "%%~fQ\.lake\build\lib\lean\." call :add_dep "%%~fQ\.lake\build\lib\lean"
exit /b 0

:add_dep
if not defined KTF_BASE_PATH goto :first_dep
for /f "usebackq delims=" %%H in ("mathlib-roots.txt") do if /I "%%~H"=="%~f1" exit /b 0
set "KTF_BASE_PATH=%KTF_BASE_PATH%;%~f1"
goto :record_dep

:first_dep
set "KTF_BASE_PATH=%~f1"

:record_dep
>>"mathlib-roots.txt" echo "%~f1"
exit /b 0

:checkhash
"%CT%" -hashfile "%~1" SHA256 >"%~3" 2>&1 || exit /b 1
"%FS%" /I /L /X /C:"%~2" "%~3" >nul || exit /b 1
exit /b 0

:allow
>>allowed-lines.txt echo '%~1' does not depend on any axioms
for %%A in (propext Classical.choice Quot.sound) do (
 >>allowed-lines.txt echo '%~1' depends on axioms: [%%A]
 for %%B in (propext Classical.choice Quot.sound) do if not "%%B"=="%%A" (
  >>allowed-lines.txt echo '%~1' depends on axioms: [%%A, %%B]
  for %%C in (propext Classical.choice Quot.sound) do if not "%%C"=="%%A" if not "%%C"=="%%B" >>allowed-lines.txt echo '%~1' depends on axioms: [%%A, %%B, %%C]
 )
)
exit /b 0

