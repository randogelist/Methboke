using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

// Offline Windows build scheduler. The imported theorem audit runs separately.
internal static class BuildR2
{
    const int ThreadBudget = 16;
    const string Root = "FrontierCanonicalGradientBudgetRoot";
    static readonly object ConsoleLock = new object();
    static volatile string phase = "initializing";
    static volatile bool cancelled;
    static StreamWriter transcript;
    static readonly UTF8Encoding Utf8 = new UTF8Encoding(false);

    internal static int Main(string[] args)
    {
        try {
            if (args.Length != 0) {
                if (args.Length != 2 || args[0] != "--object-snapshot")
                    throw new ArgumentException("Usage: BuildR2.exe [--object-snapshot OUTPUT_DIRECTORY]");
                ObjectSnapshot(args[1], Console.Out);
                return 0;
            }
            string work = FullEnv("KTF_WORK");
            string lean = FullEnv("KTF_LEAN");
            string basePath = Environment.GetEnvironmentVariable("KTF_BASE_PATH");
            if (String.IsNullOrEmpty(basePath) || !File.Exists(lean))
                throw new InvalidDataException("A native KTF_LEAN and external KTF_BASE_PATH are required.");
            var importRoots = new List<string>();
            foreach (string entry in basePath.Split(';')) {
                string dir = entry.Trim().Trim('"');
                if (dir.Length == 0) continue;
                if (!Path.IsPathRooted(dir) || Path.GetPathRoot(dir).Length < 3 || !Directory.Exists(dir))
                    throw new InvalidDataException("External import root must be an existing absolute directory: " + dir);
                importRoots.Add(Path.GetFullPath(dir));
            }
            if (importRoots.Count == 0) throw new InvalidDataException("Empty external import path.");
            basePath = String.Join(";", importRoots.ToArray());
            string payload = Path.Combine(work, "payload");
            string output = Path.Combine(work, "out");
            string logs = Path.Combine(work, "logs");
            if (Directory.Exists(output) || Directory.Exists(logs))
                throw new IOException("KTF_WORK must be a fresh attempt: out or logs already exists.");
            Directory.CreateDirectory(output);
            Directory.CreateDirectory(logs);
            int maxWorkers = Option("KTF_WORKERS", 4, 1, 4);
            int timeout = Option("KTF_MODULE_TIMEOUT_MINUTES", 180, 1, 1440);
            using (var report = new StreamWriter(Path.Combine(work, "run-build.log"), false, Utf8)) {
                report.AutoFlush = true;
                transcript = report;
                Console.CancelKeyPress += delegate(object sender, ConsoleCancelEventArgs e) {
                    e.Cancel = true;
                    cancelled = true;
                };
                using (var timer = new Timer(delegate {
                    try { Say("HEARTBEAT " + phase); } catch (IOException) { }
                }, null, 10000, 10000)) {
                    try {
                        Say("BUILD_START worker_cap=" + maxWorkers + " total_lean_threads=16 timeout_minutes=" + timeout);
                        List<Unit> units = ReadGraph(payload, output);
                        phase = "validating native toolchain and external cache inputs";
                        Say("CACHE_CHECK_START");
                        using (var cache = new BuildCache(Environment.GetEnvironmentVariable("KTF_CACHE"),
                            lean, basePath, work, "R2 direct -j N -E hasSorry -o MODULE.olean MODULE.lean; exact -j key v1")) {
                            Say("CACHE_CHECK_DONE identity=" + cache.AmbientId);
                            try {
                                Build(units, lean, basePath, output, logs, cache, maxWorkers, timeout);
                                string graphStatus = phase;
                                AuditImports(work, output, lean, basePath, timeout);
                                PrecommitAudit(work);
                                phase = graphStatus + " native_audit_imports=2";
                            } catch (Exception e) {
                                Say("CACHE_PUBLICATION_SKIPPED build or audit did not complete");
                                throw;
                            }
                            string completed = phase;
                            phase = "checking dependency tree stability";
                            cache.VerifyAmbient();
                            phase = completed;
                        }
                        Say("BUILD_GRAPH_OK " + phase);
                        return 0;
                    } catch (Exception e) {
                        Say("BUILD_GRAPH_FAIL " + e.Message);
                        return 1;
                    } finally {
                        lock (ConsoleLock) { transcript = null; }
                    }
                }
            }
        } catch (Exception e) {
            Console.Error.WriteLine("BUILD_GRAPH_FAIL " + e.Message);
            return 1;
        }
    }

    // Do not publish cache generations until the root signature import, fresh
    // axiom import and independent standard-only audit have all succeeded.
    static void PrecommitAudit(string work)
    {
        string validator = Path.Combine(work, "AuditValidator.exe");
        var info = new ProcessStartInfo(validator, "target-names.txt run-audit.log precommit-normalized-audit.log");
        info.WorkingDirectory = work;
        info.UseShellExecute = false;
        using (var proc = Process.Start(info)) {
            if (proc == null) throw new IOException("Could not start precommit axiom validator.");
            if (!proc.WaitForExit(180000)) { proc.Kill(); throw new TimeoutException("Precommit audit validation timed out."); }
            if (proc.ExitCode != 0) throw new InvalidDataException("Precommit standard-only axiom audit failed.");
        }
        Say("PRECOMMIT_AXIOM_AUDIT=PASS_STANDARD_ONLY");
    }

    // Machine-readable output only. The independent auditor compares two invocations byte for byte.
    static void ObjectSnapshot(string directory, TextWriter destination)
    {
        if (String.IsNullOrEmpty(directory) || !Path.IsPathRooted(directory))
            throw new ArgumentException("Snapshot output directory must be absolute.");
        string root = Path.GetFullPath(directory);
        string[] suffixes = { ".olean.private", ".olean.server", ".ir.sig", ".olean", ".ilean", ".ir" };
        var selected = new List<string>();
        int primary = 0;
        foreach (string path in Directory.GetFiles(root, "*", SearchOption.TopDirectoryOnly)) {
            string name = Path.GetFileName(path);
            foreach (string suffix in suffixes) {
                if (!name.EndsWith(suffix, StringComparison.OrdinalIgnoreCase)) continue;
                string module = name.Substring(0, name.Length - suffix.Length);
                if (!Regex.IsMatch(module, @"\A[A-Za-z][A-Za-z0-9_]*\z") ||
                    !File.Exists(Path.Combine(root, module + ".olean")))
                    throw new InvalidDataException("Unexpected or orphan module part: " + name);
                if (suffix == ".olean") primary++;
                selected.Add(name);
                break;
            }
        }
        if (primary == 0) throw new InvalidDataException("No primary .olean objects in " + root);
        selected.Sort(StringComparer.Ordinal);
        destination.WriteLine("KTF_OBJECT_SNAPSHOT_V1 modules=" + primary + " parts=" + selected.Count);
        foreach (string name in selected) {
            using (var stream = new FileStream(Path.Combine(root, name), FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var sha = SHA256.Create()) {
                if (name.EndsWith(".olean", StringComparison.OrdinalIgnoreCase) && stream.Length == 0)
                    throw new InvalidDataException("Empty primary module: " + name);
                string digest = BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
                destination.WriteLine(name + "\t" + stream.Length.ToString(CultureInfo.InvariantCulture) + "\t" + digest);
            }
        }
    }

    static void SaveSnapshot(string output, string path)
    {
        using (var writer = new StreamWriter(new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read), Utf8))
            ObjectSnapshot(output, writer);
    }

    static void AuditImports(string work, string output, string lean, string basePath, int timeout)
    {
        string before = Path.Combine(work, "objects-before.tsv");
        string after = Path.Combine(work, "objects-after.tsv");
        phase = "snapshotting all compiled module objects before audit";
        Say("OBJECT_SNAPSHOT_BEFORE");
        SaveSnapshot(output, before);
        try {
            using (var s = new FileStream(Path.Combine(work, "SignaturesR2.lean"), FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var a = new FileStream(Path.Combine(work, "AuditR2.lean"), FileMode.Open, FileAccess.Read, FileShare.Read)) {
                AuditOne(work, output, lean, basePath, timeout, "SignaturesR2", "run-signatures.log");
                AuditOne(work, output, lean, basePath, timeout, "AuditR2", "run-audit.log");
            }
        } finally {
            phase = "snapshotting all compiled module objects after audit";
            SaveSnapshot(output, after);
            // Both manifests are small, ordinal-sorted and UTF-8 without a BOM.
            if (!String.Equals(File.ReadAllText(before, Utf8), File.ReadAllText(after, Utf8), StringComparison.Ordinal))
                throw new IOException("Module artifacts changed across native signature/axiom imports.");
        }
        Say("OBJECT_SNAPSHOT_MATCH");
    }

    static void AuditOne(string work, string output, string lean, string basePath,
                         int timeout, string name, string log)
    {
        if (cancelled) throw new OperationCanceledException("Interrupted.");
        var unit = new Unit { Name = name };
        using (var owner = new ProcessJob())
        using (var worker = new Worker(unit, null, ThreadBudget, Path.Combine(work, log))) {
            try {
                phase = "launching fresh import " + name;
                worker.Start(lean, basePath, output, owner, work, "-j 16 -E hasSorry " + name + ".lean");
                Say("AUDIT_START " + name + " pid=" + worker.Process.Id + " -j16 log=" + worker.LogPath);
                while (!worker.Process.WaitForExit(250)) {
                    if (cancelled) throw new OperationCanceledException("Interrupted.");
                    if (worker.Elapsed.Elapsed.TotalMinutes > timeout)
                        throw new TimeoutException(name + " exceeded timeout. Log: " + worker.LogPath);
                    phase = "auditing " + name + " pid=" + worker.Process.Id + " elapsed_s=" +
                        (long)worker.Elapsed.Elapsed.TotalSeconds;
                }
                worker.Finish();
                if (worker.Process.ExitCode != 0) {
                    PrintTail(worker.LogPath);
                    throw new CompilerFailed(name + " exit=" + worker.Process.ExitCode + " log=" + worker.LogPath);
                }
                Say("AUDIT_IMPORT_FINISHED " + name + " exit=0");
            } finally { owner.Dispose(); }
        }
    }

    static void Say(string message)
    {
        string line = "[" + DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture) + "] " + message;
        lock (ConsoleLock) {
            Console.WriteLine(line);
            if (transcript != null) transcript.WriteLine(line);
        }
    }

    static string FullEnv(string name)
    {
        string value = Environment.GetEnvironmentVariable(name);
        if (String.IsNullOrEmpty(value) || !Path.IsPathRooted(value))
            throw new ArgumentException(name + " must be an absolute path.");
        return Path.GetFullPath(value);
    }

    static int Option(string name, int fallback, int min, int max)
    {
        string value = Environment.GetEnvironmentVariable(name);
        int number;
        if (String.IsNullOrEmpty(value)) return fallback;
        if (!Int32.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out number) ||
            number < min || number > max) throw new ArgumentException(name + " out of range.");
        return number;
    }

    sealed class CompilerFailed : Exception
    {
        internal CompilerFailed(string message) : base(message) { }
    }

    sealed class Unit
    {
        internal string Name, SourceHash, Identity, Lineage;
        internal readonly List<string> Imports = new List<string>();
        internal bool Running, Failed, Blocked;
        internal string FailureLog, BlockedBy;
        internal int Level = -1, Threads;
    }

    static List<Unit> ReadGraph(string payload, string output)
    {
        var units = new List<Unit>();
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (string line in File.ReadAllLines(Path.Combine(payload, "graph.tsv"))) {
            string[] words = line.Split(new char[] {' ', '\t'}, StringSplitOptions.RemoveEmptyEntries);
            if (words.Length == 0) continue;
            foreach (string word in words)
                if (!Regex.IsMatch(word, @"\A[A-Za-z][A-Za-z0-9_]*\z"))
                    throw new InvalidDataException("Invalid flat module name: " + word);
            if (!names.Add(words[0])) throw new InvalidDataException("Duplicate module: " + words[0]);
            var unit = new Unit {Name = words[0]};
            for (int i = 1; i < words.Length; i++) unit.Imports.Add(words[i]);
            if (new HashSet<string>(unit.Imports).Count != unit.Imports.Count)
                throw new InvalidDataException("Duplicate dependency for " + unit.Name);
            units.Add(unit);
        }
        var sourceNames = new HashSet<string>(StringComparer.Ordinal);
        foreach (Unit u in units) sourceNames.Add(u.Name);
        if (!sourceNames.Contains(Root)) throw new InvalidDataException("Missing graph root.");
        foreach (Unit u in units) {
            foreach (string dep in u.Imports) if (!sourceNames.Contains(dep) || dep == u.Name)
                throw new InvalidDataException("Bad graph edge " + u.Name + " -> " + dep);
            string src = Path.Combine(payload, u.Name + ".lean");
            byte[] bytes = File.ReadAllBytes(src);
            using (var sha = SHA256.Create())
                u.SourceHash = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
            string sourceText = (new UTF8Encoding(false, true)).GetString(bytes).TrimStart('\uFEFF');
            var locals = new HashSet<string>(StringComparer.Ordinal);
            foreach (Match header in Regex.Matches(sourceText, @"(?m)^[ \t]*(?:(?:public|meta|private|all)\s+)*import\b[^\r\n]*")) {
                Match imp = Regex.Match(header.Value, @"^import ([A-Za-z0-9_.]+)[ \t]*$");
                if (!imp.Success) throw new InvalidDataException("Unsupported import in " + u.Name + ": " + header.Value);
                string name = imp.Groups[1].Value;
                if (sourceNames.Contains(name)) locals.Add(name);
                else if (name != "Mathlib" && !name.StartsWith("Mathlib.", StringComparison.Ordinal) && name != "Batteries.Tactic.Lemma") throw new InvalidDataException("Unexpected external import: " + name);
            }
            if (!locals.SetEquals(u.Imports))
                throw new InvalidDataException("Source imports differ from graph for " + u.Name);
            File.WriteAllBytes(Path.Combine(output, u.Name + ".lean"), bytes);
        }
        return units;
    }

    static Dictionary<string,string> Dependencies(Unit u, Dictionary<string,Unit> table)
    {
        var result = new Dictionary<string,string>(StringComparer.Ordinal);
        foreach (string name in u.Imports) {
            if (table[name].Lineage == null) return null;
            result.Add(name, table[name].Lineage);
        }
        return result;
    }

    static int GraphLevel(Unit u, Dictionary<string,Unit> table)
    {
        if (u.Level == -2) throw new InvalidDataException("Dependency cycle at " + u.Name);
        if (u.Level >= 0) return u.Level;
        u.Level = -2;
        int level = 0;
        foreach (string dep in u.Imports) level = Math.Max(level, 1 + GraphLevel(table[dep], table));
        u.Level = level;
        return level;
    }

    static string Digest(byte[] bytes)
    {
        using (var sha = SHA256.Create())
            return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
    }

    static void VerifySource(Unit u, string output)
    {
        if (Digest(File.ReadAllBytes(Path.Combine(output, u.Name + ".lean"))) != u.SourceHash)
            throw new IOException("Staged source changed: " + u.Name);
    }

    static void Build(List<Unit> units, string lean, string basePath, string output, string logs,
                      BuildCache cache, int maxWorkers, int timeout)
    {
        var table = new Dictionary<string,Unit>(StringComparer.Ordinal);
        foreach (Unit u in units) table.Add(u.Name, u);
        var widths = new Dictionary<int,int>();
        foreach (Unit u in units) {
            int level = GraphLevel(u, table), count;
            widths.TryGetValue(level, out count); widths[level] = count + 1;
        }
        foreach (Unit u in units) u.Threads = maxWorkers == 1 || widths[u.Level] == 1 ? 16 : 4;
        var sourceGuards = new List<FileStream>();
        var active = new List<Worker>();
        int built = 0, reused = 0, failed = 0, blocked = 0;
        using (var owner = new ProcessJob()) {
            try {
                foreach (Unit u in units) {
                    sourceGuards.Add(new FileStream(Path.Combine(output, u.Name + ".lean"), FileMode.Open, FileAccess.Read, FileShare.Read));
                    VerifySource(u, output);
                }
                while (built + reused + failed + blocked < units.Count) {
                    if (cancelled) throw new OperationCanceledException("Interrupted.");
                    bool changed = false;
                    for (int i = active.Count-1; i >= 0; i--) {
                        Worker w = active[i];
                        if (!w.Process.HasExited) {
                            if (w.Elapsed.Elapsed.TotalMinutes > timeout)
                                throw new TimeoutException(w.Unit.Name + " exceeded the configured timeout. Log: " + w.LogPath);
                            continue;
                        }
                        w.Finish();
                        if (w.Process.ExitCode != 0) {
                            w.Unit.Failed = true;
                            w.Unit.FailureLog = w.LogPath;
                            w.Unit.Running = false;
                            failed++;
                            Say("MODULE_FAILED " + w.Unit.Name + " exit=" + w.Process.ExitCode + " log=" + w.LogPath);
                            PrintTail(w.LogPath);
                            w.Dispose();
                            active.RemoveAt(i);
                            changed = true;
                            continue;
                        }
                        string olean = Path.Combine(output, w.Unit.Name + ".olean");
                        if (!File.Exists(olean) || new FileInfo(olean).Length == 0)
                            throw new IOException(w.Unit.Name + " exited zero without a nonempty .olean.");
                        phase = "validating result " + w.Unit.Name;
                        VerifySource(w.Unit, output);
                        w.Unit.Identity = BuildCache.OutputIdentity(olean);
                        w.Unit.Lineage = cache.Lineage(w.Unit.Name, w.Unit.SourceHash, w.Deps, w.Unit.Identity);
                        cache.Store(w.Unit.Name, w.Unit.SourceHash, w.Deps, olean);
                        built++;
                        Say("COMPILED " + w.Unit.Name + " elapsed=" + w.Elapsed.Elapsed.ToString() +
                            " done=" + (built + reused) + "/" + units.Count);
                        w.Dispose();
                        active.RemoveAt(i);
                        changed = true;
                    }

                    // Propagate terminal failures even when the graph order is not topological.
                    bool propagation;
                    do {
                        propagation = false;
                        foreach (Unit u in units) {
                            if (u.Identity != null || u.Running || u.Failed || u.Blocked) continue;
                            foreach (string name in u.Imports) {
                                Unit dep = table[name];
                                if (!dep.Failed && !dep.Blocked) continue;
                                u.Blocked = true;
                                u.BlockedBy = name;
                                blocked++;
                                propagation = true;
                                changed = true;
                                Say("MODULE_BLOCKED " + u.Name + " dependency=" + name);
                                break;
                            }
                        }
                    } while (propagation);

                    int used = 0;
                    foreach (Worker w in active) used += w.Threads;
                    var ready = new List<Unit>();
                    foreach (Unit u in units)
                        if (u.Identity == null && !u.Running && !u.Failed && !u.Blocked &&
                            Dependencies(u,table) != null) ready.Add(u);
                    for (int i = 0; i < ready.Count; i++) {
                        if (active.Count >= maxWorkers || used >= ThreadBudget) break;
                        Unit u = ready[i];
                        int threads = u.Threads;
                        if (used + threads > ThreadBudget) continue;
                        var deps = Dependencies(u, table);
                        deps.Add("@compiler-threads", Digest(Encoding.ASCII.GetBytes("-j " + threads)));
                        string olean = Path.Combine(output, u.Name + ".olean");
                        phase = "checking reusable object " + u.Name;
                        if (cache.TryRestore(u.Name, u.SourceHash, deps, olean)) {
                            if (!File.Exists(olean) || new FileInfo(olean).Length == 0)
                                throw new IOException("Verified cache restore missing " + u.Name);
                            u.Identity = BuildCache.OutputIdentity(olean);
                            u.Lineage = cache.Lineage(u.Name, u.SourceHash, deps, u.Identity);
                            reused++;
                            Say("REUSED " + u.Name + " done=" + (built + reused) + "/" + units.Count);
                        } else {
                            var w = new Worker(u, deps, threads, Path.Combine(logs, u.Name + ".log"));
                            active.Add(w);
                            u.Running = true;
                            w.Start(lean, basePath, output, owner);
                            used += threads;
                            Say("START " + u.Name + " pid=" + w.Process.Id + " -j" + threads + " log=" + w.LogPath);
                        }
                        changed = true;
                    }
                    var descriptions = new List<string>();
                    foreach (Worker w in active)
                        descriptions.Add(w.Unit.Name + "(pid=" + w.Process.Id + ",j=" + w.Threads +
                            ",elapsed_s=" + (long)w.Elapsed.Elapsed.TotalSeconds + ")");
                    phase = "done=" + (built+reused) + "/" + units.Count + " built=" + built +
                        " reused=" + reused + " active=" + String.Join(",", descriptions.ToArray());
                    if (failed != 0 || blocked != 0)
                        phase += " failed=" + failed + " blocked=" + blocked +
                            " completed=" + (built+reused+failed+blocked) + "/" + units.Count;
                    if (!changed && active.Count == 0 && built+reused+failed+blocked != units.Count)
                        throw new InvalidDataException("Dependency cycle or blocked graph.");
                    if (!changed) Thread.Sleep(200);
                }
                foreach (Unit u in units) {
                    VerifySource(u, output);
                    if (u.Identity != null &&
                        u.Identity != BuildCache.OutputIdentity(Path.Combine(output, u.Name + ".olean")))
                        throw new IOException("Local output changed after acceptance: " + u.Name);
                }
                if (failed != 0) {
                    Say("INDEPENDENT_MODULES_FINISHED built=" + built + " reused=" + reused +
                        " failed=" + failed + " blocked=" + blocked);
                    // Repeat diagnostics at the end, after other workers have
                    // finished, so a tail of console output includes the failure.
                    foreach (Unit u in units) {
                        if (u.Failed) {
                            Say("ERROR_LOG " + u.Name + " " + u.FailureLog);
                            if (!String.IsNullOrEmpty(u.FailureLog) && File.Exists(u.FailureLog))
                                PrintTail(u.FailureLog);
                            else
                                Say("ERROR_LOG_UNAVAILABLE " + u.Name);
                        }
                    }
                    throw new CompilerFailed(failed + " module(s) failed; " + blocked +
                        " descendant(s) blocked. Independent modules finished; root/audits skipped.");
                }
            } finally {
                owner.Dispose(); // terminates any remaining owned workers, including after failure
                foreach (Worker w in active) w.Dispose();
                foreach (FileStream guard in sourceGuards) guard.Dispose();
            }
        }
    }

    static readonly Regex DiagnosticHeader = new Regex(
        @"^\s*(?:.+?:\d+(?::\d+)?(?:-\d+(?::\d+)?)?:\s*)?(error|warning|info|information)(?:\([^)]*\)|\[[^\]]*\])?\s*:",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

    static void PrintTail(string path)
    {
        const int contextLines = 12;
        var tail = new Queue<string>();
        int count = 0, context = 0;
        foreach (string line in File.ReadLines(path)) {
            if (tail.Count == 12) tail.Dequeue();
            tail.Enqueue(line);
            Match heading = DiagnosticHeader.Match(line);
            if (heading.Success) {
                context = 0;
                if (String.Equals(heading.Groups[1].Value, "error", StringComparison.OrdinalIgnoreCase)) {
                    if (count == 0) Say("LEAN_ERROR_DETAILS full_log=" + path);
                    count++;
                    Say("  " + line);
                    context = contextLines;
                }
            } else if (context > 0) {
                Say("  " + line);
                context--;
            }
        }
        if (count != 0) {
            Say("LEAN_ERRORS count=" + count + " showing=" + count + " full_log=" + path);
        } else {
            Say("LAST_LOG_LINES full_log=" + path);
            foreach (string line in tail) Say("  " + line);
        }
    }

    sealed class Worker : IDisposable
    {
        internal readonly Unit Unit;
        internal readonly IDictionary<string,string> Deps;
        internal readonly int Threads;
        internal readonly string LogPath;
        internal readonly Process Process = new Process();
        internal readonly Stopwatch Elapsed = new Stopwatch();
        readonly object gate = new object();
        StreamWriter writer;
        Exception logError;
        bool started, drained;

        internal Worker(Unit unit, IDictionary<string,string> deps, int threads, string logPath)
        {
            Unit = unit; Deps = deps; Threads = threads; LogPath = logPath;
        }

        internal void Start(string lean, string basePath, string output, ProcessJob owner)
        {
            Start(lean, basePath, output, owner, output,
                "-j " + Threads + " -E hasSorry -o " + Unit.Name + ".olean " + Unit.Name + ".lean");
        }

        internal void Start(string lean, string basePath, string output, ProcessJob owner, string working, string arguments)
        {
            writer = new StreamWriter(new FileStream(LogPath, FileMode.CreateNew, FileAccess.Write, FileShare.ReadWrite), Utf8);
            writer.AutoFlush = true;
            var info = new ProcessStartInfo(lean, arguments);
            info.WorkingDirectory = working;
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            info.RedirectStandardOutput = true;
            info.RedirectStandardError = true;
            info.StandardOutputEncoding = Utf8;
            info.StandardErrorEncoding = Utf8;
            string windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            info.EnvironmentVariables["PATH"] = Path.GetDirectoryName(lean) + ";" + Path.Combine(windows, "System32") + ";" + windows;
            info.EnvironmentVariables["LEAN_PATH"] = output + ";" + basePath;
            info.EnvironmentVariables["LEAN_NUM_THREADS"] = Threads.ToString(CultureInfo.InvariantCulture);
            Process.StartInfo = info;
            Process.OutputDataReceived += Capture;
            Process.ErrorDataReceived += Capture;
            if (!Process.Start()) throw new InvalidOperationException("Cannot start " + Unit.Name);
            started = true;
            if (!owner.Attach(Process) && !Process.HasExited) {
                try { Process.Kill(); } catch (InvalidOperationException) { }
                throw new Win32Exception("Could not attach " + Unit.Name + " to the build's Windows job.");
            }
            Elapsed.Start();
            Process.BeginOutputReadLine();
            Process.BeginErrorReadLine();
        }

        void Capture(object sender, DataReceivedEventArgs e)
        {
            if (e.Data == null) return;
            lock (gate) {
                try { if (writer != null) writer.WriteLine(e.Data); }
                catch (Exception problem) { logError = problem; }
            }
        }

        internal void Finish()
        {
            Process.WaitForExit(); // also drain both asynchronous output readers
            drained = true;
            lock (gate) {
                if (writer != null) { writer.Dispose(); writer = null; }
                if (logError != null) throw new IOException("Writing " + LogPath, logError);
            }
        }

        public void Dispose()
        {
            if (started && !drained) {
                try { if (Process.WaitForExit(3000)) Process.WaitForExit(); }
                catch (InvalidOperationException) { }
            }
            lock (gate) { if (writer != null) { writer.Dispose(); writer = null; } }
            Process.Dispose();
        }
    }

    // Closing the last non-inherited handle stops our whole worker tree, even on process termination.
    sealed class ProcessJob : IDisposable
    {
        IntPtr handle;
        [StructLayout(LayoutKind.Sequential)] struct Basic {
            internal long ProcessTime, JobTime;
            internal uint LimitFlags;
            internal UIntPtr MinWorkingSet, MaxWorkingSet;
            internal uint ActiveLimit;
            internal UIntPtr Affinity;
            internal uint Priority, Scheduling;
        }
        [StructLayout(LayoutKind.Sequential)] struct Io {
            internal ulong ReadOps, WriteOps, OtherOps, ReadBytes, WriteBytes, OtherBytes;
        }
        [StructLayout(LayoutKind.Sequential)] struct Extended {
            internal Basic BasicLimits;
            internal Io IoInfo;
            internal UIntPtr ProcessMemory, JobMemory, PeakProcessMemory, PeakJobMemory;
        }
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        static extern IntPtr CreateJobObject(IntPtr security, string name);
        [DllImport("kernel32.dll", SetLastError=true)]
        static extern bool SetInformationJobObject(IntPtr job, int infoClass, IntPtr info, uint bytes);
        [DllImport("kernel32.dll", SetLastError=true)]
        static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);

        internal ProcessJob()
        {
            handle = CreateJobObject(IntPtr.Zero, null);
            if (handle == IntPtr.Zero) throw new Win32Exception();
            Extended info = new Extended();
            info.BasicLimits.LimitFlags = 0x2000; // JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            int size = Marshal.SizeOf(typeof(Extended));
            IntPtr ptr = Marshal.AllocHGlobal(size);
            try {
                Marshal.StructureToPtr(info, ptr, false);
                if (!SetInformationJobObject(handle, 9, ptr, (uint)size)) {
                    int err = Marshal.GetLastWin32Error(); Dispose(); throw new Win32Exception(err);
                }
            } finally { Marshal.FreeHGlobal(ptr); }
        }
        internal bool Attach(Process p) { return AssignProcessToJobObject(handle, p.Handle); }
        public void Dispose() { if (handle != IntPtr.Zero) { CloseHandle(handle); handle = IntPtr.Zero; } }
    }
}
