# WFBPhysicalFourier

`STATUS = PENDING_EXTERNAL_CI` · `NO_LOCAL_LEAN`

Physical Fourier normalization, full-series summability and exact dissipation identity; no continuation conclusion.

`Endpoint.lean` imports the exact owned candidate source, whose original bytes
are pinned to the staged snapshot at `bfc9c6f39230121f6a269f65e22784597ce0d4cd`.
`../owned-sources.json` records the owned-source identity separately from
pinned upstream vendor provenance. No verified upstream attribution is invented.

`Audit.lean` freshly checks all 13 required declarations with
complete type and theorem-level axiom sentinels, and independently states the
principal theorem type. The source-embedded checks cannot replace this audit
when compiled objects are reused. Acceptance requires matching external source,
compiler, dependency and audit evidence with standard axioms only.

`closure.json` records the complete owned/vendor import closure. The exporter
constructs a separate package for external compilation while preserving the
main package's Lake file and cache identity.

This package does not establish local H1 existence, endpoint continuation,
universal Fourier-budget finiteness or the global Weak_Fourierman_B root.
