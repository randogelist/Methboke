# R0InitialFrontAdmission

`STATUS = PENDING_EXTERNAL_CI` · `NO_LOCAL_LEAN`

An actual initial classical front supplies smooth datum admission, genuine strong initial trace, compact Serrin bounds, and identification with the original Leray-Hopf path.

This newly developed owned source matches the current candidate at
`PREPRINT_FORMALISATION/WeakFouriermanB/next/InitialFrontAdmission.lean`. Its derivation basis is
`Material/MethbokeAddon/WeakFouriermanB/LocalFrontIdentification.lean` at `67f766330918577e714e326be82eebfe29f5f2f7`.
That basis is not a claim that this source existed at that path or revision.
The current owned-source hash is recorded separately.

`Audit.lean` independently states all 9 public theorem signatures and
freshly emits their exact types and complete axiom reports. Private proof
helpers are included transitively. The complete import closure contains
218 sources. Matching external verification remains pending.

This package belongs to the fixed conditional R0 finite-cap admission chain.
An actual admitted front remains an explicit mathematical premise. Universal
analytic-germ extension R1 and universal Weak_Fourierman_B budget finiteness
are not asserted. Preparation does not establish A-tier or root acceptance.
