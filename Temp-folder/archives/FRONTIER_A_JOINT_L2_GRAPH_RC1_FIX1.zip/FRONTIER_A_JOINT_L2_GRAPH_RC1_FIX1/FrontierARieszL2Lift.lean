import Mathlib

/-!
Candidate generic L² lift of an operator-valued symbol. This file does not
construct the normalized Riesz row symbol as a continuous linear map, nor
identify it with a weak derivative or an actual Navier–Stokes field. The
symbol's a.e. strong measurability and pointwise contraction are explicit.
External Lean 4.33.0 compilation, signature inspection and audit are required.
-/
noncomputable section
open MeasureTheory Filter

namespace FrontierARieszL2Lift

variable {α H K : Type*} [MeasurableSpace α]
  [NormedAddCommGroup H] [NormedSpace ℝ H]
  [NormedAddCommGroup K] [NormedSpace ℝ K]

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩
local instance : Fact (1 ≤ (⊤ : ENNReal)) := ⟨le_top⟩

/-- A measurable pointwise-contractive operator-valued symbol is L∞. -/
theorem symbol_memLp_top (μ : Measure α) (s : α → (H →L[ℝ] K))
    (hs : AEStronglyMeasurable s μ)
    (hcontract : ∀ᵐ x ∂μ, ∀ v, ‖s x v‖ ≤ ‖v‖) : MemLp s ⊤ μ := by
  apply memLp_top_of_bound hs 1
  filter_upwards [hcontract] with x hx
  apply ContinuousLinearMap.opNorm_le_bound
  · norm_num
  · intro v
    simpa only [one_mul] using hx v

/-- A bounded operator-valued symbol acts on L² by Hölder evaluation. -/
def lift (μ : Measure α) (s : α → (H →L[ℝ] K)) (hs : MemLp s ⊤ μ) :
    Lp H 2 μ →L[ℝ] Lp K 2 μ :=
  (ContinuousLinearMap.holderL μ ⊤ 2 2
    (ContinuousLinearMap.id ℝ (H →L[ℝ] K))) (MemLp.toLp s hs)

theorem lift_ae (μ : Measure α) (s : α → (H →L[ℝ] K))
    (hs : MemLp s ⊤ μ) (f : Lp H 2 μ) :
    (lift μ s hs f : α → K) =ᵐ[μ] fun x => s x ((f : α → H) x) := by
  filter_upwards [
    (show (lift μ s hs f : α → K) =ᵐ[μ]
      fun x => (MemLp.toLp s hs : α → (H →L[ℝ] K)) x ((f : α → H) x) by
        simpa only [lift, ContinuousLinearMap.holderL_apply_apply,
          ContinuousLinearMap.id_apply] using
          (ContinuousLinearMap.coeFn_holder (r := (2 : ENNReal))
            (ContinuousLinearMap.id ℝ (H →L[ℝ] K)) (MemLp.toLp s hs) f)),
    MemLp.coeFn_toLp hs] with x hx hsx
  simpa only [hsx] using hx

/-- Pointwise contraction lifts to an L² contraction, without a finite measure assumption. -/
theorem lift_contractive (μ : Measure α) (s : α → (H →L[ℝ] K))
    (hs : MemLp s ⊤ μ) (hcontract : ∀ᵐ x ∂μ, ∀ v, ‖s x v‖ ≤ ‖v‖)
    (f : Lp H 2 μ) : ‖lift μ s hs f‖ ≤ ‖f‖ := by
  apply MeasureTheory.Lp.norm_le_norm_of_ae_le
  filter_upwards [lift_ae μ s hs f, hcontract] with x hx hc
  rw [hx]
  exact hc ((f : α → H) x)

theorem lift_op_norm_le_one (μ : Measure α) (s : α → (H →L[ℝ] K))
    (hs : MemLp s ⊤ μ) (hcontract : ∀ᵐ x ∂μ, ∀ v, ‖s x v‖ ≤ ‖v‖) :
    ‖lift μ s hs‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound
  · norm_num
  · intro f
    simpa only [one_mul] using lift_contractive μ s hs hcontract f

end FrontierARieszL2Lift

#print axioms FrontierARieszL2Lift.symbol_memLp_top
#print axioms FrontierARieszL2Lift.lift_ae
#print axioms FrontierARieszL2Lift.lift_contractive
#print axioms FrontierARieszL2Lift.lift_op_norm_le_one
