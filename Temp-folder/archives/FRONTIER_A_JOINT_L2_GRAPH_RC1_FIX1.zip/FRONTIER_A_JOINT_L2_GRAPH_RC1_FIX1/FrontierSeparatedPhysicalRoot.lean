import FrontierSeparatedWeakSlicing
import FrontierSlicingEnergyClass
import FrontierGradientOnlyFinalEnergy
import FrontierPhysicalIdentification

/-! Conditional physical-field assembly from separated tests and explicit
Fourier symbols. This composes audited edges without assuming the pointwise
weak-gradient relation, field equalities, or Gram bound. It still assumes
Bochner trajectory data, the separated-test identity, an energy inequality,
and the displayed Fourier formulas for the supplied fields. It does not
construct a standard Leray–Hopf solution or an independent Stokes operator.
No local Lean execution. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierSeparatedPhysicalRoot

abbrev Space := FrontierWeakGradientSubspace.Space
abbrev Fiber := FrontierPhysicalIdentification.Fiber
abbrev Frequency := FrontierPhysicalIdentification.Frequency
abbrev RealVelocity := FrontierWeakGradientSubspace.RealVelocity
abbrev Gradient := FrontierWeakGradientSubspace.Gradient
abbrev PhysicalL2 := FrontierPhysicalIdentification.PhysicalL2

local instance physicalRealL2 : InnerProductSpace ℝ PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ PhysicalL2

/-- A finite-measure-independent assembly. The explicit separated tests
and Fourier formulas are the outstanding physical interfaces. -/
theorem physical_gram_of_separated_tests
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (μ : Measure ℝ) [IsLocallyFiniteMeasure μ]
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (vp vm : ℝ → PhysicalL2)
    (nu E0 ET : ℝ) (hnu : 0 < nu)
    (hu : MemLp u (⊤ : ENNReal) μ) (hg : MemLp g 2 μ)
    (henergy : ET + 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂μ) ≤ E0)
    (hsep : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SchwartzMap Space ℂ),
        (∫ t, φ t • ((FrontierWeakGradientSubspace.residual j (u t, g t)) ψ) ∂μ) = 0)
    (hp : ∀ᵐ t ∂μ,
      (FrontierPhysicalGramTransport.fourierCoordinateReal (vp t) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ))
    (hm : ∀ᵐ t ∂μ,
      (FrontierPhysicalGramTransport.fourierCoordinateReal (vm t) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt vp vm) μ ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral μ vp vm ≤ (E0 - ET) / (4 * nu) := by
  have hlocal : LocallyIntegrable (fun t => (u t, g t)) μ :=
    FrontierSlicingEnergyClass.pair_locallyIntegrable_of_memLp u g μ ⊤ 2
      (by simp) (by norm_num) hu hg
  have hweak := FrontierSeparatedWeakSlicing.weak_at_ae_of_separated_tests u g μ hlocal hsep
  have hbound := FrontierGradientOnlyFinalEnergy.gram_of_matrix_energy
    μ g nu E0 ET hnu hg henergy
  exact FrontierPhysicalIdentification.gram_bound_of_symbols μ
    (fun t => FrontierRealVelocityEmbedding.complexifyL2 (u t)) g
    (fun t j => FrontierGradientAdapter.gradientColumn (g t) j) vp vm
    ((E0 - ET) / (4 * nu))
    (Filter.Eventually.of_forall (fun _ _ => rfl)) hweak hp hm hbound

/-- Half-line assembly using uniform integer-interval budgets. The local
trajectory integrability, separated identities and Fourier formulas remain
explicit; no external physical realization is assumed to be constructed. -/
theorem physical_gram_halfline_of_separated_tests
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (vp vm : ℝ → PhysicalL2)
    (nu E0 : ℝ) (hnu : 0 < nu)
    (hg : ∀ n : ℕ, MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure (n : ℝ)))
    (hbudget : ∀ n : ℕ, 2 * nu *
      (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure (n : ℝ))) ≤ E0)
    (hlocal : LocallyIntegrable (fun t => (u t, g t)) (volume.restrict (Set.Ioi 0)))
    (hsep : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SchwartzMap Space ℂ),
        (∫ t, φ t • ((FrontierWeakGradientSubspace.residual j (u t, g t)) ψ)
          ∂(volume.restrict (Set.Ioi 0))) = 0)
    (hp : ∀ᵐ t ∂(volume.restrict (Set.Ioi 0)),
      (FrontierPhysicalGramTransport.fourierCoordinateReal (vp t) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ))
    (hm : ∀ᵐ t ∂(volume.restrict (Set.Ioi 0)),
      (FrontierPhysicalGramTransport.fourierCoordinateReal (vm t) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt vp vm) (volume.restrict (Set.Ioi 0)) ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral (volume.restrict (Set.Ioi 0)) vp vm ≤
        E0 / (4 * nu) := by
  have hweak := FrontierSeparatedWeakSlicing.weak_at_ae_of_separated_tests
    u g (volume.restrict (Set.Ioi 0)) hlocal hsep
  have hbound := FrontierGradientOnlyFinalEnergy.gram_halfline_of_matrix_budgets
    g nu E0 hnu hg hbudget
  exact FrontierPhysicalIdentification.gram_bound_of_symbols (volume.restrict (Set.Ioi 0))
    (fun t => FrontierRealVelocityEmbedding.complexifyL2 (u t)) g
    (fun t j => FrontierGradientAdapter.gradientColumn (g t) j) vp vm
    (E0 / (4 * nu)) (Filter.Eventually.of_forall (fun _ _ => rfl))
    hweak hp hm hbound

end FrontierSeparatedPhysicalRoot

#print axioms FrontierSeparatedPhysicalRoot.physical_gram_of_separated_tests
#print axioms FrontierSeparatedPhysicalRoot.physical_gram_halfline_of_separated_tests
