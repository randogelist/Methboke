import FrontierARieszVectorPointwise
import FrontierARieszConcreteSymbol

/-! A-TIER CANDIDATE: the normalized frequency row applied to each row of a
3 by 3 complex Euclidean fiber. The two indices are (velocity, derivative).
This is a frequency-space symbol, not an actual weak gradient or PDE result.
External compilation, signature inspection, and axiom audit are required. -/
noncomputable section
open MeasureTheory Filter
open scoped BigOperators
open FrontierARieszFrequency FrontierARieszConcreteSymbol

namespace FrontierARieszVectorSymbol

abbrev Frequency := HelicalConcreteSymbol.Frequency
abbrev GradFiber := EuclideanSpace ℂ (Fin 3 × Fin 3)
abbrev Fiber := EuclideanSpace ℂ (Fin 3)

/-- Apply a coefficient row to the derivative index of every component. -/
def coeffMap (a : Fin 3 → ℂ) : GradFiber →ₗ[ℂ] Fiber where
  toFun g := WithLp.toLp 2 (fun i =>
    a 0 * g (i, 0) + a 1 * g (i, 1) + a 2 * g (i, 2))
  map_add' g h := by
    ext i
    simp <;> ring
  map_smul' c g := by
    ext i
    simp <;> ring

/-- The coefficient-to-operator map is finite-dimensional and linear. -/
def coeffToVectorCLM : (Fin 3 → ℂ) →ₗ[ℂ] (GradFiber →L[ℂ] Fiber) where
  toFun a := LinearMap.toContinuousLinearMap (coeffMap a)
  map_add' a b := by
    ext g i
    simp [coeffMap] <;> ring
  map_smul' c a := by
    ext g i
    simp [coeffMap] <;> ring

/-- Concrete normalized Riesz row on each velocity component. -/
def vectorOp (ξ : Frequency) : GradFiber →L[ℝ] Fiber :=
  (coeffToVectorCLM (FrontierARieszConcreteSymbol.coeff ξ)).restrictScalars ℝ

theorem vectorOp_apply (ξ : Frequency) (g : GradFiber) (i : Fin 3) :
    vectorOp ξ g i = FrontierARieszVectorPointwise.vectorRow ξ
      (fun i j => g (i, j)) i := by
  simp [vectorOp, coeffToVectorCLM, coeffMap, FrontierARieszConcreteSymbol.coeff,
    FrontierARieszVectorPointwise.vectorRow, freqRow, FrontierARieszRowSymbol.row] <;> ring

/-- The fiber operator is a contraction in Euclidean norms. -/
theorem vectorOp_contractive (ξ : Frequency) (g : GradFiber) :
    ‖vectorOp ξ g‖ ≤ ‖g‖ := by
  have h := FrontierARieszVectorPointwise.vectorRow_normSq_bound ξ
    (fun i j => g (i, j))
  have hout : ‖vectorOp ξ g‖ ^ 2 =
      ∑ i, Complex.normSq (FrontierARieszVectorPointwise.vectorRow ξ
        (fun i j => g (i, j)) i) := by
    simp [EuclideanSpace.norm_sq_eq, vectorOp_apply, Complex.normSq_eq_norm_sq]
  have hin : ‖g‖ ^ 2 = ∑ i, ∑ j, Complex.normSq (g (i, j)) := by
    simp [EuclideanSpace.norm_sq_eq, Complex.normSq_eq_norm_sq, Fintype.sum_prod_type]
  have hsq : ‖vectorOp ξ g‖ ^ 2 ≤ ‖g‖ ^ 2 := by
    rw [hout, hin]
    exact h
  nlinarith [norm_nonneg (vectorOp ξ g), norm_nonneg g]

theorem measurable_vectorOp : Measurable vectorOp := by
  have hc : Continuous coeffToVectorCLM := coeffToVectorCLM.continuous_of_finiteDimensional
  have hr : Continuous (fun f : GradFiber →L[ℂ] Fiber => f.restrictScalars ℝ) :=
    ContinuousLinearMap.continuous_restrictScalars ℝ
  exact hr.measurable.comp (hc.measurable.comp FrontierARieszConcreteSymbol.measurable_coeff)

end FrontierARieszVectorSymbol

#print axioms FrontierARieszVectorSymbol.vectorOp_apply
#print axioms FrontierARieszVectorSymbol.vectorOp_contractive
#print axioms FrontierARieszVectorSymbol.measurable_vectorOp
