import FrontierPhysicalGramTransport

/-! A proposed gradient-budget bound for the *defined* physical-space
Fourier-pullback fields. This does not identify them with the conventional
helical components of a Leray--Hopf solution. No local Lean run was made. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierGradientBudgetGram

abbrev Frequency := FrontierAWeakTimeGram.Frequency
abbrev MatrixL2 := FrontierAWeakTimeGram.MatrixL2
abbrev CoordinateL2 := FrontierAWeakTimeGram.CoordinateL2
abbrev Gradient := FrontierARealGradient.RealMatrix

local instance frequencyRealL2 (μ : Measure Frequency) :
    InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

local instance physicalRealL2 : InnerProductSpace ℝ FrontierPhysicalGramTransport.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierPhysicalGramTransport.PhysicalL2

/-- A real gradient energy budget alone bounds the Gram determinant of the
project's explicit Fourier-pullback fields. No velocity trajectory,
distributional derivative, divergence, or spectral interface is assumed. -/
theorem pullback_gram_of_gradient_budget
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace MatrixL2] [BorelSpace MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace CoordinateL2] [BorelSpace CoordinateL2]
    (η : Measure τ) (g : τ → Gradient) (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hg : MemLp g 2 η)
    (hbudget : 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤ initialEnergy / (4 * nu) := by
  have hcore := FrontierARealGradient.gram_from_real_matrix η g nu initialEnergy hnu hg hbudget
  have heq :
      FeffermanAHopfGramIntegral.gramSqrt
        (fun t => plusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t)))
        (fun t => minusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t))) =
      FeffermanAHopfGramIntegral.gramSqrt
        (fun t => FrontierPhysicalGramTransport.plusField (g t))
        (fun t => FrontierPhysicalGramTransport.minusField (g t)) := by
    have hp :
        (fun t : τ => FrontierPhysicalGramTransport.fourierCoordinateReal
          (FrontierPhysicalGramTransport.plusField (g t))) =
        (fun t : τ => plusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t))) := by
      funext t
      exact FrontierPhysicalGramTransport.plusField_fourier (g t)
    have hm :
        (fun t : τ => FrontierPhysicalGramTransport.fourierCoordinateReal
          (FrontierPhysicalGramTransport.minusField (g t))) =
        (fun t : τ => minusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t))) := by
      funext t
      exact FrontierPhysicalGramTransport.minusField_fourier (g t)
    rw [← hp, ← hm]
    exact HelicalPhysicalEnergy.gramSqrt_isometry
      FrontierPhysicalGramTransport.fourierCoordinateReal
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t))
  constructor
  · simpa only [heq] using hcore.1
  · have hh := hcore.2
    unfold FeffermanAHopfGramIntegral.gramSqrtIntegral at hh ⊢
    simpa only [heq] using hh

end FrontierGradientBudgetGram

#print axioms FrontierGradientBudgetGram.pullback_gram_of_gradient_budget
