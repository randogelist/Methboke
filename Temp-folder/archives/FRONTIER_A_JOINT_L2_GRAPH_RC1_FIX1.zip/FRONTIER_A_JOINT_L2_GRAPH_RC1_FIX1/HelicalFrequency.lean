import HelicalNormalize

/-! Candidate all-frequency symbols: use zero matrices at squared length 0.
The parameterized measurability result assumes measurable real coordinate
functions; it builds a measurable matrix-valued symbol. It does not construct
the associated operator on L2 or a Fourier transform. -/

noncomputable section
open MeasureTheory
open FeffermanHelicalGeneral FeffermanHelicalNormalize

namespace FeffermanHelicalFrequency

/- Matrix is definitionally a function of two indices.  Use its product
   sigma algebra explicitly, without depending on a separately cached
   matrix-measurability module. -/
local instance : MeasurableSpace (Matrix (Fin 3) (Fin 3) ℂ) :=
  MeasurableSpace.pi

def lengthSq (x y z : ℝ) : ℝ := x ^ 2 + y ^ 2 + z ^ 2

def plus (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  if 0 < lengthSq x y z then
    positive (x / radius x y z) (y / radius x y z) (z / radius x y z)
  else 0

def minus (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  if 0 < lengthSq x y z then
    negative (x / radius x y z) (y / radius x y z) (z / radius x y z)
  else 0

def projection (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  if 0 < lengthSq x y z then
    transverse (x / radius x y z) (y / radius x y z) (z / radius x y z)
  else 0

def normalizedCurl (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  if 0 < lengthSq x y z then
    curlSymbol (x / radius x y z) (y / radius x y z) (z / radius x y z)
  else 0

theorem plus_zero : plus 0 0 0 = 0 := by simp [plus, lengthSq]
theorem minus_zero : minus 0 0 0 = 0 := by simp [minus, lengthSq]
theorem projection_zero : projection 0 0 0 = 0 := by simp [projection, lengthSq]

theorem partition (x y z : ℝ) : plus x y z + minus x y z = projection x y z := by
  by_cases h : 0 < lengthSq x y z
  · simpa only [plus, minus, projection, if_pos h] using
      normalized_helicity_partition x y z h
  · simp [plus, minus, projection, h]

theorem plus_idempotent (x y z : ℝ) : plus x y z * plus x y z = plus x y z := by
  by_cases h : 0 < lengthSq x y z
  · simpa only [plus, if_pos h] using normalized_positive_idempotent x y z h
  · simp [plus, h]

theorem minus_idempotent (x y z : ℝ) : minus x y z * minus x y z = minus x y z := by
  by_cases h : 0 < lengthSq x y z
  · simpa only [minus, if_pos h] using
      negative_idempotent (x / radius x y z) (y / radius x y z) (z / radius x y z)
        (normalized_unit x y z h)
  · simp [minus, h]

theorem cross_zero (x y z : ℝ) : plus x y z * minus x y z = 0 := by
  by_cases h : 0 < lengthSq x y z
  · simpa only [plus, minus, if_pos h] using
      helicity_cross_zero (x / radius x y z) (y / radius x y z) (z / radius x y z)
        (normalized_unit x y z h)
  · simp [plus, minus, h]

theorem plus_curl_eigen (x y z : ℝ) :
    normalizedCurl x y z * plus x y z = plus x y z := by
  by_cases h : 0 < lengthSq x y z
  · simpa only [normalizedCurl, plus, if_pos h] using
      positive_curl_eigen (x / radius x y z) (y / radius x y z) (z / radius x y z)
        (normalized_unit x y z h)
  · simp [normalizedCurl, plus, h]

theorem minus_curl_eigen (x y z : ℝ) :
    normalizedCurl x y z * minus x y z = -minus x y z := by
  by_cases h : 0 < lengthSq x y z
  · simpa only [normalizedCurl, minus, if_pos h] using
      negative_curl_eigen (x / radius x y z) (y / radius x y z) (z / radius x y z)
        (normalized_unit x y z h)
  · simp [normalizedCurl, minus, h]

theorem plus_hermitian (x y z : ℝ) (i j : Fin 3) :
    star (plus x y z j i) = plus x y z i j := by
  by_cases h : 0 < lengthSq x y z
  · simpa [plus, h] using positive_hermitian
      (x / radius x y z) (y / radius x y z) (z / radius x y z) i j
  · simp [plus, h]

theorem minus_hermitian (x y z : ℝ) (i j : Fin 3) :
    star (minus x y z j i) = minus x y z i j := by
  by_cases h : 0 < lengthSq x y z
  · simpa [minus, h] using negative_hermitian
      (x / radius x y z) (y / radius x y z) (z / radius x y z) i j
  · simp [minus, h]

theorem plus_conjugate_reversal (x y z : ℝ) (i j : Fin 3) :
    star (plus x y z i j) = plus (-x) (-y) (-z) i j := by
  have hl : lengthSq (-x) (-y) (-z) = lengthSq x y z := by simp [lengthSq]
  have hr : radius (-x) (-y) (-z) = radius x y z := by simp [radius]
  by_cases h : 0 < lengthSq x y z
  · have hn : 0 < lengthSq (-x) (-y) (-z) := by simpa [hl] using h
    simpa only [plus, if_pos h, if_pos hn, hr, neg_div] using positive_conjugate_reversal
      (x / radius x y z) (y / radius x y z) (z / radius x y z) i j
  · have hn : ¬ 0 < lengthSq (-x) (-y) (-z) := by simpa [hl] using h
    simp [plus, h, hn]

theorem minus_conjugate_reversal (x y z : ℝ) (i j : Fin 3) :
    star (minus x y z i j) = minus (-x) (-y) (-z) i j := by
  have hl : lengthSq (-x) (-y) (-z) = lengthSq x y z := by simp [lengthSq]
  have hr : radius (-x) (-y) (-z) = radius x y z := by simp [radius]
  by_cases h : 0 < lengthSq x y z
  · have hn : 0 < lengthSq (-x) (-y) (-z) := by simpa [hl] using h
    simpa only [minus, if_pos h, if_pos hn, hr, neg_div] using negative_conjugate_reversal
      (x / radius x y z) (y / radius x y z) (z / radius x y z) i j
  · have hn : ¬ 0 < lengthSq (-x) (-y) (-z) := by simpa [hl] using h
    simp [minus, h, hn]

section Measurable
variable {α : Type*} [MeasurableSpace α]

/-- Every matrix entry of the all-frequency positive symbol is measurable
    for any three measurable real frequency coordinate functions. -/
theorem measurable_plus_entry (x y z : α → ℝ)
    (hx : Measurable x) (hy : Measurable y) (hz : Measurable z) (i j : Fin 3) :
    Measurable (fun a => plus (x a) (y a) (z a) i j) := by
  have hlen : Measurable (fun a => lengthSq (x a) (y a) (z a)) := by
    unfold lengthSq
    fun_prop
  have hs : MeasurableSet {a : α | 0 < lengthSq (x a) (y a) (z a)} :=
    measurableSet_lt measurable_const hlen
  have hp : Measurable (fun a => positive
      (x a / radius (x a) (y a) (z a))
      (y a / radius (x a) (y a) (z a))
      (z a / radius (x a) (y a) (z a)) i j) := by
    fin_cases i <;> fin_cases j <;>
      simp [positive, transverse, curlSymbol, radius] <;> fun_prop
  have hm : Measurable (fun a : α =>
      if 0 < lengthSq (x a) (y a) (z a) then
        positive (x a / radius (x a) (y a) (z a))
          (y a / radius (x a) (y a) (z a))
          (z a / radius (x a) (y a) (z a)) i j
      else (0 : ℂ)) := Measurable.ite hs hp measurable_const
  have heq : (fun a => plus (x a) (y a) (z a) i j) =
      (fun a : α => if 0 < lengthSq (x a) (y a) (z a) then
        positive (x a / radius (x a) (y a) (z a))
          (y a / radius (x a) (y a) (z a))
          (z a / radius (x a) (y a) (z a)) i j
      else (0 : ℂ)) := by
    funext a
    by_cases h : 0 < lengthSq (x a) (y a) (z a) <;>
      simp [plus, h]
  rw [heq]
  exact hm

theorem measurable_minus_entry (x y z : α → ℝ)
    (hx : Measurable x) (hy : Measurable y) (hz : Measurable z) (i j : Fin 3) :
    Measurable (fun a => minus (x a) (y a) (z a) i j) := by
  have hlen : Measurable (fun a => lengthSq (x a) (y a) (z a)) := by
    unfold lengthSq
    fun_prop
  have hs : MeasurableSet {a : α | 0 < lengthSq (x a) (y a) (z a)} :=
    measurableSet_lt measurable_const hlen
  have hp : Measurable (fun a => negative
      (x a / radius (x a) (y a) (z a))
      (y a / radius (x a) (y a) (z a))
      (z a / radius (x a) (y a) (z a)) i j) := by
    fin_cases i <;> fin_cases j <;>
      simp [negative, transverse, curlSymbol, radius] <;> fun_prop
  have hm : Measurable (fun a : α =>
      if 0 < lengthSq (x a) (y a) (z a) then
        negative (x a / radius (x a) (y a) (z a))
          (y a / radius (x a) (y a) (z a))
          (z a / radius (x a) (y a) (z a)) i j
      else (0 : ℂ)) := Measurable.ite hs hp measurable_const
  have heq : (fun a => minus (x a) (y a) (z a) i j) =
      (fun a : α => if 0 < lengthSq (x a) (y a) (z a) then
        negative (x a / radius (x a) (y a) (z a))
          (y a / radius (x a) (y a) (z a))
          (z a / radius (x a) (y a) (z a)) i j
      else (0 : ℂ)) := by
    funext a
    by_cases h : 0 < lengthSq (x a) (y a) (z a) <;>
      simp [minus, h]
  rw [heq]
  exact hm

theorem measurable_plus (x y z : α → ℝ)
    (hx : Measurable x) (hy : Measurable y) (hz : Measurable z) :
    Measurable (fun a => plus (x a) (y a) (z a)) := by
  apply measurable_pi_iff.mpr
  intro i
  apply measurable_pi_iff.mpr
  intro j
  exact measurable_plus_entry x y z hx hy hz i j

theorem measurable_minus (x y z : α → ℝ)
    (hx : Measurable x) (hy : Measurable y) (hz : Measurable z) :
    Measurable (fun a => minus (x a) (y a) (z a)) := by
  apply measurable_pi_iff.mpr
  intro i
  apply measurable_pi_iff.mpr
  intro j
  exact measurable_minus_entry x y z hx hy hz i j

/-- Measurability on the concrete three-coordinate frequency space. -/
theorem measurable_plus_r3 :
    Measurable (fun ξ : Fin 3 → ℝ => plus (ξ 0) (ξ 1) (ξ 2)) := by
  exact measurable_plus (fun ξ : Fin 3 → ℝ => ξ 0)
    (fun ξ : Fin 3 → ℝ => ξ 1) (fun ξ : Fin 3 → ℝ => ξ 2)
    (measurable_pi_apply 0) (measurable_pi_apply 1) (measurable_pi_apply 2)

theorem measurable_minus_r3 :
    Measurable (fun ξ : Fin 3 → ℝ => minus (ξ 0) (ξ 1) (ξ 2)) := by
  exact measurable_minus (fun ξ : Fin 3 → ℝ => ξ 0)
    (fun ξ : Fin 3 → ℝ => ξ 1) (fun ξ : Fin 3 → ℝ => ξ 2)
    (measurable_pi_apply 0) (measurable_pi_apply 1) (measurable_pi_apply 2)
end Measurable

end FeffermanHelicalFrequency

#print axioms FeffermanHelicalFrequency.plus_zero
#print axioms FeffermanHelicalFrequency.minus_zero
#print axioms FeffermanHelicalFrequency.projection_zero
#print axioms FeffermanHelicalFrequency.partition
#print axioms FeffermanHelicalFrequency.plus_idempotent
#print axioms FeffermanHelicalFrequency.minus_idempotent
#print axioms FeffermanHelicalFrequency.cross_zero
#print axioms FeffermanHelicalFrequency.plus_curl_eigen
#print axioms FeffermanHelicalFrequency.minus_curl_eigen
#print axioms FeffermanHelicalFrequency.plus_hermitian
#print axioms FeffermanHelicalFrequency.minus_hermitian
#print axioms FeffermanHelicalFrequency.plus_conjugate_reversal
#print axioms FeffermanHelicalFrequency.minus_conjugate_reversal
#print axioms FeffermanHelicalFrequency.measurable_plus_entry
#print axioms FeffermanHelicalFrequency.measurable_minus_entry
#print axioms FeffermanHelicalFrequency.measurable_plus
#print axioms FeffermanHelicalFrequency.measurable_minus
#print axioms FeffermanHelicalFrequency.measurable_plus_r3
#print axioms FeffermanHelicalFrequency.measurable_minus_r3
