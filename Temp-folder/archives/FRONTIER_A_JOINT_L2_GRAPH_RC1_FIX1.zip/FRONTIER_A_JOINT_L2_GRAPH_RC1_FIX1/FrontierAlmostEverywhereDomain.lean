import FrontierTrajectoryEnergy

/-! Candidate: a weak gradient gives graph-domain membership almost everywhere,
and the gradient representative has the conditional Gram estimate. This does
not construct a Leray--Hopf solution or prove its energy inequality. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierAlmostEverywhereDomain

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

theorem domain_of_ae_weak_gradient
    {τ : Type*} [MeasurableSpace τ] (η : Measure τ)
    (u : τ → FrontierSpectralOperator.Field)
    (g : τ → FrontierARealGradient.RealMatrix)
    (hweak : ∀ᵐ t ∂η, ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t))) :
    ∀ᵐ t ∂η, ∃ v : FrontierSpectralOperator.Domain, v.val = u t := by
  filter_upwards [hweak] with t ht
  exact ⟨FrontierSpectralOperator.ofWeakGradient (u t) (g t) ht, rfl⟩

/-- The supplied L² weak gradient and terminal energy estimate imply the
conditional Gram bound and yield domain membership at almost every time. -/
theorem gram_and_domain_from_gradient_energy
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → FrontierSpectralOperator.Field)
    (g : τ → FrontierARealGradient.RealMatrix)
    (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : MemLp g 2 η)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂η, ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t))) :
    (∀ᵐ t ∂η, ∃ v : FrontierSpectralOperator.Domain, v.val = u t) ∧
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierACoordinateEquiv.plusPullback
        (FrontierDissipationDomain.gradientDissipation (g t)))
      (fun t => FrontierACoordinateEquiv.minusPullback
        (FrontierDissipationDomain.gradientDissipation (g t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierACoordinateEquiv.plusPullback
        (FrontierDissipationDomain.gradientDissipation (g t)))
      (fun t => FrontierACoordinateEquiv.minusPullback
        (FrontierDissipationDomain.gradientDissipation (g t))) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  have hD : Integrable (fun t => ‖g t‖ ^ 2) η :=
    (memLp_two_iff_integrable_sq_norm hg.aestronglyMeasurable).1 hg
  refine ⟨domain_of_ae_weak_gradient η u g hweak, ?_⟩
  exact FrontierDissipationDomain.projected_gradient_gram_from_energy
    η u g (fun t => ‖g t‖ ^ 2) u0 uT nu hnu hg.aestronglyMeasurable hD
    (Filter.Eventually.of_forall fun _ => rfl) henergy hweak

end FrontierAlmostEverywhereDomain

#print axioms FrontierAlmostEverywhereDomain.domain_of_ae_weak_gradient
#print axioms FrontierAlmostEverywhereDomain.gram_and_domain_from_gradient_energy
