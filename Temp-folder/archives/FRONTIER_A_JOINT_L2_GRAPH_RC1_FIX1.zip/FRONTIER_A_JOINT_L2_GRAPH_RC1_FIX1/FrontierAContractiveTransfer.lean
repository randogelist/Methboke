import FrontierAConcreteFourier

/-!
A-TIER CANDIDATE: an abstract contractive gradient-to-trajectory adapter.

A supplied continuous real-linear map B is assumed pointwise contractive;
we construct the trajectory B ∘ grad. Its time-L² and budget follow from the
gradient's own L² and energy assumptions, so a separate trajectory
measurability, norm identity, and budget are not required. No actual gradient,
Leray–Hopf solution, Fourier row operator, derivative theorem or physical
helical identification is constructed here. In particular B is a hypothesis,
not a proven representation of |D| on physical gradients. Lean compilation,
signature inspection and theorem-level axiom audits remain outstanding.
-/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierAContractiveTransfer

abbrev ComplexField := FrontierAConcreteFourier.ComplexField
abbrev CoordinateL2 := FrontierAConcreteFourier.CoordinateL2

local instance realL2 (μ : Measure Frequency) : InnerProductSpace ℝ (Lp Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp Fiber 2 μ)

/-- The trajectory is constructed by applying a supplied contraction to grad. -/
theorem contraction_inputs
    {τ G : Type*} [MeasurableSpace τ] [NormedAddCommGroup G] [NormedSpace ℝ G]
    [MeasurableSpace G] [BorelSpace G]
    [MeasurableSpace ComplexField] [BorelSpace ComplexField]
    (η : Measure τ) (B : G →L[ℝ] ComplexField) (grad : τ → G)
    (nu initialEnergy : ℝ) (hnu : 0 < nu)
    (hB : ∀ g, ‖B g‖ ≤ ‖g‖) (hgrad : MemLp grad 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖grad t‖ ^ 2 ∂η) ≤ initialEnergy) :
    MemLp (fun t => B (grad t)) 2 η ∧
      2 * nu * (∫ t, ‖B (grad t)‖ ^ 2 ∂η) ≤ initialEnergy := by
  have hx : MemLp (fun t => B (grad t)) 2 η := by
    simpa only [Function.comp_def] using B.comp_memLp' hgrad
  have hiX : Integrable (fun t => ‖B (grad t)‖ ^ 2) η :=
    (memLp_two_iff_integrable_sq_norm hx.aestronglyMeasurable).1 hx
  have hiG : Integrable (fun t => ‖grad t‖ ^ 2) η :=
    (memLp_two_iff_integrable_sq_norm hgrad.aestronglyMeasurable).1 hgrad
  have hint : (∫ t, ‖B (grad t)‖ ^ 2 ∂η) ≤ ∫ t, ‖grad t‖ ^ 2 ∂η := by
    apply integral_mono_ae hiX hiG
    exact Filter.Eventually.of_forall (fun t => by
      have h := hB (grad t)
      have hx0 := norm_nonneg (B (grad t))
      have hg0 := norm_nonneg (grad t)
      have hprod := mul_nonneg (sub_nonneg.mpr h) (add_nonneg hg0 hx0)
      nlinarith)
  exact ⟨hx, le_trans (mul_le_mul_of_nonneg_left hint (by positivity)) hEnergy⟩

/-- Concrete frequency Gram bound for the constructed trajectory B ∘ grad. -/
theorem fourier_gram_from_contraction
    {τ G : Type*} [MeasurableSpace τ] [NormedAddCommGroup G] [NormedSpace ℝ G]
    [MeasurableSpace G] [BorelSpace G]
    [MeasurableSpace ComplexField] [BorelSpace ComplexField]
    [MeasurableSpace CoordinateL2] [BorelSpace CoordinateL2]
    (η : Measure τ) (B : G →L[ℝ] ComplexField) (grad : τ → G)
    (nu initialEnergy : ℝ) (hnu : 0 < nu)
    (hB : ∀ g, ‖B g‖ ≤ ‖g‖) (hgrad : MemLp grad 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖grad t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier (volume : Measure Frequency)
        (FrontierAConcreteFourier.coordinateFourier (B (grad t))))
      (fun t => minusMultiplier (volume : Measure Frequency)
        (FrontierAConcreteFourier.coordinateFourier (B (grad t))))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier (volume : Measure Frequency)
        (FrontierAConcreteFourier.coordinateFourier (B (grad t))))
      (fun t => minusMultiplier (volume : Measure Frequency)
        (FrontierAConcreteFourier.coordinateFourier (B (grad t))))
      ≤ initialEnergy / (4 * nu) := by
  obtain ⟨hx, hbudget⟩ := contraction_inputs η B grad nu initialEnergy hnu hB hgrad hEnergy
  exact FrontierAConcreteFourier.fourier_coordinate_gram_bound η (fun t => B (grad t))
    nu initialEnergy hnu hx hbudget

end FrontierAContractiveTransfer

#print axioms FrontierAContractiveTransfer.contraction_inputs
#print axioms FrontierAContractiveTransfer.fourier_gram_from_contraction
