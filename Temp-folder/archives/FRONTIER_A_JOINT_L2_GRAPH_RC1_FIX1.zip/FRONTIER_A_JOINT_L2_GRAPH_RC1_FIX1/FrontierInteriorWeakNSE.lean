import FrontierRealSpectralEnergy

/-! Candidate concrete interior weak Navier--Stokes formulation. The test
fields below are genuine smooth compactly supported spacetime functions,
divergence-free in space. The formulation is on open positive-time intervals;
the initial condition is separately imposed as an L² right limit. Evaluation
uses selected spatial L² representatives; independence from their choice
and the standard jointly measurable spacetime realization are unproved.
Neither Fubini-based representation invariance, the boundary-test weak form
at time zero, nor nontriviality of the test class is established here. This is
NOT a proof that every standard Leray--Hopf representative instantiates this
predicate, nor a formal construction of physical Stokes/curl operators. The
time-slice weak-gradient identities and all energy/regularity properties are
still explicit fields. No Lean compiler has been run locally. -/
noncomputable section
open MeasureTheory Filter
open scoped BigOperators

namespace FrontierInteriorWeakNSE

abbrev Space := FrontierRealSpectralEnergy.Space
abbrev VelocityFiber := FrontierRealVelocityEmbedding.RealFiber
abbrev MatrixFiber := FrontierARealGradient.RealFiber
abbrev Velocity := FrontierRealVelocityEmbedding.RealField
abbrev Gradient := FrontierARealGradient.RealMatrix
abbrev Interface := FrontierSolenoidalSpectralInterface.Interface

/-- Smooth, compactly supported spacetime test fields, vanishing outside
(0,T) in time and divergence-free in the spatial variables. -/
structure InteriorTest (T : ℝ) where
  field : (ℝ × Space) → VelocityFiber
  smooth : ContDiff ℝ (⊤ : ℕ∞) field
  compact : HasCompactSupport field
  time_support : ∀ t x, t ∉ Set.Ioo 0 T → field (t, x) = 0
  divergence_free : ∀ t x,
    (∑ j : Fin 3, (fderiv ℝ (fun y : Space => field (t, y) j) x)
      (FrontierAWeakRieszBridge.unitDirection j)) = 0

def spatialTestDerivative (φ : (ℝ × Space) → VelocityFiber)
    (t : ℝ) (x : Space) (i j : Fin 3) : ℝ :=
  (fderiv ℝ (fun y : Space => φ (t, y) i) x)
    (FrontierAWeakRieszBridge.unitDirection j)

/-- The usual interior weak integrand: velocity against time derivative,
quadratic convection, and the weak-gradient viscosity term. -/
def weakDensity (u : ℝ → Velocity) (g : ℝ → Gradient) (nu : ℝ)
    (φ : (ℝ × Space) → VelocityFiber) (t : ℝ) (x : Space) : ℝ :=
  ∑ i : Fin 3,
    ((u t : Space → VelocityFiber) x i * (deriv (fun s : ℝ => φ (s, x) i) t) +
    (∑ j : Fin 3, (u t : Space → VelocityFiber) x i *
      (u t : Space → VelocityFiber) x j * spatialTestDerivative φ t x i j) -
    nu * (∑ j : Fin 3, (g t : Space → MatrixFiber) x (i, j) *
      spatialTestDerivative φ t x i j))

/-- The interior weak equation, with integrability stated explicitly so that
the total Bochner integral convention cannot make a nonintegrable expression
look like a valid equation. -/
def InteriorEquation (u : ℝ → Velocity) (g : ℝ → Gradient) (nu : ℝ) : Prop :=
  ∀ T : ℝ, 0 < T → ∀ φ : InteriorTest T,
    (∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      Integrable (weakDensity u g nu φ.field t) (volume : Measure Space)) ∧
    Integrable (fun t => ∫ x, weakDensity u g nu φ.field t x ∂volume)
      (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
    (∫ t, ∫ x, weakDensity u g nu φ.field t x ∂volume
      ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) = 0

/-- Explicit energy-class data and the concrete interior unforced weak NSE.
This is a candidate predicate, not a theorem equating it to the standard
Leray--Hopf definition. It retains the representation-level weak-gradient
premise needed by the audited Fourier pipeline. -/
structure InteriorEnergySolution
    [MeasurableSpace Velocity] [BorelSpace Velocity]
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    (u : ℝ → Velocity) (u0 : Velocity) (g : ℝ → Gradient) (nu : ℝ) : Prop where
  initial_value : u 0 = u0
  initial_right_limit : Tendsto u (nhdsWithin (0 : ℝ) (Set.Ioi (0 : ℝ))) (nhds u0)
  velocity_bound : ∀ T : ℝ, 0 ≤ T →
    MemLp u (⊤ : ENNReal) (FrontierFiniteIntervalEnergy.timeMeasure T)
  gradient_l2 : ∀ T : ℝ, 0 ≤ T →
    MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T)
  energy : ∀ T : ℝ, 0 ≤ T → ‖u T‖ ^ 2 + 2 * nu *
    (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u0‖ ^ 2
  weak_gradient : ∀ T : ℝ, 0 ≤ T →
    ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      FrontierAEProjectedGraphEnergy.WeakAt
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)
  trace_free : ∀ T : ℝ, 0 ≤ T →
    ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      ∀ᵐ x ∂(volume : Measure Space),
        (g t : Space → MatrixFiber) x (0, 0) +
        (g t : Space → MatrixFiber) x (1, 1) +
        (g t : Space → MatrixFiber) x (2, 2) = 0
  interior_equation : InteriorEquation u g nu

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

/-- Conditional finite-time Gram estimate for the above concrete weak-form
data and an operator interface. The implication uses only energy-class and
weak-gradient data; it does not require the nonlinear PDE field, the velocity
bound, or the initial right-limit field. -/
theorem gram_from_interior_energy_solution
    [MeasurableSpace Velocity] [BorelSpace Velocity]
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (S : Interface) (u : ℝ → Velocity) (u0 : Velocity) (g : ℝ → Gradient)
    (nu : ℝ) (hnu : 0 < nu) (hsol : InteriorEnergySolution u u0 g nu)
    (T : ℝ) (hT : 0 ≤ T) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierSpectralTimeComposition.positiveField S
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField S
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)))
      (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (FrontierFiniteIntervalEnergy.timeMeasure T)
      (fun t => FrontierSpectralTimeComposition.positiveField S
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField S
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  exact FrontierRealSpectralEnergy.finite_interval_real_trajectory
    S u u0 g T nu hnu hsol.initial_value (hsol.gradient_l2 T hT)
    (hsol.energy T hT) (hsol.weak_gradient T hT) (hsol.trace_free T hT)

end FrontierInteriorWeakNSE

#print axioms FrontierInteriorWeakNSE.gram_from_interior_energy_solution
