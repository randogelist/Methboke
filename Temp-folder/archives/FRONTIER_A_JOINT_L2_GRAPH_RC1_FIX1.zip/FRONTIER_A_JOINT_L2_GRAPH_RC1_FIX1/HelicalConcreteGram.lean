import HelicalConcreteSymbol
import HOPF_GRAM_INTEGRAL

/-!
Candidate connection of the concrete frequency multipliers to the verified
Gram estimate. The symbol-to-L2 realization is supplied by the imported
concrete construction. The trajectory and its projected energy budget are
explicit inputs. No physical-space Fourier transform or NSE solution is
constructed here. External Lean compilation and axiom auditing are required.
-/

noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace HelicalConcreteGram

/-- The concrete positive and negative L2 multiplier ranges are orthogonal
    for the complex inner product. -/
theorem multiplier_complex_orthogonal (μ : Measure Frequency)
    (f g : Lp Fiber 2 μ) :
    inner ℂ (plusMultiplier μ f) (minusMultiplier μ g) = 0 := by
  rw [MeasureTheory.L2.inner_def]
  have heq : (fun ξ : Frequency =>
      inner ℂ ((plusMultiplier μ f : Frequency → Fiber) ξ)
        ((minusMultiplier μ g : Frequency → Fiber) ξ)) =ᵐ[μ]
      (fun _ : Frequency => (0 : ℂ)) := by
    filter_upwards [plus_multiplier_ae μ f, minus_multiplier_ae μ g] with ξ hp hm
    rw [hp, hm, plus_action, minus_action]
    exact FeffermanHelicalFiberFrequency.sectors_orthogonal
      (ξ 0) (ξ 1) (ξ 2) ((f : Frequency → Fiber) ξ) ((g : Frequency → Fiber) ξ)
  rw [integral_congr_ae heq]
  simp

/- Regard the complex frequency-space L2 Hilbert space as a real Hilbert
   space. This is the inner-product structure used by the Gram integral. -/
local instance realL2 (μ : Measure Frequency) : InnerProductSpace ℝ (Lp Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp Fiber 2 μ)

theorem multiplier_real_orthogonal (μ : Measure Frequency)
    (f g : Lp Fiber 2 μ) :
    @inner ℝ (Lp Fiber 2 μ) (realL2 μ).toInner
      (plusMultiplier μ f) (minusMultiplier μ g) = 0 := by
  change (inner ℂ (plusMultiplier μ f) (minusMultiplier μ g)).re = 0
  rw [multiplier_complex_orthogonal μ f g]
  simp

/-- The concrete helical L2 multipliers yield the genuine vector-Gram bound
    whenever the trajectory has the stated projected energy budget. -/
theorem concrete_helical_gram_bound
    {τ : Type*} [MeasurableSpace τ] (μ : Measure Frequency) (η : Measure τ)
    [MeasurableSpace (Lp Fiber 2 μ)] [BorelSpace (Lp Fiber 2 μ)]
    (z : τ → Lp Fiber 2 μ) (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hz : MemLp z 2 η)
    (hEnergy : 2 * nu * (∫ t,
      (‖plusMultiplier μ (z t)‖ ^ 2 + ‖minusMultiplier μ (z t)‖ ^ 2) ∂η)
      ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier μ (z t)) (fun t => minusMultiplier μ (z t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier μ (z t)) (fun t => minusMultiplier μ (z t))
      ≤ initialEnergy / (4 * nu) := by
  have hp : MemLp (fun t => plusMultiplier μ (z t)) 2 η := by
    simpa only [Function.comp_def] using (plusMultiplier μ).comp_memLp' hz
  have hm : MemLp (fun t => minusMultiplier μ (z t)) 2 η := by
    simpa only [Function.comp_def] using (minusMultiplier μ).comp_memLp' hz
  have ho : ∀ᵐ t ∂η, @inner ℝ (Lp Fiber 2 μ) (realL2 μ).toInner
      (plusMultiplier μ (z t)) (minusMultiplier μ (z t)) = 0 :=
    Filter.Eventually.of_forall (fun t => multiplier_real_orthogonal μ (z t) (z t))
  exact FeffermanAHopfGramIntegral.gramSqrt_integrable_and_bound_of_memLp_ae
    η (fun t => plusMultiplier μ (z t)) (fun t => minusMultiplier μ (z t))
    nu initialEnergy hnu hp hm ho hEnergy

end HelicalConcreteGram

#print axioms HelicalConcreteGram.multiplier_complex_orthogonal
#print axioms HelicalConcreteGram.multiplier_real_orthogonal
#print axioms HelicalConcreteGram.concrete_helical_gram_bound
