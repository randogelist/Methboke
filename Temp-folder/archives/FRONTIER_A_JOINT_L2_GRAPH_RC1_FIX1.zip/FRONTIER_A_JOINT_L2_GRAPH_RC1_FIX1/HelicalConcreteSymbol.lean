import HelicalFiberFrequency
import HelicalL2Lift

/-! Candidate concrete operator-valued frequency symbols and L2 lift.
All results need native Lean compilation and axiom auditing. The underlying
Fourier transform and the real-valued-field and NSE links are not developed.
-/

noncomputable section
open MeasureTheory Filter
open FeffermanHelicalOrthogonal

namespace HelicalConcreteSymbol

abbrev Frequency := Fin 3 → ℝ
abbrev Mat := Fin 3 → Fin 3 → ℂ

local instance : MeasurableSpace (Matrix (Fin 3) (Fin 3) ℂ) := MeasurableSpace.pi

/-- Matrix action as a continuous complex-linear map, on a Euclidean fiber. -/
def matrixToComplex : Mat →ₗ[ℂ] (Fiber →L[ℂ] Fiber) :=
  ((Matrix.toEuclideanLin : Matrix (Fin 3) (Fin 3) ℂ ≃ₗ[ℂ] (Fiber →ₗ[ℂ] Fiber)).trans
    (LinearMap.toContinuousLinearMap : (Fiber →ₗ[ℂ] Fiber) ≃ₗ[ℂ] (Fiber →L[ℂ] Fiber))).toLinearMap

/-- The real-linear positive-helicity operator at each frequency. -/
def plusOp (ξ : Frequency) : Fiber →L[ℝ] Fiber :=
  (matrixToComplex (FeffermanHelicalFrequency.plus (ξ 0) (ξ 1) (ξ 2))).restrictScalars ℝ

def minusOp (ξ : Frequency) : Fiber →L[ℝ] Fiber :=
  (matrixToComplex (FeffermanHelicalFrequency.minus (ξ 0) (ξ 1) (ξ 2))).restrictScalars ℝ

theorem plus_action (ξ : Frequency) (v : Fiber) :
    plusOp ξ v = FeffermanHelicalFiberFrequency.plusMap (ξ 0) (ξ 1) (ξ 2) v := by
  rfl

theorem minus_action (ξ : Frequency) (v : Fiber) :
    minusOp ξ v = FeffermanHelicalFiberFrequency.minusMap (ξ 0) (ξ 1) (ξ 2) v := by
  rfl

theorem plus_bound (ξ : Frequency) : ‖plusOp ξ‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound
  · norm_num
  · intro v
    simpa only [plus_action, one_mul] using
      FeffermanHelicalFiberFrequency.plus_contractive (ξ 0) (ξ 1) (ξ 2) v

theorem minus_bound (ξ : Frequency) : ‖minusOp ξ‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound
  · norm_num
  · intro v
    simpa only [minus_action, one_mul] using
      FeffermanHelicalFiberFrequency.minus_contractive (ξ 0) (ξ 1) (ξ 2) v

theorem plus_idempotent (ξ : Frequency) (v : Fiber) :
    plusOp ξ (plusOp ξ v) = plusOp ξ v := by
  simpa only [plus_action] using
    FeffermanHelicalFiberFrequency.plus_idempotent (ξ 0) (ξ 1) (ξ 2) v

theorem minus_idempotent (ξ : Frequency) (v : Fiber) :
    minusOp ξ (minusOp ξ v) = minusOp ξ v := by
  simpa only [minus_action] using
    FeffermanHelicalFiberFrequency.minus_idempotent (ξ 0) (ξ 1) (ξ 2) v

/-- Candidate measurability of the actual operator-valued positive symbol. -/
theorem measurable_plusOp : Measurable plusOp := by
  have hm : Measurable (fun ξ : Frequency =>
      (show Mat from FeffermanHelicalFrequency.plus (ξ 0) (ξ 1) (ξ 2))) :=
    FeffermanHelicalFrequency.measurable_plus_r3
  have hc : Continuous matrixToComplex := matrixToComplex.continuous_of_finiteDimensional
  have hr : Continuous (fun f : Fiber →L[ℂ] Fiber => f.restrictScalars ℝ) :=
    ContinuousLinearMap.continuous_restrictScalars ℝ
  exact hr.measurable.comp (hc.measurable.comp hm)

theorem measurable_minusOp : Measurable minusOp := by
  have hm : Measurable (fun ξ : Frequency =>
      (show Mat from FeffermanHelicalFrequency.minus (ξ 0) (ξ 1) (ξ 2))) :=
    FeffermanHelicalFrequency.measurable_minus_r3
  have hc : Continuous matrixToComplex := matrixToComplex.continuous_of_finiteDimensional
  have hr : Continuous (fun f : Fiber →L[ℂ] Fiber => f.restrictScalars ℝ) :=
    ContinuousLinearMap.continuous_restrictScalars ℝ
  exact hr.measurable.comp (hc.measurable.comp hm)

theorem plus_memLp_top (μ : Measure Frequency) : MemLp plusOp ⊤ μ := by
  apply memLp_top_of_bound measurable_plusOp.aestronglyMeasurable 1
  exact Filter.Eventually.of_forall plus_bound

theorem minus_memLp_top (μ : Measure Frequency) : MemLp minusOp ⊤ μ := by
  apply memLp_top_of_bound measurable_minusOp.aestronglyMeasurable 1
  exact Filter.Eventually.of_forall minus_bound

/-- Concrete helical multiplier on frequency-space L2. -/
def plusMultiplier (μ : Measure Frequency) : Lp Fiber 2 μ →L[ℝ] Lp Fiber 2 μ :=
  HelicalL2Lift.multiplier μ (MemLp.toLp plusOp (plus_memLp_top μ))

def minusMultiplier (μ : Measure Frequency) : Lp Fiber 2 μ →L[ℝ] Lp Fiber 2 μ :=
  HelicalL2Lift.multiplier μ (MemLp.toLp minusOp (minus_memLp_top μ))

theorem plus_multiplier_ae (μ : Measure Frequency) (f : Lp Fiber 2 μ) :
    (plusMultiplier μ f : Frequency → Fiber) =ᵐ[μ]
      fun ξ => plusOp ξ ((f : Frequency → Fiber) ξ) := by
  filter_upwards [HelicalL2Lift.multiplier_ae μ
      (MemLp.toLp plusOp (plus_memLp_top μ)) f,
      MemLp.coeFn_toLp (plus_memLp_top μ)] with ξ hm hs
  simpa only [plusMultiplier, hs] using hm

theorem minus_multiplier_ae (μ : Measure Frequency) (f : Lp Fiber 2 μ) :
    (minusMultiplier μ f : Frequency → Fiber) =ᵐ[μ]
      fun ξ => minusOp ξ ((f : Frequency → Fiber) ξ) := by
  filter_upwards [HelicalL2Lift.multiplier_ae μ
      (MemLp.toLp minusOp (minus_memLp_top μ)) f,
      MemLp.coeFn_toLp (minus_memLp_top μ)] with ξ hm hs
  simpa only [minusMultiplier, hs] using hm

theorem plus_multiplier_idempotent (μ : Measure Frequency) (f : Lp Fiber 2 μ) :
    plusMultiplier μ (plusMultiplier μ f) = plusMultiplier μ f := by
  unfold plusMultiplier
  apply HelicalL2Lift.multiplier_idempotent
  filter_upwards [MemLp.coeFn_toLp (plus_memLp_top μ)] with ξ hξ
  intro v
  rw [hξ]
  exact plus_idempotent ξ v

theorem minus_multiplier_idempotent (μ : Measure Frequency) (f : Lp Fiber 2 μ) :
    minusMultiplier μ (minusMultiplier μ f) = minusMultiplier μ f := by
  unfold minusMultiplier
  apply HelicalL2Lift.multiplier_idempotent
  filter_upwards [MemLp.coeFn_toLp (minus_memLp_top μ)] with ξ hξ
  intro v
  rw [hξ]
  exact minus_idempotent ξ v

end HelicalConcreteSymbol

#print axioms HelicalConcreteSymbol.plus_action
#print axioms HelicalConcreteSymbol.minus_action
#print axioms HelicalConcreteSymbol.plus_bound
#print axioms HelicalConcreteSymbol.minus_bound
#print axioms HelicalConcreteSymbol.plus_idempotent
#print axioms HelicalConcreteSymbol.minus_idempotent
#print axioms HelicalConcreteSymbol.measurable_plusOp
#print axioms HelicalConcreteSymbol.measurable_minusOp
#print axioms HelicalConcreteSymbol.plus_memLp_top
#print axioms HelicalConcreteSymbol.minus_memLp_top
#print axioms HelicalConcreteSymbol.plus_multiplier_ae
#print axioms HelicalConcreteSymbol.minus_multiplier_ae
#print axioms HelicalConcreteSymbol.plus_multiplier_idempotent
#print axioms HelicalConcreteSymbol.minus_multiplier_idempotent
