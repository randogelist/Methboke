import FrontierSolenoidalEnergy

/-! A conditional finite-interval adapter. The endpoint values in the energy
inequality are now the values at 0 and T of the same supplied trajectory.
The weak-gradient, divergence, integrability, and energy properties remain
explicit hypotheses. No Leray--Hopf solution is constructed or identified.
No Lean compiler was run locally. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierFiniteIntervalEnergy

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

/-- Time measure on the closed finite interval. Endpoint choices do not
change Lebesgue integration, but that identification is not used here. -/
def timeMeasure (T : ℝ) : Measure ℝ := volume.restrict (Set.Icc 0 T)

/-- The finite-interval conclusion for a single supplied velocity trajectory,
under its explicitly stated weak-gradient, divergence and energy properties. -/
theorem all_finite_intervals_of_trajectory_assumptions
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → FrontierSpectralOperator.Field)
    (g : ℝ → FrontierARealGradient.RealMatrix)
    (nu : ℝ) (hnu : 0 < nu)
    (hg : ∀ T : ℝ, 0 ≤ T → MemLp g 2 (timeMeasure T))
    (henergy : ∀ T : ℝ, 0 ≤ T →
      ‖u T‖ ^ 2 + 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂(timeMeasure T)) ≤ ‖u 0‖ ^ 2)
    (hweak : ∀ T : ℝ, 0 ≤ T → ∀ᵐ t ∂(timeMeasure T), ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t)))
    (hdiv : ∀ T : ℝ, 0 ≤ T → ∀ᵐ t ∂(timeMeasure T),
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 0
        (FrontierGradientAdapter.gradientColumn (g t) 0)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 1
        (FrontierGradientAdapter.gradientColumn (g t) 1)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 2
        (FrontierGradientAdapter.gradientColumn (g t) 2)) = 0) :
    ∀ T : ℝ, 0 ≤ T →
      (∀ᵐ t ∂(timeMeasure T), FrontierPhysicalProjectors.plusProjector (u t) +
        FrontierPhysicalProjectors.minusProjector (u t) = u t) ∧
      (∀ᵐ t ∂(timeMeasure T), ∃ v : FrontierSpectralOperator.Domain, v.val = u t) ∧
      Integrable (FeffermanAHopfGramIntegral.gramSqrt
        (fun t => FrontierACoordinateEquiv.plusPullback
          (FrontierDissipationDomain.gradientDissipation (g t)))
        (fun t => FrontierACoordinateEquiv.minusPullback
          (FrontierDissipationDomain.gradientDissipation (g t)))) (timeMeasure T) ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral (timeMeasure T)
        (fun t => FrontierACoordinateEquiv.plusPullback
          (FrontierDissipationDomain.gradientDissipation (g t)))
        (fun t => FrontierACoordinateEquiv.minusPullback
          (FrontierDissipationDomain.gradientDissipation (g t))) ≤ ‖u 0‖ ^ 2 / (4 * nu) := by
  intro T hT
  exact FrontierSolenoidalEnergy.split_and_gram_of_gradient_energy
    (timeMeasure T) u g (u 0) (u T) nu hnu (hg T hT) (henergy T hT)
    (hweak T hT) (hdiv T hT)

end FrontierFiniteIntervalEnergy

#print axioms FrontierFiniteIntervalEnergy.all_finite_intervals_of_trajectory_assumptions
