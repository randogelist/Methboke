import FrontierGraphSquareMaximal

/-! Candidate: an L² representative of the squared Fourier multiplier implies
membership in the existing first-order Fourier graph. This is a Fourier-domain
result, not independent variational Stokes self-adjointness. No local Lean. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierSquareFirstDomain

abbrev Field := FrontierSpectralOperator.Field
abbrev Frequency := FrontierSpectralOperator.Frequency
abbrev Fiber := FrontierSpectralOperator.Fiber

theorem weight_continuous : Continuous FrontierProjectedDissipation.weight := by
  unfold FrontierProjectedDissipation.weight FeffermanHelicalNormalize.radius
  fun_prop

/-- A field and its squared-weighted Fourier transform in L² also have an
L² first-weighted Fourier transform. -/
theorem first_domain_of_squared_symbol (u : Field)
    (hsq : FrontierGraphSquareMaximal.HasLaplacianSymbol u) :
    FrontierDissipationDomain.HasDissipationSymbol u := by
  obtain ⟨v, hv⟩ := hsq
  let F := FrontierPhysicalGramTransport.fourierCoordinateReal u
  let G := FrontierPhysicalGramTransport.fourierCoordinateReal v
  have hF : MemLp (fun ξ => ‖(F : Frequency → Fiber) ξ‖) 2 volume := by
    exact (MeasureTheory.Lp.memLp F).norm
  have hG : MemLp (fun ξ => ‖(G : Frequency → Fiber) ξ‖) 2 volume := by
    exact (MeasureTheory.Lp.memLp G).norm
  have hsum : MemLp (fun ξ => ‖(F : Frequency → Fiber) ξ‖ +
      ‖(G : Frequency → Fiber) ξ‖) 2 volume := hF.add hG
  have hm : AEStronglyMeasurable
      (fun ξ => FrontierProjectedDissipation.weight ξ • (F : Frequency → Fiber) ξ)
      (volume : Measure Frequency) := by
    exact weight_continuous.measurable.aestronglyMeasurable.smul (MeasureTheory.Lp.memLp F).aestronglyMeasurable
  have hcoord := FrontierDomainLinear.fourierCoordinate_ae u
  change (F : Frequency → Fiber) =ᵐ[volume] _ at hcoord
  change (G : Frequency → Fiber) =ᵐ[volume] _ at hv
  have hbound : ∀ᵐ ξ ∂(volume : Measure Frequency),
      ‖FrontierProjectedDissipation.weight ξ • (F : Frequency → Fiber) ξ‖ ≤
        ‖(F : Frequency → Fiber) ξ‖ + ‖(G : Frequency → Fiber) ξ‖ := by
    filter_upwards [hv, hcoord] with ξ hv hcoord
    have hGval : (G : Frequency → Fiber) ξ =
        (FrontierProjectedDissipation.weight ξ * FrontierProjectedDissipation.weight ξ) •
          (F : Frequency → Fiber) ξ := by
      rw [hv, FrontierGraphSquared.laplacianSymbol, hcoord]
    have hweight : ‖FrontierProjectedDissipation.weight ξ‖ ≤
        1 + ‖FrontierProjectedDissipation.weight ξ‖ ^ 2 := by
      nlinarith [sq_nonneg (‖FrontierProjectedDissipation.weight ξ‖ - (1 / 2 : ℝ))]
    rw [hGval]
    simp only [norm_smul, norm_mul]
    have hfnonneg : 0 ≤ ‖(F : Frequency → Fiber) ξ‖ := norm_nonneg _
    have hmul := mul_le_mul_of_nonneg_right hweight hfnonneg
    nlinarith [hmul]
  have hmem : MemLp
      (fun ξ => FrontierProjectedDissipation.weight ξ • (F : Frequency → Fiber) ξ)
      2 (volume : Measure Frequency) := hsum.mono' hm hbound
  let V := hmem.toLp _
  refine ⟨FrontierPhysicalGramTransport.fourierCoordinateReal.symm V, ?_⟩
  have hV : (V : Frequency → Fiber) =ᵐ[volume]
      fun ξ => FrontierProjectedDissipation.weight ξ • (F : Frequency → Fiber) ξ :=
    MemLp.coeFn_toLp hmem
  change (FrontierPhysicalGramTransport.fourierCoordinateReal
      (FrontierPhysicalGramTransport.fourierCoordinateReal.symm V) : Frequency → Fiber) =ᵐ[volume] _
  rw [FrontierPhysicalGramTransport.fourierCoordinateReal.apply_symm_apply]
  filter_upwards [hV, hcoord] with ξ hV hcoord
  rw [hV, FrontierProjectedDissipation.velocitySymbol_eq_weight, hcoord]

end FrontierSquareFirstDomain

#print axioms FrontierSquareFirstDomain.weight_continuous
#print axioms FrontierSquareFirstDomain.first_domain_of_squared_symbol
