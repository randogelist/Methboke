import FrontierCanonicalPhysicalSymbols
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

/-!
Candidate: extend uniform finite-interval bounds on a single nonnegative
integrand to the positive half-line. No global energy or global integrability
is assumed. Current Mathlib documentation was consulted, but no compiler has
run. The specialization still assumes supplied weak-gradient and energy data;
it does not realize standard Leray--Hopf solutions or the Stokes square root.
-/
noncomputable section
open MeasureTheory Filter

namespace FrontierHalflineExhaustion

/-- A nonnegative locally integrable function with uniformly bounded finite
interval integrals is integrable on the positive half-line with the same bound. -/
theorem nonneg_integrable_Ioi_of_bounded_Icc
    (f : ℝ → ℝ) (C : ℝ)
    (hnonneg : ∀ t, 0 ≤ f t)
    (hloc : ∀ n : ℕ, Integrable f (volume.restrict (Set.Icc 0 (n : ℝ))))
    (hbound : ∀ n : ℕ, (∫ t in Set.Icc 0 (n : ℝ), f t) ≤ C) :
    Integrable f (volume.restrict (Set.Ioi 0)) ∧
      (∫ t in Set.Ioi 0, f t) ≤ C := by
  have hIoc : ∀ n : ℕ, IntegrableOn f (Set.Ioc 0 (n : ℝ)) volume := by
    intro n
    have hc : IntegrableOn f (Set.Icc 0 (n : ℝ)) volume := hloc n
    apply MeasureTheory.IntegrableOn.mono_set hc
    intro t ht
    exact ⟨le_of_lt ht.1, ht.2⟩
  have hinterval : ∀ n : ℕ, (∫ t in (0 : ℝ)..(n : ℝ), f t) ≤ C := by
    intro n
    rw [intervalIntegral.integral_of_le (Nat.cast_nonneg n)]
    rw [← integral_Icc_eq_integral_Ioc]
    exact hbound n
  have hnorm : (fun t => ‖f t‖) = f := by
    funext t
    calc
      ‖f t‖ = |f t| := Real.norm_eq_abs _
      _ = f t := abs_of_nonneg (hnonneg t)
  have hnormBound : ∀ᶠ n : ℕ in atTop,
      (∫ t in (0 : ℝ)..(n : ℝ), ‖f t‖) ≤ C := by
    filter_upwards [] with n
    simpa only [hnorm] using hinterval n
  have hglobal : IntegrableOn f (Set.Ioi 0) volume :=
    integrableOn_Ioi_of_intervalIntegral_norm_bounded C 0 hIoc
      tendsto_natCast_atTop_atTop hnormBound
  have hlim := intervalIntegral_tendsto_integral_Ioi (0 : ℝ) hglobal
    (tendsto_natCast_atTop_atTop : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop)
  exact ⟨hglobal, le_of_tendsto hlim (Filter.Eventually.of_forall hinterval)⟩

local instance physicalRealL2 : InnerProductSpace ℝ FrontierPhysicalGramTransport.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierPhysicalGramTransport.PhysicalL2

theorem canonical_gram_positive_halfline
    [MeasurableSpace FrontierCanonicalPhysicalSymbols.Gradient] [BorelSpace FrontierCanonicalPhysicalSymbols.Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2]
    [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → FrontierCanonicalPhysicalSymbols.RealVelocity) (u0 : FrontierCanonicalPhysicalSymbols.RealVelocity) (g : ℝ → FrontierCanonicalPhysicalSymbols.Gradient)
    (nu : ℝ) (hnu : 0 < nu) (hinit : u 0 = u0)
    (hg : ∀ T : ℝ, 0 ≤ T → MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T))
    (henergy : ∀ T : ℝ, 0 ≤ T →
      ‖u T‖ ^ 2 + 2 * nu *
        (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ T : ℝ, 0 ≤ T →
      ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T), ∀ j,
        Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
        LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
          (Lp.toTemperedDistribution (FrontierRealVelocityEmbedding.complexifyL2 (u t)))) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)))
      (volume.restrict (Set.Ioi 0)) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (volume.restrict (Set.Ioi 0))
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  have hb := FrontierCanonicalPhysicalSymbols.canonical_gram_from_explicit_inputs
    u u0 g nu hnu hinit hg henergy hweak
  apply nonneg_integrable_Ioi_of_bounded_Icc
  · intro t
    exact Real.sqrt_nonneg _
  · intro n
    simpa only [FrontierFiniteIntervalEnergy.timeMeasure] using
      (hb (n : ℝ) (Nat.cast_nonneg n)).1
  · intro n
    simpa only [FrontierFiniteIntervalEnergy.timeMeasure,
      FeffermanAHopfGramIntegral.gramSqrtIntegral] using
      (hb (n : ℝ) (Nat.cast_nonneg n)).2

end FrontierHalflineExhaustion

#print axioms FrontierHalflineExhaustion.nonneg_integrable_Ioi_of_bounded_Icc
#print axioms FrontierHalflineExhaustion.canonical_gram_positive_halfline
