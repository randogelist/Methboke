import FrontierRealFourierSeed

/-! Coordinatewise Fourier reality for integrable real-valued complex vector
fields. The theorem concerns the pointwise Fourier integral. Its passage to
L² representatives and density of such fields in the physical real L² space
are not established here. No local Lean run. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierRealVectorFourierSeed
abbrev Space := FrontierRealFourierSeed.Space
abbrev Fiber := EuclideanSpace ℂ (Fin 3)

/-- Coordinate evaluation is complex-linear and continuous. -/
def coordinateMap (j : Fin 3) : Fiber →ₗ[ℂ] ℂ where
  toFun v := v j
  map_add' v w := by simp
  map_smul' c v := by simp

def coordinateCLM (j : Fin 3) : Fiber →L[ℂ] ℂ :=
  LinearMap.toContinuousLinearMap (coordinateMap j)

theorem coordinateCLM_apply (j : Fin 3) (v : Fiber) : coordinateCLM j v = v j := by rfl

/-- The vector Fourier integral commutes with coordinate evaluation. -/
theorem fourier_coordinate_integrable
    (f : Space → Fiber) (hf : Integrable f (volume : Measure Space))
    (ξ : Space) (j : Fin 3) :
    FourierTransform.fourier (fun x => f x j) ξ =
      (FourierTransform.fourier f ξ) j := by
  have h : FourierTransform.fourier (fun x => coordinateCLM j (f x)) ξ =
      coordinateCLM j (FourierTransform.fourier f ξ) := by
    rw [Real.fourier_eq, Real.fourier_eq]
    have hi : Integrable (fun x : Space =>
        Real.fourierChar (-inner ℝ x ξ) • f x) (volume : Measure Space) :=
      (Real.fourierIntegral_convergent_iff ξ).2 hf
    simpa only [Circle.smul_def, map_smul] using ((coordinateCLM j).integral_comp_comm hi)
  simpa only [coordinateCLM_apply] using h

/-- Each coordinate of the Fourier transform of a real vector field obeys
conjugate reversal. -/
theorem fourier_real_vector_conjugate
    (f : Space → Fiber) (hf : Integrable f (volume : Measure Space))
    (hreal : ∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3, star (f x j) = f x j)
    (ξ : Space) (j : Fin 3) :
    (FourierTransform.fourier f (-ξ)) j =
      star ((FourierTransform.fourier f ξ) j) := by
  have hr : ∀ᵐ x ∂(volume : Measure Space), star ((fun x => f x j) x) =
      (fun x => f x j) x := by
    filter_upwards [hreal] with x hx
    exact hx j
  calc
    (FourierTransform.fourier f (-ξ)) j =
        FourierTransform.fourier (fun x => f x j) (-ξ) :=
      (fourier_coordinate_integrable f hf (-ξ) j).symm
    _ = star (FourierTransform.fourier (fun x => f x j) ξ) :=
      FrontierRealFourierSeed.fourier_real_ae_conjugate _ hr ξ
    _ = star ((FourierTransform.fourier f ξ) j) :=
      congrArg star (fourier_coordinate_integrable f hf ξ j)

end FrontierRealVectorFourierSeed

#print axioms FrontierRealVectorFourierSeed.coordinateCLM_apply
#print axioms FrontierRealVectorFourierSeed.fourier_coordinate_integrable
#print axioms FrontierRealVectorFourierSeed.fourier_real_vector_conjugate
