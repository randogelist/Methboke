using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

// Standalone .NET Framework 4.x validator for native Lean #print axioms output.
// Validation concerns this exact named audit set. It makes no closure claim.
internal static class AuditValidator
{
    static readonly string[] Allowed = { "propext", "Classical.choice", "Quot.sound" };
    static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
    static readonly Regex QualifiedName = new Regex(@"\A[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*\z",
        RegexOptions.CultureInvariant);

    internal static int Main(string[] args)
    {
        try {
            if (args.Length == 1 && args[0] == "--self-test") {
                SelfTest();
                Console.WriteLine("AUDIT_VALIDATOR_SELF_TEST=PASS");
                return 0;
            }
            if (args.Length != 3)
                throw new InvalidDataException("Usage: AuditValidator.exe EXPECTED_NAMES_FILE RAW_AUDIT_LOG NEW_NORMALIZED_OUTPUT");
            if (File.Exists(args[2]))
                throw new IOException("Normalized output already exists. Select a fresh filename.");
            string[] expected = ReadExpected(args[0]);
            if (new FileInfo(args[1]).Length > 1048576)
                throw new InvalidDataException("Audit log exceeds the 1 MiB limit.");
            string[] canonical = Validate(expected, File.ReadAllText(args[1], Utf8));
            // CreateNew protects against a prior receipt and against concurrent validator attempts.
            using (var stream = new FileStream(args[2], FileMode.CreateNew, FileAccess.Write, FileShare.Read))
            using (var writer = new StreamWriter(stream, Utf8))
                foreach (string line in canonical) writer.WriteLine(line);
            Console.WriteLine("AXIOM_AUDIT=STANDARD_ONLY_" + expected.Length + "_NAMED_THEOREMS");
            Console.WriteLine("SORRYAX=NONE");
            Console.WriteLine("AXIOM_REPORTS_EXACT=" + expected.Length);
            return 0;
        } catch (Exception e) {
            Console.Error.WriteLine("AXIOM_AUDIT=FAIL " + e.Message);
            return 1;
        }
    }

    static string[] ReadExpected(string path)
    {
        string[] names = File.ReadAllLines(path, Utf8);
        if (names.Length == 0 || names.Length > 10000)
            throw new InvalidDataException("Expected theorem list is empty or exceeds 10000 names.");
        return names;
    }

    internal static string[] Validate(string[] expected, string text)
    {
        var required = new HashSet<string>(StringComparer.Ordinal);
        foreach (string name in expected)
            if (!QualifiedName.IsMatch(name) || !required.Add(name))
                throw new InvalidDataException("Invalid or duplicate expected theorem: " + name);
        if (required.Count == 0) throw new InvalidDataException("Empty expected theorem list.");
        var reports = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);
        var input = new Reader(text);
        input.SkipSpace();
        while (!input.End) {
            input.Expect('\'');
            string name = input.Name();
            input.Expect('\'');
            if (!required.Contains(name)) input.Fail("Unexpected theorem '" + name + "'");
            if (reports.ContainsKey(name)) input.Fail("Duplicate report for '" + name + "'");
            input.Space();
            var axioms = new HashSet<string>(StringComparer.Ordinal);
            string verb = input.Word();
            if (verb == "does") {
                input.SpacedWord("not"); input.SpacedWord("depend"); input.SpacedWord("on");
                input.SpacedWord("any"); input.SpacedWord("axioms");
            } else if (verb == "depends") {
                input.SpacedWord("on"); input.SpacedWord("axioms");
                input.SkipSpace(); input.Expect(':'); input.SkipSpace(); input.Expect('['); input.SkipSpace();
                // Native Lean prints an empty dependency set using the "does not depend" form.
                while (true) {
                    string axiom = input.Name();
                    if (Array.IndexOf(Allowed, axiom) < 0) input.Fail("Unapproved axiom '" + axiom + "' in '" + name + "'");
                    if (!axioms.Add(axiom)) input.Fail("Duplicate axiom in '" + name + "'");
                    input.SkipSpace();
                    if (input.Take(']')) break;
                    input.Expect(','); input.SkipSpace();
                }
            } else input.Fail("Unrecognized axiom report for '" + name + "'");
            reports.Add(name, axioms);
            if (!input.End) input.Space();
        }
        var output = new List<string>();
        foreach (string name in expected) {
            HashSet<string> set;
            if (!reports.TryGetValue(name, out set)) throw new InvalidDataException("Missing report for '" + name + "'");
            var ordered = new List<string>();
            foreach (string axiom in Allowed) if (set.Contains(axiom)) ordered.Add(axiom);
            output.Add("'" + name + "' " + (ordered.Count == 0 ? "does not depend on any axioms" :
                "depends on axioms: [" + String.Join(", ", ordered.ToArray()) + "]"));
        }
        return output.ToArray();
    }

    sealed class Reader
    {
        readonly string text;
        int at;
        internal Reader(string value) { text = value; }
        internal bool End { get { return at == text.Length; } }
        static bool IsSpace(char c) { return c == ' ' || c == '\t' || c == '\r' || c == '\n'; }
        internal void SkipSpace() { while (!End && IsSpace(text[at])) at++; }
        internal void Space() { int old = at; SkipSpace(); if (old == at) Fail("Expected whitespace between tokens or reports"); }
        internal bool Take(char c) { if (End || text[at] != c) return false; at++; return true; }
        internal void Expect(char c) { if (!Take(c)) Fail("Expected '" + c + "'"); }
        internal string Word()
        {
            int begin = at;
            while (!End && text[at] >= 'a' && text[at] <= 'z') at++;
            if (begin == at) Fail("Expected report keyword");
            return text.Substring(begin, at - begin);
        }
        internal void SpacedWord(string expected) { Space(); if (Word() != expected) Fail("Expected keyword '" + expected + "'"); }
        internal string Name()
        {
            int begin = at;
            while (!End) {
                char c = text[at];
                if (!(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z') &&
                    !(c >= '0' && c <= '9') && c != '_' && c != '.') break;
                at++;
            }
            string value = text.Substring(begin, at - begin);
            if (!QualifiedName.IsMatch(value)) Fail("Expected a complete Lean name");
            return value;
        }
        internal void Fail(string why)
        {
            int line = 1;
            for (int i = 0; i < at; i++) if (text[i] == '\n') line++;
            throw new InvalidDataException(why + " at line " + line + ", offset " + at + ".");
        }
    }

    static void SelfTest()
    {
        string[] names = { "KTheta.a", "KTheta.b" };
        string a = "'KTheta.a' depends on axioms: [propext,\r\n Classical.choice,\n Quot.sound]";
        string b = "'KTheta.b' does not depend on any axioms";
        string text = a + "\r\n" + b + "\r\n";
        string[] result = Validate(names, text);
        if (result.Length != 2 || result[0].IndexOf("[propext, Classical.choice, Quot.sound]", StringComparison.Ordinal) < 0)
            throw new InvalidDataException("Canonicalization self-test failed.");
        Validate(names, b + "\n'KTheta.a'\n depends on axioms:\n[Quot.sound, propext, Classical.choice]\n");
        string[] invalid = {
            a, text + a, text + "warning: extra output\n", text.Replace("propext", "sorryAx"),
            text.Replace("propext", "Custom.propext"), text.Replace("Classical.choice", "propext"),
            text.Replace("KTheta.a", "KTheta.extra"), text.Replace("Quot.sound]", "Quot.sound,]"),
            text.Replace("Quot.sound]", "Quot.sound"), text.Replace("propext,\r\n Classical.choice", "propext Classical.choice"),
            text.Replace("depends on axioms", "depends unexpectedly on axioms"), a + b,
            text.Replace("Quot.sound", "Quot.sound.more"), text.Replace("[propext,\r\n Classical.choice,\n Quot.sound]", "[]"),
            "unexpected-prefix\n" + text, text + "\0", text.Replace("any axioms", "any axiomsgarbage")
        };
        foreach (string bad in invalid) {
            bool rejected = false;
            try { Validate(names, bad); } catch (InvalidDataException) { rejected = true; }
            if (!rejected) throw new InvalidDataException("Malformed audit self-test was accepted.");
        }
        bool duplicateListRejected = false;
        try { Validate(new string[] { "KTheta.a", "KTheta.a" }, a); }
        catch (InvalidDataException) { duplicateListRejected = true; }
        if (!duplicateListRejected) throw new InvalidDataException("Duplicate expected list was accepted.");
    }
}
