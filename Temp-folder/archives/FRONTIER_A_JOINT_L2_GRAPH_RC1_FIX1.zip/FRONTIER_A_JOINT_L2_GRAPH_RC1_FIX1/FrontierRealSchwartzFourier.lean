import FrontierRealVectorFourierSeed
import FrontierDomainLinear
import FrontierHermitianDensity

/-! Candidate identification of the L² Fourier transform of a real Schwartz
vector seed with Hermitian symmetry on coordinate frequency space. Real
Schwartz density in the physical real L² space and the Leray--Hopf
realization remain open. No local Lean run. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierRealSchwartzFourier

abbrev Space := FrontierRealVectorFourierSeed.Space
abbrev Fiber := FrontierRealVectorFourierSeed.Fiber
abbrev Field := HelicalR3Plancherel.ComplexField
abbrev Frequency := FrontierAESymmetry.Frequency

/-- Real Schwartz seeds have Hermitian coordinate-space L² Fourier transforms. -/
theorem fourier_hermitian_of_real_schwartz
    (f : SchwartzMap Space Fiber)
    (hreal : ∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3,
      star (f x j) = f x j) :
    FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate (f.toLp 2 volume)) := by
  have hFour : (FourierTransform.fourier (f.toLp 2 volume) : Field) =
      (FourierTransform.fourier f).toLp 2 volume := by
    rw [SchwartzMap.toLp_fourier_eq]
  have hcoord := FrontierDomainLinear.fourierCoordinate_ae (f.toLp 2 volume)
  rw [hFour] at hcoord
  have hf := (FourierTransform.fourier f).coeFn_toLp 2 volume
  have hcoordSeed := HelicalCoordinateBridge.toLp_preserves_volume.quasiMeasurePreserving.ae_eq_comp hf
  have hcoordSeed' : ∀ᵐ ξ ∂(volume : Measure Frequency),
      ((FourierTransform.fourier f).toLp 2 volume : Field) (WithLp.toLp 2 ξ) =
        (FourierTransform.fourier f) (WithLp.toLp 2 ξ) := by
    filter_upwards [hcoordSeed] with ξ hξ
    exact hξ
  have hn := FrontierVolumeSymmetry.volume_reflectsAE _ hcoord
  have hnSeed := FrontierVolumeSymmetry.volume_reflectsAE _ hcoordSeed'
  filter_upwards [hcoord, hn, hcoordSeed', hnSeed] with ξ hξ hneg hs hsneg
  intro j
  rw [hneg, hξ, hsneg, hs]
  have hv := FrontierRealVectorFourierSeed.fourier_real_vector_conjugate
    f f.integrable hreal (WithLp.toLp 2 ξ) j
  have hnegCoord : WithLp.toLp 2 (-ξ) = -(WithLp.toLp 2 ξ : Space) := by
    ext i
    rfl
  rw [hnegCoord]
  simpa only [SchwartzMap.fourier_coe] using hv

/-- Symmetry extends from this explicit real Schwartz seed set to its L² closure. -/
theorem fourier_hermitian_of_real_schwartz_closure
    (u : Field)
    (hu : u ∈ closure {v : Field | ∃ f : SchwartzMap Space Fiber,
      (∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3, star (f x j) = f x j) ∧
      f.toLp 2 volume = v}) :
    FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate u) := by
  apply FrontierHermitianDensity.fourier_hermitian_of_mem_closure _ _ u hu
  intro v hv
  rcases hv with ⟨f, hf, rfl⟩
  exact fourier_hermitian_of_real_schwartz f hf

end FrontierRealSchwartzFourier

#print axioms FrontierRealSchwartzFourier.fourier_hermitian_of_real_schwartz
#print axioms FrontierRealSchwartzFourier.fourier_hermitian_of_real_schwartz_closure
