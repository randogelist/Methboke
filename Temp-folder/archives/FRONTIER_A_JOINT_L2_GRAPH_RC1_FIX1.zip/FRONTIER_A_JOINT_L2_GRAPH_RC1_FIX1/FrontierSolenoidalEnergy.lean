import FrontierAlmostEverywhereDomain
import FrontierDivergenceTraceIdentity

/-! Candidate composition for a supplied trajectory and real L² gradient.
The weak derivative identities, distributional divergence, L²-in-time gradient,
and energy inequality are assumptions. This does not construct a Leray--Hopf
solution or establish any of those assumptions for one. No local Lean run. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierSolenoidalEnergy

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

/-- Under explicit weak-gradient, distributional divergence, and energy
assumptions, a supplied trajectory splits under the two helical projectors
almost everywhere and its projected-gradient Gram integrand has the stated
energy bound. -/
theorem split_and_gram_of_gradient_energy
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → FrontierSpectralOperator.Field)
    (g : τ → FrontierARealGradient.RealMatrix)
    (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : MemLp g 2 η)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂η, ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t)))
    (hdiv : ∀ᵐ t ∂η,
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 0
        (FrontierGradientAdapter.gradientColumn (g t) 0)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 1
        (FrontierGradientAdapter.gradientColumn (g t) 1)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 2
        (FrontierGradientAdapter.gradientColumn (g t) 2)) = 0) :
    (∀ᵐ t ∂η, FrontierPhysicalProjectors.plusProjector (u t) +
      FrontierPhysicalProjectors.minusProjector (u t) = u t) ∧
    (∀ᵐ t ∂η, ∃ v : FrontierSpectralOperator.Domain, v.val = u t) ∧
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierACoordinateEquiv.plusPullback
        (FrontierDissipationDomain.gradientDissipation (g t)))
      (fun t => FrontierACoordinateEquiv.minusPullback
        (FrontierDissipationDomain.gradientDissipation (g t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierACoordinateEquiv.plusPullback
        (FrontierDissipationDomain.gradientDissipation (g t)))
      (fun t => FrontierACoordinateEquiv.minusPullback
        (FrontierDissipationDomain.gradientDissipation (g t))) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  constructor
  · filter_upwards [hweak, hdiv] with t ht hd
    exact FrontierDivergenceTraceIdentity.split_of_distributional_divergence_zero
      (u t) (FrontierARealGradient.complexifyL2 (g t))
      (fun j => FrontierGradientAdapter.gradientColumn (g t) j) (fun _ => rfl) ht hd
  · exact FrontierAlmostEverywhereDomain.gram_and_domain_from_gradient_energy
      η u g u0 uT nu hnu hg henergy hweak

end FrontierSolenoidalEnergy

#print axioms FrontierSolenoidalEnergy.split_and_gram_of_gradient_energy
