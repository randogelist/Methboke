import HelicalTransverse

/-!
Candidate finite-dimensional Hilbert-space realization of the two verified
helical matrices. This file concerns a single real unit direction; it does
not construct a frequency-dependent L2 multiplier or a PDE solution.

No local compiler was run. Every declaration requires native compilation and
theorem-level axiom auditing.
-/

noncomputable section

namespace FeffermanHelicalOrthogonal

open FeffermanHelicalGeneral

abbrev Fiber := EuclideanSpace ℂ (Fin 3)

def plusMap (x y z : ℝ) : Fiber →ₗ[ℂ] Fiber :=
  Matrix.toEuclideanLin (positive x y z)

def minusMap (x y z : ℝ) : Fiber →ₗ[ℂ] Fiber :=
  Matrix.toEuclideanLin (negative x y z)

theorem plus_matrix_hermitian (x y z : ℝ) :
    (positive x y z).IsHermitian :=
  Matrix.IsHermitian.ext (positive_hermitian x y z)

theorem minus_matrix_hermitian (x y z : ℝ) :
    (negative x y z).IsHermitian :=
  Matrix.IsHermitian.ext (negative_hermitian x y z)

theorem plus_symmetric (x y z : ℝ) : (plusMap x y z).IsSymmetric := by
  exact Matrix.isSymmetric_toEuclideanLin_iff.mpr (plus_matrix_hermitian x y z)

theorem minus_symmetric (x y z : ℝ) : (minusMap x y z).IsSymmetric := by
  exact Matrix.isSymmetric_toEuclideanLin_iff.mpr (minus_matrix_hermitian x y z)

theorem plus_map_idempotent (x y z : ℝ)
    (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fiber) :
    plusMap x y z (plusMap x y z v) = plusMap x y z v := by
  have hm := congrArg
    (fun M : Matrix (Fin 3) (Fin 3) ℂ => Matrix.toEuclideanLin M)
    (positive_idempotent x y z h)
  have hv := congrArg (fun F : Fiber →ₗ[ℂ] Fiber => F v) hm
  simpa only [Matrix.toLpLin_mul_same, LinearMap.comp_apply, plusMap,
    Matrix.toEuclideanLin] using hv

theorem minus_map_idempotent (x y z : ℝ)
    (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fiber) :
    minusMap x y z (minusMap x y z v) = minusMap x y z v := by
  have hm := congrArg
    (fun M : Matrix (Fin 3) (Fin 3) ℂ => Matrix.toEuclideanLin M)
    (negative_idempotent x y z h)
  have hv := congrArg (fun F : Fiber →ₗ[ℂ] Fiber => F v) hm
  simpa only [Matrix.toLpLin_mul_same, LinearMap.comp_apply, minusMap,
    Matrix.toEuclideanLin] using hv

theorem plus_after_minus_zero (x y z : ℝ)
    (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fiber) :
    plusMap x y z (minusMap x y z v) = 0 := by
  have hm := congrArg
    (fun M : Matrix (Fin 3) (Fin 3) ℂ => Matrix.toEuclideanLin M)
    (helicity_cross_zero x y z h)
  have hv := congrArg (fun F : Fiber →ₗ[ℂ] Fiber => F v) hm
  simpa only [Matrix.toLpLin_mul_same, LinearMap.comp_apply, map_zero,
    LinearMap.zero_apply, plusMap, minusMap, Matrix.toEuclideanLin] using hv

/-- The two sectors have zero complex inner product, even when their
    input vectors differ. -/
theorem helical_sectors_orthogonal (x y z : ℝ)
    (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v w : Fiber) :
    inner ℂ (plusMap x y z v) (minusMap x y z w) = 0 := by
  calc
    inner ℂ (plusMap x y z v) (minusMap x y z w) =
        inner ℂ (plusMap x y z (plusMap x y z v)) (minusMap x y z w) := by
          rw [plus_map_idempotent x y z h v]
    _ = inner ℂ (plusMap x y z v) (plusMap x y z (minusMap x y z w)) :=
      plus_symmetric x y z _ _
    _ = 0 := by rw [plus_after_minus_zero x y z h w]; simp

/-- A symmetric idempotent complex linear map is contractive. -/
private theorem symmetric_idempotent_norm_le {E : Type*}
    [NormedAddCommGroup E] [InnerProductSpace ℂ E]
    (P : E →ₗ[ℂ] E) (hsym : P.IsSymmetric)
    (hid : ∀ v, P (P v) = P v) (v : E) : ‖P v‖ ≤ ‖v‖ := by
  have ho : inner ℂ (P v) (v - P v) = 0 := by
    have hh : inner ℂ (P v) v = inner ℂ (P v) (P v) := by
      simpa only [hid] using hsym (P v) v
    rw [inner_sub_right, hh, sub_self]
  have ha : P v + (v - P v) = v := by abel
  have hn := norm_add_sq (𝕜 := ℂ) (P v) (v - P v)
  rw [ha, ho] at hn
  simp only [RCLike.zero_re, map_zero, mul_zero, add_zero] at hn
  have hnonneg := sq_nonneg ‖v - P v‖
  have hp := norm_nonneg (P v)
  have hv := norm_nonneg v
  nlinarith

theorem plus_contractive (x y z : ℝ)
    (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fiber) :
    ‖plusMap x y z v‖ ≤ ‖v‖ :=
  symmetric_idempotent_norm_le (plusMap x y z) (plus_symmetric x y z)
    (plus_map_idempotent x y z h) v

theorem minus_contractive (x y z : ℝ)
    (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fiber) :
    ‖minusMap x y z v‖ ≤ ‖v‖ :=
  symmetric_idempotent_norm_le (minusMap x y z) (minus_symmetric x y z)
    (minus_map_idempotent x y z h) v

end FeffermanHelicalOrthogonal

#print axioms FeffermanHelicalOrthogonal.plus_matrix_hermitian
#print axioms FeffermanHelicalOrthogonal.minus_matrix_hermitian
#print axioms FeffermanHelicalOrthogonal.plus_symmetric
#print axioms FeffermanHelicalOrthogonal.minus_symmetric
#print axioms FeffermanHelicalOrthogonal.plus_map_idempotent
#print axioms FeffermanHelicalOrthogonal.minus_map_idempotent
#print axioms FeffermanHelicalOrthogonal.plus_after_minus_zero
#print axioms FeffermanHelicalOrthogonal.helical_sectors_orthogonal
#print axioms FeffermanHelicalOrthogonal.plus_contractive
#print axioms FeffermanHelicalOrthogonal.minus_contractive
