import HelicalConcreteSymbol
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace

/-!
Candidate measure-preserving coordinate transport between Euclidean R3 and
Fin 3 -> R. This is independent of any Fourier or physical realization.
The declared L2 maps use product volume on coordinates and Euclidean volume.
External native Lean compilation and theorem-level axiom audit are required.
-/
noncomputable section
open MeasureTheory
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace HelicalCoordinateBridge

abbrev Space := EuclideanSpace ℝ (Fin 3)
abbrev EuclideanL2 := Lp Fiber 2 (volume : Measure Space)
abbrev CoordinateL2 := Lp Fiber 2 (volume : Measure Frequency)

theorem toLp_preserves_volume :
    MeasurePreserving (WithLp.toLp 2 : Frequency → Space)
      (volume : Measure Frequency) (volume : Measure Space) :=
  PiLp.volume_preserving_toLp (Fin 3)

theorem ofLp_preserves_volume :
    MeasurePreserving (WithLp.ofLp : Space → Frequency)
      (volume : Measure Space) (volume : Measure Frequency) :=
  PiLp.volume_preserving_ofLp (Fin 3)

/-- Pull back Euclidean-frequency fields to coordinate-frequency fields. -/
def toCoordinates : EuclideanL2 →ₗᵢ[ℂ] CoordinateL2 :=
  Lp.compMeasurePreservingₗᵢ ℂ (WithLp.toLp 2) toLp_preserves_volume

/-- Pull back coordinate-frequency fields to Euclidean-frequency fields. -/
def toEuclidean : CoordinateL2 →ₗᵢ[ℂ] EuclideanL2 :=
  Lp.compMeasurePreservingₗᵢ ℂ WithLp.ofLp ofLp_preserves_volume

theorem toCoordinates_norm (f : EuclideanL2) : ‖toCoordinates f‖ = ‖f‖ :=
  toCoordinates.norm_map f

theorem toEuclidean_norm (f : CoordinateL2) : ‖toEuclidean f‖ = ‖f‖ :=
  toEuclidean.norm_map f

theorem toCoordinates_ae (f : EuclideanL2) :
    ((toCoordinates f : CoordinateL2) : Frequency → Fiber) =ᵐ[volume]
      (fun ξ => (f : Space → Fiber) (WithLp.toLp 2 ξ)) := by
  change ((Lp.compMeasurePreserving (WithLp.toLp 2) toLp_preserves_volume f : CoordinateL2) : Frequency → Fiber) =ᵐ[volume] _
  simpa only [Function.comp_def] using Lp.coeFn_compMeasurePreserving f toLp_preserves_volume

theorem toEuclidean_ae (f : CoordinateL2) :
    ((toEuclidean f : EuclideanL2) : Space → Fiber) =ᵐ[volume]
      (fun ξ => (f : Frequency → Fiber) (WithLp.ofLp ξ)) := by
  change ((Lp.compMeasurePreserving WithLp.ofLp ofLp_preserves_volume f : EuclideanL2) : Space → Fiber) =ᵐ[volume] _
  simpa only [Function.comp_def] using Lp.coeFn_compMeasurePreserving f ofLp_preserves_volume

end HelicalCoordinateBridge

#print axioms HelicalCoordinateBridge.toLp_preserves_volume
#print axioms HelicalCoordinateBridge.ofLp_preserves_volume
#print axioms HelicalCoordinateBridge.toCoordinates_norm
#print axioms HelicalCoordinateBridge.toEuclidean_norm
#print axioms HelicalCoordinateBridge.toCoordinates_ae
#print axioms HelicalCoordinateBridge.toEuclidean_ae
