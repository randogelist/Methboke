import HelicalBessel
import HelicalCoordinateBridge
import HelicalR3Plancherel

/-!
Concrete Fourier-coordinate frequency Gram bound, A-TIER CANDIDATE.

This is a theorem about a supplied complex vector L2 trajectory. The Fourier
transform is Mathlib's L2 transform and the frequency-coordinate transfer is
the previously constructed measure-preserving map. No Leray--Hopf solution,
physical real-field identification, physical helical projectors, Sobolev
energy identity, or differentiation normalization is defined or discharged
here. In particular the conclusion is a frequency-space Gram integrand, not
the frozen physical Frontier_A endpoint. No transversality premise is used.
External compilation, signature inspection and axiom audit are required.
-/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierAConcreteFourier

abbrev ComplexField := HelicalR3Plancherel.ComplexField
abbrev CoordinateL2 := HelicalCoordinateBridge.CoordinateL2

def coordinateFourier (f : ComplexField) : CoordinateL2 :=
  HelicalCoordinateBridge.toCoordinates (HelicalR3Plancherel.fourierComplex f)

theorem coordinateFourier_norm (f : ComplexField) :
    ‖coordinateFourier f‖ = ‖f‖ := by
  rw [coordinateFourier, HelicalCoordinateBridge.toCoordinates_norm]
  exact HelicalR3Plancherel.fourierComplex.norm_map f

local instance realL2 (μ : Measure Frequency) : InnerProductSpace ℝ (Lp Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp Fiber 2 μ)

/-- A frequency-space result for a supplied complex trajectory with its own
    time-L2 and energy-budget assumptions. -/
theorem fourier_coordinate_gram_bound
    {τ : Type*} [MeasurableSpace τ] (η : Measure τ)
    [MeasurableSpace ComplexField] [BorelSpace ComplexField]
    [MeasurableSpace CoordinateL2] [BorelSpace CoordinateL2]
    (x : τ → ComplexField) (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hx : MemLp x 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖x t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier (volume : Measure Frequency) (coordinateFourier (x t)))
      (fun t => minusMultiplier (volume : Measure Frequency) (coordinateFourier (x t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier (volume : Measure Frequency) (coordinateFourier (x t)))
      (fun t => minusMultiplier (volume : Measure Frequency) (coordinateFourier (x t)))
      ≤ initialEnergy / (4 * nu) := by
  have hf : MemLp (fun t => HelicalR3Plancherel.fourierComplex (x t)) 2 η := by
    simpa [Function.comp_def] using
      HelicalR3Plancherel.fourierComplex.toLinearIsometry.toContinuousLinearMap.comp_memLp' hx
  have hz : MemLp (fun t => coordinateFourier (x t)) 2 η := by
    simpa [Function.comp_def, coordinateFourier] using
      HelicalCoordinateBridge.toCoordinates.toContinuousLinearMap.comp_memLp' hf
  have hbudget : 2 * nu * (∫ t, ‖coordinateFourier (x t)‖ ^ 2 ∂η) ≤ initialEnergy := by
    simpa only [coordinateFourier_norm] using hEnergy
  exact HelicalBessel.gram_bound_from_full_energy (volume : Measure Frequency) η
    (fun t => coordinateFourier (x t)) nu initialEnergy hnu hz hbudget

end FrontierAConcreteFourier

#print axioms FrontierAConcreteFourier.coordinateFourier_norm
#print axioms FrontierAConcreteFourier.fourier_coordinate_gram_bound
