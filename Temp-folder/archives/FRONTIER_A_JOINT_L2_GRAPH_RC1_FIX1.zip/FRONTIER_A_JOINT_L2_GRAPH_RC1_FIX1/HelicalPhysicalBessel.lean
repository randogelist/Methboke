import HelicalPhysicalEnergy
import HelicalBessel

/-! A-tier candidate: transport the Bessel estimate through a supplied real
linear isometric equivalence. No transversality is required. No actual Fourier
map, physical solution or Leray-Hopf dissipation is constructed. External
compilation, signature inspection and theorem-level audit are required. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal
namespace HelicalPhysicalBessel

local instance (priority := 10000) realL2 (μ : Measure Frequency) :
    InnerProductSpace ℝ (Lp Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp Fiber 2 μ)
local instance (priority := 10000) realL2Module (μ : Measure Frequency) :
    Module ℝ (Lp Fiber 2 μ) := (realL2 μ).toModule

/-- The supplied isometric pullbacks satisfy the energy Gram bound. -/
theorem physical_gram_from_full_energy
    {E τ : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [MeasurableSpace τ] (μ : Measure Frequency) (η : Measure τ)
    [MeasurableSpace (Lp Fiber 2 μ)] [BorelSpace (Lp Fiber 2 μ)]
    (U : E ≃ₗᵢ[ℝ] Lp Fiber 2 μ) (x : τ → E) (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hz : MemLp (fun t => U (x t)) 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖x t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => U.symm (plusMultiplier μ (U (x t))))
      (fun t => U.symm (minusMultiplier μ (U (x t))))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => U.symm (plusMultiplier μ (U (x t))))
      (fun t => U.symm (minusMultiplier μ (U (x t))))
      ≤ initialEnergy / (4 * nu) := by
  have hbudget : 2 * nu * (∫ t, ‖U (x t)‖ ^ 2 ∂η) ≤ initialEnergy := by
    simpa only [U.norm_map] using hEnergy
  have h := HelicalBessel.gram_bound_from_full_energy
    μ η (fun t => U (x t)) nu initialEnergy hnu hz hbudget
  have heq := @HelicalPhysicalEnergy.gramSqrt_isometry (Lp Fiber 2 μ) E τ
    _ (realL2 μ) _ ‹InnerProductSpace ℝ E› U.symm
    (fun t => plusMultiplier μ (U (x t)))
    (fun t => minusMultiplier μ (U (x t)))
  have hpoint (t : τ) := congrFun heq t
  constructor
  · simpa only [heq] using h.1
  · unfold FeffermanAHopfGramIntegral.gramSqrtIntegral at h ⊢
    simpa only [hpoint] using h.2

end HelicalPhysicalBessel
#print axioms HelicalPhysicalBessel.physical_gram_from_full_energy
