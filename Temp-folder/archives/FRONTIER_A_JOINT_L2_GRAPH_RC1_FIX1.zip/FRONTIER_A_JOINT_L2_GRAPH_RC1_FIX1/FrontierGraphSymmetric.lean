import FrontierProjectedDissipation

/-! Symmetry of the Fourier graph operator on its explicit graph domain.
This does not prove self-adjointness, density or maximality, and it does not
identify the independent Stokes square root. No local Lean run. -/
noncomputable section
open MeasureTheory Filter FourierTransform
namespace FrontierGraphSymmetric

abbrev Domain := FrontierSpectralOperator.Domain
abbrev Frequency := FrontierSpectralOperator.Frequency
abbrev Fiber := FrontierSpectralOperator.Fiber

/-- The project graph operator is symmetric, since its Fourier multiplier
is real-valued. The arguments must both lie in its explicit graph domain. -/
theorem dissipation_symmetric (u v : Domain) :
    inner ℂ (FrontierSpectralOperator.dissipation u) v.val =
      inner ℂ u.val (FrontierSpectralOperator.dissipation v) := by
  have hAu := FrontierSpectralOperator.dissipation_fourier u
  have hAv := FrontierSpectralOperator.dissipation_fourier v
  have hu := FrontierDomainLinear.fourierCoordinate_ae u.val
  have hv := FrontierDomainLinear.fourierCoordinate_ae v.val
  change (FrontierACoordinateEquiv.fourierCoordinate
      (FrontierSpectralOperator.dissipation u) : Frequency → Fiber) =ᵐ[volume] _ at hAu
  change (FrontierACoordinateEquiv.fourierCoordinate
      (FrontierSpectralOperator.dissipation v) : Frequency → Fiber) =ᵐ[volume] _ at hAv
  calc
    _ = inner ℂ (FrontierACoordinateEquiv.fourierCoordinate
          (FrontierSpectralOperator.dissipation u))
        (FrontierACoordinateEquiv.fourierCoordinate v.val) :=
      (FrontierACoordinateEquiv.fourierCoordinate.inner_map_map _ _).symm
    _ = inner ℂ (FrontierACoordinateEquiv.fourierCoordinate u.val)
        (FrontierACoordinateEquiv.fourierCoordinate
          (FrontierSpectralOperator.dissipation v)) := by
      rw [MeasureTheory.L2.inner_def, MeasureTheory.L2.inner_def]
      apply integral_congr_ae
      filter_upwards [hAu, hAv, hu, hv] with ξ hAu hAv hu hv
      rw [hAu, hAv, FrontierProjectedDissipation.velocitySymbol_eq_weight,
        FrontierProjectedDissipation.velocitySymbol_eq_weight, ← hu, ← hv]
      simp [inner_smul_left, inner_smul_right, FrontierProjectedDissipation.weight] <;>
        norm_num [map_ofNat]
    _ = _ := FrontierACoordinateEquiv.fourierCoordinate.inner_map_map _ _

end FrontierGraphSymmetric
#print axioms FrontierGraphSymmetric.dissipation_symmetric
