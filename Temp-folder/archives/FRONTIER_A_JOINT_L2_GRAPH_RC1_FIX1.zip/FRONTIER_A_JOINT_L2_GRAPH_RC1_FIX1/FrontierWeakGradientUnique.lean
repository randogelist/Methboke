import FrontierWeakGradientSubspace

/-! Uniqueness of a supplied real L² weak gradient: equality of the three
associated distributions gives equality of their L² columns, and the columns
recover all real matrix entries. This is a spatial result only; it does not
construct a Leray–Hopf trajectory or prove a time-slicing theorem.
No local Lean run. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierWeakGradientUnique

abbrev Space := FrontierWeakGradientClosed.Space
abbrev Fiber := FrontierWeakGradientClosed.Fiber
abbrev Field := FrontierAWeakRieszBridge.Field
abbrev RealFiber := FrontierARealGradient.RealFiber
abbrev Gradient := FrontierARealGradient.RealMatrix

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩

/-- Equality of one complex column implies equality of the corresponding real
matrix entries for almost every spatial point. -/
theorem entries_ae_of_column_eq (g h : Gradient) (j : Fin 3)
    (hcol : FrontierGradientAdapter.gradientColumn g j =
      FrontierGradientAdapter.gradientColumn h j) :
    ∀ᵐ x ∂(volume : Measure Space), ∀ i : Fin 3,
      (g : Space → RealFiber) x (i, j) = (h : Space → RealFiber) x (i, j) := by
  have ha := FrontierAWeakMatrixColumns.columnL2_ae j
    (FrontierARealGradient.complexifyL2 g)
  have hb := FrontierAWeakMatrixColumns.columnL2_ae j
    (FrontierARealGradient.complexifyL2 h)
  change ((FrontierGradientAdapter.gradientColumn g j : Field) : Space → Fiber) =ᵐ[volume] _ at ha
  change ((FrontierGradientAdapter.gradientColumn h j : Field) : Space → Fiber) =ᵐ[volume] _ at hb
  rw [hcol] at ha
  have hg := FrontierARealGradient.complexifyL2_ae g
  have hh := FrontierARealGradient.complexifyL2_ae h
  filter_upwards [ha, hb, hg, hh] with x ha hb hg hh
  intro i
  have he := congrArg (fun v : Fiber => v i) (ha.symm.trans hb)
  simp only [FrontierAWeakMatrixColumns.columnCLM_apply] at he
  rw [hg, hh] at he
  change (((g : Space → RealFiber) x (i, j) : ℝ) : ℂ) =
    (((h : Space → RealFiber) x (i, j) : ℝ) : ℂ) at he
  exact_mod_cast he

/-- All three complex columns determine the original real L² matrix. -/
theorem matrix_eq_of_column_eq (g h : Gradient)
    (hcol : ∀ j, FrontierGradientAdapter.gradientColumn g j =
      FrontierGradientAdapter.gradientColumn h j) : g = h := by
  have h0 := entries_ae_of_column_eq g h 0 (hcol 0)
  have h1 := entries_ae_of_column_eq g h 1 (hcol 1)
  have h2 := entries_ae_of_column_eq g h 2 (hcol 2)
  apply Lp.ext
  filter_upwards [h0, h1, h2] with x h0 h1 h2
  ext k
  rcases k with ⟨i, j⟩
  fin_cases j
  · exact h0 i
  · exact h1 i
  · exact h2 i

/-- For one supplied velocity, two weak-gradient witnesses coincide. -/
theorem weak_gradient_unique (u : Field) (g h : Gradient)
    (hg : FrontierAEProjectedGraphEnergy.WeakAt u g)
    (hh : FrontierAEProjectedGraphEnergy.WeakAt u h) : g = h := by
  apply matrix_eq_of_column_eq
  intro j
  have hinj : Function.Injective
      (Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2) := by
    apply LinearMap.ker_eq_bot.mp
    exact Lp.ker_toTemperedDistributionCLM_eq_bot
  apply hinj
  exact (hg j).trans (hh j).symm

/-- The first projection is injective on the weak-gradient graph. -/
theorem first_projection_injective (p q : FrontierWeakGradientSubspace.graph)
    (h : p.val.1 = q.val.1) : p = q := by
  apply Subtype.ext
  apply Prod.ext h
  have hp := (FrontierWeakGradientSubspace.mem_graph_iff p.val).1 p.property
  have hq := (FrontierWeakGradientSubspace.mem_graph_iff q.val).1 q.property
  rw [h] at hp
  exact weak_gradient_unique (FrontierRealVelocityEmbedding.complexifyL2 q.val.1)
    p.val.2 q.val.2 hp hq

end FrontierWeakGradientUnique

#print axioms FrontierWeakGradientUnique.entries_ae_of_column_eq
#print axioms FrontierWeakGradientUnique.matrix_eq_of_column_eq
#print axioms FrontierWeakGradientUnique.weak_gradient_unique
#print axioms FrontierWeakGradientUnique.first_projection_injective
