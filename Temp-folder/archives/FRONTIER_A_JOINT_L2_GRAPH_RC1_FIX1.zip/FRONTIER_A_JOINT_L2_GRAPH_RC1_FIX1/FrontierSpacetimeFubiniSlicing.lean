import FrontierSeparatedWeakSlicing
import FrontierSlicingEnergyClass
import Mathlib.MeasureTheory.Integral.Prod

/-! Fubini bridge to the audited separated-test slicing theorem. The joint
residual density is supplied along with (1) its L1 product-test integrability,
(2) a.e. spatial-integral identification with the project's tempered residual,
and (3) vanishing of its spacetime product tests. These are explicit premises:
this file does not construct Bochner L2 sections from spacetime fields, prove
the marginal identification, or derive joint integrability from energy-class
data. No Lean compiler was run locally. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierSpacetimeFubiniSlicing

abbrev Space := FrontierSeparatedWeakSlicing.Space
abbrev Fiber := FrontierSeparatedWeakSlicing.Fiber
abbrev RealVelocity := FrontierSeparatedWeakSlicing.RealVelocity
abbrev Gradient := FrontierSeparatedWeakSlicing.Gradient
abbrev SpatialTest := SchwartzMap Space ℂ
abbrev JointResidual := Fin 3 → SpatialTest → (ℝ × Space) → Fiber

/-- Fubini passes actual spacetime product-integral identities to the separated
residual equations, provided the spatial integral of the supplied joint
density is identified with the project's distributional residual. -/
theorem separated_tests_of_joint_integrals
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (μ : Measure ℝ) [SFinite μ]
    (R : JointResidual)
    (hrep : ∀ (j : Fin 3) (ψ : SpatialTest),
      ∀ᵐ t ∂μ, (∫ x, R j ψ (t, x) ∂(volume : Measure Space)) =
        (FrontierWeakGradientSubspace.residual j (u t, g t)) ψ)
    (hint : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SpatialTest),
        Integrable (fun tx => φ tx.1 • R j ψ tx)
          (μ.prod (volume : Measure Space)))
    (hweak : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SpatialTest),
        (∫ tx, φ tx.1 • R j ψ tx ∂(μ.prod (volume : Measure Space))) = 0) :
    ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SpatialTest),
        (∫ t, φ t • ((FrontierWeakGradientSubspace.residual j (u t, g t)) ψ) ∂μ) = 0 := by
  intro φ hφ hφc j ψ
  calc
    (∫ t, φ t • ((FrontierWeakGradientSubspace.residual j (u t, g t)) ψ) ∂μ) =
        ∫ t, ∫ x, φ t • R j ψ (t, x) ∂(volume : Measure Space) ∂μ := by
      apply integral_congr_ae
      filter_upwards [hrep j ψ] with t ht
      rw [integral_smul, ht]
    _ = ∫ tx, φ tx.1 • R j ψ tx ∂(μ.prod (volume : Measure Space)) := by
      exact (integral_prod (fun tx => φ tx.1 • R j ψ tx) (hint φ hφ hφc j ψ)).symm
    _ = 0 := hweak φ hφ hφc j ψ

/-- The product-integral weak identities yield a.e. weak gradients when the
existing local Bochner integrability condition is available. -/
theorem weak_at_ae_of_joint_integrals
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (μ : Measure ℝ) [SFinite μ]
    (hlocal : LocallyIntegrable (fun t => (u t, g t)) μ)
    (R : JointResidual)
    (hrep : ∀ (j : Fin 3) (ψ : SpatialTest),
      ∀ᵐ t ∂μ, (∫ x, R j ψ (t, x) ∂(volume : Measure Space)) =
        (FrontierWeakGradientSubspace.residual j (u t, g t)) ψ)
    (hint : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SpatialTest),
        Integrable (fun tx => φ tx.1 • R j ψ tx) (μ.prod (volume : Measure Space)))
    (hweak : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SpatialTest),
        (∫ tx, φ tx.1 • R j ψ tx ∂(μ.prod (volume : Measure Space))) = 0) :
    ∀ᵐ t ∂μ, FrontierAEProjectedGraphEnergy.WeakAt
      (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t) := by
  exact FrontierSeparatedWeakSlicing.weak_at_ae_of_separated_tests u g μ hlocal
    (separated_tests_of_joint_integrals u g μ R hrep hint hweak)

/-- The same spacetime-to-slice implication with separate velocity/gradient
energy-class assumptions in place of an independent local pair-integrability
hypothesis. The joint-density premises still need physical construction. -/
theorem weak_at_ae_of_energy_and_joint_integrals
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (μ : Measure ℝ)
    [SFinite μ] [IsLocallyFiniteMeasure μ]
    (hu : MemLp u (⊤ : ENNReal) μ) (hg : MemLp g 2 μ)
    (R : JointResidual)
    (hrep : ∀ (j : Fin 3) (ψ : SpatialTest),
      ∀ᵐ t ∂μ, (∫ x, R j ψ (t, x) ∂(volume : Measure Space)) =
        (FrontierWeakGradientSubspace.residual j (u t, g t)) ψ)
    (hint : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SpatialTest),
        Integrable (fun tx => φ tx.1 • R j ψ tx) (μ.prod (volume : Measure Space)))
    (hweak : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SpatialTest),
        (∫ tx, φ tx.1 • R j ψ tx ∂(μ.prod (volume : Measure Space))) = 0) :
    ∀ᵐ t ∂μ, FrontierAEProjectedGraphEnergy.WeakAt
      (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t) := by
  have hlocal : LocallyIntegrable (fun t => (u t, g t)) μ :=
    FrontierSlicingEnergyClass.pair_locallyIntegrable_of_memLp
      u g μ ⊤ 2 (by simp) (by norm_num) hu hg
  exact weak_at_ae_of_joint_integrals u g μ hlocal R hrep hint hweak

end FrontierSpacetimeFubiniSlicing

#print axioms FrontierSpacetimeFubiniSlicing.separated_tests_of_joint_integrals
#print axioms FrontierSpacetimeFubiniSlicing.weak_at_ae_of_joint_integrals
#print axioms FrontierSpacetimeFubiniSlicing.weak_at_ae_of_energy_and_joint_integrals
