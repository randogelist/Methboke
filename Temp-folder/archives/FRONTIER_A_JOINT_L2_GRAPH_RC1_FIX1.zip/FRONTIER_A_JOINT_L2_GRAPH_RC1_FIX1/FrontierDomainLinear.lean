import FrontierSpectralClosure

/-! Candidate algebra of the Fourier graph domain. The construction remains
separate from independent Stokes and Leray--Hopf semantic identifications.
No Lean compiler was executed locally. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierDomainLinear
abbrev Field := FrontierSpectralOperator.Field
abbrev Frequency := FrontierSpectralOperator.Frequency
abbrev Fiber := FrontierSpectralOperator.Fiber
abbrev PhysicalL2 := FrontierSpectralOperator.PhysicalL2
abbrev Domain := FrontierSpectralOperator.Domain

/-- A common representative for the coordinate Fourier isometry. -/
theorem fourierCoordinate_ae (u : Field) :
    (FrontierACoordinateEquiv.fourierCoordinate u : Frequency → Fiber) =ᵐ[volume]
      fun ξ => (FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ) := by
  change ((HelicalCoordinateBridge.toCoordinates (FourierTransform.fourier u : Field) :
    HelicalCoordinateBridge.CoordinateL2) : Frequency → Fiber) =ᵐ[volume] _
  exact HelicalCoordinateBridge.toCoordinates_ae (FourierTransform.fourier u : Field)

/-- The velocity symbols are additive up to the natural L² null set. -/
theorem velocitySymbol_add (u v : Field) :
    FrontierMultiplierBridge.velocitySymbol (u + v) =ᵐ[volume]
      fun ξ => FrontierMultiplierBridge.velocitySymbol u ξ +
        FrontierMultiplierBridge.velocitySymbol v ξ := by
  have ha := Lp.coeFn_add (FrontierACoordinateEquiv.fourierCoordinate u)
    (FrontierACoordinateEquiv.fourierCoordinate v)
  have hlin : FrontierACoordinateEquiv.fourierCoordinate (u + v) =
      FrontierACoordinateEquiv.fourierCoordinate u + FrontierACoordinateEquiv.fourierCoordinate v :=
    (FrontierACoordinateEquiv.fourierCoordinate.map_add u v)
  have hsum := fourierCoordinate_ae (u + v)
  rw [hlin] at hsum
  filter_upwards [hsum, ha, fourierCoordinate_ae u, fourierCoordinate_ae v] with ξ hs ha hu hv
  ext i
  have he := congrArg (fun x : Fiber => x i) (hs.symm.trans (ha.trans (congrArg₂ (· + ·) hu hv)))
  simp only [FrontierMultiplierBridge.velocitySymbol, PiLp.add_apply]
  simp only [PiLp.add_apply] at he
  rw [he]
  ring

/-- The velocity symbol commutes with complex scalar multiplication a.e. -/
theorem velocitySymbol_smul (c : ℂ) (u : Field) :
    FrontierMultiplierBridge.velocitySymbol (c • u) =ᵐ[volume]
      fun ξ => c • FrontierMultiplierBridge.velocitySymbol u ξ := by
  have ha := Lp.coeFn_smul c (FrontierACoordinateEquiv.fourierCoordinate u)
  have hlin : FrontierACoordinateEquiv.fourierCoordinate (c • u) =
      c • FrontierACoordinateEquiv.fourierCoordinate u :=
    (FrontierACoordinateEquiv.fourierCoordinate.map_smul c u)
  have hsum := fourierCoordinate_ae (c • u)
  rw [hlin] at hsum
  filter_upwards [hsum, ha, fourierCoordinate_ae u] with ξ hs ha hu
  ext i
  have he := congrArg (fun x : Fiber => x i) (hs.symm.trans (ha.trans (congrArg (fun x : Fiber => c • x) hu)))
  simp only [FrontierMultiplierBridge.velocitySymbol, PiLp.smul_apply,
    smul_eq_mul]
  simp only [PiLp.smul_apply, smul_eq_mul] at he
  rw [he]
  ring


/-- Addition preserves the explicit graph domain. -/
theorem has_add (u v : Field)
    (hu : FrontierDissipationDomain.HasDissipationSymbol u)
    (hv : FrontierDissipationDomain.HasDissipationSymbol v) :
    FrontierDissipationDomain.HasDissipationSymbol (u + v) := by
  obtain ⟨a, ha⟩ := hu
  obtain ⟨b, hb⟩ := hv
  refine ⟨a + b, ?_⟩
  have hc := Lp.coeFn_add (FrontierPhysicalGramTransport.fourierCoordinateReal a)
    (FrontierPhysicalGramTransport.fourierCoordinateReal b)
  have he : FrontierPhysicalGramTransport.fourierCoordinateReal (a + b) =
      FrontierPhysicalGramTransport.fourierCoordinateReal a +
      FrontierPhysicalGramTransport.fourierCoordinateReal b := by simp
  rw [he]
  filter_upwards [ha, hb, hc, velocitySymbol_add u v] with ξ ha hb hc hs
  rw [hc]
  simp only [Pi.add_apply, ha, hb, hs]

/-- Scalar multiplication preserves the explicit graph domain. -/
theorem has_smul (c : ℂ) (u : Field)
    (hu : FrontierDissipationDomain.HasDissipationSymbol u) :
    FrontierDissipationDomain.HasDissipationSymbol (c • u) := by
  obtain ⟨a, ha⟩ := hu
  refine ⟨c • a, ?_⟩
  have hc := Lp.coeFn_smul c (FrontierACoordinateEquiv.fourierCoordinate a)
  change (FrontierACoordinateEquiv.fourierCoordinate (c • a) : Frequency → Fiber) =ᵐ[volume] _
  rw [map_smul]
  filter_upwards [ha, hc, velocitySymbol_smul c u] with ξ ha hc hs
  change (FrontierACoordinateEquiv.fourierCoordinate a : Frequency → Fiber) ξ = _ at ha
  rw [hc]
  simp only [Pi.smul_apply, ha, hs]

/-- Additive graph-domain operation. -/
def add (u v : Domain) : Domain := ⟨u.val + v.val, has_add u.val v.val u.property v.property⟩
/-- Complex scalar graph-domain operation. -/
def smul (c : ℂ) (u : Domain) : Domain := ⟨c • u.val, has_smul c u.val u.property⟩

/-- The unique spectral representative is additive. -/
theorem dissipation_add (u v : Domain) :
    FrontierSpectralOperator.dissipation (add u v) =
      FrontierSpectralOperator.dissipation u + FrontierSpectralOperator.dissipation v := by
  apply FrontierSpectralOperator.dissipation_eq_of_symbol
  have ha := FrontierSpectralOperator.dissipation_fourier u
  have hb := FrontierSpectralOperator.dissipation_fourier v
  have hc := Lp.coeFn_add
    (FrontierPhysicalGramTransport.fourierCoordinateReal (FrontierSpectralOperator.dissipation u))
    (FrontierPhysicalGramTransport.fourierCoordinateReal (FrontierSpectralOperator.dissipation v))
  rw [map_add]
  filter_upwards [ha, hb, hc, velocitySymbol_add u.val v.val] with ξ ha hb hc hs
  change _ = FrontierMultiplierBridge.velocitySymbol (u.val + v.val) ξ
  rw [hc]
  simp only [Pi.add_apply, ha, hb, hs]

/-- The unique spectral representative is complex homogeneous. -/
theorem dissipation_smul (c : ℂ) (u : Domain) :
    FrontierSpectralOperator.dissipation (smul c u) =
      c • FrontierSpectralOperator.dissipation u := by
  apply FrontierSpectralOperator.dissipation_eq_of_symbol
  have ha := FrontierSpectralOperator.dissipation_fourier u
  have hc := Lp.coeFn_smul c (FrontierACoordinateEquiv.fourierCoordinate (FrontierSpectralOperator.dissipation u))
  change (FrontierACoordinateEquiv.fourierCoordinate
    (c • FrontierSpectralOperator.dissipation u) : Frequency → Fiber) =ᵐ[volume] _
  rw [map_smul]
  filter_upwards [ha, hc, velocitySymbol_smul c u.val] with ξ ha hc hs
  change (FrontierACoordinateEquiv.fourierCoordinate (FrontierSpectralOperator.dissipation u) : Frequency → Fiber) ξ = _ at ha
  change _ = FrontierMultiplierBridge.velocitySymbol (c • u.val) ξ
  rw [hc]
  simp only [Pi.smul_apply, ha, hs]

end FrontierDomainLinear

#print axioms FrontierDomainLinear.fourierCoordinate_ae
#print axioms FrontierDomainLinear.velocitySymbol_add
#print axioms FrontierDomainLinear.velocitySymbol_smul
#print axioms FrontierDomainLinear.has_add
#print axioms FrontierDomainLinear.has_smul
#print axioms FrontierDomainLinear.dissipation_add
#print axioms FrontierDomainLinear.dissipation_smul
