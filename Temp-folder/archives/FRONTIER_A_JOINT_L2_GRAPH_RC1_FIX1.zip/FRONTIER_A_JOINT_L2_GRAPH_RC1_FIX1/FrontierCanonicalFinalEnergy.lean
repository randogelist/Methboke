import FrontierPhysicalTransferWithEnergy
import FrontierCanonicalInterface

/-! Final-energy Gram estimate for the project-defined canonical operators.
The time-L² gradient, energy inequality, weak derivative and trace-free
premises are explicit. No independent Stokes/helical operator or standard
Leray--Hopf realization is asserted. No local Lean run. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierCanonicalFinalEnergy

abbrev RealVelocity := FrontierRealSpectralEnergy.RealVelocity
abbrev Gradient := FrontierRealSpectralEnergy.Gradient
abbrev Space := FrontierRealSpectralEnergy.Space
abbrev RealFiber := FrontierRealSpectralEnergy.RealFiber

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

/-- The canonical field identities follow from the weak-gradient and trace
premises, so no separately assumed field-identification equalities are needed.
The remaining assumptions are exactly the real trajectory's analytic data. -/
theorem gram_canonical_with_final_energy
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → RealVelocity) (u0 : RealVelocity) (g : ℝ → Gradient)
    (T nu : ℝ) (hnu : 0 < nu)
    (hg : MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T))
    (henergy : ‖u T‖ ^ 2 + 2 * nu *
      (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      FrontierAEProjectedGraphEnergy.WeakAt (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
    (htrace : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      ∀ᵐ x ∂(volume : Measure Space),
        (g t : Space → RealFiber) x (0, 0) + (g t : Space → RealFiber) x (1, 1) +
          (g t : Space → RealFiber) x (2, 2) = 0) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierSpectralTimeComposition.positiveField FrontierCanonicalInterface.canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField FrontierCanonicalInterface.canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)))
      (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (FrontierFiniteIntervalEnergy.timeMeasure T)
      (fun t => FrontierSpectralTimeComposition.positiveField FrontierCanonicalInterface.canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField FrontierCanonicalInterface.canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)) ≤
          (‖u0‖ ^ 2 - ‖u T‖ ^ 2) / (4 * nu) := by
  have hd := FrontierTimeTraceBridge.divergence_zero_ae_of_real_trace
    (FrontierFiniteIntervalEnergy.timeMeasure T) g htrace
  have hp : (fun t => FrontierSpectralTimeComposition.positiveField FrontierCanonicalInterface.canonical
      (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)) =ᵐ[
        FrontierFiniteIntervalEnergy.timeMeasure T]
      (fun t => FrontierPhysicalGramTransport.plusField (g t)) := by
    filter_upwards [hweak, hd] with t hw hd
    exact (FrontierSpectralTimeComposition.operator_fields_eq_canonical
      FrontierCanonicalInterface.canonical (FrontierRealVelocityEmbedding.complexifyL2 (u t))
      (g t) hw hd).1
  have hm : (fun t => FrontierSpectralTimeComposition.negativeField FrontierCanonicalInterface.canonical
      (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)) =ᵐ[
        FrontierFiniteIntervalEnergy.timeMeasure T]
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) := by
    filter_upwards [hweak, hd] with t hw hd
    exact (FrontierSpectralTimeComposition.operator_fields_eq_canonical
      FrontierCanonicalInterface.canonical (FrontierRealVelocityEmbedding.complexifyL2 (u t))
      (g t) hw hd).2
  exact FrontierPhysicalTransferWithEnergy.gram_transfer_with_final_energy
    (FrontierFiniteIntervalEnergy.timeMeasure T) g
    (fun t => FrontierSpectralTimeComposition.positiveField FrontierCanonicalInterface.canonical
      (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
    (fun t => FrontierSpectralTimeComposition.negativeField FrontierCanonicalInterface.canonical
      (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
    nu (‖u0‖ ^ 2) (‖u T‖ ^ 2) hnu hg henergy hp hm

end FrontierCanonicalFinalEnergy

#print axioms FrontierCanonicalFinalEnergy.gram_canonical_with_final_energy
