import FrontierSolenoidalSpectralInterface
import FrontierRealGradientDivergence

/-! Candidate time-slice bridge: a supplied real L² gradient with zero trace
almost everywhere in space and time gives the distributional divergence
identity required by the spectral interface. With supplied weak-gradient
identities, the same data yield the helical split almost everywhere in time.
This does not define a Leray–Hopf solution or establish these premises from
its physical weak formulation. No local Lean run. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierTimeTraceBridge
abbrev Space := FrontierARealGradient.Space
abbrev RealFiber := FrontierARealGradient.RealFiber
abbrev Gradient := FrontierARealGradient.RealMatrix
abbrev Field := FrontierSpectralOperator.Field

/-- A spatially trace-free real gradient gives zero divergence distribution. -/
theorem divergence_zero_of_real_trace (g : Gradient)
    (htrace : ∀ᵐ x ∂(volume : Measure Space),
      (g : Space → RealFiber) x (0, 0) + (g : Space → RealFiber) x (1, 1) +
        (g : Space → RealFiber) x (2, 2) = 0) :
    Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 0
        (FrontierGradientAdapter.gradientColumn g 0)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 1
        (FrontierGradientAdapter.gradientColumn g 1)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 2
        (FrontierGradientAdapter.gradientColumn g 2)) = 0 := by
  have h := FrontierDivergenceTraceIdentity.distributional_divergence_eq_trace
    (FrontierARealGradient.complexifyL2 g)
    (fun j => FrontierGradientAdapter.gradientColumn g j) (fun _ => rfl)
  have hz : Lp.toTemperedDistribution (0 : Field) = 0 := by
    change (Lp.toTemperedDistributionCLM FrontierPhysicalDivergence.Fiber
      (volume : Measure FrontierPhysicalDivergence.Space) 2) 0 = 0
    exact map_zero _
  rw [FrontierRealGradientDivergence.complex_trace_zero_of_ae_real_trace_zero g htrace, hz] at h
  exact h.symm

/-- The trace-free condition supplies divergence zero almost everywhere in time. -/
theorem divergence_zero_ae_of_real_trace {τ : Type*} [MeasurableSpace τ]
    (η : Measure τ) (g : τ → Gradient)
    (htrace : ∀ᵐ t ∂η, ∀ᵐ x ∂(volume : Measure Space),
      (g t : Space → RealFiber) x (0, 0) + (g t : Space → RealFiber) x (1, 1) +
        (g t : Space → RealFiber) x (2, 2) = 0) :
    ∀ᵐ t ∂η,
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 0
          (FrontierGradientAdapter.gradientColumn (g t) 0)) +
        Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 1
          (FrontierGradientAdapter.gradientColumn (g t) 1)) +
        Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 2
          (FrontierGradientAdapter.gradientColumn (g t) 2)) = 0 := by
  filter_upwards [htrace] with t ht
  exact divergence_zero_of_real_trace (g t) ht

/-- A weak gradient and trace-free property give the helical split a.e. in time. -/
theorem split_ae_of_weak_gradient_and_real_trace {τ : Type*} [MeasurableSpace τ]
    (η : Measure τ) (u : τ → Field) (g : τ → Gradient)
    (hweak : ∀ᵐ t ∂η, ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t)))
    (htrace : ∀ᵐ t ∂η, ∀ᵐ x ∂(volume : Measure Space),
      (g t : Space → RealFiber) x (0, 0) + (g t : Space → RealFiber) x (1, 1) +
        (g t : Space → RealFiber) x (2, 2) = 0) :
    ∀ᵐ t ∂η, FrontierSolenoidalSpectralInterface.Solenoidal (u t) := by
  filter_upwards [hweak, htrace] with t hw ht
  exact FrontierRealGradientDivergence.split_of_real_weak_gradient_trace_zero (u t) (g t) hw ht

end FrontierTimeTraceBridge

#print axioms FrontierTimeTraceBridge.divergence_zero_of_real_trace
#print axioms FrontierTimeTraceBridge.divergence_zero_ae_of_real_trace
#print axioms FrontierTimeTraceBridge.split_ae_of_weak_gradient_and_real_trace
