import FrontierAMatrixFourierAE
import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier

/-! A-tier candidate, not compiled. This is the integrable-function core
of Fourier naturality for arbitrary bounded complex-linear fiber maps.
It does not assert L² naturality, weak-gradient identification, or any
Leray–Hopf realization. External compilation and axiom audit are required. -/

noncomputable section
open MeasureTheory FourierTransform

namespace FrontierAFourierPostcompL1

abbrev Space := FrontierAMatrixFourier.Space
abbrev GradFiber := FrontierAMatrixFourier.GradFiber
abbrev Fiber := EuclideanSpace ℂ (Fin 3)

/-- Pointwise Fourier transform commutes with an arbitrary continuous
complex-linear fiber map on integrable matrix-valued functions. -/
theorem fourier_postcomp_integrable
    (L : GradFiber →L[ℂ] Fiber) (f : Space → GradFiber)
    (hf : Integrable f (volume : Measure Space)) (ξ : Space) :
    FourierTransform.fourier (fun x => L (f x)) ξ =
      L (FourierTransform.fourier f ξ) := by
  rw [Real.fourier_eq, Real.fourier_eq]
  have hi : Integrable (fun x : Space =>
      Real.fourierChar (-inner ℝ x ξ) • f x) (volume : Measure Space) :=
    (Real.fourierIntegral_convergent_iff ξ).2 hf
  simpa only [Circle.smul_def, map_smul] using (L.integral_comp_comm hi)

end FrontierAFourierPostcompL1

#print axioms FrontierAFourierPostcompL1.fourier_postcomp_integrable
