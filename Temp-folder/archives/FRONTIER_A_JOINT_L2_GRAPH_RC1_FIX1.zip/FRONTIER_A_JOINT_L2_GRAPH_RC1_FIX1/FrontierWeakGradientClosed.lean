import FrontierAEProjectedGraphEnergy
import FrontierRealVelocityEmbedding

/-! The graph of the supplied L² weak-gradient relation is closed in the
product of real velocity and real matrix L² spaces. This is a spatial
functional-analytic step towards time slicing; it does not prove that an
independently defined Leray–Hopf spacetime representative gives a graph-valued
Bochner trajectory. No local Lean compilation was performed. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierWeakGradientClosed

abbrev Space := FrontierAWeakRieszBridge.Space
abbrev Fiber := FrontierAWeakRieszBridge.Fiber
abbrev RealVelocity := FrontierRealVelocityEmbedding.RealField
abbrev Gradient := FrontierARealGradient.RealMatrix
abbrev Distribution := TemperedDistribution Space Fiber

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩

/-- Distributional weak-gradient data form a closed subset of the natural
product L² topology. No time or Navier–Stokes premise is used. -/
theorem isClosed_weak_gradient_graph :
    IsClosed {p : RealVelocity × Gradient |
      FrontierAEProjectedGraphEnergy.WeakAt
        (FrontierRealVelocityEmbedding.complexifyL2 p.1) p.2} := by
  have hvelocity : Continuous (fun p : RealVelocity × Gradient =>
      FrontierRealVelocityEmbedding.complexifyL2 p.1) :=
    FrontierRealVelocityEmbedding.complexifyL2.continuous.comp continuous_fst
  have hdist : Continuous (fun p : RealVelocity × Gradient =>
      Lp.toTemperedDistribution
        (FrontierRealVelocityEmbedding.complexifyL2 p.1)) :=
    (Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2).continuous.comp hvelocity
  have hcolumn (j : Fin 3) : Continuous (fun p : RealVelocity × Gradient =>
      FrontierGradientAdapter.gradientColumn p.2 j) := by
    exact (FrontierAWeakMatrixColumns.columnL2 j).continuous.comp
      (FrontierARealGradient.complexifyL2.continuous.comp continuous_snd)
  have hcolDist (j : Fin 3) : Continuous (fun p : RealVelocity × Gradient =>
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn p.2 j)) :=
    (Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2).continuous.comp (hcolumn j)
  have hderiv (j : Fin 3) : Continuous (fun p : RealVelocity × Gradient =>
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (FrontierRealVelocityEmbedding.complexifyL2 p.1))) := by
    exact (LineDeriv.lineDerivOpCLM ℂ Distribution
      (FrontierAWeakRieszBridge.unitDirection j)).continuous.comp hdist
  have hset : {p : RealVelocity × Gradient |
      FrontierAEProjectedGraphEnergy.WeakAt
        (FrontierRealVelocityEmbedding.complexifyL2 p.1) p.2} =
      ⋂ j : Fin 3, {p : RealVelocity × Gradient |
        Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn p.2 j) =
        LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
          (Lp.toTemperedDistribution (FrontierRealVelocityEmbedding.complexifyL2 p.1))} := by
    ext p
    simp only [Set.mem_setOf_eq, Set.mem_iInter, FrontierAEProjectedGraphEnergy.WeakAt]
  rw [hset]
  exact isClosed_iInter (fun j => isClosed_eq (hcolDist j) (hderiv j))

end FrontierWeakGradientClosed

#print axioms FrontierWeakGradientClosed.isClosed_weak_gradient_graph
