import Mathlib

/-!
# Algebraic consequences of concentration

This module contains abstract lemmas intended for Round 9 of the physical
Frontier_A work. They are **conditional**: they do not construct any
Navier--Stokes solution, prove the short-time sharpness theorem, establish
Hölder's inequality in a physical model, or prove any determinant
integrability statement. The relevant mass, norm, and time-scale links must
be supplied by separate audited theorems.

Candidate Lean only: this file has not been compiled or audited on the
user's native Windows Lean 4.33.0 toolchain.
-/

open Filter
open scoped Topology

namespace FrontierConcentration

/-- If almost all of a mass lies near the initial time, the remainder is
bounded by the missing mass. This is an algebraic step toward concentration. -/
theorem outside_mass_le
    {budget total near outside error : ℝ}
    (h_total : total ≤ budget)
    (h_near : budget - error ≤ near)
    (h_split : total = near + outside) :
    outside ≤ error := by
  linarith

/-- A fixed positive amount of mass cannot be bounded by a fixed norm times
scales tending to zero. All quantities are abstract real sequences. -/
theorem no_uniform_scaled_bound
    {mass amplitude scale : ℕ → ℝ} {c C : ℝ}
    (hc : 0 < c)
    (hscale : Tendsto scale atTop (𝓝 0))
    (hscale_nonneg : ∀ n, 0 ≤ scale n)
    (hmass : ∀ n, c ≤ mass n)
    (hcapacity : ∀ n, mass n ≤ amplitude n * scale n)
    (hbounded : ∀ n, amplitude n ≤ C) : False := by
  have hcap : ∀ n, c ≤ C * scale n := by
    intro n
    exact le_trans (hmass n)
      (le_trans (hcapacity n)
        (mul_le_mul_of_nonneg_right (hbounded n) (hscale_nonneg n)))
  have hlim : Tendsto (fun n : ℕ => C * scale n) atTop (𝓝 (C * 0)) :=
    tendsto_const_nhds.mul hscale
  have hzero : c ≤ C * 0 :=
    ge_of_tendsto hlim (Filter.Eventually.of_forall hcap)
  have hzero' : c ≤ 0 := by simpa using hzero
  exact (not_le_of_gt hc) hzero'

/-- Abstract unboundedness conclusion. In a physical application, `mass n`
is a normalized short-time integral, `amplitude n` is an Lp norm, and
`scale n` is the Hölder factor. Those identifications are explicit remaining
premises and are not established in this module. -/
theorem scaled_profiles_unbounded
    {mass amplitude scale : ℕ → ℝ} {c : ℝ}
    (hc : 0 < c)
    (hscale : Tendsto scale atTop (𝓝 0))
    (hscale_nonneg : ∀ n, 0 ≤ scale n)
    (hmass : ∀ n, c ≤ mass n)
    (hcapacity : ∀ n, mass n ≤ amplitude n * scale n) :
    ∀ C : ℝ, ∃ n : ℕ, C < amplitude n := by
  intro C
  by_contra h
  push_neg at h
  exact no_uniform_scaled_bound hc hscale hscale_nonneg hmass hcapacity h

end FrontierConcentration
