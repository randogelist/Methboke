import FrontierWeakGradientClosed

/-! The supplied real L² weak-gradient graph as a closed linear subspace.
This spatial result is a prerequisite for a Bochner time-slicing proof; it
does not assert that any standard Leray–Hopf trajectory belongs to this graph.
No local Lean run. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierWeakGradientSubspace

abbrev Space := FrontierWeakGradientClosed.Space
abbrev Fiber := FrontierWeakGradientClosed.Fiber
abbrev RealVelocity := FrontierWeakGradientClosed.RealVelocity
abbrev Gradient := FrontierWeakGradientClosed.Gradient
abbrev Distribution := FrontierWeakGradientClosed.Distribution

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩

/-- The gradient-column distribution as a real-linear map. -/
def columnDistribution (j : Fin 3) : Gradient →ₗ[ℝ] Distribution :=
  ((Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2).restrictScalars ℝ).toLinearMap.comp
    (((FrontierAWeakMatrixColumns.columnL2 j).restrictScalars ℝ).toLinearMap.comp
      FrontierARealGradient.complexifyL2.toLinearMap)

/-- The directional derivative of the velocity distribution as a real-linear map. -/
def velocityDerivative (j : Fin 3) : RealVelocity →ₗ[ℝ] Distribution :=
  ((LineDeriv.lineDerivOpCLM ℂ Distribution
    (FrontierAWeakRieszBridge.unitDirection j)).restrictScalars ℝ).toLinearMap.comp
    (((Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2).restrictScalars ℝ).toLinearMap.comp
      FrontierRealVelocityEmbedding.complexifyL2.toLinearMap)

/-- Difference of the two sides of one weak derivative equation. -/
def residual (j : Fin 3) : (RealVelocity × Gradient) →ₗ[ℝ] Distribution :=
  (columnDistribution j).comp (LinearMap.snd ℝ RealVelocity Gradient) -
    (velocityDerivative j).comp (LinearMap.fst ℝ RealVelocity Gradient)

theorem residual_apply (j : Fin 3) (p : RealVelocity × Gradient) :
    residual j p =
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn p.2 j) -
        LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
          (Lp.toTemperedDistribution (FrontierRealVelocityEmbedding.complexifyL2 p.1)) := by
  rfl

/-- Kernel intersection: one equation for each spatial direction. -/
def graph : Submodule ℝ (RealVelocity × Gradient) :=
  ⨅ j : Fin 3, (residual j).ker

/-- Membership is exactly the existing pointwise weak-gradient relation. -/
theorem mem_graph_iff (p : RealVelocity × Gradient) :
    p ∈ graph ↔ FrontierAEProjectedGraphEnergy.WeakAt
      (FrontierRealVelocityEmbedding.complexifyL2 p.1) p.2 := by
  rw [graph, Submodule.mem_iInf]
  simp only [LinearMap.mem_ker, residual_apply, sub_eq_zero,
    FrontierAEProjectedGraphEnergy.WeakAt]

/-- The weak-gradient subspace is closed in the product L² topology. -/
theorem isClosed_graph : IsClosed (graph : Set (RealVelocity × Gradient)) := by
  have hset : (graph : Set (RealVelocity × Gradient)) =
      {p : RealVelocity × Gradient | FrontierAEProjectedGraphEnergy.WeakAt
        (FrontierRealVelocityEmbedding.complexifyL2 p.1) p.2} := by
    ext p
    exact mem_graph_iff p
  rw [hset]
  exact FrontierWeakGradientClosed.isClosed_weak_gradient_graph

end FrontierWeakGradientSubspace

#print axioms FrontierWeakGradientSubspace.residual_apply
#print axioms FrontierWeakGradientSubspace.mem_graph_iff
#print axioms FrontierWeakGradientSubspace.isClosed_graph
