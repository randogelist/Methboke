import FrontierSpectralTimeComposition
import FrontierTimeTraceBridge
import FrontierRealVelocityNorm

/-! Candidate finite-interval operator estimate for a supplied real L²
trajectory and real L² gradient. The weak-gradient, trace-free, energy and
operator-interface assumptions are explicit. No actual Leray–Hopf predicate
is constructed or identified, and no physical operator is instantiated.
No local Lean compiler was run. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierRealSpectralEnergy

abbrev RealVelocity := FrontierRealVelocityEmbedding.RealField
abbrev Gradient := FrontierARealGradient.RealMatrix
abbrev Space := FrontierARealGradient.Space
abbrev RealFiber := FrontierARealGradient.RealFiber
abbrev Interface := FrontierSolenoidalSpectralInterface.Interface

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

/-- Real-data version of the conditional spectral estimate. The norm and
divergence conversion are proved; all analytic trajectory and operator
premises remain explicit. -/
theorem finite_interval_real_trajectory
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (S : Interface) (u : ℝ → RealVelocity) (u0 : RealVelocity) (g : ℝ → Gradient)
    (T nu : ℝ) (hnu : 0 < nu) (hinit : u 0 = u0)
    (hg : MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T))
    (henergy : ‖u T‖ ^ 2 + 2 * nu *
      (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      FrontierAEProjectedGraphEnergy.WeakAt (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
    (htrace : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      ∀ᵐ x ∂(volume : Measure Space),
        (g t : Space → RealFiber) x (0, 0) + (g t : Space → RealFiber) x (1, 1) +
          (g t : Space → RealFiber) x (2, 2) = 0) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierSpectralTimeComposition.positiveField S
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField S
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)))
      (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (FrontierFiniteIntervalEnergy.timeMeasure T)
      (fun t => FrontierSpectralTimeComposition.positiveField S
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField S
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  have he : ‖FrontierRealVelocityEmbedding.complexifyL2 (u T)‖ ^ 2 + 2 * nu *
      (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤
        ‖FrontierRealVelocityEmbedding.complexifyL2 (u 0)‖ ^ 2 := by
    simpa only [FrontierRealVelocityNorm.complexifyL2_norm, hinit] using henergy
  have hd := FrontierTimeTraceBridge.divergence_zero_ae_of_real_trace
    (FrontierFiniteIntervalEnergy.timeMeasure T) g htrace
  have hb := FrontierSpectralTimeComposition.finite_interval_gram_from_spectral_interface
    S (fun t => FrontierRealVelocityEmbedding.complexifyL2 (u t)) g T nu hnu hg he hweak hd
  simpa only [FrontierRealVelocityNorm.complexifyL2_norm, hinit] using hb

end FrontierRealSpectralEnergy

#print axioms FrontierRealSpectralEnergy.finite_interval_real_trajectory
