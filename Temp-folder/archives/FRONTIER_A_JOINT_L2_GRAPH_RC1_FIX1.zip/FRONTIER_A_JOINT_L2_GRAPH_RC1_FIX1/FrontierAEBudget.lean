import FrontierFrozenRoot

/-! Candidate bridge from an almost-everywhere initial-energy budget to all
finite times. A good time after T is chosen in (T,T+1); nonnegativity of the
dissipation then gives the budget at T. The global-in-time a.e. budget and
local integrability remain explicit hypotheses. The application concerns the
project's canonical matrix-derived fields, not an independently realized
Leray--Hopf solution. No local Lean execution or axiom audit. -/

noncomputable section
open MeasureTheory Filter

namespace FrontierAEBudget

local instance physicalRealL2 : InnerProductSpace ℝ FrontierFrozenRoot.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierFrozenRoot.PhysicalL2

/-- An a.e. assertion on the positive half-line holds at some time > T. -/
theorem exists_good_after (p : ℝ → Prop)
    (hp : ∀ᵐ s ∂(volume.restrict (Set.Ioi (0 : ℝ))), p s)
    (T : ℝ) (hT : 0 ≤ T) : ∃ s, T < s ∧ p s := by
  let J : Set ℝ := Set.Ioo T (T + 1)
  have hvolume : (volume : Measure ℝ) J ≠ 0 := by
    change (volume : Measure ℝ) (Set.Ioo T (T + 1)) ≠ 0
    rw [Real.volume_Ioo]
    have hsub : T + 1 - T = (1 : ℝ) := by ring
    rw [hsub]
    norm_num
  letI : (ae ((volume : Measure ℝ).restrict J)).NeBot := ae_restrict_neBot.mpr hvolume
  have hsubset : J ⊆ Set.Ioi (0 : ℝ) := by
    intro s hs
    exact lt_of_le_of_lt hT hs.1
  have hpJ : ∀ᵐ s ∂((volume : Measure ℝ).restrict J), p s :=
    ae_restrict_of_ae_restrict_of_subset hsubset hp
  have hmem : ∀ᵐ s ∂((volume : Measure ℝ).restrict J), s ∈ J :=
    ae_restrict_mem measurableSet_Ioo
  obtain ⟨s, hs⟩ := (hmem.and hpJ).exists
  exact ⟨s, hs.1.1, hs.2⟩

/-- A nonnegative locally integrable density has every finite-time budget
once the budget is available for almost every positive time. -/
theorem all_finite_budgets_of_ae
    (f : ℝ → ℝ) (ν E : ℝ) (hν : 0 ≤ ν)
    (hf : ∀ s : ℝ, 0 ≤ s → IntegrableOn f (Set.Icc 0 s) volume)
    (hnonneg : ∀ t, 0 ≤ f t)
    (hae : ∀ᵐ s ∂(volume.restrict (Set.Ioi (0 : ℝ))),
      2 * ν * (∫ t in Set.Icc 0 s, f t) ≤ E) :
    ∀ T : ℝ, 0 ≤ T → 2 * ν * (∫ t in Set.Icc 0 T, f t) ≤ E := by
  intro T hT
  obtain ⟨s, hTs, hs⟩ := exists_good_after _ hae T hT
  have hsi : IntegrableOn f (Set.Icc 0 s) volume := hf s (le_trans hT (le_of_lt hTs))
  have hmono : (∫ t in Set.Icc 0 T, f t) ≤ ∫ t in Set.Icc 0 s, f t := by
    apply setIntegral_mono_set hsi (Filter.Eventually.of_forall hnonneg)
    exact Filter.Eventually.of_forall (fun t ht => ⟨ht.1, le_trans ht.2 (le_of_lt hTs)⟩)
  exact le_trans (mul_le_mul_of_nonneg_left hmono (by positivity)) hs

/-- If the usual terminal-energy inequality is known a.e., its nonnegative
terminal term can be dropped and the dissipation budget propagated to every T. -/
theorem all_finite_budgets_of_ae_terminal_energy
    {H : Type*} [NormedAddCommGroup H] (u : ℝ → H) (f : ℝ → ℝ)
    (ν E : ℝ) (hν : 0 ≤ ν)
    (hf : ∀ s : ℝ, 0 ≤ s → IntegrableOn f (Set.Icc 0 s) volume)
    (hnonneg : ∀ t, 0 ≤ f t)
    (hae : ∀ᵐ s ∂(volume.restrict (Set.Ioi (0 : ℝ))),
      ‖u s‖ ^ 2 + 2 * ν * (∫ t in Set.Icc 0 s, f t) ≤ E) :
    ∀ T : ℝ, 0 ≤ T → 2 * ν * (∫ t in Set.Icc 0 T, f t) ≤ E := by
  apply all_finite_budgets_of_ae f ν E hν hf hnonneg
  filter_upwards [hae] with s hs
  nlinarith [sq_nonneg ‖u s‖]

/-- Canonical frozen estimate for every T from time-L2 matrix data and an a.e.
dissipation budget. No velocity or physical-solution realization is asserted. -/
theorem canonical_frontierA_of_ae_budget
    [MeasurableSpace FrontierFrozenRoot.Gradient] [BorelSpace FrontierFrozenRoot.Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix] [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField] [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2] [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (g : ℝ → FrontierFrozenRoot.Gradient) (u0 : FrontierFrozenRoot.RealVelocity)
    (ν : ℝ) (hν : 0 < ν)
    (hg : ∀ T : ℝ, 0 ≤ T → MemLp g 2 (FrontierFrozenRoot.timeMeasure T))
    (hae : ∀ᵐ s ∂(volume.restrict (Set.Ioi (0 : ℝ))),
      2 * ν * (∫ t in Set.Icc 0 s, ‖g t‖ ^ 2) ≤ ‖u0‖ ^ 2) :
    ∀ T : ℝ, 0 ≤ T →
      Integrable (FeffermanAHopfGramIntegral.gramSqrt
        (fun t => FrontierPhysicalGramTransport.plusField (g t))
        (fun t => FrontierPhysicalGramTransport.minusField (g t)))
        (FrontierFrozenRoot.timeMeasure T) ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral (FrontierFrozenRoot.timeMeasure T)
        (fun t => FrontierPhysicalGramTransport.plusField (g t))
        (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤ ‖u0‖ ^ 2 / (4 * ν) := by
  have hint : ∀ s : ℝ, 0 ≤ s →
      IntegrableOn (fun t => ‖g t‖ ^ 2) (Set.Icc 0 s) volume := by
    intro s hs
    exact (memLp_two_iff_integrable_sq_norm (hg s hs).aestronglyMeasurable).1 (hg s hs)
  have hbudget := all_finite_budgets_of_ae (fun t => ‖g t‖ ^ 2) ν (‖u0‖ ^ 2)
    (le_of_lt hν) hint (fun t => sq_nonneg ‖g t‖) hae
  intro T hT
  exact FrontierFrozenRoot.canonical_matrix_frontierA g u0 T ν hT hν (hg T hT) (hbudget T hT)

end FrontierAEBudget

#print axioms FrontierAEBudget.exists_good_after
#print axioms FrontierAEBudget.all_finite_budgets_of_ae
#print axioms FrontierAEBudget.all_finite_budgets_of_ae_terminal_energy
#print axioms FrontierAEBudget.canonical_frontierA_of_ae_budget
