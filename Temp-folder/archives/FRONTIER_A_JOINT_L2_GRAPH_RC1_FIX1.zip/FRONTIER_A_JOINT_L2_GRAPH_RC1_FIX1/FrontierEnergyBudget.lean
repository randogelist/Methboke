import FrontierARealWeakTimeGram

/-!
# Candidate energy-input adapter

`D`, `g`, `u0` and `uT` below are supplied data. Their actual relation to an
unforced physical Leray–Hopf solution and its distributional gradient is NOT
constructed in this file. The dissipation-density identification, energy
inequality, strong measurability and integrability remain explicit premises.
-/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierEnergyBudget

local instance realL2 (μ : Measure FrontierAWeakTimeGram.Frequency) :
    InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

/-- A supplied terminal-energy inequality and a supplied physical
  dissipation density yield the time L² and energy inputs of v0.28. -/
theorem gradient_inputs_from_energy
    {τ G V : Type*} [MeasurableSpace τ]
    [NormedAddCommGroup G] [MeasurableSpace G] [BorelSpace G]
    [NormedAddCommGroup V]
    (η : Measure τ) (g : τ → G) (D : τ → ℝ) (u0 uT : V) (nu : ℝ)
    (hg : AEStronglyMeasurable g η) (hD : Integrable D η)
    (hidentify : D =ᵐ[η] fun t => ‖g t‖ ^ 2)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, D t ∂η) ≤ ‖u0‖ ^ 2) :
    MemLp g 2 η ∧ 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ ‖u0‖ ^ 2 := by
  have hsq : Integrable (fun t => ‖g t‖ ^ 2) η := hD.congr hidentify
  have hlp : MemLp g 2 η := (memLp_two_iff_integrable_sq_norm hg).2 hsq
  have heq : (∫ t, D t ∂η) = ∫ t, ‖g t‖ ^ 2 ∂η := integral_congr_ae hidentify
  constructor
  · exact hlp
  · rw [← heq]
    nlinarith [sq_nonneg ‖uT‖]

/-- Conditional v0.28 weak-gradient result using a terminal-energy
  inequality and an explicitly identified integrable dissipation density.
  The physical and weak-derivative hypotheses remain explicit. -/
theorem real_weak_from_terminal_energy
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → FrontierAWeakTimeGram.Field)
    (g : τ → FrontierARealGradient.RealMatrix)
    (du : τ → Fin 3 → FrontierAWeakTimeGram.Field)
    (D : τ → ℝ) (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : AEStronglyMeasurable g η) (hD : Integrable D η)
    (hidentify : D =ᵐ[η] fun t => ‖g t‖ ^ 2)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, D t ∂η) ≤ ‖u0‖ ^ 2)
    (hcol : ∀ᵐ t ∂η, ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 (g t)) = du t j)
    (hweak : ∀ᵐ t ∂η, ∀ j, Lp.toTemperedDistribution (du t j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t))) :
    (Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier (volume : Measure FrontierAWeakTimeGram.Frequency)
        (FrontierARealGradient.realGradientSpectrum (g t)))
      (fun t => minusMultiplier (volume : Measure FrontierAWeakTimeGram.Frequency)
        (FrontierARealGradient.realGradientSpectrum (g t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier (volume : Measure FrontierAWeakTimeGram.Frequency)
        (FrontierARealGradient.realGradientSpectrum (g t)))
      (fun t => minusMultiplier (volume : Measure FrontierAWeakTimeGram.Frequency)
        (FrontierARealGradient.realGradientSpectrum (g t)))
      ≤ ‖u0‖ ^ 2 / (4 * nu)) ∧
    (∀ᵐ t ∂η, ∀ᵐ ξ ∂(volume : Measure FrontierAWeakTimeGram.Frequency), ∀ i : Fin 3,
      (FrontierARealGradient.realGradientSpectrum (g t) : FrontierAWeakTimeGram.Frequency → FrontierAWeakTimeGram.Fiber) ξ i =
        ((2 * Real.pi : ℝ) : ℂ) *
        (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2) : ℂ) *
        (FourierTransform.fourier (u t) : FrontierAWeakTimeGram.Field) (WithLp.toLp 2 ξ) i) := by
  obtain ⟨hlp, hbudget⟩ := gradient_inputs_from_energy η g D u0 uT nu hg hD hidentify henergy
  exact FrontierARealWeakTimeGram.time_real_gram_and_weak_symbol
    η u g du nu (‖u0‖ ^ 2) hnu hlp hbudget hcol hweak

end FrontierEnergyBudget

#print axioms FrontierEnergyBudget.gradient_inputs_from_energy
#print axioms FrontierEnergyBudget.real_weak_from_terminal_energy
