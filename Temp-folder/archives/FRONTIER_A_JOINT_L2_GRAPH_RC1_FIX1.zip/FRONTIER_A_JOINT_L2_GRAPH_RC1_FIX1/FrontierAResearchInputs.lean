import HOPF_GRAM_INTEGRAL

/-!
Explicit research-input skeleton for Frontier_A.  The underlying Hilbert space
is real-valued vector L2 on Euclidean R3. The arguments named `dissipation`,
`helicalPlus`, and `helicalMinus` are supplied data: this file does not define
Leray-Hopf solutions, prove that the data arise from one, or identify the
operators with Fourier helical projections. Those identifications are separate
unresolved research inputs. In particular this theorem is not the full
unconditional physical Frontier_A theorem.

Literature context: Lerner and Vigneron, "On Some Properties of the Curl
Operator and Their Consequences for the Navier-Stokes System", Communications
in Mathematical Research 38 (2022), DOI 10.4208/cmr.2021-0106, studies the
curl/helical decomposition on divergence-free fields. The Leray-Hopf energy
class and energy inequality are standard analytic inputs; see e.g. Dubois,
"Uniqueness for some Leray-Hopf solutions to the
Navier-Stokes equations", DOI 10.1016/S0022-0396(02)00108-0. These references
are context, not axioms or machine-checked proofs of the hypotheses below.

The mathematical analytic inputs are explicitly listed as hypotheses: L2 in
time of the supplied dissipation, its Leray-Hopf energy budget, and the split
and orthogonality of the supplied helical maps. The derivation constructs the
actual two-vector Gram determinant and proves integrability and the bound.
Native external compilation and theorem-level axiom audit are required.
-/

noncomputable section
open MeasureTheory Filter

namespace FrontierAResearchInputs

abbrev Space := EuclideanSpace ℝ (Fin 3)
abbrev PhysicalVector := EuclideanSpace ℝ (Fin 3)
abbrev PhysicalL2 := Lp PhysicalVector 2 (volume : Measure Space)

variable [MeasurableSpace PhysicalL2] [BorelSpace PhysicalL2]

/-- Conditional root for supplied physical-space data. The names of the
    arguments do not prove their physical interpretation; the four research
    premises and the missing interpretation are documented above. -/
theorem frontier_A_from_research_inputs
    (T nu : ℝ) (initialVelocity : PhysicalL2)
    (dissipation : ℝ → PhysicalL2)
    (helicalPlus helicalMinus : PhysicalL2 →L[ℝ] PhysicalL2)
    (hT : 0 ≤ T) (hnu : 0 < nu)
    (dissipationL2 : MemLp dissipation 2
      (volume.restrict (Set.Ioc (0 : ℝ) T)))
    (energyBudget : 2 * nu * (∫ t in Set.Ioc (0 : ℝ) T,
      ‖dissipation t‖ ^ 2) ≤ ‖initialVelocity‖ ^ 2)
    (helicalSplit : ∀ᵐ t ∂(volume.restrict (Set.Ioc (0 : ℝ) T)),
      helicalPlus (dissipation t) + helicalMinus (dissipation t) = dissipation t)
    (helicalOrthogonal : ∀ᵐ t ∂(volume.restrict (Set.Ioc (0 : ℝ) T)),
      inner ℝ (helicalPlus (dissipation t)) (helicalMinus (dissipation t)) = 0) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => helicalPlus (dissipation t))
      (fun t => helicalMinus (dissipation t)))
      (volume.restrict (Set.Ioc (0 : ℝ) T)) ∧
    (∫ t in Set.Ioc (0 : ℝ) T, FeffermanAHopfGramIntegral.gramSqrt
      (fun t => helicalPlus (dissipation t))
      (fun t => helicalMinus (dissipation t)) t)
      ≤ ‖initialVelocity‖ ^ 2 / (4 * nu) := by
  have hp : MemLp (fun t => helicalPlus (dissipation t)) 2
      (volume.restrict (Set.Ioc (0 : ℝ) T)) := by
    simpa only [Function.comp_def] using helicalPlus.comp_memLp' dissipationL2
  have hm : MemLp (fun t => helicalMinus (dissipation t)) 2
      (volume.restrict (Set.Ioc (0 : ℝ) T)) := by
    simpa only [Function.comp_def] using helicalMinus.comp_memLp' dissipationL2
  have heq : (∫ t in Set.Ioc (0 : ℝ) T,
      (‖helicalPlus (dissipation t)‖ ^ 2 + ‖helicalMinus (dissipation t)‖ ^ 2)) =
      ∫ t in Set.Ioc (0 : ℝ) T, ‖dissipation t‖ ^ 2 := by
    apply integral_congr_ae
    filter_upwards [helicalSplit, helicalOrthogonal] with t hs ho
    have h := norm_add_sq_real (helicalPlus (dissipation t)) (helicalMinus (dissipation t))
    rw [hs, ho] at h
    linarith
  apply FeffermanAHopfGramIntegral.time_gramSqrt_integrable_and_bound
    T nu (‖initialVelocity‖ ^ 2)
    (fun t => helicalPlus (dissipation t))
    (fun t => helicalMinus (dissipation t)) hnu hp hm helicalOrthogonal
  rw [heq]
  exact energyBudget

end FrontierAResearchInputs

#print axioms FrontierAResearchInputs.frontier_A_from_research_inputs
