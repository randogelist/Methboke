import HelicalCoordinateBridge
import HelicalR3Plancherel
import HelicalConcreteGram

/-! A-TIER CANDIDATE: build the equivalence between Euclidean and
coordinate-frequency L² spaces, compose it with the actual complex L²
Fourier transform, and transport the helical multipliers. All fields remain
complex; no Leray--Hopf, real-field, derivative or Sobolev identification
is asserted. External compilation and theorem-level axiom audit required. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal HelicalCoordinateBridge
namespace FrontierACoordinateEquiv

theorem euclidean_roundtrip (f : EuclideanL2) :
    toEuclidean (toCoordinates f) = f := by
  apply Lp.ext
  have h := ofLp_preserves_volume.quasiMeasurePreserving.ae_eq_comp (toCoordinates_ae f)
  filter_upwards [toEuclidean_ae (toCoordinates f), h] with ξ h₁ h₂
  simpa only [Function.comp_def, WithLp.toLp_ofLp] using h₁.trans h₂

theorem coordinate_roundtrip (f : CoordinateL2) :
    toCoordinates (toEuclidean f) = f := by
  apply Lp.ext
  have h := toLp_preserves_volume.quasiMeasurePreserving.ae_eq_comp (toEuclidean_ae f)
  filter_upwards [toCoordinates_ae (toEuclidean f), h] with ξ h₁ h₂
  simpa only [Function.comp_def, WithLp.ofLp_toLp] using h₁.trans h₂

/-- Pullback along the volume-preserving Euclidean/coordinate equivalence. -/
def coordinateEquiv : EuclideanL2 ≃ₗᵢ[ℂ] CoordinateL2 where
  toLinearEquiv :=
    { toFun := toCoordinates
      invFun := toEuclidean
      left_inv := euclidean_roundtrip
      right_inv := coordinate_roundtrip
      map_add' := fun x y => toCoordinates.map_add x y
      map_smul' := fun c x => toCoordinates.map_smul c x }
  norm_map' := toCoordinates_norm

/-- Mathlib's L² Fourier transform followed by coordinate transport. -/
def fourierCoordinate : HelicalR3Plancherel.ComplexField ≃ₗᵢ[ℂ] CoordinateL2 :=
  HelicalR3Plancherel.fourierComplex.trans coordinateEquiv

theorem fourier_coordinate_norm (f : HelicalR3Plancherel.ComplexField) :
    ‖fourierCoordinate f‖ = ‖f‖ := fourierCoordinate.norm_map f

theorem fourier_coordinate_inverse (f : HelicalR3Plancherel.ComplexField) :
    fourierCoordinate.symm (fourierCoordinate f) = f := fourierCoordinate.symm_apply_apply f

/-- Conjugated multipliers on complex L² physical-coordinate fields. -/
def plusPullback (f : HelicalR3Plancherel.ComplexField) : HelicalR3Plancherel.ComplexField :=
  fourierCoordinate.symm (plusMultiplier (volume : Measure Frequency) (fourierCoordinate f))

def minusPullback (f : HelicalR3Plancherel.ComplexField) : HelicalR3Plancherel.ComplexField :=
  fourierCoordinate.symm (minusMultiplier (volume : Measure Frequency) (fourierCoordinate f))

theorem plus_intertwines (f : HelicalR3Plancherel.ComplexField) :
    fourierCoordinate (plusPullback f) = plusMultiplier (volume : Measure Frequency) (fourierCoordinate f) := by
  simp [plusPullback]

theorem minus_intertwines (f : HelicalR3Plancherel.ComplexField) :
    fourierCoordinate (minusPullback f) = minusMultiplier (volume : Measure Frequency) (fourierCoordinate f) := by
  simp [minusPullback]

theorem plus_idempotent (f : HelicalR3Plancherel.ComplexField) :
    plusPullback (plusPullback f) = plusPullback f := by
  simp [plusPullback, plus_multiplier_idempotent]

theorem minus_idempotent (f : HelicalR3Plancherel.ComplexField) :
    minusPullback (minusPullback f) = minusPullback f := by
  simp [minusPullback, minus_multiplier_idempotent]

/-- Orthogonality of the conjugated complex L² multiplier ranges. -/
theorem pullback_orthogonal (f g : HelicalR3Plancherel.ComplexField) :
    inner ℂ (plusPullback f) (minusPullback g) = 0 := by
  calc
    inner ℂ (plusPullback f) (minusPullback g) =
        inner ℂ (fourierCoordinate (plusPullback f))
          (fourierCoordinate (minusPullback g)) :=
      (fourierCoordinate.inner_map_map _ _).symm
    _ = 0 := by
      rw [plus_intertwines, minus_intertwines]
      exact HelicalConcreteGram.multiplier_complex_orthogonal
        (volume : Measure Frequency) (fourierCoordinate f) (fourierCoordinate g)

end FrontierACoordinateEquiv
#print axioms FrontierACoordinateEquiv.euclidean_roundtrip
#print axioms FrontierACoordinateEquiv.coordinate_roundtrip
#print axioms FrontierACoordinateEquiv.fourier_coordinate_norm
#print axioms FrontierACoordinateEquiv.fourier_coordinate_inverse
#print axioms FrontierACoordinateEquiv.plus_intertwines
#print axioms FrontierACoordinateEquiv.minus_intertwines
#print axioms FrontierACoordinateEquiv.plus_idempotent
#print axioms FrontierACoordinateEquiv.minus_idempotent

#print axioms FrontierACoordinateEquiv.pullback_orthogonal
