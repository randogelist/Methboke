import FrontierDistributionTrace

/-! Candidate identity connecting a supplied weak gradient's L² trace to the
sum of its diagonal weak-derivative distributions. The coordinate extraction
is repeated into each vector component; this is a faithful encoding of the
scalar divergence. The identity depends on the supplied column equations.
The link to a Leray--Hopf trajectory remains open. No local Lean run. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierDivergenceTraceIdentity

abbrev Space := FrontierPhysicalDivergence.Space
abbrev Fiber := FrontierPhysicalDivergence.Fiber
abbrev Field := FrontierPhysicalDivergence.Field
abbrev MatrixL2 := FrontierPhysicalDivergence.MatrixL2

/-- Embed coordinate j of a vector as a constant vector. -/
def diagonalMap (j : Fin 3) : Fiber →ₗ[ℂ] Fiber where
  toFun v := WithLp.toLp 2 (fun _ : Fin 3 => v j)
  map_add' v w := by ext i; simp
  map_smul' c v := by ext i; simp

def diagonalCLM (j : Fin 3) : Fiber →L[ℂ] Fiber :=
  LinearMap.toContinuousLinearMap (diagonalMap j)

theorem diagonalCLM_apply (j i : Fin 3) (v : Fiber) :
    diagonalCLM j v i = v j := by rfl

def diagonalL2 (j : Fin 3) : Field →L[ℂ] Field :=
  ContinuousLinearMap.compLpL 2 (volume : Measure Space) (diagonalCLM j)

/-- The matrix trace is the sum of the diagonal weak-derivative columns. -/
theorem traceL2_eq_diagonal_columns (g : MatrixL2) (du : Fin 3 → Field)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j g = du j) :
    FrontierPhysicalDivergence.traceL2 g =
      diagonalL2 0 (du 0) + diagonalL2 1 (du 1) + diagonalL2 2 (du 2) := by
  apply Lp.ext
  have ht := ContinuousLinearMap.coeFn_compLpL FrontierPhysicalDivergence.traceCLM g
  have h0 := FrontierAWeakMatrixColumns.columnL2_ae 0 g
  have h1 := FrontierAWeakMatrixColumns.columnL2_ae 1 g
  have h2 := FrontierAWeakMatrixColumns.columnL2_ae 2 g
  rw [hcol 0] at h0
  rw [hcol 1] at h1
  rw [hcol 2] at h2
  have he0 := ContinuousLinearMap.coeFn_compLpL (diagonalCLM 0) (du 0)
  have he1 := ContinuousLinearMap.coeFn_compLpL (diagonalCLM 1) (du 1)
  have he2 := ContinuousLinearMap.coeFn_compLpL (diagonalCLM 2) (du 2)
  have ha := Lp.coeFn_add (diagonalL2 0 (du 0)) (diagonalL2 1 (du 1))
  have hb := Lp.coeFn_add (diagonalL2 0 (du 0) + diagonalL2 1 (du 1)) (diagonalL2 2 (du 2))
  change ((FrontierPhysicalDivergence.traceL2 g : Field) : Space → Fiber) =ᵐ[volume]
    (fun x => FrontierPhysicalDivergence.traceCLM (g x)) at ht
  change ((diagonalL2 0 (du 0) : Field) : Space → Fiber) =ᵐ[volume]
    (fun x => diagonalCLM 0 (du 0 x)) at he0
  change ((diagonalL2 1 (du 1) : Field) : Space → Fiber) =ᵐ[volume]
    (fun x => diagonalCLM 1 (du 1 x)) at he1
  change ((diagonalL2 2 (du 2) : Field) : Space → Fiber) =ᵐ[volume]
    (fun x => diagonalCLM 2 (du 2 x)) at he2
  filter_upwards [ht, h0, h1, h2, he0, he1, he2, ha, hb] with x ht h0 h1 h2 he0 he1 he2 ha hb
  rw [ht, hb]
  simp only [Pi.add_apply] at ha ⊢
  rw [ha, he0, he1, he2, h0, h1, h2]
  ext i
  simp only [PiLp.add_apply, FrontierPhysicalDivergence.traceCLM_apply,
    diagonalCLM_apply, FrontierAWeakMatrixColumns.columnCLM_apply]

/-- The repeated scalar distributional divergence, formed from the diagonal
weak-derivative fields, equals the distribution of the L² gradient trace. -/
theorem distributional_divergence_eq_trace (g : MatrixL2) (du : Fin 3 → Field)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j g = du j) :
    Lp.toTemperedDistribution (FrontierPhysicalDivergence.traceL2 g) =
      Lp.toTemperedDistribution (diagonalL2 0 (du 0)) +
      Lp.toTemperedDistribution (diagonalL2 1 (du 1)) +
      Lp.toTemperedDistribution (diagonalL2 2 (du 2)) := by
  rw [traceL2_eq_diagonal_columns g du hcol]
  change (Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2) _ = _
  simp only [map_add]
  rfl

/-- Distributional divergence-free supplied weak derivatives yield the
helical projector split. -/
theorem split_of_distributional_divergence_zero
    (u : Field) (g : MatrixL2) (du : Fin 3 → Field)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j g = du j)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (hdiv : Lp.toTemperedDistribution (diagonalL2 0 (du 0)) +
      Lp.toTemperedDistribution (diagonalL2 1 (du 1)) +
      Lp.toTemperedDistribution (diagonalL2 2 (du 2)) = 0) :
    FrontierPhysicalProjectors.plusProjector u +
      FrontierPhysicalProjectors.minusProjector u = u := by
  apply FrontierDistributionTrace.split_of_distributional_gradient_trace_zero u g du hcol hweak
  rw [distributional_divergence_eq_trace g du hcol]
  exact hdiv

end FrontierDivergenceTraceIdentity

#print axioms FrontierDivergenceTraceIdentity.diagonalCLM_apply
#print axioms FrontierDivergenceTraceIdentity.traceL2_eq_diagonal_columns
#print axioms FrontierDivergenceTraceIdentity.distributional_divergence_eq_trace
#print axioms FrontierDivergenceTraceIdentity.split_of_distributional_divergence_zero
