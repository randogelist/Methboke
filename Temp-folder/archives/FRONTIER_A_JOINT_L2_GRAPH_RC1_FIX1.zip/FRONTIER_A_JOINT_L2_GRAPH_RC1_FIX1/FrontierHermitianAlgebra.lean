import FrontierVolumeSymmetry

/-! Candidate algebra for Hermitian-symmetric frequency L² fields. This is
only an algebraic prerequisite for an L²-density argument; it does not prove
closedness, Fourier symmetry of real fields, or physical realization.
No Lean compilation was performed locally. -/
noncomputable section
open MeasureTheory Filter
open FrontierAESymmetry

namespace FrontierHermitianAlgebra

abbrev Frequency := FrontierAESymmetry.Frequency
abbrev Fiber := FrontierAESymmetry.Fiber
abbrev FrequencyL2 := Lp Fiber 2 (volume : Measure Frequency)

theorem zero : HermitianAE volume (0 : FrequencyL2) := by
  have hz := MeasureTheory.Lp.coeFn_zero Fiber 2 (volume : Measure Frequency)
  have hzn := FrontierVolumeSymmetry.volume_reflectsAE _ hz
  filter_upwards [hz, hzn] with ξ hξ hneg
  intro j
  rw [hneg, hξ]
  simp

theorem add (f g : FrequencyL2) (hf : HermitianAE volume f)
    (hg : HermitianAE volume g) : HermitianAE volume (f + g) := by
  have ha := MeasureTheory.Lp.coeFn_add f g
  have han := FrontierVolumeSymmetry.volume_reflectsAE _ ha
  filter_upwards [hf, hg, ha, han] with ξ hf hg hξ hneg
  intro j
  rw [hneg, hξ]
  simp only [Pi.add_apply, PiLp.add_apply, star_add, hf j, hg j]

/-- Multiplication by a conjugation-fixed complex scalar preserves symmetry. -/
theorem smul (c : ℂ) (hc : star c = c) (f : FrequencyL2)
    (hf : HermitianAE volume f) : HermitianAE volume (c • f) := by
  have ha := MeasureTheory.Lp.coeFn_smul c f
  have han := FrontierVolumeSymmetry.volume_reflectsAE _ ha
  filter_upwards [hf, ha, han] with ξ hf hξ hneg
  intro j
  rw [hneg, hξ]
  simp only [Pi.smul_apply, PiLp.smul_apply, smul_eq_mul, star_mul, hc, hf j]
  exact mul_comm _ _

end FrontierHermitianAlgebra

#print axioms FrontierHermitianAlgebra.zero
#print axioms FrontierHermitianAlgebra.add
#print axioms FrontierHermitianAlgebra.smul
