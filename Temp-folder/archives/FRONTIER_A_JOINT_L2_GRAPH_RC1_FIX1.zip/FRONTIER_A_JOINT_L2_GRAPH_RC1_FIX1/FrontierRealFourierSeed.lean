import FrontierHermitianDensity
import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier

/-! Candidate seed-level Fourier reality, for scalar complex functions that
are real almost everywhere. It states no helical or Leray--Hopf result. The
L² vector-valued Schwartz seed transfer and real-field density still need
proof. No Lean compiler has been run locally. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierRealFourierSeed
abbrev Space := HelicalCoordinateBridge.Space

/-- The ordinary Fourier integral of an a.e.-real complex scalar function
has conjugate-reversal symmetry. The total Bochner integral convention is used. -/
theorem fourier_real_ae_conjugate (f : Space → ℂ)
    (hreal : ∀ᵐ x ∂(volume : Measure Space), star (f x) = f x)
    (ξ : Space) : FourierTransform.fourier f (-ξ) =
      star (FourierTransform.fourier f ξ) := by
  rw [Real.fourier_eq, Real.fourier_eq]
  change (∫ x : Space, Real.fourierChar (-inner ℝ x (-ξ)) • f x ∂volume) =
    (starRingEnd ℂ) (∫ x : Space, Real.fourierChar (-inner ℝ x ξ) • f x ∂volume)
  rw [← integral_conj]
  apply integral_congr_ae
  filter_upwards [hreal] with x hx
  change (starRingEnd ℂ) (f x) = f x at hx
  simp only [Circle.smul_def, smul_eq_mul, map_mul,
    Circle.starRingEnd_addChar, inner_neg_right, neg_neg, hx]

end FrontierRealFourierSeed

#print axioms FrontierRealFourierSeed.fourier_real_ae_conjugate
