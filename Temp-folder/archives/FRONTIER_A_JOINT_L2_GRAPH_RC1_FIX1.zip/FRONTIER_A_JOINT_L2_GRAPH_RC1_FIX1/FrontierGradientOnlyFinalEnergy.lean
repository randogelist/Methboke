import FrontierPhysicalTransferWithEnergy
import FrontierHalflineExhaustion

/-! Gradient-only Gram estimates. These theorems impose no divergence,
weak-gradient, velocity or field-identification premise: the two fields are
the project's gradient-derived Fourier pullbacks themselves. Identifying them
with the helical fields of a standard velocity remains a separate bridge.
No local Lean compilation. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierGradientOnlyFinalEnergy

abbrev Gradient := FrontierARealGradient.RealMatrix

local instance physicalRealL2 : InnerProductSpace ℝ FrontierPhysicalGramTransport.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierPhysicalGramTransport.PhysicalL2

/-- The final-energy estimate for arbitrary supplied real matrix data. -/
theorem gram_of_matrix_energy
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (g : τ → Gradient) (nu initialEnergy finalEnergy : ℝ)
    (hnu : 0 < nu) (hg : MemLp g 2 η)
    (henergy : finalEnergy + 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤
        (initialEnergy - finalEnergy) / (4 * nu) := by
  exact FrontierPhysicalTransferWithEnergy.gram_transfer_with_final_energy
    η g (fun t => FrontierPhysicalGramTransport.plusField (g t))
    (fun t => FrontierPhysicalGramTransport.minusField (g t))
    nu initialEnergy finalEnergy hnu hg henergy (Filter.Eventually.of_forall fun _ => rfl)
    (Filter.Eventually.of_forall fun _ => rfl)

/-- Uniform matrix dissipation budgets imply the half-line estimate, without
global gradient integrability as an independent assumption. -/
theorem gram_halfline_of_matrix_budgets
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (g : ℝ → Gradient) (nu E : ℝ) (hnu : 0 < nu)
    (hg : ∀ n : ℕ, MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure (n : ℝ)))
    (hbudget : ∀ n : ℕ, 2 * nu *
      (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure (n : ℝ))) ≤ E) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)))
      (volume.restrict (Set.Ioi 0)) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (volume.restrict (Set.Ioi 0))
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤ E / (4 * nu) := by
  apply FrontierHalflineExhaustion.nonneg_integrable_Ioi_of_bounded_Icc
  · intro t
    exact Real.sqrt_nonneg _
  · intro n
    have h := gram_of_matrix_energy (FrontierFiniteIntervalEnergy.timeMeasure (n : ℝ))
      g nu E 0 hnu (hg n) (by simpa using hbudget n)
    simpa only [FrontierFiniteIntervalEnergy.timeMeasure] using h.1
  · intro n
    have h := gram_of_matrix_energy (FrontierFiniteIntervalEnergy.timeMeasure (n : ℝ))
      g nu E 0 hnu (hg n) (by simpa using hbudget n)
    simpa only [FrontierFiniteIntervalEnergy.timeMeasure,
      FeffermanAHopfGramIntegral.gramSqrtIntegral, sub_zero] using h.2

end FrontierGradientOnlyFinalEnergy

#print axioms FrontierGradientOnlyFinalEnergy.gram_of_matrix_energy
#print axioms FrontierGradientOnlyFinalEnergy.gram_halfline_of_matrix_budgets
