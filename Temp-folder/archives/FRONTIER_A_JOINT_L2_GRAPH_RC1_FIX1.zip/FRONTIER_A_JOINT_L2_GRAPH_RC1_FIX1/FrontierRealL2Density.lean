import FrontierRealSchwartzFourier
import FrontierAFourierPostcompL2

/-! Candidate: every coordinatewise-real physical complex L² field is in the
L² closure of real Schwartz vector fields. The real-part retraction is applied
to the dense set of arbitrary complex Schwartz fields. This does not identify
any Navier--Stokes trajectory, nor does it establish the helical dissipation
identification. No local Lean compiler has been run. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierRealL2Density

abbrev Space := FrontierRealSchwartzFourier.Space
abbrev Fiber := FrontierRealSchwartzFourier.Fiber
abbrev Field := FrontierRealSchwartzFourier.Field

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩

/-- Keep the real part of every coordinate, as a real-linear map. -/
def fiberReal : Fiber →ₗ[ℝ] Fiber where
  toFun v := WithLp.toLp 2 (fun j => ((v j).re : ℂ))
  map_add' v w := by ext j; simp
  map_smul' c v := by ext j; simp

def fiberRealCLM : Fiber →L[ℝ] Fiber := fiberReal.toContinuousLinearMap

theorem fiberReal_apply (v : Fiber) (j : Fin 3) :
    fiberRealCLM v j = ((v j).re : ℂ) := by rfl

def realPartL2 : Field →L[ℝ] Field :=
  ContinuousLinearMap.compLpL 2 (volume : Measure Space) fiberRealCLM

theorem realPartL2_ae (u : Field) :
    (realPartL2 u : Space → Fiber) =ᵐ[volume]
      fun x => fiberRealCLM ((u : Space → Fiber) x) := by
  exact ContinuousLinearMap.coeFn_compLpL fiberRealCLM u

/-- The real retraction fixes every field real coordinatewise almost everywhere. -/
theorem realPartL2_eq_self_of_real_ae (u : Field)
    (hu : ∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3,
      star ((u : Space → Fiber) x j) = (u : Space → Fiber) x j) :
    realPartL2 u = u := by
  apply Lp.ext
  filter_upwards [realPartL2_ae u, hu] with x hx hr
  rw [hx]
  ext j
  rw [fiberReal_apply]
  apply Complex.conj_eq_iff_re.mp
  exact hr j

/-- Postcomposition by real part commutes with Schwartz-to-L². -/
theorem realPartL2_toLp (f : SchwartzMap Space Fiber) :
    realPartL2 (f.toLp 2 volume) =
      ((SchwartzMap.postcompCLM fiberRealCLM) f).toLp 2 volume := by
  apply Lp.ext
  filter_upwards [realPartL2_ae (f.toLp 2 volume), f.coeFn_toLp 2 volume,
    ((SchwartzMap.postcompCLM fiberRealCLM) f).coeFn_toLp 2 volume] with x hR hf hg
  simpa only [SchwartzMap.postcompCLM_apply, hf, hg] using hR

/-- Real Schwartz vectors are dense in the coordinatewise-real physical L² subspace. -/
theorem real_schwartz_dense_at_real (u : Field)
    (hu : ∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3,
      star ((u : Space → Fiber) x j) = (u : Space → Fiber) x j) :
    u ∈ closure {v : Field | ∃ f : SchwartzMap Space Fiber,
      (∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3, star (f x j) = f x j) ∧
      f.toLp 2 volume = v} := by
  let S : Set Field := {v : Field | ∃ f : SchwartzMap Space Fiber,
      (∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3, star (f x j) = f x j) ∧
      f.toLp 2 volume = v}
  have hall : ∀ v : Field, realPartL2 v ∈ closure S := by
    intro v
    let p : Field → Prop := fun w => realPartL2 w ∈ closure S
    change p v
    apply DenseRange.induction_on (p := p)
      (SchwartzMap.denseRange_toLpCLM (p := 2) ENNReal.ofNat_ne_top) v
    · exact isClosed_closure.preimage realPartL2.continuous
    · intro f
      dsimp only [p]
      simp only [SchwartzMap.toLpCLM_apply]
      rw [realPartL2_toLp]
      apply subset_closure
      refine ⟨(SchwartzMap.postcompCLM fiberRealCLM) f, ?_, rfl⟩
      filter_upwards [] with x
      intro j
      rw [SchwartzMap.postcompCLM_apply, fiberReal_apply]
      simp
  have h := hall u
  rw [realPartL2_eq_self_of_real_ae u hu] at h
  exact h

/-- The Fourier transform of any coordinatewise-real physical L² field is Hermitian. -/
theorem fourier_hermitian_of_real_l2 (u : Field)
    (hu : ∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3,
      star ((u : Space → Fiber) x j) = (u : Space → Fiber) x j) :
    FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate u) := by
  exact FrontierRealSchwartzFourier.fourier_hermitian_of_real_schwartz_closure u
    (real_schwartz_dense_at_real u hu)

end FrontierRealL2Density

#print axioms FrontierRealL2Density.fiberReal_apply
#print axioms FrontierRealL2Density.realPartL2_ae
#print axioms FrontierRealL2Density.realPartL2_eq_self_of_real_ae
#print axioms FrontierRealL2Density.realPartL2_toLp
#print axioms FrontierRealL2Density.real_schwartz_dense_at_real
#print axioms FrontierRealL2Density.fourier_hermitian_of_real_l2
