import FrontierRealVelocityEmbedding
import FrontierHermitianAlgebra

/-!
Candidate converse to Fourier Hermitian symmetry for complex physical L².
No local Lean execution. This proves neither a Leray–Hopf existence theorem
nor an identification of the project graph operator with a Stokes square root.
-/
noncomputable section
open MeasureTheory Filter
open FrontierAESymmetry

namespace FrontierPhysicalReality

abbrev Space := FrontierRealL2Density.Space
abbrev Fiber := FrontierRealL2Density.Fiber
abbrev Field := FrontierRealL2Density.Field
abbrev Frequency := FrontierHermitianAlgebra.Frequency
abbrev FrequencyL2 := FrontierHermitianAlgebra.FrequencyL2

def RealAE (u : Field) : Prop :=
  ∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3,
    star ((u : Space → Fiber) x j) = (u : Space → Fiber) x j

theorem realPart_real (u : Field) : RealAE (FrontierRealL2Density.realPartL2 u) := by
  filter_upwards [FrontierRealL2Density.realPartL2_ae u] with x hx
  intro j
  rw [hx, FrontierRealL2Density.fiberReal_apply]
  simp

/-- The only frequency field for which both f and i f are Hermitian is zero. -/
theorem hermitian_and_i_hermitian_eq_zero (f : FrequencyL2)
    (hf : HermitianAE volume f)
    (hif : HermitianAE volume ((Complex.I : ℂ) • f)) : f = 0 := by
  apply Lp.ext
  have hs := Lp.coeFn_smul (Complex.I : ℂ) f
  have hsn := FrontierVolumeSymmetry.volume_reflectsAE _ hs
  have hz := Lp.coeFn_zero Fiber 2 (volume : Measure Frequency)
  filter_upwards [hf, hif, hs, hsn, hz] with ξ hξ hi hsm hsmn hzero
  rw [hzero]
  ext j
  have h := hi j
  rw [hsmn, hsm] at h
  simp only [Pi.smul_apply, PiLp.smul_apply, smul_eq_mul, star_mul] at h
  rw [hξ j] at h
  have hr := congrArg Complex.re h
  have him := congrArg Complex.im h
  simp [Complex.mul_re, Complex.mul_im] at hr him
  apply Complex.ext <;> simp <;> linarith

/-- Re u + i Im u = u, with both terms formed by the existing real-part map. -/
theorem real_imag_decomposition (u : Field) :
    u = FrontierRealL2Density.realPartL2 u +
      (Complex.I : ℂ) • FrontierRealL2Density.realPartL2 ((-Complex.I : ℂ) • u) := by
  apply Lp.ext
  have hA := Lp.coeFn_add (FrontierRealL2Density.realPartL2 u)
    ((Complex.I : ℂ) • FrontierRealL2Density.realPartL2 ((-Complex.I : ℂ) • u))
  have hB := Lp.coeFn_smul (Complex.I : ℂ)
    (FrontierRealL2Density.realPartL2 ((-Complex.I : ℂ) • u))
  have hC := Lp.coeFn_smul (-Complex.I : ℂ) u
  filter_upwards [hA, hB, hC, FrontierRealL2Density.realPartL2_ae u,
    FrontierRealL2Density.realPartL2_ae ((-Complex.I : ℂ) • u)] with x ha hb hc hr hs
  rw [ha]
  simp only [Pi.add_apply]
  rw [hb]
  simp only [Pi.smul_apply]
  rw [hr, hs, hc]
  ext j
  simp only [Pi.add_apply, Pi.smul_apply, PiLp.add_apply, PiLp.smul_apply,
    FrontierRealL2Density.fiberReal_apply, smul_eq_mul]
  apply Complex.ext <;> simp [Complex.mul_re, Complex.mul_im]

/-- Fourier Hermitian symmetry exactly characterizes physically real L² fields. -/
theorem real_iff_fourier_hermitian (u : Field) :
    RealAE u ↔ HermitianAE volume (FrontierACoordinateEquiv.fourierCoordinate u) := by
  constructor
  · exact FrontierRealL2Density.fourier_hermitian_of_real_l2 u
  · intro hu
    let r := FrontierRealL2Density.realPartL2 u
    let s := FrontierRealL2Density.realPartL2 ((-Complex.I : ℂ) • u)
    have hr : HermitianAE volume (FrontierACoordinateEquiv.fourierCoordinate r) :=
      FrontierRealL2Density.fourier_hermitian_of_real_l2 r (realPart_real u)
    have hs : HermitianAE volume (FrontierACoordinateEquiv.fourierCoordinate s) :=
      FrontierRealL2Density.fourier_hermitian_of_real_l2 s (realPart_real _)
    have hdiff := FrontierHermitianAlgebra.add _ _ hu
      (FrontierHermitianAlgebra.smul (-1 : ℂ) (by simp) _ hr)
    have hdiff' : HermitianAE volume ((Complex.I : ℂ) •
        FrontierACoordinateEquiv.fourierCoordinate s) := by
      have hid : FrontierACoordinateEquiv.fourierCoordinate u +
          (-1 : ℂ) • FrontierACoordinateEquiv.fourierCoordinate r =
          (Complex.I : ℂ) • FrontierACoordinateEquiv.fourierCoordinate s := by
        rw [real_imag_decomposition u]
        simp only [map_add, map_smul, neg_one_smul]
        abel
      rw [← hid]
      exact hdiff
    have hs0 := hermitian_and_i_hermitian_eq_zero _ hs hdiff'
    have hs0' : s = 0 := by
      apply FrontierACoordinateEquiv.fourierCoordinate.injective
      simpa using hs0
    have hu' : u = r := by
      rw [real_imag_decomposition u]
      change r + (Complex.I : ℂ) • s = r
      simp [hs0']
    rw [hu']
    exact realPart_real u

theorem plus_real_of_real_velocity (u : FrontierRealVelocityEmbedding.RealField) :
    RealAE (FrontierACoordinateEquiv.plusPullback
      (FrontierRealVelocityEmbedding.complexifyL2 u)) := by
  apply (real_iff_fourier_hermitian _).2
  exact FrontierRealVelocityEmbedding.plus_fourier_hermitian_of_real_field u

theorem minus_real_of_real_velocity (u : FrontierRealVelocityEmbedding.RealField) :
    RealAE (FrontierACoordinateEquiv.minusPullback
      (FrontierRealVelocityEmbedding.complexifyL2 u)) := by
  apply (real_iff_fourier_hermitian _).2
  exact FrontierRealVelocityEmbedding.minus_fourier_hermitian_of_real_field u

end FrontierPhysicalReality

#print axioms FrontierPhysicalReality.real_iff_fourier_hermitian
#print axioms FrontierPhysicalReality.plus_real_of_real_velocity
#print axioms FrontierPhysicalReality.minus_real_of_real_velocity
