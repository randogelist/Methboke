import FrontierSpectralClosure

/-!
A-tier candidate: lift the audited pointwise helical conjugate-reversal
identities to the existing frequency L² multipliers. Reflection of almost-
everywhere events is an explicit property of the supplied measure. This file
neither proves that volume has this property nor identifies Fourier symmetry
with real-valued physical fields. No Lean compiler was run locally.
-/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierAESymmetry

abbrev Frequency := HelicalConcreteSymbol.Frequency
abbrev Fiber := FeffermanHelicalOrthogonal.Fiber

/-- Conjugate reversal for selected L² representatives, understood a.e. -/
def HermitianAE (μ : Measure Frequency) (f : Lp Fiber 2 μ) : Prop :=
  ∀ᵐ ξ ∂μ, ∀ j : Fin 3,
    (f : Frequency → Fiber) (-ξ) j = star ((f : Frequency → Fiber) ξ j)

/-- Reflection transports every a.e. event to an a.e. reflected event.
It is a measure property and is an explicit hypothesis below. -/
def ReflectsAE (μ : Measure Frequency) : Prop :=
  ∀ P : Frequency → Prop, (∀ᵐ ξ ∂μ, P ξ) → ∀ᵐ ξ ∂μ, P (-ξ)

/-- A change of representatives preserves Hermitian symmetry, provided
reflection also transports the a.e. equality. -/
theorem hermitianAE_congr (μ : Measure Frequency) (f g : Lp Fiber 2 μ)
    (hreflect : ReflectsAE μ)
    (hfg : (f : Frequency → Fiber) =ᵐ[μ] (g : Frequency → Fiber))
    (hf : HermitianAE μ f) : HermitianAE μ g := by
  have hfgneg := hreflect _ hfg
  filter_upwards [hf, hfg, hfgneg] with ξ hsym hξ hneg
  intro j
  rw [← hneg, ← hξ]
  exact hsym j

/-- The concrete plus multiplier preserves a.e. conjugate reversal,
assuming only the measure's a.e.-reflection property. -/
theorem plus_preserves_hermitianAE (μ : Measure Frequency) (f : Lp Fiber 2 μ)
    (hreflect : ReflectsAE μ) (hf : HermitianAE μ f) :
    HermitianAE μ (plusMultiplier μ f) := by
  have happly := plus_multiplier_ae μ f
  have happlyneg := hreflect _ happly
  filter_upwards [hf, happly, happlyneg] with ξ hsym hξ hneg
  intro i
  rw [hneg, hξ]
  have hv : (f : Frequency → Fiber) (-ξ) =
      WithLp.toLp 2 (fun j => star ((f : Frequency → Fiber) ξ j)) := by
    ext j
    exact hsym j
  have hm := FrontierRealSymmetry.plus_mulVec_conjugate_reversal
    (ξ 0) (ξ 1) (ξ 2) (fun j => (f : Frequency → Fiber) ξ j) i
  simpa [plus_action, FeffermanHelicalFiberFrequency.plusMap,
    Matrix.toEuclideanLin, Matrix.toLpLin_apply, hv] using hm

/-- The concrete minus multiplier satisfies the same a.e. property. -/
theorem minus_preserves_hermitianAE (μ : Measure Frequency) (f : Lp Fiber 2 μ)
    (hreflect : ReflectsAE μ) (hf : HermitianAE μ f) :
    HermitianAE μ (minusMultiplier μ f) := by
  have happly := minus_multiplier_ae μ f
  have happlyneg := hreflect _ happly
  filter_upwards [hf, happly, happlyneg] with ξ hsym hξ hneg
  intro i
  rw [hneg, hξ]
  have hv : (f : Frequency → Fiber) (-ξ) =
      WithLp.toLp 2 (fun j => star ((f : Frequency → Fiber) ξ j)) := by
    ext j
    exact hsym j
  have hm := FrontierRealSymmetry.minus_mulVec_conjugate_reversal
    (ξ 0) (ξ 1) (ξ 2) (fun j => (f : Frequency → Fiber) ξ j) i
  simpa [minus_action, FeffermanHelicalFiberFrequency.minusMap,
    Matrix.toEuclideanLin, Matrix.toLpLin_apply, hv] using hm

end FrontierAESymmetry

#print axioms FrontierAESymmetry.hermitianAE_congr
#print axioms FrontierAESymmetry.plus_preserves_hermitianAE
#print axioms FrontierAESymmetry.minus_preserves_hermitianAE
