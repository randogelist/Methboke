import FrontierLiteraturePhysicalImplication

/-! The concrete gradient-derived Fourier pullbacks have the velocity
dissipation symbols under the supplied weak-gradient equations. This is an
internal model identity; matching the pullbacks to independently defined
physical Stokes/helicity fields, and obtaining the weak-gradient and energy
data from Leray--Hopf solutions, remains open. No local Lean run. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierCanonicalPhysicalSymbols

abbrev RealVelocity := FrontierLiteraturePhysicalImplication.RealVelocity
abbrev Gradient := FrontierLiteraturePhysicalImplication.Gradient
abbrev PhysicalField := FrontierLiteraturePhysicalImplication.PhysicalField
abbrev Frequency := FrontierPhysicalIdentification.Frequency
abbrev Fiber := FrontierPhysicalIdentification.Fiber

local instance physicalRealL2 : InnerProductSpace ℝ PhysicalField :=
  InnerProductSpace.rclikeToReal ℂ PhysicalField

/-- The canonical two fields obey the physical-composition Fourier premises
whenever the supplied matrix represents the weak gradient of the velocity. -/
theorem canonical_symbols_of_weak_gradient
    (u : FrontierAWeakTimeGram.Field) (g : Gradient)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) :
    ((FrontierPhysicalGramTransport.fourierCoordinateReal
      (FrontierPhysicalGramTransport.plusField g) : Frequency → Fiber) =ᵐ[volume]
      fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol u ξ)) ∧
    ((FrontierPhysicalGramTransport.fourierCoordinateReal
      (FrontierPhysicalGramTransport.minusField g) : Frequency → Fiber) =ᵐ[volume]
      fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol u ξ)) := by
  have hs := FrontierMultiplierBridge.real_gradient_spectrum_eq_symbol u g
    (fun j => FrontierGradientAdapter.gradientColumn g j) (fun _ => rfl) hweak
  constructor
  · rw [FrontierPhysicalGramTransport.plusField_fourier]
    filter_upwards [plus_multiplier_ae (volume : Measure Frequency)
      (FrontierARealGradient.realGradientSpectrum g), hs] with ξ hp hξ
    rw [hp, hξ]
  · rw [FrontierPhysicalGramTransport.minusField_fourier]
    filter_upwards [minus_multiplier_ae (volume : Measure Frequency)
      (FrontierARealGradient.realGradientSpectrum g), hs] with ξ hm hξ
    rw [hm, hξ]

/-- Under the explicit time-slice gradient and energy inputs, the concrete
pullbacks satisfy the finite-interval bound. The Fourier-symbol premises of
the prior implication are now proved, not assumed. -/
theorem canonical_gram_from_explicit_inputs
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2]
    [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → RealVelocity) (u0 : RealVelocity) (g : ℝ → Gradient)
    (nu : ℝ) (hnu : 0 < nu) (hinit : u 0 = u0)
    (hg : ∀ T : ℝ, 0 ≤ T → MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T))
    (henergy : ∀ T : ℝ, 0 ≤ T →
      ‖u T‖ ^ 2 + 2 * nu *
        (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ T : ℝ, 0 ≤ T →
      ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T), ∀ j,
        Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
        LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
          (Lp.toTemperedDistribution (FrontierRealVelocityEmbedding.complexifyL2 (u t)))) :
    ∀ T : ℝ, 0 ≤ T →
      Integrable (FeffermanAHopfGramIntegral.gramSqrt
        (fun t => FrontierPhysicalGramTransport.plusField (g t))
        (fun t => FrontierPhysicalGramTransport.minusField (g t)))
        (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral
        (FrontierFiniteIntervalEnergy.timeMeasure T)
        (fun t => FrontierPhysicalGramTransport.plusField (g t))
        (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  have hp : ∀ T : ℝ, 0 ≤ T → ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      (FrontierPhysicalGramTransport.fourierCoordinateReal
        (FrontierPhysicalGramTransport.plusField (g t)) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ) := by
    intro T hT
    filter_upwards [hweak T hT] with t ht
    exact (canonical_symbols_of_weak_gradient _ _ ht).1
  have hm : ∀ T : ℝ, 0 ≤ T → ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      (FrontierPhysicalGramTransport.fourierCoordinateReal
        (FrontierPhysicalGramTransport.minusField (g t)) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ) := by
    intro T hT
    filter_upwards [hweak T hT] with t ht
    exact (canonical_symbols_of_weak_gradient _ _ ht).2
  exact FrontierLiteraturePhysicalImplication.physical_gram_from_explicit_inputs
    u u0 g (fun t => FrontierPhysicalGramTransport.plusField (g t))
    (fun t => FrontierPhysicalGramTransport.minusField (g t)) nu hnu hinit hg henergy hweak hp hm

end FrontierCanonicalPhysicalSymbols

#print axioms FrontierCanonicalPhysicalSymbols.canonical_symbols_of_weak_gradient
#print axioms FrontierCanonicalPhysicalSymbols.canonical_gram_from_explicit_inputs
