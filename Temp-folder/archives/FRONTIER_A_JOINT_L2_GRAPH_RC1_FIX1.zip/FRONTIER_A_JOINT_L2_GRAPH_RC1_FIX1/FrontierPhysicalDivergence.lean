import FrontierWeakSplitBridge
import FrontierAWeakMatrixColumns

/-! Candidate physical L² divergence bridge. The gradient and its columns are
still supplied, as is the vanishing of their trace in L². The latter is the
concrete L² divergence-free condition for this weak gradient; no equivalence
with an independently defined distributional divergence is claimed here.
No local Lean compilation has been performed. -/
noncomputable section
open MeasureTheory Filter FourierTransform
namespace FrontierPhysicalDivergence

abbrev Space := FrontierAWeakMatrixColumns.Space
abbrev GradFiber := FrontierAWeakMatrixColumns.GradFiber
abbrev Fiber := FrontierAWeakMatrixColumns.Fiber
abbrev MatrixL2 := FrontierAWeakMatrixColumns.MatrixL2
abbrev Field := FrontierAWeakMatrixColumns.Field

/-- Repeat the trace in each coordinate so the established vector-valued
Fourier postcomposition theorem can be applied. -/
def traceMap : GradFiber →ₗ[ℂ] Fiber where
  toFun g := WithLp.toLp 2 (fun _ : Fin 3 => g (0, 0) + g (1, 1) + g (2, 2))
  map_add' g h := by ext i; simp <;> ring
  map_smul' c g := by ext i; simp <;> ring

def traceCLM : GradFiber →L[ℂ] Fiber :=
  LinearMap.toContinuousLinearMap traceMap

theorem traceCLM_apply (g : GradFiber) (i : Fin 3) :
    traceCLM g i = g (0, 0) + g (1, 1) + g (2, 2) := by
  rfl

def traceL2 : MatrixL2 →L[ℂ] Field :=
  ContinuousLinearMap.compLpL 2 (volume : Measure Space) traceCLM

/-- If the supplied L² gradient has zero trace, its Fourier transform has
zero trace, hence so do the Fourier transforms of its weak derivative columns. -/
theorem fourier_trace_zero_of_traceL2_eq_zero
    (g : MatrixL2) (du : Fin 3 → Field)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j g = du j)
    (hdiv : traceL2 g = 0) :
    ∀ᵐ ξ ∂(volume : Measure Space),
      FrontierAWeakRieszBridge.weakFourierMatrix du ξ 0 0 +
      FrontierAWeakRieszBridge.weakFourierMatrix du ξ 1 1 +
      FrontierAWeakRieszBridge.weakFourierMatrix du ξ 2 2 = 0 := by
  have hz : traceL2 (FourierTransform.fourier g) = 0 := by
    change (ContinuousLinearMap.compLpL 2 (volume : Measure Space) traceCLM)
      (FourierTransform.fourier g) = 0
    rw [← FrontierAFourierPostcompL2.fourier_postcomp_l2 traceCLM g]
    change FourierTransform.fourier (traceL2 g) = 0
    rw [hdiv]
    simp
  have hcomp := ContinuousLinearMap.coeFn_compLpL traceCLM (FourierTransform.fourier g)
  have hzero := MeasureTheory.Lp.coeFn_zero Fiber 2 (volume : Measure Space)
  have hcols := FrontierAWeakMatrixColumns.matrix_fourier_eq_weak_columns g du hcol
  change ((traceL2 (FourierTransform.fourier g) : Field) : Space → Fiber) =ᵐ[volume]
    (fun ξ => traceCLM ((FourierTransform.fourier g : MatrixL2) ξ)) at hcomp
  rw [hz] at hcomp
  filter_upwards [hcomp, hzero, hcols] with ξ hcomp hzero hcols
  have hvalue := congrArg (fun v : Fiber => v 0) (hcomp.symm.trans hzero)
  rw [traceCLM_apply, hcols 0 0, hcols 1 1, hcols 2 2] at hvalue
  simpa using hvalue

/-- Projector split from a weak gradient whose L² trace vanishes. -/
theorem split_of_weak_gradient_trace_zero
    (u : Field) (g : MatrixL2) (du : Fin 3 → Field)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j g = du j)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (hdiv : traceL2 g = 0) :
    FrontierPhysicalProjectors.plusProjector u +
      FrontierPhysicalProjectors.minusProjector u = u := by
  exact FrontierWeakSplitBridge.split_of_weak_derivatives_and_fourier_trace u du hweak
    (fourier_trace_zero_of_traceL2_eq_zero g du hcol hdiv)

end FrontierPhysicalDivergence

#print axioms FrontierPhysicalDivergence.traceCLM_apply
#print axioms FrontierPhysicalDivergence.fourier_trace_zero_of_traceL2_eq_zero
#print axioms FrontierPhysicalDivergence.split_of_weak_gradient_trace_zero
