import FrontierDomainLinear

/-! Candidate commutation of the constructed helical projectors with the
Fourier graph operator `dissipation`. These results concern the existing
Fourier-defined constructions; no identification with an independent Stokes
square root, real-valued physical projection, or Leray--Hopf solution is
asserted. External Lean compilation and axiom audit are required. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierProjectedDissipation
abbrev Field := FrontierSpectralOperator.Field
abbrev Frequency := FrontierSpectralOperator.Frequency
abbrev Fiber := FrontierSpectralOperator.Fiber
abbrev Domain := FrontierSpectralOperator.Domain

/-- The helical fiber symbols are complex-linear, although their L² lifts
are exposed as real-linear operators. -/
theorem plusOp_complex_smul (ξ : Frequency) (c : ℂ) (v : Fiber) :
    plusOp ξ (c • v) = c • plusOp ξ v := by
  exact (matrixToComplex (FeffermanHelicalFrequency.plus (ξ 0) (ξ 1) (ξ 2))).map_smul c v

theorem minusOp_complex_smul (ξ : Frequency) (c : ℂ) (v : Fiber) :
    minusOp ξ (c • v) = c • minusOp ξ v := by
  exact (matrixToComplex (FeffermanHelicalFrequency.minus (ξ 0) (ξ 1) (ξ 2))).map_smul c v

def weight (ξ : Frequency) : ℂ :=
  ((2 * Real.pi : ℝ) : ℂ) * (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2) : ℂ)

theorem velocitySymbol_eq_weight (u : Field) (ξ : Frequency) :
    FrontierMultiplierBridge.velocitySymbol u ξ =
      weight ξ • (FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ) := by
  ext i
  simp [FrontierMultiplierBridge.velocitySymbol, weight, PiLp.smul_apply, smul_eq_mul]

theorem velocitySymbol_plus (u : Field) :
    FrontierMultiplierBridge.velocitySymbol (FrontierPhysicalProjectors.plusProjector u) =ᵐ[volume]
      fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol u ξ) := by
  have hp := FrontierDomainLinear.fourierCoordinate_ae (FrontierPhysicalProjectors.plusProjector u)
  have hu := FrontierDomainLinear.fourierCoordinate_ae u
  change (FrontierPhysicalGramTransport.fourierCoordinateReal
    (FrontierPhysicalProjectors.plusProjector u) : Frequency → Fiber) =ᵐ[volume] _ at hp
  rw [FrontierPhysicalProjectors.plus_fourier] at hp
  have hm := plus_multiplier_ae (volume : Measure Frequency)
    (FrontierPhysicalGramTransport.fourierCoordinateReal u)
  filter_upwards [hp, hu, hm] with ξ hp hu hm
  have hp' : (FourierTransform.fourier (FrontierPhysicalProjectors.plusProjector u) : Field)
      (WithLp.toLp 2 ξ) = plusOp ξ ((FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ)) := by
    rw [← hp, hm]
    exact congrArg (plusOp ξ) hu
  simp only [velocitySymbol_eq_weight, hp', plusOp_complex_smul]

theorem velocitySymbol_minus (u : Field) :
    FrontierMultiplierBridge.velocitySymbol (FrontierPhysicalProjectors.minusProjector u) =ᵐ[volume]
      fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol u ξ) := by
  have hp := FrontierDomainLinear.fourierCoordinate_ae (FrontierPhysicalProjectors.minusProjector u)
  have hu := FrontierDomainLinear.fourierCoordinate_ae u
  change (FrontierPhysicalGramTransport.fourierCoordinateReal
    (FrontierPhysicalProjectors.minusProjector u) : Frequency → Fiber) =ᵐ[volume] _ at hp
  rw [FrontierPhysicalProjectors.minus_fourier] at hp
  have hm := minus_multiplier_ae (volume : Measure Frequency)
    (FrontierPhysicalGramTransport.fourierCoordinateReal u)
  filter_upwards [hp, hu, hm] with ξ hp hu hm
  have hp' : (FourierTransform.fourier (FrontierPhysicalProjectors.minusProjector u) : Field)
      (WithLp.toLp 2 ξ) = minusOp ξ ((FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ)) := by
    rw [← hp, hm]
    exact congrArg (minusOp ξ) hu
  simp only [velocitySymbol_eq_weight, hp', minusOp_complex_smul]

theorem plus_has_dissipation (u : Domain) :
    FrontierDissipationDomain.HasDissipationSymbol (FrontierPhysicalProjectors.plusProjector u.val) := by
  refine ⟨FrontierPhysicalProjectors.plusProjector (FrontierSpectralOperator.dissipation u), ?_⟩
  rw [FrontierPhysicalProjectors.plus_fourier]
  filter_upwards [plus_multiplier_ae (volume : Measure Frequency)
      (FrontierPhysicalGramTransport.fourierCoordinateReal (FrontierSpectralOperator.dissipation u)),
      FrontierSpectralOperator.dissipation_fourier u, velocitySymbol_plus u.val] with ξ hm hu hp
  rw [hm, hu, hp]

theorem minus_has_dissipation (u : Domain) :
    FrontierDissipationDomain.HasDissipationSymbol (FrontierPhysicalProjectors.minusProjector u.val) := by
  refine ⟨FrontierPhysicalProjectors.minusProjector (FrontierSpectralOperator.dissipation u), ?_⟩
  rw [FrontierPhysicalProjectors.minus_fourier]
  filter_upwards [minus_multiplier_ae (volume : Measure Frequency)
      (FrontierPhysicalGramTransport.fourierCoordinateReal (FrontierSpectralOperator.dissipation u)),
      FrontierSpectralOperator.dissipation_fourier u, velocitySymbol_minus u.val] with ξ hm hu hp
  rw [hm, hu, hp]

def plusDomain (u : Domain) : Domain := ⟨FrontierPhysicalProjectors.plusProjector u.val, plus_has_dissipation u⟩
def minusDomain (u : Domain) : Domain := ⟨FrontierPhysicalProjectors.minusProjector u.val, minus_has_dissipation u⟩

theorem dissipation_plus (u : Domain) :
    FrontierSpectralOperator.dissipation (plusDomain u) =
      FrontierPhysicalProjectors.plusProjector (FrontierSpectralOperator.dissipation u) := by
  apply FrontierSpectralOperator.dissipation_eq_of_symbol
  rw [FrontierPhysicalProjectors.plus_fourier]
  filter_upwards [plus_multiplier_ae (volume : Measure Frequency)
      (FrontierPhysicalGramTransport.fourierCoordinateReal (FrontierSpectralOperator.dissipation u)),
      FrontierSpectralOperator.dissipation_fourier u, velocitySymbol_plus u.val] with ξ hm hu hp
  change _ = FrontierMultiplierBridge.velocitySymbol (FrontierPhysicalProjectors.plusProjector u.val) ξ
  rw [hm, hu, hp]

theorem dissipation_minus (u : Domain) :
    FrontierSpectralOperator.dissipation (minusDomain u) =
      FrontierPhysicalProjectors.minusProjector (FrontierSpectralOperator.dissipation u) := by
  apply FrontierSpectralOperator.dissipation_eq_of_symbol
  rw [FrontierPhysicalProjectors.minus_fourier]
  filter_upwards [minus_multiplier_ae (volume : Measure Frequency)
      (FrontierPhysicalGramTransport.fourierCoordinateReal (FrontierSpectralOperator.dissipation u)),
      FrontierSpectralOperator.dissipation_fourier u, velocitySymbol_minus u.val] with ξ hm hu hp
  change _ = FrontierMultiplierBridge.velocitySymbol (FrontierPhysicalProjectors.minusProjector u.val) ξ
  rw [hm, hu, hp]

end FrontierProjectedDissipation

#print axioms FrontierProjectedDissipation.plusOp_complex_smul
#print axioms FrontierProjectedDissipation.minusOp_complex_smul
#print axioms FrontierProjectedDissipation.velocitySymbol_eq_weight
#print axioms FrontierProjectedDissipation.velocitySymbol_plus
#print axioms FrontierProjectedDissipation.velocitySymbol_minus
#print axioms FrontierProjectedDissipation.plus_has_dissipation
#print axioms FrontierProjectedDissipation.minus_has_dissipation
#print axioms FrontierProjectedDissipation.dissipation_plus
#print axioms FrontierProjectedDissipation.dissipation_minus
