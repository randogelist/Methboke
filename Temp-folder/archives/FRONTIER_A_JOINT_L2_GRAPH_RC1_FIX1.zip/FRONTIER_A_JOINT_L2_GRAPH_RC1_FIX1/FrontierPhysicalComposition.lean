import FrontierPhysicalIdentification

/-!
Conditional composition of the externally reported v0.31 bridge theorems.
No Leray–Hopf solution, Stokes operator, or physical Fourier-symbol identity
is constructed here. The weak-gradient, energy, and symbol premises remain
explicit. This file is an uncompiled candidate.
-/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierPhysicalComposition

local instance physicalRealL2 :
    InnerProductSpace ℝ FrontierPhysicalGramTransport.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierPhysicalGramTransport.PhysicalL2

/-- For supplied fields satisfying the listed weak-gradient, terminal-energy,
and Fourier-symbol premises, the corresponding Gram integrand is integrable
and has the expected bound. The fields are not asserted to arise from an
actual Leray–Hopf solution. -/
theorem physical_fields_gram_from_energy_and_symbols
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → FrontierAWeakTimeGram.Field)
    (g : τ → FrontierARealGradient.RealMatrix)
    (vp vm : τ → FrontierPhysicalGramTransport.PhysicalL2)
    (D : τ → ℝ) (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : AEStronglyMeasurable g η) (hD : Integrable D η)
    (hidentify : D =ᵐ[η] fun t => ‖g t‖ ^ 2)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, D t ∂η) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂η, ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t)))
    (hp : ∀ᵐ t ∂η,
      (FrontierPhysicalGramTransport.fourierCoordinateReal (vp t) :
        FrontierPhysicalIdentification.Frequency → FrontierPhysicalIdentification.Fiber) =ᵐ[volume]
      fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol (u t) ξ))
    (hm : ∀ᵐ t ∂η,
      (FrontierPhysicalGramTransport.fourierCoordinateReal (vm t) :
        FrontierPhysicalIdentification.Frequency → FrontierPhysicalIdentification.Fiber) =ᵐ[volume]
      fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol (u t) ξ)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt vp vm) η ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral η vp vm ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  have hbound := FrontierGradientAdapter.pullback_gram_from_gradient_columns
    η u g D u0 uT nu hnu hg hD hidentify henergy hweak
  have hcol : ∀ᵐ t ∂η, ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 (g t)) =
      FrontierGradientAdapter.gradientColumn (g t) j :=
    Filter.Eventually.of_forall (fun _ _ => rfl)
  exact FrontierPhysicalIdentification.gram_bound_of_symbols η u g
    (fun t j => FrontierGradientAdapter.gradientColumn (g t) j)
    vp vm (‖u0‖ ^ 2 / (4 * nu)) hcol hweak hp hm hbound

end FrontierPhysicalComposition

#print axioms FrontierPhysicalComposition.physical_fields_gram_from_energy_and_symbols
