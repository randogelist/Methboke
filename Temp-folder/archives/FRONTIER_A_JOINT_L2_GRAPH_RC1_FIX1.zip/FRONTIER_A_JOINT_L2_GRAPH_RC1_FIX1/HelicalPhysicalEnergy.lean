import HelicalEnergyBridge

/-!
Candidate transport of the concrete frequency-space Gram bound through a
supplied real linear isometric equivalence. This does not construct the
Fourier transform, a physical solution, the dissipation trajectory, or its
energy law. Native external compilation and theorem-level audit are required.
-/

noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace HelicalPhysicalEnergy

/-- A real linear isometry preserves the full two-vector Gram integrand. -/
theorem gramSqrt_isometry
    {E F α : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [NormedAddCommGroup F] [InnerProductSpace ℝ F]
    (U : E ≃ₗᵢ[ℝ] F) (v w : α → E) :
    FeffermanAHopfGramIntegral.gramSqrt (fun t => U (v t)) (fun t => U (w t)) =
      FeffermanAHopfGramIntegral.gramSqrt v w := by
  funext t
  unfold FeffermanAHopfGramIntegral.gramSqrt
  have hg : FeffermanAHopfGramIntegral.vectorGram (U (v t)) (U (w t)) =
      FeffermanAHopfGramIntegral.vectorGram (v t) (w t) := by
    simp only [FeffermanAHopfGramIntegral.vectorGram, U.inner_map_map]
  rw [hg]

local instance (priority := 10000) realL2 (μ : Measure Frequency) : InnerProductSpace ℝ (Lp Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp Fiber 2 μ)

local instance (priority := 10000) realL2Module (μ : Measure Frequency) :
    Module ℝ (Lp Fiber 2 μ) := (realL2 μ).toModule

/-- The Gram bound transfers to pullbacks of the concrete frequency operators.
    The isometry, square integrability, transversality and energy budget are
    all explicit inputs. No claim is made that U is the Fourier transform. -/
theorem physical_fiber_transverse_gram_bound
    {E τ : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [MeasurableSpace τ] (μ : Measure Frequency) (η : Measure τ)
    [MeasurableSpace (Lp Fiber 2 μ)] [BorelSpace (Lp Fiber 2 μ)]
    (U : E ≃ₗᵢ[ℝ] Lp Fiber 2 μ) (x : τ → E) (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hz : MemLp (fun t => U (x t)) 2 η)
    (htrans : ∀ᵐ t ∂η, ∀ᵐ ξ ∂μ,
      Matrix.toEuclideanLin
        (FeffermanHelicalFrequency.projection (ξ 0) (ξ 1) (ξ 2))
        (((U (x t)) : Frequency → Fiber) ξ) = (((U (x t)) : Frequency → Fiber) ξ))
    (hEnergy : 2 * nu * (∫ t, ‖x t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => U.symm (plusMultiplier μ (U (x t))))
      (fun t => U.symm (minusMultiplier μ (U (x t))))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => U.symm (plusMultiplier μ (U (x t))))
      (fun t => U.symm (minusMultiplier μ (U (x t))))
      ≤ initialEnergy / (4 * nu) := by
  have hbudget : 2 * nu * (∫ t, ‖U (x t)‖ ^ 2 ∂η) ≤ initialEnergy := by
    simpa only [U.norm_map] using hEnergy
  have h := HelicalEnergyBridge.fiber_transverse_energy_gram_bound
    μ η (fun t => U (x t)) nu initialEnergy hnu hz htrans hbudget
  have heq := @gramSqrt_isometry (Lp Fiber 2 μ) E τ
    _ (realL2 μ) _ ‹InnerProductSpace ℝ E› U.symm
    (fun t => plusMultiplier μ (U (x t)))
    (fun t => minusMultiplier μ (U (x t)))
  have hpoint (t : τ) := congrFun heq t
  constructor
  · simpa only [heq] using h.1
  · unfold FeffermanAHopfGramIntegral.gramSqrtIntegral at h ⊢
    simpa only [hpoint] using h.2

end HelicalPhysicalEnergy

#print axioms HelicalPhysicalEnergy.gramSqrt_isometry
#print axioms HelicalPhysicalEnergy.physical_fiber_transverse_gram_bound
