import FrontierARieszFrequency
import HelicalConcreteSymbol

/-! A-TIER CANDIDATE. Concrete scalar-frequency Riesz row. It acts on the
three complex frequency amplitudes of one velocity component. It is not an
actual Navier-Stokes weak derivative, nor yet the nine-component gradient.
External Windows Lean compilation and named axiom auditing are required. -/
noncomputable section
open MeasureTheory Filter
open FrontierARieszFrequency

namespace FrontierARieszConcreteSymbol

abbrev Frequency := HelicalConcreteSymbol.Frequency
abbrev Fiber := FeffermanHelicalOrthogonal.Fiber

/-- Complex-linear dot product with a prescribed coefficient row. -/
def coeffDot (a : Fin 3 → ℂ) : Fiber →ₗ[ℂ] ℂ where
  toFun v := a 0 * v 0 + a 1 * v 1 + a 2 * v 2
  map_add' v w := by simp <;> ring
  map_smul' c v := by simp <;> ring

/-- Convert a coefficient row to a continuous linear functional. -/
def coeffToCLM : (Fin 3 → ℂ) →ₗ[ℂ] (Fiber →L[ℂ] ℂ) where
  toFun a := LinearMap.toContinuousLinearMap (coeffDot a)
  map_add' a b := by
    ext v
    simp [coeffDot] <;> ring
  map_smul' c a := by
    ext v
    simp [coeffDot] <;> ring

def coeff (ξ : Frequency) : Fin 3 → ℂ := ![
  -Complex.I * (normalizedX (ξ 0) (ξ 1) (ξ 2) : ℂ),
  -Complex.I * (normalizedY (ξ 0) (ξ 1) (ξ 2) : ℂ),
  -Complex.I * (normalizedZ (ξ 0) (ξ 1) (ξ 2) : ℂ)]

def rowOp (ξ : Frequency) : Fiber →L[ℝ] ℂ :=
  (coeffToCLM (coeff ξ)).restrictScalars ℝ

theorem rowOp_apply (ξ : Frequency) (v : Fiber) :
    rowOp ξ v = freqRow (ξ 0) (ξ 1) (ξ 2) (v 0) (v 1) (v 2) := by
  simp [rowOp, coeffToCLM, coeffDot, coeff, freqRow, FrontierARieszRowSymbol.row] <;> ring

theorem rowOp_contractive (ξ : Frequency) (v : Fiber) : ‖rowOp ξ v‖ ≤ ‖v‖ := by
  have h := freq_row_normSq_bound (ξ 0) (ξ 1) (ξ 2) (v 0) (v 1) (v 2)
  have hnorm : ‖v‖ ^ 2 = Complex.normSq (v 0) + Complex.normSq (v 1) + Complex.normSq (v 2) := by
    simpa [EuclideanSpace.norm_sq_eq, Fin.sum_univ_succ, Complex.normSq_eq_norm_sq, add_assoc]
  have hsq : ‖rowOp ξ v‖ ^ 2 ≤ ‖v‖ ^ 2 := by
    simpa only [rowOp_apply, hnorm, ← Complex.normSq_eq_norm_sq] using h
  nlinarith [norm_nonneg (rowOp ξ v), norm_nonneg v]

theorem measurable_coeff : Measurable coeff := by
  apply measurable_pi_lambda
  intro i
  fin_cases i <;> simp [coeff, normalizedX, normalizedY, normalizedZ,
    FeffermanHelicalNormalize.radius] <;> fun_prop

theorem measurable_rowOp : Measurable rowOp := by
  have hc : Continuous coeffToCLM := coeffToCLM.continuous_of_finiteDimensional
  have hr : Continuous (fun f : Fiber →L[ℂ] ℂ => f.restrictScalars ℝ) :=
    ContinuousLinearMap.continuous_restrictScalars ℝ
  exact hr.measurable.comp (hc.measurable.comp measurable_coeff)

end FrontierARieszConcreteSymbol

#print axioms FrontierARieszConcreteSymbol.rowOp_apply
#print axioms FrontierARieszConcreteSymbol.rowOp_contractive
#print axioms FrontierARieszConcreteSymbol.measurable_coeff
#print axioms FrontierARieszConcreteSymbol.measurable_rowOp
