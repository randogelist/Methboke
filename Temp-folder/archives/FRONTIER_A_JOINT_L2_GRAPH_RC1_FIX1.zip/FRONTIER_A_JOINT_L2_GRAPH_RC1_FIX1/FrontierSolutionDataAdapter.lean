import FrontierCanonicalPhysicalSymbols

/-! Candidate adapter from separately supplied solution-data theorems to the
physical-field implication. `Solution` is a parameter: this module does not
define the Navier--Stokes equations or establish that its predicate represents
Leray--Hopf solutions. The input theorems below explicitly supply the initial
representative, time-L² gradient, weak-derivative identity, and energy budget.
The independently supplied fields additionally require an explicit a.e.
identification with the canonical Fourier fields. No source reference alone
proves that this Lean semantic identification holds. No local Lean run. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierSolutionDataAdapter

abbrev RealVelocity := FrontierLiteraturePhysicalImplication.RealVelocity
abbrev Gradient := FrontierLiteraturePhysicalImplication.Gradient
abbrev PhysicalField := FrontierLiteraturePhysicalImplication.PhysicalField
abbrev Frequency := FrontierPhysicalIdentification.Frequency
abbrev Fiber := FrontierPhysicalIdentification.Fiber
abbrev timeMeasure := FrontierFiniteIntervalEnergy.timeMeasure

local instance physicalRealL2 : InnerProductSpace ℝ PhysicalField :=
  InnerProductSpace.rclikeToReal ℂ PhysicalField

/-- Conditional adapter for an arbitrary externally supplied solution
predicate. Neither the predicate's PDE semantics nor its connection to the
independent physical fields is established by this theorem. The four supplied
solution-data implications and the field identification are separate, named
premises; none is the Gram conclusion. -/
theorem gram_for_solution_of_data_and_field_identification
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2]
    [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (Solution : (ℝ → RealVelocity) → RealVelocity → ℝ → Prop)
    (u : ℝ → RealVelocity) (u0 : RealVelocity) (g : ℝ → Gradient)
    (dp dm : ℝ → PhysicalField) (nu : ℝ) (hnu : 0 < nu)
    (hsolution : Solution u u0 nu)
    (initial_from_solution : Solution u u0 nu → u 0 = u0)
    (gradient_from_solution : Solution u u0 nu →
      ∀ T : ℝ, 0 ≤ T → MemLp g 2 (timeMeasure T))
    (energy_from_solution : Solution u u0 nu →
      ∀ T : ℝ, 0 ≤ T → ‖u T‖ ^ 2 + 2 * nu *
        (∫ t, ‖g t‖ ^ 2 ∂(timeMeasure T)) ≤ ‖u0‖ ^ 2)
    (weak_gradient_from_solution : Solution u u0 nu →
      ∀ T : ℝ, 0 ≤ T → ∀ᵐ t ∂(timeMeasure T), ∀ j,
        Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
        LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
          (Lp.toTemperedDistribution (FrontierRealVelocityEmbedding.complexifyL2 (u t))))
    (physical_field_identification : ∀ T : ℝ, 0 ≤ T →
      ∀ᵐ t ∂(timeMeasure T),
        dp t = FrontierPhysicalGramTransport.plusField (g t) ∧
        dm t = FrontierPhysicalGramTransport.minusField (g t)) :
    ∀ T : ℝ, 0 ≤ T →
      Integrable (FeffermanAHopfGramIntegral.gramSqrt dp dm) (timeMeasure T) ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral (timeMeasure T) dp dm ≤
        ‖u0‖ ^ 2 / (4 * nu) := by
  have hweak := weak_gradient_from_solution hsolution
  have hp : ∀ T : ℝ, 0 ≤ T → ∀ᵐ t ∂(timeMeasure T),
      (FrontierPhysicalGramTransport.fourierCoordinateReal (dp t) : Frequency → Fiber) =ᵐ[volume]
      fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ) := by
    intro T hT
    filter_upwards [hweak T hT, physical_field_identification T hT] with t hw hi
    rw [hi.1]
    exact (FrontierCanonicalPhysicalSymbols.canonical_symbols_of_weak_gradient _ _ hw).1
  have hm : ∀ T : ℝ, 0 ≤ T → ∀ᵐ t ∂(timeMeasure T),
      (FrontierPhysicalGramTransport.fourierCoordinateReal (dm t) : Frequency → Fiber) =ᵐ[volume]
      fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ) := by
    intro T hT
    filter_upwards [hweak T hT, physical_field_identification T hT] with t hw hi
    rw [hi.2]
    exact (FrontierCanonicalPhysicalSymbols.canonical_symbols_of_weak_gradient _ _ hw).2
  exact FrontierLiteraturePhysicalImplication.physical_gram_from_explicit_inputs
    u u0 g dp dm nu hnu (initial_from_solution hsolution)
    (gradient_from_solution hsolution) (energy_from_solution hsolution) hweak hp hm

end FrontierSolutionDataAdapter

#print axioms FrontierSolutionDataAdapter.gram_for_solution_of_data_and_field_identification
