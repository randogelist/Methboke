import FrontierARieszConcreteSymbol
import FrontierARieszL2Lift

/-! Candidate L² operator for the concrete normalized frequency row acting
on three complex amplitudes of one velocity component. This is not yet the
physical-space operator, the full gradient, a weak-derivative theorem, or a
Leray–Hopf realization. External Lean compilation and audit are required. -/
noncomputable section
open MeasureTheory Filter
open FrontierARieszConcreteSymbol

namespace FrontierARieszConcreteL2

theorem symbol_memLp_top (μ : Measure Frequency) : MemLp rowOp ⊤ μ := by
  apply FrontierARieszL2Lift.symbol_memLp_top μ rowOp
  · exact measurable_rowOp.aestronglyMeasurable
  · exact Filter.Eventually.of_forall rowOp_contractive

def rowMultiplier (μ : Measure Frequency) : Lp Fiber 2 μ →L[ℝ] Lp ℂ 2 μ :=
  FrontierARieszL2Lift.lift μ rowOp (symbol_memLp_top μ)

theorem rowMultiplier_ae (μ : Measure Frequency) (f : Lp Fiber 2 μ) :
    (rowMultiplier μ f : Frequency → ℂ) =ᵐ[μ]
      fun ξ => rowOp ξ ((f : Frequency → Fiber) ξ) := by
  exact FrontierARieszL2Lift.lift_ae μ rowOp (symbol_memLp_top μ) f

theorem rowMultiplier_contractive (μ : Measure Frequency) (f : Lp Fiber 2 μ) :
    ‖rowMultiplier μ f‖ ≤ ‖f‖ := by
  apply FrontierARieszL2Lift.lift_contractive μ rowOp (symbol_memLp_top μ)
  exact Filter.Eventually.of_forall rowOp_contractive

theorem rowMultiplier_op_norm_le_one (μ : Measure Frequency) :
    ‖rowMultiplier μ‖ ≤ 1 := by
  apply FrontierARieszL2Lift.lift_op_norm_le_one μ rowOp (symbol_memLp_top μ)
  exact Filter.Eventually.of_forall rowOp_contractive

end FrontierARieszConcreteL2

#print axioms FrontierARieszConcreteL2.symbol_memLp_top
#print axioms FrontierARieszConcreteL2.rowMultiplier_ae
#print axioms FrontierARieszConcreteL2.rowMultiplier_contractive
#print axioms FrontierARieszConcreteL2.rowMultiplier_op_norm_le_one
