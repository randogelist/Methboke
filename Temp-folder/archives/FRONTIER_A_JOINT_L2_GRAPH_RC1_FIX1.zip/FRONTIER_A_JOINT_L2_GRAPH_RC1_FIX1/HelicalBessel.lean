import HelicalConcreteGram

/-! Candidate Bessel inequality for the two concrete multipliers. No
transversality assumption is required. The physical interpretation and the
energy budget remain separate. This file has not been compiled. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal
namespace HelicalBessel

theorem plus_fiber_symmetric (x y z : ℝ) :
    (FeffermanHelicalFiberFrequency.plusMap x y z).IsSymmetric := by
  apply Matrix.isSymmetric_toEuclideanLin_iff.mpr
  exact Matrix.IsHermitian.ext (FeffermanHelicalFrequency.plus_hermitian x y z)

theorem minus_fiber_symmetric (x y z : ℝ) :
    (FeffermanHelicalFiberFrequency.minusMap x y z).IsSymmetric := by
  apply Matrix.isSymmetric_toEuclideanLin_iff.mpr
  exact Matrix.IsHermitian.ext (FeffermanHelicalFrequency.minus_hermitian x y z)

theorem plus_symmetric (μ : Measure Frequency) (f g : Lp Fiber 2 μ) :
    inner ℂ (plusMultiplier μ f) g = inner ℂ f (plusMultiplier μ g) := by
  rw [MeasureTheory.L2.inner_def, MeasureTheory.L2.inner_def]
  apply integral_congr_ae
  filter_upwards [plus_multiplier_ae μ f, plus_multiplier_ae μ g] with ξ hf hg
  rw [hf, hg, plus_action, plus_action]
  exact plus_fiber_symmetric (ξ 0) (ξ 1) (ξ 2) _ _

theorem minus_symmetric (μ : Measure Frequency) (f g : Lp Fiber 2 μ) :
    inner ℂ (minusMultiplier μ f) g = inner ℂ f (minusMultiplier μ g) := by
  rw [MeasureTheory.L2.inner_def, MeasureTheory.L2.inner_def]
  apply integral_congr_ae
  filter_upwards [minus_multiplier_ae μ f, minus_multiplier_ae μ g] with ξ hf hg
  rw [hf, hg, minus_action, minus_action]
  exact minus_fiber_symmetric (ξ 0) (ξ 1) (ξ 2) _ _

theorem bessel (μ : Measure Frequency) (f : Lp Fiber 2 μ) :
    ‖plusMultiplier μ f‖ ^ 2 + ‖minusMultiplier μ f‖ ^ 2 ≤ ‖f‖ ^ 2 := by
  let p := plusMultiplier μ f
  let m := minusMultiplier μ f
  have hp : inner ℂ p f = inner ℂ p p := by
    simpa only [p, plus_multiplier_idempotent] using
      plus_symmetric μ (plusMultiplier μ f) f
  have hm : inner ℂ m f = inner ℂ m m := by
    simpa only [m, minus_multiplier_idempotent] using
      minus_symmetric μ (minusMultiplier μ f) f
  have hpm : inner ℂ p m = 0 :=
    HelicalConcreteGram.multiplier_complex_orthogonal μ f f
  have hmp : inner ℂ m p = 0 := by
    rw [← inner_conj_symm, hpm]
    simp
  have ho : inner ℂ (p + m) (f - (p + m)) = 0 := by
    rw [inner_add_left, inner_sub_right, inner_sub_right,
      inner_add_right, inner_add_right, hp, hm, hpm, hmp]
    ring
  have ha : p + m + (f - (p + m)) = f := by abel
  have h1 := norm_add_sq (𝕜 := ℂ) (p + m) (f - (p + m))
  have h2 := norm_add_sq (𝕜 := ℂ) p m
  rw [ha, ho] at h1
  rw [hpm] at h2
  simp only [RCLike.zero_re, map_zero, mul_zero, add_zero] at h1 h2
  have hnonneg := sq_nonneg ‖f - (p + m)‖
  dsimp [p, m] at *
  linarith

local instance realL2 (μ : Measure Frequency) : InnerProductSpace ℝ (Lp Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp Fiber 2 μ)

theorem gram_bound_from_full_energy
    {τ : Type*} [MeasurableSpace τ] (μ : Measure Frequency) (η : Measure τ)
    [MeasurableSpace (Lp Fiber 2 μ)] [BorelSpace (Lp Fiber 2 μ)]
    (z : τ → Lp Fiber 2 μ) (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hz : MemLp z 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖z t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier μ (z t)) (fun t => minusMultiplier μ (z t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier μ (z t)) (fun t => minusMultiplier μ (z t))
      ≤ initialEnergy / (4 * nu) := by
  have hp : MemLp (fun t => plusMultiplier μ (z t)) 2 η := by
    simpa only [Function.comp_def] using (plusMultiplier μ).comp_memLp' hz
  have hm : MemLp (fun t => minusMultiplier μ (z t)) 2 η := by
    simpa only [Function.comp_def] using (minusMultiplier μ).comp_memLp' hz
  have hiP : Integrable (fun t => ‖plusMultiplier μ (z t)‖ ^ 2) η :=
    (memLp_two_iff_integrable_sq_norm hp.aestronglyMeasurable).1 hp
  have hiM : Integrable (fun t => ‖minusMultiplier μ (z t)‖ ^ 2) η :=
    (memLp_two_iff_integrable_sq_norm hm.aestronglyMeasurable).1 hm
  have hiZ : Integrable (fun t => ‖z t‖ ^ 2) η :=
    (memLp_two_iff_integrable_sq_norm hz.aestronglyMeasurable).1 hz
  have hle : (∫ t, (‖plusMultiplier μ (z t)‖ ^ 2 +
      ‖minusMultiplier μ (z t)‖ ^ 2) ∂η) ≤ ∫ t, ‖z t‖ ^ 2 ∂η := by
    apply integral_mono_ae (hiP.add hiM) hiZ
    exact Filter.Eventually.of_forall (fun t => bessel μ (z t))
  apply HelicalConcreteGram.concrete_helical_gram_bound μ η z nu initialEnergy hnu hz
  exact le_trans (mul_le_mul_of_nonneg_left hle (by positivity)) hEnergy

end HelicalBessel

#print axioms HelicalBessel.plus_fiber_symmetric
#print axioms HelicalBessel.minus_fiber_symmetric
#print axioms HelicalBessel.plus_symmetric
#print axioms HelicalBessel.minus_symmetric
#print axioms HelicalBessel.bessel
#print axioms HelicalBessel.gram_bound_from_full_energy
