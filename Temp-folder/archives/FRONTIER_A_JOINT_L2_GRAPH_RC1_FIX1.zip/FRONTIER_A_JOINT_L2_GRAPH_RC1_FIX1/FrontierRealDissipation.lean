import FrontierPhysicalReality
import FrontierProjectedDissipation
import FrontierAEProjectedGraphEnergy

/-! Reality of the actual canonical dissipation and Gram fields for a supplied
real velocity and weak gradient. This result does not construct a Leray--Hopf
trajectory or identify an independent Stokes operator. No local Lean run. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open FrontierAESymmetry
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierRealDissipation

abbrev Frequency := FrontierPhysicalReality.Frequency
abbrev Fiber := FrontierPhysicalReality.Fiber
abbrev Field := FrontierPhysicalReality.Field
abbrev RealVelocity := FrontierRealVelocityEmbedding.RealField
abbrev Gradient := FrontierARealGradient.RealMatrix

/-- The real even 2π|ξ| multiplier preserves the Fourier Hermitian symmetry
of any real velocity, provided its L² Fourier representative exists. -/
theorem dissipation_real_of_real_velocity
    (u : RealVelocity) (v : FrontierSpectralOperator.Domain)
    (hv : v.val = FrontierRealVelocityEmbedding.complexifyL2 u) :
    FrontierPhysicalReality.RealAE (FrontierSpectralOperator.dissipation v) := by
  apply (FrontierPhysicalReality.real_iff_fourier_hermitian _).2
  have hsym := FrontierRealVelocityEmbedding.fourier_hermitian_of_real_field u
  have hcoord := FrontierDomainLinear.fourierCoordinate_ae
    (FrontierRealVelocityEmbedding.complexifyL2 u)
  have hcoordNeg := FrontierVolumeSymmetry.volume_reflectsAE _ hcoord
  have hD := FrontierSpectralOperator.dissipation_fourier v
  rw [hv] at hD
  change (FrontierACoordinateEquiv.fourierCoordinate
      (FrontierSpectralOperator.dissipation v) : Frequency → Fiber) =ᵐ[volume]
        FrontierMultiplierBridge.velocitySymbol (FrontierRealVelocityEmbedding.complexifyL2 u) at hD
  have hDNeg := FrontierVolumeSymmetry.volume_reflectsAE _ hD
  filter_upwards [hsym, hcoord, hcoordNeg, hD, hDNeg] with ξ hs hc hcn hd hdn
  intro j
  rw [hdn, hd]
  rw [FrontierProjectedDissipation.velocitySymbol_eq_weight,
    FrontierProjectedDissipation.velocitySymbol_eq_weight]
  rw [← hcn, ← hc]
  simp only [PiLp.smul_apply, smul_eq_mul, star_mul]
  rw [hs j]
  simp [FrontierProjectedDissipation.weight, FeffermanHelicalNormalize.radius] <;> ring

/-- Weak gradient data provide the domain element; its gradient-derived
positive square-root representative is real in physical L². -/
theorem gradient_dissipation_real
    (u : RealVelocity) (g : Gradient)
    (hw : FrontierAEProjectedGraphEnergy.WeakAt
      (FrontierRealVelocityEmbedding.complexifyL2 u) g) :
    FrontierPhysicalReality.RealAE (FrontierDissipationDomain.gradientDissipation g) := by
  let v := FrontierSpectralOperator.ofWeakGradient
    (FrontierRealVelocityEmbedding.complexifyL2 u) g hw
  have h := dissipation_real_of_real_velocity u v rfl
  have heq : FrontierSpectralOperator.dissipation v =
      FrontierDissipationDomain.gradientDissipation g :=
    FrontierSpectralOperator.dissipation_ofWeakGradient
      (FrontierRealVelocityEmbedding.complexifyL2 u) g hw
  exact (congrArg FrontierPhysicalReality.RealAE heq).mp h

/-- Both fields actually used in the gradient Gram estimate are real whenever
`g` is the weak spatial gradient of the supplied real velocity. -/
theorem gram_fields_real_of_weak_gradient
    (u : RealVelocity) (g : Gradient)
    (hw : FrontierAEProjectedGraphEnergy.WeakAt
      (FrontierRealVelocityEmbedding.complexifyL2 u) g) :
    FrontierPhysicalReality.RealAE (FrontierPhysicalGramTransport.plusField g) ∧
    FrontierPhysicalReality.RealAE (FrontierPhysicalGramTransport.minusField g) := by
  have h := gradient_dissipation_real u g hw
  have hs := (FrontierPhysicalReality.real_iff_fourier_hermitian _).1 h
  constructor
  · rw [← FrontierDissipationDomain.plus_projected_gradientDissipation]
    apply (FrontierPhysicalReality.real_iff_fourier_hermitian _).2
    rw [FrontierACoordinateEquiv.plus_intertwines]
    exact FrontierVolumeSymmetry.plus_preserves _ hs
  · rw [← FrontierDissipationDomain.minus_projected_gradientDissipation]
    apply (FrontierPhysicalReality.real_iff_fourier_hermitian _).2
    rw [FrontierACoordinateEquiv.minus_intertwines]
    exact FrontierVolumeSymmetry.minus_preserves _ hs

end FrontierRealDissipation

#print axioms FrontierRealDissipation.dissipation_real_of_real_velocity
#print axioms FrontierRealDissipation.gradient_dissipation_real
#print axioms FrontierRealDissipation.gram_fields_real_of_weak_gradient
