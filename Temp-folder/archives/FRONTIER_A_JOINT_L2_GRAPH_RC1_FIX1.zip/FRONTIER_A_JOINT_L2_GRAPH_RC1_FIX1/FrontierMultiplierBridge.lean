import FrontierAWeakGramInput
import FrontierARealGradient

/-!
Candidate pointwise-to-L2 bridge. The supplied fields and weak derivatives
are arbitrary, not a constructed Leray--Hopf solution. Identifying the
pointwise symbol hypothesis below with an actual physical helical field is
still a separate analytic obligation. No Lean compiler has been run here.
-/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierMultiplierBridge
abbrev Frequency := HelicalConcreteSymbol.Frequency
abbrev Field := FrontierAWeakGramInput.Field
abbrev Fiber := FrontierAWeakGramInput.Fiber
abbrev CoordinateL2 := FrontierAConcreteFourier.CoordinateL2

/-- The weak-velocity dissipation symbol in coordinate frequency space. -/
def velocitySymbol (u : Field) (ξ : Frequency) : Fiber :=
  WithLp.toLp 2 (fun i =>
    ((2 * Real.pi : ℝ) : ℂ) *
      (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2) : ℂ) *
      (FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ) i)

/-- The Riesz reconstruction agrees with the weak velocity symbol a.e. -/
theorem real_gradient_spectrum_eq_symbol
    (u : Field) (g : FrontierARealGradient.RealMatrix) (du : Fin 3 → Field)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 g) = du j)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) :
    (FrontierARealGradient.realGradientSpectrum g : Frequency → Fiber) =ᵐ[volume]
      velocitySymbol u := by
  have h := FrontierAWeakGramInput.gram_input_eq_weak_velocity_symbol
    u (FrontierARealGradient.complexifyL2 g) du hcol hweak
  filter_upwards [h] with ξ hξ
  ext i
  simpa [velocitySymbol, FrontierARealGradient.realGradientSpectrum] using hξ i

/-- Pointwise identification with the explicit velocity symbol yields equality
of both supplied frequency-space L2 fields with the existing helical lifts. -/
theorem helical_l2_of_velocity_symbol
    (u : Field) (g : FrontierARealGradient.RealMatrix) (du : Fin 3 → Field)
    (vp vm : CoordinateL2)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 g) = du j)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (hp : (vp : Frequency → Fiber) =ᵐ[volume]
      fun ξ => plusOp ξ (velocitySymbol u ξ))
    (hm : (vm : Frequency → Fiber) =ᵐ[volume]
      fun ξ => minusOp ξ (velocitySymbol u ξ)) :
    vp = plusMultiplier (volume : Measure Frequency)
        (FrontierARealGradient.realGradientSpectrum g) ∧
    vm = minusMultiplier (volume : Measure Frequency)
        (FrontierARealGradient.realGradientSpectrum g) := by
  have hs := real_gradient_spectrum_eq_symbol u g du hcol hweak
  constructor
  · apply Lp.ext
    filter_upwards [hp, hs, plus_multiplier_ae (volume : Measure Frequency)
      (FrontierARealGradient.realGradientSpectrum g)] with ξ h₁ h₂ h₃
    rw [h₁, h₃, h₂]
  · apply Lp.ext
    filter_upwards [hm, hs, minus_multiplier_ae (volume : Measure Frequency)
      (FrontierARealGradient.realGradientSpectrum g)] with ξ h₁ h₂ h₃
    rw [h₁, h₃, h₂]

/-- Time-dependent assembly. These hypotheses must still be established for
actual weak-solution and physical projection representatives. -/
theorem time_helical_l2_of_velocity_symbol
    {τ : Type*} [MeasurableSpace τ] (η : Measure τ)
    (u : τ → Field) (g : τ → FrontierARealGradient.RealMatrix)
    (du : τ → Fin 3 → Field) (vp vm : τ → CoordinateL2)
    (hcol : ∀ᵐ t ∂η, ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 (g t)) = du t j)
    (hweak : ∀ᵐ t ∂η, ∀ j, Lp.toTemperedDistribution (du t j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t)))
    (hp : ∀ᵐ t ∂η, (vp t : Frequency → Fiber) =ᵐ[volume]
      fun ξ => plusOp ξ (velocitySymbol (u t) ξ))
    (hm : ∀ᵐ t ∂η, (vm t : Frequency → Fiber) =ᵐ[volume]
      fun ξ => minusOp ξ (velocitySymbol (u t) ξ)) :
    ∀ᵐ t ∂η,
      vp t = plusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t)) ∧
      vm t = minusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t)) := by
  filter_upwards [hcol, hweak, hp, hm] with t hc hw hplus hminus
  exact helical_l2_of_velocity_symbol (u t) (g t) (du t) (vp t) (vm t)
    hc hw hplus hminus

end FrontierMultiplierBridge

#print axioms FrontierMultiplierBridge.time_helical_l2_of_velocity_symbol
#print axioms FrontierMultiplierBridge.real_gradient_spectrum_eq_symbol
#print axioms FrontierMultiplierBridge.helical_l2_of_velocity_symbol
