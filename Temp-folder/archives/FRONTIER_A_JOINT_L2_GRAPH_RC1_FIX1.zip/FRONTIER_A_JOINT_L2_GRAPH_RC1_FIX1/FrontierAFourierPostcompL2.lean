import FrontierAFourierPostcompL1
import Mathlib.Analysis.Fourier.LpSpace

/-! Untested A-tier candidate. The only intended theorem is L² Fourier
naturality for bounded complex-linear postcomposition. No physical or
weak-gradient identification is asserted. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierAFourierPostcompL2
abbrev Space := FrontierAFourierPostcompL1.Space
abbrev GradFiber := FrontierAFourierPostcompL1.GradFiber
abbrev Fiber := FrontierAFourierPostcompL1.Fiber
abbrev MatrixL2 := Lp GradFiber 2 (volume : Measure Space)
abbrev VectorL2 := Lp Fiber 2 (volume : Measure Space)

/-- Postcomposition of a Schwartz representative commutes with the L² lift. -/
theorem postcomp_toLp (L : GradFiber →L[ℂ] Fiber) (f : SchwartzMap Space GradFiber) :
    (ContinuousLinearMap.compLpL 2 (volume : Measure Space) L) (f.toLp 2 volume) =
      ((SchwartzMap.postcompCLM L) f).toLp 2 volume := by
  apply Lp.ext
  filter_upwards [L.coeFn_compLpL (f.toLp 2 volume), f.coeFn_toLp 2 volume,
    ((SchwartzMap.postcompCLM L) f).coeFn_toLp 2 volume] with x hL hf hg
  simpa only [SchwartzMap.postcompCLM_apply, hf, hg] using hL

/-- Fourier transform commutes with bounded fiber postcomposition on Schwartz functions. -/
theorem postcomp_fourier_schwartz (L : GradFiber →L[ℂ] Fiber)
    (f : SchwartzMap Space GradFiber) :
    FourierTransform.fourier ((SchwartzMap.postcompCLM L) f) =
      (SchwartzMap.postcompCLM L) (FourierTransform.fourier f) := by
  ext x i
  have hp : (⇑((SchwartzMap.postcompCLM L) f) : Space → Fiber) =
      (fun x => L (f x)) := by
    funext y
    exact SchwartzMap.postcompCLM_apply L f y
  have h := FrontierAFourierPostcompL1.fourier_postcomp_integrable L f f.integrable x
  rw [← hp] at h
  simpa only [SchwartzMap.fourier_coe, SchwartzMap.postcompCLM_apply] using
    congrArg (fun v : Fiber => v.ofLp i) h

/-- L² Fourier transform commutes with a bounded complex-linear fiber map. -/
theorem fourier_postcomp_l2 (L : GradFiber →L[ℂ] Fiber) (f : MatrixL2) :
    FourierTransform.fourier ((ContinuousLinearMap.compLpL 2 (volume : Measure Space) L) f) =
      (ContinuousLinearMap.compLpL 2 (volume : Measure Space) L) (FourierTransform.fourier f) := by
  let p : MatrixL2 → Prop := fun f =>
    FourierTransform.fourier ((ContinuousLinearMap.compLpL 2 (volume : Measure Space) L) f) =
      (ContinuousLinearMap.compLpL 2 (volume : Measure Space) L) (FourierTransform.fourier f)
  change p f
  apply DenseRange.induction_on (p := p)
    (SchwartzMap.denseRange_toLpCLM (p := 2) ENNReal.ofNat_ne_top) f
  · apply isClosed_eq
    · exact ((fourierCLM ℂ VectorL2).comp (ContinuousLinearMap.compLpL 2 volume L)).continuous
    · exact ((ContinuousLinearMap.compLpL 2 volume L).comp (fourierCLM ℂ MatrixL2)).continuous
  · intro g
    dsimp only [p]
    simp only [SchwartzMap.toLpCLM_apply]
    rw [postcomp_toLp, SchwartzMap.toLp_fourier_eq, SchwartzMap.toLp_fourier_eq,
      postcomp_fourier_schwartz, postcomp_toLp]

end FrontierAFourierPostcompL2

#print axioms FrontierAFourierPostcompL2.postcomp_toLp
#print axioms FrontierAFourierPostcompL2.postcomp_fourier_schwartz
#print axioms FrontierAFourierPostcompL2.fourier_postcomp_l2
