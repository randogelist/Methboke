import FrontierVolumeSymmetry

/-! Candidate: the Hermitian frequency-L² fields form a closed set. This is
an L²-density prerequisite only. It does not prove that a real velocity has a
Hermitian Fourier transform or construct a Leray--Hopf solution. No local Lean
compiler was run. -/
noncomputable section
open MeasureTheory Filter
open FrontierAESymmetry

namespace FrontierHermitianClosed
abbrev Frequency := FrontierAESymmetry.Frequency
abbrev Fiber := FrontierAESymmetry.Fiber
abbrev FrequencyL2 := Lp Fiber 2 (volume : Measure Frequency)

def fiberConj : Fiber →ₗ[ℝ] Fiber where
  toFun x := WithLp.toLp 2 (fun j => star (x j))
  map_add' x y := by ext j; simp
  map_smul' c x := by ext j; simp

def fiberConjCLM : Fiber →L[ℝ] Fiber := fiberConj.toContinuousLinearMap

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩

/-- Conjugation after reflection, acting on L² classes. -/
def conjugateReflection : FrequencyL2 →L[ℝ] FrequencyL2 :=
  (ContinuousLinearMap.compLpL 2 (volume : Measure Frequency) fiberConjCLM).comp
    ((Lp.compMeasurePreservingₗᵢ ℝ (fun ξ : Frequency => -ξ)
      (Measure.measurePreserving_neg (volume : Measure Frequency))).toContinuousLinearMap)

theorem conjugateReflection_ae (f : FrequencyL2) :
    (conjugateReflection f : Frequency → Fiber) =ᵐ[volume]
      fun ξ => fiberConj ((f : Frequency → Fiber) (-ξ)) := by
  have hc := ContinuousLinearMap.coeFn_compLpL fiberConjCLM
    ((Lp.compMeasurePreserving (fun ξ : Frequency => -ξ)
      (Measure.measurePreserving_neg (volume : Measure Frequency))) f)
  have hr := Lp.coeFn_compMeasurePreserving f
    (Measure.measurePreserving_neg (volume : Measure Frequency))
  have hreflect :
      (Lp.compMeasurePreservingₗᵢ ℝ (fun ξ : Frequency => -ξ)
        (Measure.measurePreserving_neg (volume : Measure Frequency))).toContinuousLinearMap f =
      (Lp.compMeasurePreserving (fun ξ : Frequency => -ξ)
        (Measure.measurePreserving_neg (volume : Measure Frequency))) f := by
    rfl
  filter_upwards [hc, hr] with ξ hc hr
  change ((ContinuousLinearMap.compLpL 2 (volume : Measure Frequency) fiberConjCLM)
    ((Lp.compMeasurePreservingₗᵢ ℝ (fun ξ : Frequency => -ξ)
      (Measure.measurePreserving_neg (volume : Measure Frequency))).toContinuousLinearMap f)
      : Frequency → Fiber) ξ = fiberConj ((f : Frequency → Fiber) (-ξ))
  rw [hreflect]
  simpa only [fiberConjCLM, Function.comp_apply] using hc.trans (congrArg fiberConj hr)

theorem hermitian_iff_fixed (f : FrequencyL2) :
    HermitianAE volume f ↔ conjugateReflection f = f := by
  constructor
  · intro h
    apply Lp.ext
    filter_upwards [conjugateReflection_ae f, h] with ξ hc hs
    rw [hc]
    ext j
    change star ((f : Frequency → Fiber) (-ξ) j) = (f : Frequency → Fiber) ξ j
    rw [hs j]
    exact star_star _
  · intro h
    have he := conjugateReflection_ae f
    rw [h] at he
    filter_upwards [he] with ξ he
    intro j
    have hj := congrArg (fun x : Fiber => x j) he
    have hj' := congrArg star hj
    simpa [fiberConj] using hj'.symm

theorem isClosed_hermitian : IsClosed {f : FrequencyL2 | HermitianAE volume f} := by
  have hclosed : IsClosed {f : FrequencyL2 | conjugateReflection f = f} :=
    isClosed_eq conjugateReflection.continuous continuous_id
  simpa only [hermitian_iff_fixed] using hclosed

end FrontierHermitianClosed

#print axioms FrontierHermitianClosed.conjugateReflection_ae
#print axioms FrontierHermitianClosed.hermitian_iff_fixed
#print axioms FrontierHermitianClosed.isClosed_hermitian
