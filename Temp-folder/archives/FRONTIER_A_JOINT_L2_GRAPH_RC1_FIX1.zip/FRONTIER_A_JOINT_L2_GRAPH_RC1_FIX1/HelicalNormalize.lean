import HelicalGeneral

/-!
An elementary finite-dimensional normalization step for a nonzero Fourier
frequency.  The premise is strict positivity of its squared Euclidean length.
No Fourier multiplier, measure theory, or PDE solution is constructed here.
This file requires external Lean compilation and theorem-level axiom audit.
-/

noncomputable section

namespace FeffermanHelicalNormalize

def radius (x y z : ℝ) : ℝ := Real.sqrt (x ^ 2 + y ^ 2 + z ^ 2)

theorem normalized_unit (x y z : ℝ) (h : 0 < x ^ 2 + y ^ 2 + z ^ 2) :
    (x / radius x y z) ^ 2 + (y / radius x y z) ^ 2 +
      (z / radius x y z) ^ 2 = 1 := by
  have hr : 0 < radius x y z := Real.sqrt_pos.2 h
  have hs : (radius x y z) ^ 2 = x ^ 2 + y ^ 2 + z ^ 2 :=
    Real.sq_sqrt (le_of_lt h)
  field_simp [ne_of_gt hr] <;> nlinarith [hs]

/-- The verified unit-direction partition specializes to each frequency
    whose squared length is strictly positive. -/
theorem normalized_helicity_partition (x y z : ℝ)
    (h : 0 < x ^ 2 + y ^ 2 + z ^ 2) :
    FeffermanHelicalGeneral.positive (x / radius x y z) (y / radius x y z)
        (z / radius x y z) +
      FeffermanHelicalGeneral.negative (x / radius x y z) (y / radius x y z)
        (z / radius x y z) =
      FeffermanHelicalGeneral.transverse (x / radius x y z) (y / radius x y z)
        (z / radius x y z) := by
  exact FeffermanHelicalGeneral.helicity_partition _ _ _ (normalized_unit x y z h)

/-- The positive-helicity symbol is idempotent at each such frequency. -/
theorem normalized_positive_idempotent (x y z : ℝ)
    (h : 0 < x ^ 2 + y ^ 2 + z ^ 2) :
    FeffermanHelicalGeneral.positive (x / radius x y z) (y / radius x y z)
        (z / radius x y z) *
      FeffermanHelicalGeneral.positive (x / radius x y z) (y / radius x y z)
        (z / radius x y z) =
      FeffermanHelicalGeneral.positive (x / radius x y z) (y / radius x y z)
        (z / radius x y z) := by
  exact FeffermanHelicalGeneral.positive_idempotent _ _ _ (normalized_unit x y z h)

end FeffermanHelicalNormalize

#print axioms FeffermanHelicalNormalize.normalized_unit
#print axioms FeffermanHelicalNormalize.normalized_helicity_partition
#print axioms FeffermanHelicalNormalize.normalized_positive_idempotent
