import FrontierSpectralDomain

/-! A-TIER CANDIDATE. A canonical Fourier-symbol operator on its explicit
L² graph domain. This does not assert identification with an independently
defined Stokes square root, preservation of real fields, or Leray–Hopf theory.
No Lean compiler was run locally. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierSpectralOperator

abbrev Field := FrontierDissipationDomain.Field
abbrev Frequency := FrontierDissipationDomain.Frequency
abbrev Fiber := FrontierDissipationDomain.Fiber
abbrev PhysicalL2 := FrontierDissipationDomain.PhysicalL2

/-- The graph domain contains exactly those velocities whose explicit
2π|ξ| Fourier symbol has an L² representative. -/
def Domain := {u : Field // FrontierDissipationDomain.HasDissipationSymbol u}

/-- A representative exists by the definition of the graph domain and is
independent of this choice by `symbol_representative_unique`. -/
def dissipation (u : Domain) : PhysicalL2 := Classical.choose u.property

theorem dissipation_fourier (u : Domain) :
    (FrontierPhysicalGramTransport.fourierCoordinateReal (dissipation u) : Frequency → Fiber) =ᵐ[volume]
      FrontierMultiplierBridge.velocitySymbol u.val := by
  exact Classical.choose_spec u.property

/-- Any valid representative of the velocity symbol agrees with the operator. -/
theorem dissipation_eq_of_symbol (u : Domain) (v : PhysicalL2)
    (hv : (FrontierPhysicalGramTransport.fourierCoordinateReal v : Frequency → Fiber) =ᵐ[volume]
      FrontierMultiplierBridge.velocitySymbol u.val) :
    dissipation u = v := by
  exact FrontierDissipationDomain.symbol_representative_unique u.val _ _
    (dissipation_fourier u) hv

/-- Any weak gradient witnesses membership of the graph domain. -/
def ofWeakGradient (u : Field) (g : FrontierARealGradient.RealMatrix)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) : Domain :=
  ⟨u, FrontierDissipationDomain.weak_gradient_has_dissipation_symbol u g hweak⟩

/-- On any velocity admitting the displayed weak gradient, the canonical
operator agrees with the gradient-based representative. -/
theorem dissipation_eq_gradient (u : Domain) (g : FrontierARealGradient.RealMatrix)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u.val)) :
    dissipation u = FrontierDissipationDomain.gradientDissipation g := by
  apply dissipation_eq_of_symbol
  rw [FrontierDissipationDomain.gradientDissipation_fourier]
  exact FrontierMultiplierBridge.real_gradient_spectrum_eq_symbol u.val g
    (fun j => FrontierGradientAdapter.gradientColumn g j) (fun _ => rfl) hweak

/-- Domain construction from a weak gradient has the expected value. -/
theorem dissipation_ofWeakGradient (u : Field) (g : FrontierARealGradient.RealMatrix)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) :
    dissipation (ofWeakGradient u g hweak) = FrontierDissipationDomain.gradientDissipation g := by
  exact dissipation_eq_gradient (ofWeakGradient u g hweak) g hweak

local instance physicalRealL2 : InnerProductSpace ℝ PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ PhysicalL2

/-- Conditional Gram bound for the canonical spectral operator along a
trajectory with supplied weak gradients and terminal-energy data. -/
theorem spectral_projected_gram_from_energy
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → Domain)
    (g : τ → FrontierARealGradient.RealMatrix)
    (D : τ → ℝ) (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : AEStronglyMeasurable g η) (hD : Integrable D η)
    (hidentify : D =ᵐ[η] fun t => ‖g t‖ ^ 2)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, D t ∂η) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂η, ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t).val)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierACoordinateEquiv.plusPullback (dissipation (u t)))
      (fun t => FrontierACoordinateEquiv.minusPullback (dissipation (u t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierACoordinateEquiv.plusPullback (dissipation (u t)))
      (fun t => FrontierACoordinateEquiv.minusPullback (dissipation (u t))) ≤
        ‖u0‖ ^ 2 / (4 * nu) := by
  have hbound := FrontierDissipationDomain.projected_gradient_gram_from_energy
    η (fun t => (u t).val) g D u0 uT nu hnu hg hD hidentify henergy hweak
  have heq : FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierACoordinateEquiv.plusPullback
        (FrontierDissipationDomain.gradientDissipation (g t)))
      (fun t => FrontierACoordinateEquiv.minusPullback
        (FrontierDissipationDomain.gradientDissipation (g t))) =ᵐ[η]
      FeffermanAHopfGramIntegral.gramSqrt
        (fun t => FrontierACoordinateEquiv.plusPullback (dissipation (u t)))
        (fun t => FrontierACoordinateEquiv.minusPullback (dissipation (u t))) := by
    filter_upwards [hweak] with t ht
    have h := dissipation_eq_gradient (u t) (g t) ht
    simp only [FeffermanAHopfGramIntegral.gramSqrt, h]
  constructor
  · exact hbound.1.congr heq
  · unfold FeffermanAHopfGramIntegral.gramSqrtIntegral at hbound ⊢
    rw [← integral_congr_ae heq]
    exact hbound.2

end FrontierSpectralOperator

#print axioms FrontierSpectralOperator.dissipation_fourier
#print axioms FrontierSpectralOperator.dissipation_eq_of_symbol
#print axioms FrontierSpectralOperator.dissipation_eq_gradient
#print axioms FrontierSpectralOperator.dissipation_ofWeakGradient

#print axioms FrontierSpectralOperator.spectral_projected_gram_from_energy


/-! A-TIER CANDIDATE. Pointwise Fourier-representative conjugate symmetry for
helical matrix actions. The passage from pointwise representatives to L²
a.e. classes, reflection of null sets, and the equivalence between Hermitian
Fourier symmetry and real-valued physical fields remain open. -/
noncomputable section
open FeffermanHelicalFrequency
namespace FrontierRealSymmetry
abbrev Frequency := Fin 3 → ℝ
abbrev Vector := Fin 3 → ℂ

/-- Hermitian symmetry for a pointwise complex Fourier representative. -/
def HermitianSymmetric (F : Frequency → Vector) : Prop :=
  ∀ ξ j, F (-ξ) j = star (F ξ j)

/-- Positive helical action respects pointwise conjugate reversal. -/
theorem plus_mulVec_conjugate_reversal (x y z : ℝ) (v : Vector) (i : Fin 3) :
    ((plus (-x) (-y) (-z)).mulVec (fun j => star (v j))) i =
      star (((plus x y z).mulVec v) i) := by
  simp [Matrix.mulVec, dotProduct, Fin.sum_univ_succ,
    plus_conjugate_reversal, mul_comm]

/-- Negative helical action respects pointwise conjugate reversal. -/
theorem minus_mulVec_conjugate_reversal (x y z : ℝ) (v : Vector) (i : Fin 3) :
    ((minus (-x) (-y) (-z)).mulVec (fun j => star (v j))) i =
      star (((minus x y z).mulVec v) i) := by
  simp [Matrix.mulVec, dotProduct, Fin.sum_univ_succ,
    minus_conjugate_reversal, mul_comm]

def plusRepresentative (F : Frequency → Vector) (ξ : Frequency) : Vector :=
  (plus (ξ 0) (ξ 1) (ξ 2)).mulVec (F ξ)

def minusRepresentative (F : Frequency → Vector) (ξ : Frequency) : Vector :=
  (minus (ξ 0) (ξ 1) (ξ 2)).mulVec (F ξ)

theorem plus_preserves_pointwise_symmetry (F : Frequency → Vector)
    (h : HermitianSymmetric F) : HermitianSymmetric (plusRepresentative F) := by
  intro ξ i
  have hv : F (-ξ) = fun j => star (F ξ j) := by
    funext j
    exact h ξ j
  simpa [plusRepresentative, hv] using
    plus_mulVec_conjugate_reversal (ξ 0) (ξ 1) (ξ 2) (F ξ) i

theorem minus_preserves_pointwise_symmetry (F : Frequency → Vector)
    (h : HermitianSymmetric F) : HermitianSymmetric (minusRepresentative F) := by
  intro ξ i
  have hv : F (-ξ) = fun j => star (F ξ j) := by
    funext j
    exact h ξ j
  simpa [minusRepresentative, hv] using
    minus_mulVec_conjugate_reversal (ξ 0) (ξ 1) (ξ 2) (F ξ) i
end FrontierRealSymmetry

#print axioms FrontierRealSymmetry.plus_mulVec_conjugate_reversal
#print axioms FrontierRealSymmetry.minus_mulVec_conjugate_reversal
#print axioms FrontierRealSymmetry.plus_preserves_pointwise_symmetry
#print axioms FrontierRealSymmetry.minus_preserves_pointwise_symmetry


/-!
A-TIER CANDIDATE: scalar Fourier transversality implies the existing helical
operator splitting. The normalized frequency dot product and almost-everywhere
nonzero frequency are explicit hypotheses. This does not derive them from a
distributional divergence equation, and does not construct a Leray--Hopf field.
No local Lean compiler has been run.
-/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierSolenoidal

abbrev Frequency := FrontierPhysicalGramTransport.Frequency
abbrev Fiber := FeffermanHelicalOrthogonal.Fiber
abbrev PhysicalL2 := FrontierPhysicalGramTransport.PhysicalL2

/-- A direction-orthogonal amplitude is fixed by its transverse matrix. -/
theorem normalized_dot_zero_fixed (x y z : ℝ) (v : Fiber)
    (hdot : (x : ℂ) * v 0 + (y : ℂ) * v 1 + (z : ℂ) * v 2 = 0) :
    Matrix.toEuclideanLin (FeffermanHelicalGeneral.transverse x y z) v = v := by
  have hx := congrArg (fun a : ℂ => (x : ℂ) * a) hdot
  have hy := congrArg (fun a : ℂ => (y : ℂ) * a) hdot
  have hz := congrArg (fun a : ℂ => (z : ℂ) * a) hdot
  ext i
  fin_cases i
  · simp [Matrix.toEuclideanLin, Matrix.toLpLin_apply,
      Matrix.mulVec, dotProduct, Fin.sum_univ_succ,
      FeffermanHelicalGeneral.transverse]
    linear_combination -hx
  · simp [Matrix.toEuclideanLin, Matrix.toLpLin_apply,
      Matrix.mulVec, dotProduct, Fin.sum_univ_succ,
      FeffermanHelicalGeneral.transverse]
    linear_combination -hy
  · simp [Matrix.toEuclideanLin, Matrix.toLpLin_apply,
      Matrix.mulVec, dotProduct, Fin.sum_univ_succ,
      FeffermanHelicalGeneral.transverse]
    linear_combination -hz

/-- A normalized scalar Fourier-solenoidality condition implies the two
helical Fourier-conjugate operators split the supplied L² field. -/
theorem split_of_normalized_fourier_dot
    (f : PhysicalL2)
    (hnonzero : ∀ᵐ ξ ∂(volume : Measure Frequency),
      0 < FeffermanHelicalFrequency.lengthSq (ξ 0) (ξ 1) (ξ 2))
    (hdot : ∀ᵐ ξ ∂(volume : Measure Frequency),
      let r := FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2)
      let v := (FrontierPhysicalGramTransport.fourierCoordinateReal f : Frequency → Fiber) ξ
      ((ξ 0 / r : ℝ) : ℂ) * v 0 + ((ξ 1 / r : ℝ) : ℂ) * v 1 +
        ((ξ 2 / r : ℝ) : ℂ) * v 2 = 0) :
    FrontierPhysicalProjectors.plusProjector f +
      FrontierPhysicalProjectors.minusProjector f = f := by
  apply FrontierPhysicalProjectors.transverse_split
  filter_upwards [hnonzero, hdot] with ξ hξ hdotξ
  simp only [FeffermanHelicalFrequency.projection, if_pos hξ]
  exact normalized_dot_zero_fixed
    (ξ 0 / FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2))
    (ξ 1 / FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2))
    (ξ 2 / FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2)) _ hdotξ

end FrontierSolenoidal

#print axioms FrontierSolenoidal.normalized_dot_zero_fixed
#print axioms FrontierSolenoidal.split_of_normalized_fourier_dot
