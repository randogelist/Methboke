import FrontierAWeakGramInput
import FrontierAMatrixFourier

/-! Untested conditional candidate. For supplied time-dependent L² fields,
a matrix L² energy budget yields the existing abstract Gram bound and the
weak equations identify its frequency input at almost every time. No
Leray–Hopf solution, physical energy inequality, or physical helical Gram
is constructed. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierAWeakTimeGram
abbrev Space := FrontierAWeakGramInput.Space
abbrev Frequency := FrontierAWeakGramInput.Frequency
abbrev MatrixL2 := FrontierAWeakGramInput.MatrixL2
abbrev Field := FrontierAWeakGramInput.Field
abbrev Fiber := FrontierAWeakGramInput.Fiber
abbrev CoordinateL2 := FrontierAConcreteFourier.CoordinateL2

local instance realL2 (μ : Measure Frequency) :
    InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

/-- The precise existing Riesz input to the conditional Gram estimate. -/
def gramInput (g : MatrixL2) : CoordinateL2 :=
  FrontierAConcreteFourier.coordinateFourier
    (FrontierARieszVectorL2.inverseFourierVectorCLM
      (FrontierAMatrixFourier.matrixFourier g))

/-- The supplied-field Gram estimate together with the a.e. Fourier symbol
identification. The matrix-column, weak-equation, time L² and energy
assumptions are all explicit. -/
theorem time_gram_and_weak_symbol
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace MatrixL2] [BorelSpace MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace CoordinateL2] [BorelSpace CoordinateL2]
    (η : Measure τ) (u : τ → Field) (g : τ → MatrixL2)
    (du : τ → Fin 3 → Field) (nu initialEnergy : ℝ) (hnu : 0 < nu)
    (hgrad : MemLp g 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ initialEnergy)
    (hcol : ∀ᵐ t ∂η, ∀ j, FrontierAWeakMatrixColumns.columnL2 j (g t) = du t j)
    (hweak : ∀ᵐ t ∂η, ∀ j, Lp.toTemperedDistribution (du t j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t))) :
    (Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier (volume : Measure Frequency) (gramInput (g t)))
      (fun t => minusMultiplier (volume : Measure Frequency) (gramInput (g t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier (volume : Measure Frequency) (gramInput (g t)))
      (fun t => minusMultiplier (volume : Measure Frequency) (gramInput (g t)))
      ≤ initialEnergy / (4 * nu)) ∧
    (∀ᵐ t ∂η, ∀ᵐ ξ ∂(volume : Measure Frequency), ∀ i : Fin 3,
      (gramInput (g t) : Frequency → Fiber) ξ i =
        ((2 * Real.pi : ℝ) : ℂ) *
        (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2) : ℂ) *
        (FourierTransform.fourier (u t) : Field) (WithLp.toLp 2 ξ) i) := by
  constructor
  · simpa only [gramInput] using
      FrontierAMatrixFourier.gram_from_physical_matrix η g nu initialEnergy hnu hgrad hEnergy
  · filter_upwards [hcol, hweak] with t hc hw
    exact FrontierAWeakGramInput.gram_input_eq_weak_velocity_symbol (u t) (g t) (du t) hc hw

end FrontierAWeakTimeGram

#print axioms FrontierAWeakTimeGram.time_gram_and_weak_symbol
