import FrontierSpectralClosure

/-! A-tier candidate. Weak directional derivative equations imply the Fourier
velocity is orthogonal to frequency when the Fourier trace of those derivatives
is zero. A second result converts an unnormalized scalar Fourier dot-product
premise to the existing helical splitting theorem. The vanishing Fourier trace,
a.e. nonzero frequency and the connection between different physical fields are
explicit premises. This does not yet derive distributional divergence-freeness
or establish a Leray–Hopf realization. No local Lean compiler was run. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierDivergence
abbrev Space := FrontierAWeakRieszBridge.Space
abbrev Field := FrontierAWeakRieszBridge.Field
abbrev Frequency := FrontierPhysicalGramTransport.Frequency
abbrev Fiber := FeffermanHelicalOrthogonal.Fiber
abbrev PhysicalL2 := FrontierPhysicalGramTransport.PhysicalL2

/-- With explicit weak directional derivatives and a vanishing Fourier trace,
the Fourier transform of the velocity has zero frequency dot-product. -/
theorem weak_derivatives_fourier_trace_zero
    (u : Field) (du : Fin 3 → Field)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (htrace : ∀ᵐ ξ ∂(volume : Measure Space),
      FrontierAWeakRieszBridge.weakFourierMatrix du ξ 0 0 +
      FrontierAWeakRieszBridge.weakFourierMatrix du ξ 1 1 +
      FrontierAWeakRieszBridge.weakFourierMatrix du ξ 2 2 = 0) :
    ∀ᵐ ξ ∂(volume : Measure Space),
      (ξ.ofLp 0 : ℂ) * (FourierTransform.fourier u : Field) ξ 0 +
      (ξ.ofLp 1 : ℂ) * (FourierTransform.fourier u : Field) ξ 1 +
      (ξ.ofLp 2 : ℂ) * (FourierTransform.fourier u : Field) ξ 2 = 0 := by
  have hscale : (((2 * Real.pi : ℝ) : ℂ) * Complex.I) ≠ 0 := by
    apply mul_ne_zero
    · exact_mod_cast (mul_ne_zero (by norm_num : (2 : ℝ) ≠ 0) Real.pi_ne_zero)
    · exact Complex.I_ne_zero
  filter_upwards [FrontierAWeakRieszBridge.weak_fourier_matrix_eq u du hweak, htrace]
    with ξ hmatrix hdiag
  rw [hmatrix] at hdiag
  dsimp only [FrontierARieszDerivativeAlgebra.derivativeMatrix] at hdiag
  have hfactor : (((2 * Real.pi : ℝ) : ℂ) * Complex.I) *
      ((ξ.ofLp 0 : ℂ) * (FourierTransform.fourier u : Field) ξ 0 +
       (ξ.ofLp 1 : ℂ) * (FourierTransform.fourier u : Field) ξ 1 +
       (ξ.ofLp 2 : ℂ) * (FourierTransform.fourier u : Field) ξ 2) = 0 := by
    linear_combination hdiag
  exact (mul_eq_zero.mp hfactor).resolve_left hscale

/-- The unnormalized scalar dot condition already implies the normalized one,
even at zero radius because division is total in Lean. -/
theorem normalized_dot_of_unnormalized (x y z r : ℝ) (v : Fiber)
    (h : (x : ℂ) * v 0 + (y : ℂ) * v 1 + (z : ℂ) * v 2 = 0) :
    ((x / r : ℝ) : ℂ) * v 0 + ((y / r : ℝ) : ℂ) * v 1 +
      ((z / r : ℝ) : ℂ) * v 2 = 0 := by
  push_cast
  calc
    (x : ℂ) / (r : ℂ) * v 0 + (y : ℂ) / (r : ℂ) * v 1 +
        (z : ℂ) / (r : ℂ) * v 2 =
      (r : ℂ)⁻¹ * ((x : ℂ) * v 0 + (y : ℂ) * v 1 + (z : ℂ) * v 2) := by
        simp only [div_eq_mul_inv]
        ring
    _ = 0 := by rw [h, mul_zero]

/-- An unnormalized Fourier dot-product condition gives the existing
helical-projector split. Nonzero frequency remains an explicit a.e. premise. -/
theorem split_of_fourier_dot (f : PhysicalL2)
    (hnonzero : ∀ᵐ ξ ∂(volume : Measure Frequency),
      0 < FeffermanHelicalFrequency.lengthSq (ξ 0) (ξ 1) (ξ 2))
    (hdot : ∀ᵐ ξ ∂(volume : Measure Frequency),
      let v := (FrontierPhysicalGramTransport.fourierCoordinateReal f : Frequency → Fiber) ξ
      (ξ 0 : ℂ) * v 0 + (ξ 1 : ℂ) * v 1 + (ξ 2 : ℂ) * v 2 = 0) :
    FrontierPhysicalProjectors.plusProjector f +
      FrontierPhysicalProjectors.minusProjector f = f := by
  apply FrontierSolenoidal.split_of_normalized_fourier_dot f hnonzero
  filter_upwards [hdot] with ξ hξ
  exact normalized_dot_of_unnormalized (ξ 0) (ξ 1) (ξ 2)
    (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2)) _ hξ
end FrontierDivergence

#print axioms FrontierDivergence.weak_derivatives_fourier_trace_zero
#print axioms FrontierDivergence.normalized_dot_of_unnormalized
#print axioms FrontierDivergence.split_of_fourier_dot
