import HOPF_GRAM_INTEGRAL

/-!
A candidate bridge from a single square-integrable Hilbert-valued trajectory
and a self-adjoint idempotent continuous linear map to the already constructed
Gram integral. The projector axioms and the energy inequality are explicit
premises. This does not construct a physical Leray--Hopf solution or identify
a helical Fourier projector. This file requires native compilation and audit.
-/

noncomputable section

open MeasureTheory
open Filter

namespace HopfGramProjected

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- A self-adjoint idempotent splits each vector into orthogonal pieces. -/
theorem projector_orthogonal (P : H →L[ℝ] H)
    (hsym : ∀ x y : H, inner ℝ (P x) y = inner ℝ x (P y))
    (hid : ∀ x : H, P (P x) = P x) (x : H) :
    inner ℝ (P x) (x - P x) = 0 := by
  have h : inner ℝ (P x) x = inner ℝ (P x) (P x) := by
    simpa only [hid] using hsym (P x) x
  rw [inner_sub_right, h, sub_self]

/-- Pythagorean decomposition of the squared norm. -/
theorem projector_energy (P : H →L[ℝ] H)
    (hsym : ∀ x y : H, inner ℝ (P x) y = inner ℝ x (P y))
    (hid : ∀ x : H, P (P x) = P x) (x : H) :
    ‖P x‖ ^ 2 + ‖x - P x‖ ^ 2 = ‖x‖ ^ 2 := by
  have hadd : P x + (x - P x) = x := by abel
  have h := norm_add_sq_real (P x) (x - P x)
  rw [hadd, projector_orthogonal P hsym hid x] at h
  linarith

/-- The constructed Gram integral is controlled by the energy of one
    L2 trajectory. The orthogonality and two projected L2 facts are derived
    here, not assumed separately. -/
theorem projected_gram_integrable_and_bound
    {α : Type*} [MeasurableSpace α] [MeasurableSpace H] [BorelSpace H]
    (μ : Measure α) (P : H →L[ℝ] H) (z : α → H)
    (nu initialEnergy : ℝ)
    (hnu : 0 < nu)
    (hz : MemLp z 2 μ)
    (hsym : ∀ x y : H, inner ℝ (P x) y = inner ℝ x (P y))
    (hid : ∀ x : H, P (P x) = P x)
    (hEnergy : 2 * nu * (∫ t, ‖z t‖ ^ 2 ∂μ) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => P (z t)) (fun t => z t - P (z t))) μ ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral μ
      (fun t => P (z t)) (fun t => z t - P (z t))
      ≤ initialEnergy / (4 * nu) := by
  have hp : MemLp (fun t => P (z t)) 2 μ := by
    simpa only [Function.comp_def] using P.comp_memLp' hz
  have hm : MemLp (fun t => z t - P (z t)) 2 μ := hz.sub hp
  have ho : ∀ᵐ t ∂μ, inner ℝ (P (z t)) (z t - P (z t)) = 0 :=
    Filter.Eventually.of_forall (fun t => projector_orthogonal P hsym hid (z t))
  have heq : (∫ t, (‖P (z t)‖ ^ 2 + ‖z t - P (z t)‖ ^ 2) ∂μ) =
      (∫ t, ‖z t‖ ^ 2 ∂μ) := by
    apply integral_congr_ae
    exact Filter.Eventually.of_forall (fun t => projector_energy P hsym hid (z t))
  have hbudget : 2 * nu *
      (∫ t, (‖P (z t)‖ ^ 2 + ‖z t - P (z t)‖ ^ 2) ∂μ) ≤ initialEnergy := by
    rw [heq]
    exact hEnergy
  exact FeffermanAHopfGramIntegral.gramSqrt_integrable_and_bound_of_memLp_ae
    μ (fun t => P (z t)) (fun t => z t - P (z t)) nu initialEnergy
    hnu hp hm ho hbudget

end HopfGramProjected

#print axioms HopfGramProjected.projector_orthogonal
#print axioms HopfGramProjected.projector_energy
#print axioms HopfGramProjected.projected_gram_integrable_and_bound
