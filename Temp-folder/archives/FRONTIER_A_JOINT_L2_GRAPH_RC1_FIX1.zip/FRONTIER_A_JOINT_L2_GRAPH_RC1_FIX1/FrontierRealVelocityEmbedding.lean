import FrontierRealL2Density

/-! Candidate physical real-velocity complexification. The velocity is an
arbitrary real L² vector field. Its complexification is coordinatewise real
almost everywhere, and the Fourier transforms of its two projected fields
are Hermitian. The converse from Fourier Hermitian symmetry to physical
realness is not proved here; nor is any Leray--Hopf trajectory constructed.
No local Lean compiler was run. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierRealVelocityEmbedding

abbrev Space := FrontierRealL2Density.Space
abbrev ComplexFiber := FrontierRealL2Density.Fiber
abbrev Field := FrontierRealL2Density.Field
abbrev RealFiber := EuclideanSpace ℝ (Fin 3)
abbrev RealField := Lp RealFiber 2 (volume : Measure Space)

/-- Coordinatewise embedding of real velocity vectors into complex vectors. -/
def fiberComplex : RealFiber →ₗ[ℝ] ComplexFiber where
  toFun v := WithLp.toLp 2 (fun j => (v j : ℂ))
  map_add' v w := by ext j; simp
  map_smul' c v := by ext j; simp

def fiberComplexCLM : RealFiber →L[ℝ] ComplexFiber :=
  fiberComplex.toContinuousLinearMap

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩

def complexifyL2 : RealField →L[ℝ] Field :=
  ContinuousLinearMap.compLpL 2 (volume : Measure Space) fiberComplexCLM

theorem complexifyL2_ae (u : RealField) :
    (complexifyL2 u : Space → ComplexFiber) =ᵐ[volume]
      fun x => fiberComplexCLM ((u : Space → RealFiber) x) := by
  exact ContinuousLinearMap.coeFn_compLpL fiberComplexCLM u

/-- The chosen representative of the complexified real field is real a.e. -/
theorem complexifyL2_real_ae (u : RealField) :
    ∀ᵐ x ∂(volume : Measure Space), ∀ j : Fin 3,
      star ((complexifyL2 u : Space → ComplexFiber) x j) =
        (complexifyL2 u : Space → ComplexFiber) x j := by
  filter_upwards [complexifyL2_ae u] with x hx
  intro j
  rw [hx]
  change star (((u : Space → RealFiber) x j : ℝ) : ℂ) =
    (((u : Space → RealFiber) x j : ℝ) : ℂ)
  simp

/-- Fourier Hermitian symmetry for the complexification of real velocity. -/
theorem fourier_hermitian_of_real_field (u : RealField) :
    FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate (complexifyL2 u)) := by
  exact FrontierRealL2Density.fourier_hermitian_of_real_l2 _ (complexifyL2_real_ae u)

/-- The plus-projected complexified velocity has a Hermitian Fourier field. -/
theorem plus_fourier_hermitian_of_real_field (u : RealField) :
    FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate
        (FrontierACoordinateEquiv.plusPullback (complexifyL2 u))) := by
  rw [FrontierACoordinateEquiv.plus_intertwines]
  exact FrontierVolumeSymmetry.plus_preserves _ (fourier_hermitian_of_real_field u)

/-- The minus-projected complexified velocity has a Hermitian Fourier field. -/
theorem minus_fourier_hermitian_of_real_field (u : RealField) :
    FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate
        (FrontierACoordinateEquiv.minusPullback (complexifyL2 u))) := by
  rw [FrontierACoordinateEquiv.minus_intertwines]
  exact FrontierVolumeSymmetry.minus_preserves _ (fourier_hermitian_of_real_field u)

end FrontierRealVelocityEmbedding

#print axioms FrontierRealVelocityEmbedding.complexifyL2_ae
#print axioms FrontierRealVelocityEmbedding.complexifyL2_real_ae
#print axioms FrontierRealVelocityEmbedding.fourier_hermitian_of_real_field
#print axioms FrontierRealVelocityEmbedding.plus_fourier_hermitian_of_real_field
#print axioms FrontierRealVelocityEmbedding.minus_fourier_hermitian_of_real_field
