import FrontierARieszVectorGram
import HelicalCoordinateBridge

/-! A-TIER CANDIDATE. Matrix-valued complex L² Plancherel and coordinate
transport composed with the vector Riesz Gram estimate. The physical-space
matrix trajectory and its time-L² and energy budget are supplied. This file
does not define a Leray–Hopf solution, prove that the matrix is a weak gradient,
establish the distributional Fourier derivative identity, identify the real
physical helical Gram, or establish Navier–Stokes energy. External native Lean
compilation, signature inspection and theorem-level audits are required. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierAMatrixFourier

abbrev Space := HelicalCoordinateBridge.Space
abbrev GradFiber := FrontierARieszVectorSymbol.GradFiber
abbrev PhysicalMatrix := Lp GradFiber 2 (volume : Measure Space)
abbrev FrequencyMatrix := Lp GradFiber 2 (volume : Measure HelicalConcreteSymbol.Frequency)

/-- Vector-valued L² Fourier transform followed by the audited coordinate
pullback, specialized to a complex 3×3 matrix fiber. -/
def matrixToCoordinates : PhysicalMatrix →ₗᵢ[ℂ] FrequencyMatrix :=
  Lp.compMeasurePreservingₗᵢ ℂ (WithLp.toLp 2)
    HelicalCoordinateBridge.toLp_preserves_volume

def matrixFourier : PhysicalMatrix →L[ℂ] FrequencyMatrix :=
  matrixToCoordinates.toContinuousLinearMap.comp
    (MeasureTheory.Lp.fourierTransformₗᵢ Space GradFiber).toLinearIsometry.toContinuousLinearMap

theorem matrixFourier_norm (g : PhysicalMatrix) : ‖matrixFourier g‖ = ‖g‖ := by
  change ‖matrixToCoordinates ((MeasureTheory.Lp.fourierTransformₗᵢ Space GradFiber) g)‖ = ‖g‖
  rw [matrixToCoordinates.norm_map]
  exact (MeasureTheory.Lp.fourierTransformₗᵢ Space GradFiber).norm_map g

local instance realL2 (μ : Measure HelicalConcreteSymbol.Frequency) :
    InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

/-- A supplied physical-space matrix with its energy budget gives the
frequency-space Gram conclusion, without a separately supplied frequency
trajectory or budget. This does not identify the matrix as a weak gradient. -/
theorem gram_from_physical_matrix
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace PhysicalMatrix] [BorelSpace PhysicalMatrix]
    [MeasurableSpace FrequencyMatrix] [BorelSpace FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAConcreteFourier.CoordinateL2]
    [BorelSpace FrontierAConcreteFourier.CoordinateL2]
    (η : Measure τ) (grad : τ → PhysicalMatrix)
    (nu initialEnergy : ℝ) (hnu : 0 < nu)
    (hgrad : MemLp grad 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖grad t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (FrontierAConcreteFourier.coordinateFourier
          (FrontierARieszVectorL2.inverseFourierVectorCLM (matrixFourier (grad t)))))
      (fun t => minusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (FrontierAConcreteFourier.coordinateFourier
          (FrontierARieszVectorL2.inverseFourierVectorCLM (matrixFourier (grad t)))))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (FrontierAConcreteFourier.coordinateFourier
          (FrontierARieszVectorL2.inverseFourierVectorCLM (matrixFourier (grad t)))))
      (fun t => minusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (FrontierAConcreteFourier.coordinateFourier
          (FrontierARieszVectorL2.inverseFourierVectorCLM (matrixFourier (grad t)))))
      ≤ initialEnergy / (4 * nu) := by
  have hfreq : MemLp (fun t => matrixFourier (grad t)) 2 η := by
    simpa only [Function.comp_def] using matrixFourier.comp_memLp' hgrad
  have hbudget : 2 * nu * (∫ t, ‖matrixFourier (grad t)‖ ^ 2 ∂η) ≤ initialEnergy := by
    simpa only [matrixFourier_norm] using hEnergy
  exact FrontierARieszVectorGram.gram_from_frequency_matrix η (fun t => matrixFourier (grad t))
    nu initialEnergy hnu hfreq hbudget

end FrontierAMatrixFourier

#print axioms FrontierAMatrixFourier.matrixFourier_norm
#print axioms FrontierAMatrixFourier.gram_from_physical_matrix
