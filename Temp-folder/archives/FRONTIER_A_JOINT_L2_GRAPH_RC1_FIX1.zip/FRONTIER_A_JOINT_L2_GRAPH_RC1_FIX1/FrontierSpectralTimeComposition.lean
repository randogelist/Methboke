import FrontierSolenoidalSpectralInterface
import FrontierAEProjectedGraphEnergy

/-! Candidate composition of the audited solenoidal operator interface with
its a.e. weak-gradient graph lift. All operator laws in `Interface`, spatial
weak gradient and divergence, time-L² gradient and energy inequality remain
explicit premises. The supplied interface is not shown to instantiate the
physical curl/Stokes spectral operators; no Leray--Hopf realization is claimed.
No Lean compiler has been run locally. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierSpectralTimeComposition

abbrev Field := FrontierSpectralOperator.Field
abbrev Gradient := FrontierARealGradient.RealMatrix
abbrev Interface := FrontierSolenoidalSpectralInterface.Interface
abbrev Domain := FrontierSpectralOperator.Domain

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

/-- Apply the supplied operator to the positive projected graph lift where
that lift satisfies the internal solenoidal split; use zero elsewhere. -/
def positiveField (S : Interface) (u : Field) (g : Gradient) : Field := by
  classical
  let v := FrontierAEProjectedGraphEnergy.graphLift u g
  exact if h : FrontierSolenoidalSpectralInterface.Solenoidal v.val then
    S.dissipation (FrontierSolenoidalSpectralInterface.positiveDomain S v h) else 0

def negativeField (S : Interface) (u : Field) (g : Gradient) : Field := by
  classical
  let v := FrontierAEProjectedGraphEnergy.graphLift u g
  exact if h : FrontierSolenoidalSpectralInterface.Solenoidal v.val then
    S.dissipation (FrontierSolenoidalSpectralInterface.negativeDomain S v h) else 0

/-- On weak-gradient and divergence-free slices, the supplied spectral
operator outputs equal the existing canonical Fourier-pullback fields. -/
theorem operator_fields_eq_canonical (S : Interface) (u : Field) (g : Gradient)
    (hw : FrontierAEProjectedGraphEnergy.WeakAt u g)
    (hd : Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 0
        (FrontierGradientAdapter.gradientColumn g 0)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 1
        (FrontierGradientAdapter.gradientColumn g 1)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 2
        (FrontierGradientAdapter.gradientColumn g 2)) = 0) :
    positiveField S u g = FrontierPhysicalGramTransport.plusField g ∧
      negativeField S u g = FrontierPhysicalGramTransport.minusField g := by
  have hv : (FrontierAEProjectedGraphEnergy.graphLift u g).val = u :=
    FrontierAEProjectedGraphEnergy.graphLift_val_of_weak u g hw
  have hs : FrontierSolenoidalSpectralInterface.Solenoidal
      (FrontierAEProjectedGraphEnergy.graphLift u g).val := by
    rw [hv]
    exact FrontierSolenoidalSpectralInterface.solenoidal_of_weak_divergence u g hw hd
  have hw' : FrontierAEProjectedGraphEnergy.WeakAt
      (FrontierAEProjectedGraphEnergy.graphLift u g).val g := by
    rw [hv]
    exact hw
  constructor
  · unfold positiveField
    simp only [dif_pos hs]
    exact FrontierSolenoidalSpectralInterface.positive_dissipation_eq_canonical S
      (FrontierAEProjectedGraphEnergy.graphLift u g) hs g hw'
  · unfold negativeField
    simp only [dif_pos hs]
    exact FrontierSolenoidalSpectralInterface.negative_dissipation_eq_canonical S
      (FrontierAEProjectedGraphEnergy.graphLift u g) hs g hw'

/-- Under explicit operator, weak-gradient, divergence and energy inputs,
the Gram bound holds for the supplied operator's projected graph fields. -/
theorem finite_interval_gram_from_spectral_interface
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (S : Interface) (u : ℝ → Field) (g : ℝ → Gradient)
    (T nu : ℝ) (hnu : 0 < nu)
    (hg : MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T))
    (henergy : ‖u T‖ ^ 2 + 2 * nu *
      (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u 0‖ ^ 2)
    (hweak : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      FrontierAEProjectedGraphEnergy.WeakAt (u t) (g t))
    (hdiv : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 0
        (FrontierGradientAdapter.gradientColumn (g t) 0)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 1
        (FrontierGradientAdapter.gradientColumn (g t) 1)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 2
        (FrontierGradientAdapter.gradientColumn (g t) 2)) = 0) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => positiveField S (u t) (g t))
      (fun t => negativeField S (u t) (g t)))
      (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (FrontierFiniteIntervalEnergy.timeMeasure T)
      (fun t => positiveField S (u t) (g t))
      (fun t => negativeField S (u t) (g t)) ≤ ‖u 0‖ ^ 2 / (4 * nu) := by
  have hcore := FrontierAEProjectedGraphEnergy.finite_interval_projected_graph_from_weak_gradient
    u g T nu hnu hg henergy hweak
  have heq : FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierSpectralOperator.dissipation
        (FrontierProjectedDissipation.plusDomain
          (FrontierAEProjectedGraphEnergy.graphLift (u t) (g t))))
      (fun t => FrontierSpectralOperator.dissipation
        (FrontierProjectedDissipation.minusDomain
          (FrontierAEProjectedGraphEnergy.graphLift (u t) (g t)))) =ᵐ[
            FrontierFiniteIntervalEnergy.timeMeasure T]
    FeffermanAHopfGramIntegral.gramSqrt
      (fun t => positiveField S (u t) (g t))
      (fun t => negativeField S (u t) (g t)) := by
    filter_upwards [hweak, hdiv] with t hw hd
    have hv := FrontierAEProjectedGraphEnergy.graphLift_val_of_weak (u t) (g t) hw
    have hw' : FrontierAEProjectedGraphEnergy.WeakAt
        (FrontierAEProjectedGraphEnergy.graphLift (u t) (g t)).val (g t) := by
      rw [hv]
      exact hw
    have hp := FrontierProjectedGraphEnergy.projected_plus_of_weak_gradient
      (FrontierAEProjectedGraphEnergy.graphLift (u t) (g t)) (g t) hw'
    have hm := FrontierProjectedGraphEnergy.projected_minus_of_weak_gradient
      (FrontierAEProjectedGraphEnergy.graphLift (u t) (g t)) (g t) hw'
    have he := operator_fields_eq_canonical S (u t) (g t) hw hd
    simp only [FeffermanAHopfGramIntegral.gramSqrt, hp, hm,
      FrontierDissipationDomain.plus_projected_gradientDissipation,
      FrontierDissipationDomain.minus_projected_gradientDissipation, he.1, he.2]
  constructor
  · exact hcore.1.congr heq
  · unfold FeffermanAHopfGramIntegral.gramSqrtIntegral at hcore ⊢
    rw [← integral_congr_ae heq]
    exact hcore.2

end FrontierSpectralTimeComposition

#print axioms FrontierSpectralTimeComposition.operator_fields_eq_canonical
#print axioms FrontierSpectralTimeComposition.finite_interval_gram_from_spectral_interface
