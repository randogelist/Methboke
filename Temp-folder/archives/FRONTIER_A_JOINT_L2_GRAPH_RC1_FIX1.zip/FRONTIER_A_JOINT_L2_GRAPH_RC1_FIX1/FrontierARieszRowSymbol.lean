import Mathlib

/-!
Finite-dimensional candidate for the Riesz gradient row symbol.
No multiplier, L² operator, time trajectory, weak derivative or physical
Leray–Hopf solution is constructed in this file. The normalized direction is
supplied and the results require a native Windows Lean 4.33.0 compile and
theorem-level audit before promotion.
-/
noncomputable section

namespace FrontierARieszRowSymbol

/-- Algebraic three-dimensional Cauchy–Schwarz for a subunit real row. -/
theorem real_row_bound (a b c u v w : ℝ)
    (hunit : a ^ 2 + b ^ 2 + c ^ 2 ≤ 1) :
    (a * u + b * v + c * w) ^ 2 ≤ u ^ 2 + v ^ 2 + w ^ 2 := by
  have hid :
      (a ^ 2 + b ^ 2 + c ^ 2) * (u ^ 2 + v ^ 2 + w ^ 2) -
        (a * u + b * v + c * w) ^ 2 =
        (a * v - b * u) ^ 2 + (a * w - c * u) ^ 2 +
          (b * w - c * v) ^ 2 := by ring
  have hcs : (a * u + b * v + c * w) ^ 2 ≤
      (a ^ 2 + b ^ 2 + c ^ 2) * (u ^ 2 + v ^ 2 + w ^ 2) := by
    nlinarith [sq_nonneg (a * v - b * u), sq_nonneg (a * w - c * u),
      sq_nonneg (b * w - c * v)]
  have hmul : 0 ≤ (1 - (a ^ 2 + b ^ 2 + c ^ 2)) *
      (u ^ 2 + v ^ 2 + w ^ 2) := by
    apply mul_nonneg
    · linarith
    · positivity
  nlinarith [hmul]

/-- For a normalized frequency direction this is the row
    g ↦ -i ∑ nⱼ gⱼ, acting on one complex velocity component. -/
def row (a b c : ℝ) (u v w : ℂ) : ℂ :=
  -Complex.I * ((a : ℂ) * u + (b : ℂ) * v + (c : ℂ) * w)

/-- The row contracts the sum of the three complex component energies. -/
theorem row_normSq_bound (a b c : ℝ) (u v w : ℂ)
    (hunit : a ^ 2 + b ^ 2 + c ^ 2 ≤ 1) :
    Complex.normSq (row a b c u v w) ≤
      Complex.normSq u + Complex.normSq v + Complex.normSq w := by
  have hre := real_row_bound a b c u.re v.re w.re hunit
  have him := real_row_bound a b c u.im v.im w.im hunit
  norm_num [row, Complex.normSq, Complex.mul_re, Complex.mul_im] at *
  nlinarith [hre, him]

end FrontierARieszRowSymbol

#print axioms FrontierARieszRowSymbol.real_row_bound
#print axioms FrontierARieszRowSymbol.row_normSq_bound
