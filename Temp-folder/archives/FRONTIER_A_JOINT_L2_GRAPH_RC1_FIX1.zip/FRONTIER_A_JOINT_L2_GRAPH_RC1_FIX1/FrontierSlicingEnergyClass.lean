import FrontierWeakGradientSlicing
import Mathlib.MeasureTheory.Function.LocallyIntegrable

/-! Candidate bridge from independent Bochner energy-class bounds to the
local integrability hypothesis of the existing closed-graph slicing theorem.
This does not construct the Bochner trajectories from jointly measurable
spacetime representatives, establish the smooth-average graph hypothesis,
or formalize a Leray–Hopf solution. No local Lean compilation. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierSlicingEnergyClass

abbrev RealVelocity := FrontierWeakGradientSubspace.RealVelocity
abbrev Gradient := FrontierWeakGradientSubspace.Gradient

/-- Componentwise local integrability entails local integrability in the
product space. This only uses bounded product injections and addition. -/
theorem pair_locallyIntegrable
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (μ : Measure ℝ)
    (hu : LocallyIntegrable u μ) (hg : LocallyIntegrable g μ) :
    LocallyIntegrable (fun t => (u t, g t)) μ := by
  have hul : LocallyIntegrableOn (fun t => (u t, (0 : Gradient))) Set.univ μ := by
    simpa only [Function.comp_def, ContinuousLinearMap.inl_apply] using
      (ContinuousLinearMap.inl ℝ RealVelocity Gradient).locallyIntegrableOn_comp
        (hu.locallyIntegrableOn Set.univ)
  have hgl : LocallyIntegrableOn (fun t => ((0 : RealVelocity), g t)) Set.univ μ := by
    simpa only [Function.comp_def, ContinuousLinearMap.inr_apply] using
      (ContinuousLinearMap.inr ℝ RealVelocity Gradient).locallyIntegrableOn_comp
        (hg.locallyIntegrableOn Set.univ)
  have hpair : (fun t => (u t, g t)) =
      (fun t => (u t, (0 : Gradient))) + (fun t => ((0 : RealVelocity), g t)) := by
    funext t
    simp only [Pi.add_apply, Prod.mk_add_mk, add_zero, zero_add]
  rw [hpair]
  exact locallyIntegrableOn_univ.mp (hul.add hgl)

/-- General componentwise Bochner Lp bounds supply the local hypothesis
when the time measure is locally finite and both exponents are at least 1. -/
theorem pair_locallyIntegrable_of_memLp
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (μ : Measure ℝ)
    [IsLocallyFiniteMeasure μ] (p q : ENNReal)
    (hp : 1 ≤ p) (hq : 1 ≤ q)
    (hu : MemLp u p μ) (hg : MemLp g q μ) :
    LocallyIntegrable (fun t => (u t, g t)) μ := by
  exact pair_locallyIntegrable u g μ (hu.locallyIntegrable hp) (hg.locallyIntegrable hq)

/-- Conditional time-slicing theorem with separate velocity and gradient
energy-class hypotheses. The smooth-average graph assumption remains. -/
theorem weak_at_ae_of_energy_class_and_smooth_averages
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (μ : Measure ℝ)
    [IsLocallyFiniteMeasure μ]
    (hu : MemLp u (⊤ : ENNReal) μ) (hg : MemLp g 2 μ)
    (havg : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      (∫ t, φ t • (u t, g t) ∂μ) ∈ FrontierWeakGradientSubspace.graph) :
    ∀ᵐ t ∂μ, FrontierAEProjectedGraphEnergy.WeakAt
      (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t) := by
  apply FrontierWeakGradientSlicing.weak_at_ae_of_smooth_time_averages u g μ
  · exact pair_locallyIntegrable_of_memLp u g μ ⊤ 2 (by simp) (by norm_num) hu hg
  · exact havg

end FrontierSlicingEnergyClass

#print axioms FrontierSlicingEnergyClass.pair_locallyIntegrable
#print axioms FrontierSlicingEnergyClass.pair_locallyIntegrable_of_memLp
#print axioms FrontierSlicingEnergyClass.weak_at_ae_of_energy_class_and_smooth_averages
