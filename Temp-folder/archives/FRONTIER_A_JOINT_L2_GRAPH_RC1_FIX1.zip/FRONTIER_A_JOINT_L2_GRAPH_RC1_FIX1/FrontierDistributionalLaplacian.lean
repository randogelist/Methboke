import FrontierGraphSquared
import FrontierAWeakFourierAE
import FrontierAWeakRieszBridge

/-! Identification of the square of the project Fourier graph operator with
minus the distributional Laplacian, on data admitting three supplied first and
same-direction second L² weak derivatives. This does not construct the Stokes
operator or its square root, establish a domain equivalence, or treat a
Leray–Hopf trajectory. No local Lean execution. -/
noncomputable section
open MeasureTheory Filter FourierTransform
namespace FrontierDistributionalLaplacian
abbrev Field := FrontierSpectralOperator.Field
abbrev Domain := FrontierSpectralOperator.Domain
abbrev Space := FrontierAWeakRieszBridge.Space
abbrev Fiber := FrontierSpectralOperator.Fiber
abbrev Frequency := FrontierSpectralOperator.Frequency

/-- A supplied L² weak coordinate derivative has the expected Fourier symbol
on the coordinate-frequency model used by the project. -/
theorem weak_coordinate_fourier_ae (u du : Field) (j : Fin 3)
    (h : Lp.toTemperedDistribution du =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) :
    ∀ᵐ ξ ∂(volume : Measure Frequency),
      (FourierTransform.fourier du : Field) (WithLp.toLp 2 ξ) =
        ((((2 * Real.pi : ℝ) : ℂ) * Complex.I * (ξ j : ℂ))) •
          (FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ) := by
  have h0 := FrontierAWeakFourierAE.fourier_weak_derivative_ae u du
    (FrontierAWeakRieszBridge.unitDirection j) h
  have h1 := HelicalCoordinateBridge.toLp_preserves_volume.quasiMeasurePreserving.ae h0
  filter_upwards [h1] with ξ hξ
  simpa [FrontierAWeakFourierAE.derivativeConstant,
    FrontierAWeakRieszBridge.unitDirection, EuclideanSpace.inner_single_right] using hξ

/-- If a graph-domain field has three first L² weak derivatives and the three
corresponding pure second L² weak derivatives, then the second graph output
plus their sum vanishes in physical L². The additional composite-domain
hypothesis says only that the graph operator can be applied a second time. -/
theorem graph_square_add_weak_laplacian_eq_zero
    (u : Domain) (hg : FrontierGraphSquared.CompositeDomain u)
    (du ddu : Fin 3 → Field)
    (hfirst : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u.val))
    (hsecond : ∀ j, Lp.toTemperedDistribution (ddu j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (du j))) :
    FrontierSpectralOperator.dissipation
      ⟨FrontierSpectralOperator.dissipation u, hg⟩ + ddu 0 + ddu 1 + ddu 2 = 0 := by
  change FrontierDissipationDomain.HasDissipationSymbol
    (FrontierSpectralOperator.dissipation u) at hg
  let w : Field := FrontierSpectralOperator.dissipation
      ⟨FrontierSpectralOperator.dissipation u, hg⟩
  let F := FrontierACoordinateEquiv.fourierCoordinate
  have hw := FrontierGraphSquared.second_dissipation_fourier_explicit u hg
  have h0 := weak_coordinate_fourier_ae u.val (du 0) 0 (hfirst 0)
  have h1 := weak_coordinate_fourier_ae u.val (du 1) 1 (hfirst 1)
  have h2 := weak_coordinate_fourier_ae u.val (du 2) 2 (hfirst 2)
  have k0 := weak_coordinate_fourier_ae (du 0) (ddu 0) 0 (hsecond 0)
  have k1 := weak_coordinate_fourier_ae (du 1) (ddu 1) 1 (hsecond 1)
  have k2 := weak_coordinate_fourier_ae (du 2) (ddu 2) 2 (hsecond 2)
  have d0 := FrontierDomainLinear.fourierCoordinate_ae (ddu 0)
  have d1 := FrontierDomainLinear.fourierCoordinate_ae (ddu 1)
  have d2 := FrontierDomainLinear.fourierCoordinate_ae (ddu 2)
  have ha := Lp.coeFn_add (F w) (F (ddu 0))
  have hb := Lp.coeFn_add (F w + F (ddu 0)) (F (ddu 1))
  have hc := Lp.coeFn_add (F w + F (ddu 0) + F (ddu 1)) (F (ddu 2))
  have hz := Lp.coeFn_zero Fiber 2 (volume : Measure Frequency)
  apply FrontierACoordinateEquiv.fourierCoordinate.injective
  simp only [map_add, map_zero]
  apply Lp.ext
  filter_upwards [hw, h0, h1, h2, k0, k1, k2, d0, d1, d2, ha, hb, hc, hz]
    with ξ hw h0 h1 h2 k0 k1 k2 d0 d1 d2 ha hb hc hz
  rw [hc]
  simp only [Pi.add_apply]
  rw [hb]
  simp only [Pi.add_apply]
  rw [ha, hz]
  simp only [Pi.add_apply]
  change (F w : Frequency → Fiber) ξ = _ at hw
  change (F (ddu 0) : Frequency → Fiber) ξ = _ at d0
  change (F (ddu 1) : Frequency → Fiber) ξ = _ at d1
  change (F (ddu 2) : Frequency → Fiber) ξ = _ at d2
  rw [hw, d0, d1, d2, k0, k1, k2, h0, h1, h2]
  ext i
  simp only [PiLp.add_apply, PiLp.smul_apply, smul_eq_mul, Complex.ofReal_add,
    Complex.ofReal_mul, Complex.ofReal_pow, Pi.zero_apply, WithLp.ofLp_zero, PiLp.zero_apply]
  have hi : (Complex.I : ℂ) ^ 2 = -1 := by simpa [pow_two] using Complex.I_mul_I
  ring_nf <;> simp only [hi] <;> ring


/-- The independently defined negative distributional Laplacian, expressed
as the sum of three iterated weak coordinate derivatives. -/
def negativeDistributionalLaplacian (u : Field) : TemperedDistribution Space Fiber :=
  -(LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection 0)
      (LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection 0) (Lp.toTemperedDistribution u)) +
    LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection 1)
      (LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection 1) (Lp.toTemperedDistribution u)) +
    LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection 2)
      (LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection 2) (Lp.toTemperedDistribution u)))

/-- On supplied second-order weak-derivative data, the project graph square is
an L² representative of the independently defined negative distributional
Laplacian. -/
theorem graph_square_eq_negative_distributional_laplacian
    (u : Domain) (hg : FrontierGraphSquared.CompositeDomain u)
    (du ddu : Fin 3 → Field)
    (hfirst : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u.val))
    (hsecond : ∀ j, Lp.toTemperedDistribution (ddu j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (du j))) :
    Lp.toTemperedDistribution (FrontierSpectralOperator.dissipation
      ⟨FrontierSpectralOperator.dissipation u, hg⟩) = negativeDistributionalLaplacian u.val := by
  change FrontierDissipationDomain.HasDissipationSymbol
    (FrontierSpectralOperator.dissipation u) at hg
  have h := congrArg Lp.toTemperedDistribution
    (graph_square_add_weak_laplacian_eq_zero u hg du ddu hfirst hsecond)
  change (Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2) _ =
    (Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2) 0 at h
  simp only [map_add, map_zero, Lp.toTemperedDistributionCLM_apply] at h
  rw [hsecond 0, hsecond 1, hsecond 2, hfirst 0, hfirst 1, hfirst 2] at h
  unfold negativeDistributionalLaplacian
  apply eq_neg_iff_add_eq_zero.mpr
  simpa only [add_assoc] using h

end FrontierDistributionalLaplacian
#print axioms FrontierDistributionalLaplacian.weak_coordinate_fourier_ae
#print axioms FrontierDistributionalLaplacian.graph_square_add_weak_laplacian_eq_zero
#print axioms FrontierDistributionalLaplacian.graph_square_eq_negative_distributional_laplacian
