import FrontierARealWeakTimeGram
import FrontierACoordinateEquiv
import HelicalPhysicalEnergy

/-!
Concrete complex L2 Fourier pullback of the conditional weak-gradient Gram
bound. This uses the previously constructed Fourier/coordinate equivalence,
not a supplied isometry. The fields below are *defined* by pulling the
frequency multipliers back. Identifying them with A^(1/2) P_± applied to an
actual real Leray–Hopf solution, as well as constructing the gradient data and
energy inequality from that solution, remains open. In particular this module
does not assert the frozen unconditional physical theorem.
-/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierPhysicalGramTransport

abbrev Frequency := FrontierAWeakTimeGram.Frequency
abbrev Field := FrontierAWeakTimeGram.Field
abbrev MatrixL2 := FrontierAWeakTimeGram.MatrixL2
abbrev CoordinateL2 := FrontierAWeakTimeGram.CoordinateL2
abbrev PhysicalL2 := HelicalR3Plancherel.ComplexField

local instance frequencyRealL2 (μ : Measure Frequency) :
    InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

local instance physicalRealL2 : InnerProductSpace ℝ PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ PhysicalL2

/-- Mathlib Fourier transform followed by Euclidean coordinate transport,
viewed as an isometry of real Hilbert spaces. -/
def fourierCoordinateReal : PhysicalL2 ≃ₗᵢ[ℝ] CoordinateL2 where
  toLinearEquiv := FrontierACoordinateEquiv.fourierCoordinate.toLinearEquiv.restrictScalars ℝ
  norm_map' := by
    intro x
    exact FrontierACoordinateEquiv.fourierCoordinate.norm_map x

/-- The two complex physical-space fields are concrete Fourier pullbacks of
the frequency-space Gram inputs constructed from the supplied real matrix. -/
def plusField (g : FrontierARealGradient.RealMatrix) : PhysicalL2 :=
  fourierCoordinateReal.symm
    (plusMultiplier (volume : Measure Frequency) (FrontierARealGradient.realGradientSpectrum g))

def minusField (g : FrontierARealGradient.RealMatrix) : PhysicalL2 :=
  fourierCoordinateReal.symm
    (minusMultiplier (volume : Measure Frequency) (FrontierARealGradient.realGradientSpectrum g))

theorem plusField_fourier (g : FrontierARealGradient.RealMatrix) :
    fourierCoordinateReal (plusField g) =
      plusMultiplier (volume : Measure Frequency) (FrontierARealGradient.realGradientSpectrum g) := by
  simp [plusField]

theorem minusField_fourier (g : FrontierARealGradient.RealMatrix) :
    fourierCoordinateReal (minusField g) =
      minusMultiplier (volume : Measure Frequency) (FrontierARealGradient.realGradientSpectrum g) := by
  simp [minusField]

/-- Under exactly the supplied real-gradient, energy, and weak-derivative
premises, the concrete Fourier-pulled-back fields have the same Gram
integrability/budget as the spectral fields. No separate almost-everywhere
plus/minus transport hypotheses are required. -/
theorem real_gradient_pullback_gram_bound
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace MatrixL2] [BorelSpace MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace CoordinateL2] [BorelSpace CoordinateL2]
    (η : Measure τ) (u : τ → Field) (g : τ → FrontierARealGradient.RealMatrix)
    (du : τ → Fin 3 → Field) (nu initialEnergy : ℝ) (hnu : 0 < nu)
    (hgrad : MemLp g 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ initialEnergy)
    (hcol : ∀ᵐ t ∂η, ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 (g t)) = du t j)
    (hweak : ∀ᵐ t ∂η, ∀ j, Lp.toTemperedDistribution (du t j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t))) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusField (g t)) (fun t => minusField (g t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusField (g t)) (fun t => minusField (g t)) ≤ initialEnergy / (4 * nu) := by
  have hcore := FrontierARealWeakTimeGram.time_real_gram_and_weak_symbol
    η u g du nu initialEnergy hnu hgrad hEnergy hcol hweak
  have heq :
      FeffermanAHopfGramIntegral.gramSqrt
        (fun t => plusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t)))
        (fun t => minusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t))) =
      FeffermanAHopfGramIntegral.gramSqrt
        (fun t => plusField (g t)) (fun t => minusField (g t)) := by
    have hplus :
        (fun t : τ => fourierCoordinateReal (plusField (g t))) =
        (fun t : τ => plusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t))) := by
      funext t
      exact plusField_fourier (g t)
    have hminus :
        (fun t : τ => fourierCoordinateReal (minusField (g t))) =
        (fun t : τ => minusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t))) := by
      funext t
      exact minusField_fourier (g t)
    rw [← hplus, ← hminus]
    exact HelicalPhysicalEnergy.gramSqrt_isometry fourierCoordinateReal
      (fun t => plusField (g t)) (fun t => minusField (g t))
  constructor
  · simpa only [heq] using hcore.1.1
  · have hh := hcore.1.2
    unfold FeffermanAHopfGramIntegral.gramSqrtIntegral at hh ⊢
    simpa only [heq] using hh

end FrontierPhysicalGramTransport

#print axioms FrontierPhysicalGramTransport.plusField_fourier
#print axioms FrontierPhysicalGramTransport.minusField_fourier
#print axioms FrontierPhysicalGramTransport.real_gradient_pullback_gram_bound
