import FrontierInteriorWeakNSE

/-! The existing project-defined Fourier multipliers and graph operator
construct the previously supplied spectral interface. This proves existence
for these project-defined operators only; it does not identify them with an
independently defined physical Stokes square root. No local Lean run. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierCanonicalInterface

/-- Match the real Hilbert structure used by the imported Gram theorems. -/
local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

/-- Canonical Fourier-symbol realization of the solenoidal interface. -/
def canonical : FrontierSolenoidalSpectralInterface.Interface where
  positive := FrontierPhysicalProjectors.plusProjector
  negative := FrontierPhysicalProjectors.minusProjector
  dissipation := FrontierSpectralOperator.dissipation
  positive_fourier := by
    intro u hu
    exact FrontierPhysicalProjectors.plus_fourier u
  negative_fourier := by
    intro u hu
    exact FrontierPhysicalProjectors.minus_fourier u
  dissipation_plus_fourier := by
    intro u hu
    exact FrontierSpectralOperator.dissipation_fourier
      (FrontierProjectedDissipation.plusDomain u)
  dissipation_minus_fourier := by
    intro u hu
    exact FrontierSpectralOperator.dissipation_fourier
      (FrontierProjectedDissipation.minusDomain u)

/-- An interface exists without a separate spectral-law premise. -/
theorem interface_exists : Nonempty FrontierSolenoidalSpectralInterface.Interface :=
  ⟨canonical⟩

/-- With the canonical operators, the audited implication requires no
separately supplied interface. The energy-solution hypothesis is unchanged;
its realization by a standard Leray--Hopf solution remains open. -/
theorem gram_from_interior_energy_solution_canonical
    [MeasurableSpace FrontierInteriorWeakNSE.Velocity]
    [BorelSpace FrontierInteriorWeakNSE.Velocity]
    [MeasurableSpace FrontierInteriorWeakNSE.Gradient]
    [BorelSpace FrontierInteriorWeakNSE.Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → FrontierInteriorWeakNSE.Velocity)
    (u0 : FrontierInteriorWeakNSE.Velocity) (g : ℝ → FrontierInteriorWeakNSE.Gradient)
    (nu : ℝ) (hnu : 0 < nu)
    (hsol : FrontierInteriorWeakNSE.InteriorEnergySolution u u0 g nu)
    (T : ℝ) (hT : 0 ≤ T) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierSpectralTimeComposition.positiveField canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)))
      (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (FrontierFiniteIntervalEnergy.timeMeasure T)
      (fun t => FrontierSpectralTimeComposition.positiveField canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  exact FrontierInteriorWeakNSE.gram_from_interior_energy_solution
    canonical u u0 g nu hnu hsol T hT

/-- The canonical Fourier-symbol bound under the exact weaker real-trajectory
premises; no equation, initial right limit or global-in-time energy structure is
assumed. Identification with independently defined physical operators remains
separate. -/
theorem finite_interval_real_trajectory_canonical
    [MeasurableSpace FrontierRealSpectralEnergy.Gradient]
    [BorelSpace FrontierRealSpectralEnergy.Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → FrontierRealSpectralEnergy.RealVelocity)
    (u0 : FrontierRealSpectralEnergy.RealVelocity) (g : ℝ → FrontierRealSpectralEnergy.Gradient)
    (T nu : ℝ) (hnu : 0 < nu) (hinit : u 0 = u0)
    (hg : MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T))
    (henergy : ‖u T‖ ^ 2 + 2 * nu *
      (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      FrontierAEProjectedGraphEnergy.WeakAt (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
    (htrace : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      ∀ᵐ x ∂(volume : Measure FrontierRealSpectralEnergy.Space),
        (g t : FrontierRealSpectralEnergy.Space → FrontierRealSpectralEnergy.RealFiber) x (0, 0) +
        (g t : FrontierRealSpectralEnergy.Space → FrontierRealSpectralEnergy.RealFiber) x (1, 1) +
        (g t : FrontierRealSpectralEnergy.Space → FrontierRealSpectralEnergy.RealFiber) x (2, 2) = 0) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierSpectralTimeComposition.positiveField canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)))
      (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (FrontierFiniteIntervalEnergy.timeMeasure T)
      (fun t => FrontierSpectralTimeComposition.positiveField canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  exact FrontierRealSpectralEnergy.finite_interval_real_trajectory
    canonical u u0 g T nu hnu hinit hg henergy hweak htrace

end FrontierCanonicalInterface

#print axioms FrontierCanonicalInterface.canonical
#print axioms FrontierCanonicalInterface.interface_exists
#print axioms FrontierCanonicalInterface.gram_from_interior_energy_solution_canonical
#print axioms FrontierCanonicalInterface.finite_interval_real_trajectory_canonical
