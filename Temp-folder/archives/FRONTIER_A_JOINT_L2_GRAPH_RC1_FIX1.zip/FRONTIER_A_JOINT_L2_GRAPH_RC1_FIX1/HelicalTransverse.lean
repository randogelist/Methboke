import HelicalGeneral

/-!
An algebraic action-level bridge for the previously constructed helical
matrices. All vectors here are frequency amplitudes in `Fin 3 → ℂ`, not
functions of frequency. The transverse hypothesis is explicit. This module
does not construct a Fourier multiplier or a Navier--Stokes solution.
-/

noncomputable section

namespace FeffermanHelicalTransverse

open FeffermanHelicalGeneral

/-- The two matrix actions add up to the original transverse amplitude. -/
theorem transverse_split (x y z : ℝ) (hunit : x ^ 2 + y ^ 2 + z ^ 2 = 1)
    (v : Fin 3 → ℂ) (hv : (transverse x y z).mulVec v = v) :
    (positive x y z).mulVec v + (negative x y z).mulVec v = v := by
  have hp := congrArg (fun M : Matrix (Fin 3) (Fin 3) ℂ => M.mulVec v)
    (helicity_partition x y z hunit)
  rw [Matrix.add_mulVec, hv] at hp
  exact hp

/-- For transverse amplitudes, the negative sector is the complement of
    the positive sector. -/
theorem negative_eq_complement (x y z : ℝ)
    (hunit : x ^ 2 + y ^ 2 + z ^ 2 = 1)
    (v : Fin 3 → ℂ) (hv : (transverse x y z).mulVec v = v) :
    (negative x y z).mulVec v = v - (positive x y z).mulVec v := by
  have hs := transverse_split x y z hunit v hv
  calc
    (negative x y z).mulVec v =
        ((positive x y z).mulVec v + (negative x y z).mulVec v) -
          (positive x y z).mulVec v := by abel
    _ = v - (positive x y z).mulVec v := by rw [hs]

/-- Idempotence passes from the verified symbol to its action on vectors. -/
theorem positive_action_idempotent (x y z : ℝ)
    (hunit : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fin 3 → ℂ) :
    (positive x y z).mulVec ((positive x y z).mulVec v) =
      (positive x y z).mulVec v := by
  rw [Matrix.mulVec_mulVec, positive_idempotent x y z hunit]

theorem negative_action_idempotent (x y z : ℝ)
    (hunit : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fin 3 → ℂ) :
    (negative x y z).mulVec ((negative x y z).mulVec v) =
      (negative x y z).mulVec v := by
  rw [Matrix.mulVec_mulVec, negative_idempotent x y z hunit]

theorem positive_after_negative_zero (x y z : ℝ)
    (hunit : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fin 3 → ℂ) :
    (positive x y z).mulVec ((negative x y z).mulVec v) = 0 := by
  rw [Matrix.mulVec_mulVec, helicity_cross_zero x y z hunit]
  exact Matrix.zero_mulVec v

theorem positive_action_curl_eigen (x y z : ℝ)
    (hunit : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fin 3 → ℂ) :
    (curlSymbol x y z).mulVec ((positive x y z).mulVec v) =
      (positive x y z).mulVec v := by
  rw [Matrix.mulVec_mulVec, positive_curl_eigen x y z hunit]

theorem negative_action_curl_eigen (x y z : ℝ)
    (hunit : x ^ 2 + y ^ 2 + z ^ 2 = 1) (v : Fin 3 → ℂ) :
    (curlSymbol x y z).mulVec ((negative x y z).mulVec v) =
      -((negative x y z).mulVec v) := by
  rw [Matrix.mulVec_mulVec, negative_curl_eigen x y z hunit]
  exact Matrix.neg_mulVec v (negative x y z)

end FeffermanHelicalTransverse

#print axioms FeffermanHelicalTransverse.transverse_split
#print axioms FeffermanHelicalTransverse.negative_eq_complement
#print axioms FeffermanHelicalTransverse.positive_action_idempotent
#print axioms FeffermanHelicalTransverse.negative_action_idempotent
#print axioms FeffermanHelicalTransverse.positive_after_negative_zero
#print axioms FeffermanHelicalTransverse.positive_action_curl_eigen
#print axioms FeffermanHelicalTransverse.negative_action_curl_eigen
