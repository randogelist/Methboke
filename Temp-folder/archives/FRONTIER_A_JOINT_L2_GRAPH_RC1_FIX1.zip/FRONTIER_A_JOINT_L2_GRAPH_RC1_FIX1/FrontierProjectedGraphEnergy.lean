import FrontierProjectedDissipation
import FrontierAlmostEverywhereDomain

/-! Candidate energy transfer to the project’s Fourier graph operator applied
to projected velocities. The supplied trajectory is graph-domain valued; its
weak-gradient and energy hypotheses remain explicit. This does not identify
the graph operator with an independently defined physical Stokes square root,
nor does it construct or identify a Leray--Hopf trajectory. No local Lean run. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierProjectedGraphEnergy

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

/-- Applying graph dissipation to the positive helical projection agrees with
the positive helical projection of the weak-gradient dissipation. -/
theorem projected_plus_of_weak_gradient
    (u : FrontierSpectralOperator.Domain) (g : FrontierARealGradient.RealMatrix)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u.val)) :
    FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.plusDomain u) =
      FrontierACoordinateEquiv.plusPullback (FrontierDissipationDomain.gradientDissipation g) := by
  rw [FrontierProjectedDissipation.dissipation_plus,
    FrontierSpectralOperator.dissipation_eq_gradient u g hweak,
    FrontierPhysicalProjectors.plus_matches_pullback]

theorem projected_minus_of_weak_gradient
    (u : FrontierSpectralOperator.Domain) (g : FrontierARealGradient.RealMatrix)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u.val)) :
    FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.minusDomain u) =
      FrontierACoordinateEquiv.minusPullback (FrontierDissipationDomain.gradientDissipation g) := by
  rw [FrontierProjectedDissipation.dissipation_minus,
    FrontierSpectralOperator.dissipation_eq_gradient u g hweak,
    FrontierPhysicalProjectors.minus_matches_pullback]

/-- The gradient-based integral estimate applies to graph dissipation of
projected velocities for a supplied graph-domain trajectory. -/
theorem projected_graph_gram_from_gradient_energy
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → FrontierSpectralOperator.Domain)
    (g : τ → FrontierARealGradient.RealMatrix)
    (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : MemLp g 2 η)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂η, ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t).val)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.plusDomain (u t)))
      (fun t => FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.minusDomain (u t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.plusDomain (u t)))
      (fun t => FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.minusDomain (u t))) ≤
        ‖u0‖ ^ 2 / (4 * nu) := by
  have hb := FrontierAlmostEverywhereDomain.gram_and_domain_from_gradient_energy
    η (fun t => (u t).val) g u0 uT nu hnu hg henergy hweak
  have heq : FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierACoordinateEquiv.plusPullback
        (FrontierDissipationDomain.gradientDissipation (g t)))
      (fun t => FrontierACoordinateEquiv.minusPullback
        (FrontierDissipationDomain.gradientDissipation (g t))) =ᵐ[η]
      FeffermanAHopfGramIntegral.gramSqrt
        (fun t => FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.plusDomain (u t)))
        (fun t => FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.minusDomain (u t))) := by
    filter_upwards [hweak] with t ht
    have hp := projected_plus_of_weak_gradient (u t) (g t) ht
    have hm := projected_minus_of_weak_gradient (u t) (g t) ht
    simp only [FeffermanAHopfGramIntegral.gramSqrt, hp, hm]
  constructor
  · exact hb.2.1.congr heq
  · unfold FeffermanAHopfGramIntegral.gramSqrtIntegral at hb ⊢
    rw [← integral_congr_ae heq]
    exact hb.2.2

end FrontierProjectedGraphEnergy

#print axioms FrontierProjectedGraphEnergy.projected_plus_of_weak_gradient
#print axioms FrontierProjectedGraphEnergy.projected_minus_of_weak_gradient
#print axioms FrontierProjectedGraphEnergy.projected_graph_gram_from_gradient_energy
