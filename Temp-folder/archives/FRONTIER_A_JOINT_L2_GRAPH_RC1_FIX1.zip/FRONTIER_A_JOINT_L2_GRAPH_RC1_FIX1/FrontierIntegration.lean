import FrontierSpine
import FrontierScalar
import FrontierConcentration
import FrontierEnergyDefect

/-!
Integration root for the candidate extension of Frontier_A v0.28.
The source files retain explicit assumptions; importing this module does not
establish physical Leray–Hopf realization, sharpness, or full closure.
-/

namespace FrontierIntegration

/-- Deterministic scalar chain. Physical realization and all hypotheses of
this implication must be established independently for any intended use. -/
theorem budget_and_radial_envelope
    (nu initial terminal h mismatch defect alpha m n a b : ℝ)
    (hnu : 0 < nu) (hterminal : 0 ≤ terminal)
    (hmismatch : 0 ≤ mismatch) (hdefect : 0 ≤ defect)
    (henergy : initial = terminal + 4 * nu * h + 2 * nu * mismatch + defect)
    (hab : a + b = 1) (ha0 : 0 ≤ alpha) (ha1 : alpha ≤ 1)
    (hm : 0 ≤ a - m ^ 2) (hn : 0 ≤ b - n ^ 2) :
    h ≤ initial / (4 * nu) ∧ (alpha * m) ^ 2 + (alpha * n) ^ 2 ≤ 1 := by
  exact ⟨FrontierScalar.energy_defect_bound nu initial terminal h mismatch defect
      hnu hterminal hmismatch hdefect henergy,
    FrontierScalar.radial_bound alpha m n a b hab ha0 ha1 hm hn⟩

end FrontierIntegration

#print axioms FrontierIntegration.budget_and_radial_envelope
#print FrontierSpine.real_weak_gram_transport
