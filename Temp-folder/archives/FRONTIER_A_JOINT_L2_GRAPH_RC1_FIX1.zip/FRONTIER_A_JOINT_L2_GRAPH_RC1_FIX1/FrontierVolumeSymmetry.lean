import FrontierAESymmetry
import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.MeasureTheory.Group.Measure

/-! Candidate discharge of the measure-reflection assumption for Lebesgue
volume on the frequency coordinate space. Fourier reality of actual physical
fields and the Leray--Hopf realization remain separate obligations. -/
noncomputable section
open MeasureTheory
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierVolumeSymmetry

/-- Lebesgue almost-everywhere statements survive frequency reversal. -/
theorem volume_reflectsAE : FrontierAESymmetry.ReflectsAE volume := by
  intro P hP
  exact (Measure.measurePreserving_neg
    (volume : Measure FrontierAESymmetry.Frequency)).quasiMeasurePreserving.ae hP

/-- Plus helicity preserves Hermitian symmetry without a reflection premise. -/
theorem plus_preserves (f : Lp FrontierAESymmetry.Fiber 2 volume)
    (hf : FrontierAESymmetry.HermitianAE volume f) :
    FrontierAESymmetry.HermitianAE volume (plusMultiplier volume f) :=
  FrontierAESymmetry.plus_preserves_hermitianAE volume f volume_reflectsAE hf

/-- Minus helicity preserves Hermitian symmetry without a reflection premise. -/
theorem minus_preserves (f : Lp FrontierAESymmetry.Fiber 2 volume)
    (hf : FrontierAESymmetry.HermitianAE volume f) :
    FrontierAESymmetry.HermitianAE volume (minusMultiplier volume f) :=
  FrontierAESymmetry.minus_preserves_hermitianAE volume f volume_reflectsAE hf

end FrontierVolumeSymmetry

#print axioms FrontierVolumeSymmetry.volume_reflectsAE
#print axioms FrontierVolumeSymmetry.plus_preserves
#print axioms FrontierVolumeSymmetry.minus_preserves
