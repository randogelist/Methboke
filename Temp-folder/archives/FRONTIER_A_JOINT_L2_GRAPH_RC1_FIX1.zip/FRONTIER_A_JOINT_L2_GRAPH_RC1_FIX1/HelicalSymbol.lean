import Mathlib

/-!
The explicit positive and negative helical Fourier symbols at the single
unit frequency axis xi=(0,0,1). They are 3-by-3 complex matrices acting
on Fourier amplitudes. This file is a finite-dimensional algebraic test;
it does not define a multiplier on R^3, a Fourier transform, or a Hopf
trajectory.
-/

noncomputable section

namespace FeffermanHelicalAxis

/-- Leray projection onto the plane perpendicular to (0,0,1). -/
def transverse : Matrix (Fin 3) (Fin 3) ℂ :=
  !![1, 0, 0; 0, 1, 0; 0, 0, 0]

/-- Fourier symbol i (xi cross .) for xi=(0,0,1). -/
def curlAxis : Matrix (Fin 3) (Fin 3) ℂ :=
  !![0, -Complex.I, 0; Complex.I, 0, 0; 0, 0, 0]

/-- Projection onto the positive helicity sector at the chosen axis. -/
def positive : Matrix (Fin 3) (Fin 3) ℂ :=
  !![(1 / 2 : ℂ), -Complex.I / 2, 0;
     Complex.I / 2, (1 / 2 : ℂ), 0;
     0, 0, 0]

/-- Projection onto the negative helicity sector at the chosen axis. -/
def negative : Matrix (Fin 3) (Fin 3) ℂ :=
  !![(1 / 2 : ℂ), Complex.I / 2, 0;
     -Complex.I / 2, (1 / 2 : ℂ), 0;
     0, 0, 0]

theorem helicity_partition : positive + negative = transverse := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [positive, negative, transverse, Complex.ext_iff,
      Complex.div_re, Complex.div_im, Complex.normSq]

theorem positive_idempotent : positive * positive = positive := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [positive, Matrix.mul_apply, Fin.sum_univ_succ,
      Complex.ext_iff, Complex.div_re, Complex.div_im, Complex.normSq]

theorem negative_idempotent : negative * negative = negative := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [negative, Matrix.mul_apply, Fin.sum_univ_succ,
      Complex.ext_iff, Complex.div_re, Complex.div_im, Complex.normSq]

theorem helicity_cross_zero : positive * negative = 0 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [positive, negative, Matrix.mul_apply, Fin.sum_univ_succ,
      Complex.ext_iff, Complex.div_re, Complex.div_im, Complex.normSq]

theorem positive_curl_eigen : curlAxis * positive = positive := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [curlAxis, positive, Matrix.mul_apply, Fin.sum_univ_succ,
      Complex.ext_iff, Complex.div_re, Complex.div_im, Complex.normSq]

theorem negative_curl_eigen : curlAxis * negative = -negative := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [curlAxis, negative, Matrix.mul_apply, Fin.sum_univ_succ,
      Complex.ext_iff, Complex.div_re, Complex.div_im, Complex.normSq]

end FeffermanHelicalAxis

#print axioms FeffermanHelicalAxis.helicity_partition
#print axioms FeffermanHelicalAxis.positive_idempotent
#print axioms FeffermanHelicalAxis.negative_idempotent
#print axioms FeffermanHelicalAxis.helicity_cross_zero
#print axioms FeffermanHelicalAxis.positive_curl_eigen
#print axioms FeffermanHelicalAxis.negative_curl_eigen
