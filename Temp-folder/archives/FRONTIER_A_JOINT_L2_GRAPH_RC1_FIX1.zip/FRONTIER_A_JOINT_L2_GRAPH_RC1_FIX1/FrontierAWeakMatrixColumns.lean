import FrontierAFourierPostcompL2
import FrontierAWeakRieszBridge

/-! Untested candidate. The supplied L² matrix must have the supplied
weak-derivative fields as its columns. Neither the matrix nor the fields are
constructed from a Leray–Hopf solution. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierAWeakMatrixColumns
abbrev Space := FrontierAFourierPostcompL2.Space
abbrev GradFiber := FrontierAFourierPostcompL2.GradFiber
abbrev Fiber := FrontierAFourierPostcompL2.Fiber
abbrev MatrixL2 := FrontierAFourierPostcompL2.MatrixL2
abbrev Field := FrontierAWeakRieszBridge.Field

/-- One-hot derivative-index extraction. -/
def columnCLM (j : Fin 3) : GradFiber →L[ℂ] Fiber :=
  FrontierARieszVectorSymbol.coeffToVectorCLM (fun k => if k = j then 1 else 0)

theorem columnCLM_apply (j : Fin 3) (g : GradFiber) (i : Fin 3) :
    columnCLM j g i = g (i, j) := by
  fin_cases j <;> simp [columnCLM, FrontierARieszVectorSymbol.coeffToVectorCLM,
    FrontierARieszVectorSymbol.coeffMap]

def columnL2 (j : Fin 3) : MatrixL2 →L[ℂ] Field :=
  ContinuousLinearMap.compLpL 2 (volume : Measure Space) (columnCLM j)

theorem columnL2_ae (j : Fin 3) (g : MatrixL2) :
    (columnL2 j g : Space → Fiber) =ᵐ[volume]
      fun x => columnCLM j ((g : Space → GradFiber) x) := by
  exact ContinuousLinearMap.coeFn_compLpL (columnCLM j) g

/-- Pointwise form of the L² Fourier naturality of a concrete column. -/
theorem fourier_column_ae (g : MatrixL2) (du : Fin 3 → Field)
    (j : Fin 3) (hcol : columnL2 j g = du j) :
    ∀ᵐ ξ ∂(volume : Measure Space), ∀ i : Fin 3,
      (FourierTransform.fourier g : MatrixL2) ξ (i, j) =
        (FourierTransform.fourier (du j) : Field) ξ i := by
  have hn : FourierTransform.fourier (du j) =
      columnL2 j (FourierTransform.fourier g) := by
    rw [← hcol]
    exact FrontierAFourierPostcompL2.fourier_postcomp_l2 (columnCLM j) g
  have ha := columnL2_ae j (FourierTransform.fourier g)
  rw [← hn] at ha
  filter_upwards [ha] with ξ hξ
  intro i
  have hi := congrArg (fun v : Fiber => v i) hξ
  simpa only [columnCLM_apply] using hi.symm

/-- All entries agree with the Fourier transforms of the supplied columns. -/
theorem matrix_fourier_eq_weak_columns (g : MatrixL2) (du : Fin 3 → Field)
    (hcol : ∀ j, columnL2 j g = du j) :
    ∀ᵐ ξ ∂(volume : Measure Space), ∀ i j : Fin 3,
      (FourierTransform.fourier g : MatrixL2) ξ (i, j) =
        FrontierAWeakRieszBridge.weakFourierMatrix du ξ i j := by
  have h0 := fourier_column_ae g du 0 (hcol 0)
  have h1 := fourier_column_ae g du 1 (hcol 1)
  have h2 := fourier_column_ae g du 2 (hcol 2)
  filter_upwards [h0, h1, h2] with ξ h0 h1 h2
  intro i j
  fin_cases j
  · simpa only [FrontierAWeakRieszBridge.weakFourierMatrix] using! h0 i
  · simpa only [FrontierAWeakRieszBridge.weakFourierMatrix] using! h1 i
  · simpa only [FrontierAWeakRieszBridge.weakFourierMatrix] using! h2 i

/-- The Fourier transform of the supplied matrix is the derivative matrix
whenever its columns satisfy the supplied distributional weak equations. -/
theorem matrix_fourier_eq_weak_derivative (u : Field) (g : MatrixL2)
    (du : Fin 3 → Field) (hcol : ∀ j, columnL2 j g = du j)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) :
    ∀ᵐ ξ ∂(volume : Measure Space), ∀ i j : Fin 3,
      (FourierTransform.fourier g : MatrixL2) ξ (i, j) =
        FrontierARieszDerivativeAlgebra.derivativeMatrix (2 * Real.pi) ξ.ofLp
          (fun k => (FourierTransform.fourier u : Field) ξ k) i j := by
  filter_upwards [matrix_fourier_eq_weak_columns g du hcol,
    FrontierAWeakRieszBridge.weak_fourier_matrix_eq u du hweak] with ξ hcols hder
  intro i j
  rw [← hder]
  exact hcols i j

end FrontierAWeakMatrixColumns

#print axioms FrontierAWeakMatrixColumns.columnCLM_apply
#print axioms FrontierAWeakMatrixColumns.columnL2_ae
#print axioms FrontierAWeakMatrixColumns.fourier_column_ae
#print axioms FrontierAWeakMatrixColumns.matrix_fourier_eq_weak_columns
#print axioms FrontierAWeakMatrixColumns.matrix_fourier_eq_weak_derivative
