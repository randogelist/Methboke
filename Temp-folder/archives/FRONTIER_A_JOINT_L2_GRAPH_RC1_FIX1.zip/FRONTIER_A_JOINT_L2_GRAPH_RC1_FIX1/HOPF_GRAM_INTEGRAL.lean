import FEFFERMAN_A_HOPF_GRAM

/-!
Construction of the square-root determinant integral from actual vectors in
a real inner product space. The final wrapper accepts L2 trajectories with
almost-everywhere strongly measurable representatives; they are NOT claimed
here to be the helical projections of a physical NSE
solution. The a.e. orthogonality, square-integrability and energy budget are
explicit inputs. The determinant is that of the full Gram matrix, including
off-diagonal inner products, and is not defined to be diagonal.
-/

noncomputable section

open MeasureTheory
open Filter

namespace FeffermanAHopfGramIntegral

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- The actual Gram matrix of the two vectors. -/
def vectorGram (x y : H) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![inner ℝ x x, inner ℝ x y; inner ℝ y x, inner ℝ y y]

/-- Orthogonality identifies the actual Gram determinant with the existing
    diagonal energy-Gram determinant. -/
theorem vectorGram_det_of_orthogonal (x y : H) (hxy : inner ℝ x y = 0) :
    (vectorGram x y).det =
      (FeffermanAHopfGram.energyGram (‖x‖ ^ 2) (‖y‖ ^ 2)).det := by
  rw [FeffermanAHopfGram.energyGram_det]
  simp [vectorGram, Matrix.det_fin_two, hxy]

/-- Construct the integrand by taking the square root of the determinant of
    the actual two-vector Gram matrix at each time. -/
def gramSqrt {α : Type*} (vPlus vMinus : α → H) : α → ℝ :=
  fun t => Real.sqrt ((vectorGram (vPlus t) (vMinus t)).det)

/-- Construct the real Lebesgue integral of the Gram integrand. -/
def gramSqrtIntegral {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (vPlus vMinus : α → H) : ℝ :=
  ∫ t, gramSqrt vPlus vMinus t ∂μ

/--
The time-dependent vector construction. Global measurability is assumed for
the chosen representatives. A physical Leray--Hopf development must produce
such representatives, the stated Hilbert-space vectors and the energy budget.
The conclusion proves integrability of the genuine Gram integrand as well as
its integral bound; it does not assume either conclusion.
-/
theorem gramSqrt_integrable_and_bound
    {α : Type*} [MeasurableSpace α] [MeasurableSpace H]
    [OpensMeasurableSpace H] (μ : Measure α)
    (vPlus vMinus : α → H) (nu initialEnergy : ℝ)
    (hnu : 0 < nu)
    (hPlusMeas : Measurable vPlus)
    (hMinusMeas : Measurable vMinus)
    (hPlusInt : Integrable (fun t => ‖vPlus t‖ ^ 2) μ)
    (hMinusInt : Integrable (fun t => ‖vMinus t‖ ^ 2) μ)
    (hOrth : ∀ᵐ t ∂μ, inner ℝ (vPlus t) (vMinus t) = 0)
    (hEnergy : 2 * nu *
      (∫ t, (‖vPlus t‖ ^ 2 + ‖vMinus t‖ ^ 2) ∂μ) ≤ initialEnergy) :
    Integrable (gramSqrt vPlus vMinus) μ ∧
      gramSqrtIntegral μ vPlus vMinus ≤ initialEnergy / (4 * nu) := by
  have hpm : Measurable (fun t => ‖vPlus t‖ ^ 2) :=
    hPlusMeas.norm.pow_const 2
  have hmm : Measurable (fun t => ‖vMinus t‖ ^ 2) :=
    hMinusMeas.norm.pow_const 2
  have hpn : ∀ᵐ t ∂μ, 0 ≤ ‖vPlus t‖ ^ 2 :=
    Filter.Eventually.of_forall (fun t => sq_nonneg ‖vPlus t‖)
  have hmn : ∀ᵐ t ∂μ, 0 ≤ ‖vMinus t‖ ^ 2 :=
    Filter.Eventually.of_forall (fun t => sq_nonneg ‖vMinus t‖)
  have hsum : Integrable (fun t => ‖vPlus t‖ ^ 2 + ‖vMinus t‖ ^ 2) μ :=
    hPlusInt.add hMinusInt
  have hcore := FeffermanAHopfGram.hopf_gram_sqrt_integrable_and_bound
    μ (fun t => ‖vPlus t‖ ^ 2) (fun t => ‖vMinus t‖ ^ 2) nu initialEnergy
    hnu hpm hmm hpn hmn hsum hEnergy
  have heq : (fun t => Real.sqrt
      ((FeffermanAHopfGram.energyGram (‖vPlus t‖ ^ 2) (‖vMinus t‖ ^ 2)).det))
      =ᵐ[μ] gramSqrt vPlus vMinus := by
    filter_upwards [hOrth] with t ht
    simp only [gramSqrt, vectorGram_det_of_orthogonal (vPlus t) (vMinus t) ht]
  constructor
  · exact hcore.1.congr heq
  · unfold gramSqrtIntegral
    rw [← integral_congr_ae heq]
    exact hcore.2

/-- Same construction expressed with the natural Hilbert-valued L2 input.
    Measurability is still required for the chosen representatives. -/
theorem gramSqrt_integrable_and_bound_of_memLp
    {α : Type*} [MeasurableSpace α] [MeasurableSpace H]
    [OpensMeasurableSpace H] (μ : Measure α)
    (vPlus vMinus : α → H) (nu initialEnergy : ℝ)
    (hnu : 0 < nu)
    (hPlusMeas : Measurable vPlus)
    (hMinusMeas : Measurable vMinus)
    (hPlusLp : MemLp vPlus 2 μ)
    (hMinusLp : MemLp vMinus 2 μ)
    (hOrth : ∀ᵐ t ∂μ, inner ℝ (vPlus t) (vMinus t) = 0)
    (hEnergy : 2 * nu *
      (∫ t, (‖vPlus t‖ ^ 2 + ‖vMinus t‖ ^ 2) ∂μ) ≤ initialEnergy) :
    Integrable (gramSqrt vPlus vMinus) μ ∧
      gramSqrtIntegral μ vPlus vMinus ≤ initialEnergy / (4 * nu) := by
  have hPlusInt : Integrable (fun t => ‖vPlus t‖ ^ 2) μ :=
    (memLp_two_iff_integrable_sq_norm hPlusLp.aestronglyMeasurable).1 hPlusLp
  have hMinusInt : Integrable (fun t => ‖vMinus t‖ ^ 2) μ :=
    (memLp_two_iff_integrable_sq_norm hMinusLp.aestronglyMeasurable).1 hMinusLp
  exact gramSqrt_integrable_and_bound μ vPlus vMinus nu initialEnergy
    hnu hPlusMeas hMinusMeas hPlusInt hMinusInt hOrth hEnergy

/-- Natural almost-everywhere L2 version. Measurable representatives are
    constructed from `MemLp`, and all identities are transferred through
    their almost-everywhere equality. The physical interpretation of the
    two vector trajectories and the energy budget remain explicit inputs. -/
theorem gramSqrt_integrable_and_bound_of_memLp_ae
    {α : Type*} [MeasurableSpace α] [MeasurableSpace H] [BorelSpace H]
    (μ : Measure α) (vPlus vMinus : α → H) (nu initialEnergy : ℝ)
    (hnu : 0 < nu)
    (hPlusLp : MemLp vPlus 2 μ)
    (hMinusLp : MemLp vMinus 2 μ)
    (hOrth : ∀ᵐ t ∂μ, inner ℝ (vPlus t) (vMinus t) = 0)
    (hEnergy : 2 * nu *
      (∫ t, (‖vPlus t‖ ^ 2 + ‖vMinus t‖ ^ 2) ∂μ) ≤ initialEnergy) :
    Integrable (gramSqrt vPlus vMinus) μ ∧
      gramSqrtIntegral μ vPlus vMinus ≤ initialEnergy / (4 * nu) := by
  let p := AEStronglyMeasurable.mk vPlus hPlusLp.aestronglyMeasurable
  let m := AEStronglyMeasurable.mk vMinus hMinusLp.aestronglyMeasurable
  have hpEq : vPlus =ᵐ[μ] p := hPlusLp.aestronglyMeasurable.ae_eq_mk
  have hmEq : vMinus =ᵐ[μ] m := hMinusLp.aestronglyMeasurable.ae_eq_mk
  have hpMeas : Measurable p := hPlusLp.aestronglyMeasurable.measurable_mk
  have hmMeas : Measurable m := hMinusLp.aestronglyMeasurable.measurable_mk
  have hpLp : MemLp p 2 μ := (memLp_congr_ae hpEq).1 hPlusLp
  have hmLp : MemLp m 2 μ := (memLp_congr_ae hmEq).1 hMinusLp
  have hmOrth : ∀ᵐ t ∂μ, inner ℝ (p t) (m t) = 0 := by
    filter_upwards [hpEq, hmEq, hOrth] with t hp hm ho
    rw [← hp, ← hm]
    exact ho
  have hsumEq :
      (fun t => ‖vPlus t‖ ^ 2 + ‖vMinus t‖ ^ 2) =ᵐ[μ]
      (fun t => ‖p t‖ ^ 2 + ‖m t‖ ^ 2) := by
    filter_upwards [hpEq, hmEq] with t hp hm
    rw [hp, hm]
  have hEnergyRep : 2 * nu * (∫ t, (‖p t‖ ^ 2 + ‖m t‖ ^ 2) ∂μ)
      ≤ initialEnergy := by
    rw [← integral_congr_ae hsumEq]
    exact hEnergy
  have hrep := gramSqrt_integrable_and_bound_of_memLp μ p m nu initialEnergy
    hnu hpMeas hmMeas hpLp hmLp hmOrth hEnergyRep
  have hGramEq : gramSqrt vPlus vMinus =ᵐ[μ] gramSqrt p m := by
    filter_upwards [hpEq, hmEq] with t hp hm
    simp only [gramSqrt, hp, hm]
  constructor
  · exact hrep.1.congr hGramEq.symm
  · have hIntegralEq : gramSqrtIntegral μ vPlus vMinus =
        gramSqrtIntegral μ p m := integral_congr_ae hGramEq
    rw [hIntegralEq]
    exact hrep.2

/-- Explicit finite-time version of the constructed square-root Gram
    integral. The interval is `(0,T]`; no positivity of T is needed for the
    formal implication. The energy inequality remains a stated premise. -/
theorem time_gramSqrt_integrable_and_bound
    [MeasurableSpace H] [BorelSpace H]
    (T nu initialEnergy : ℝ) (vPlus vMinus : ℝ → H)
    (hnu : 0 < nu)
    (hPlusLp : MemLp vPlus 2 (volume.restrict (Set.Ioc (0 : ℝ) T)))
    (hMinusLp : MemLp vMinus 2 (volume.restrict (Set.Ioc (0 : ℝ) T)))
    (hOrth : ∀ᵐ t ∂(volume.restrict (Set.Ioc (0 : ℝ) T)),
      inner ℝ (vPlus t) (vMinus t) = 0)
    (hEnergy : 2 * nu *
      (∫ t in Set.Ioc (0 : ℝ) T, (‖vPlus t‖ ^ 2 + ‖vMinus t‖ ^ 2))
        ≤ initialEnergy) :
    Integrable (gramSqrt vPlus vMinus)
      (volume.restrict (Set.Ioc (0 : ℝ) T)) ∧
    (∫ t in Set.Ioc (0 : ℝ) T, gramSqrt vPlus vMinus t)
      ≤ initialEnergy / (4 * nu) := by
  simpa only [gramSqrtIntegral] using
    (gramSqrt_integrable_and_bound_of_memLp_ae
      (volume.restrict (Set.Ioc (0 : ℝ) T)) vPlus vMinus nu initialEnergy
      hnu hPlusLp hMinusLp hOrth hEnergy)

end FeffermanAHopfGramIntegral

#print axioms FeffermanAHopfGramIntegral.vectorGram_det_of_orthogonal
#print axioms FeffermanAHopfGramIntegral.gramSqrt_integrable_and_bound
#print axioms FeffermanAHopfGramIntegral.gramSqrt_integrable_and_bound_of_memLp
#print axioms FeffermanAHopfGramIntegral.gramSqrt_integrable_and_bound_of_memLp_ae
#print axioms FeffermanAHopfGramIntegral.time_gramSqrt_integrable_and_bound
