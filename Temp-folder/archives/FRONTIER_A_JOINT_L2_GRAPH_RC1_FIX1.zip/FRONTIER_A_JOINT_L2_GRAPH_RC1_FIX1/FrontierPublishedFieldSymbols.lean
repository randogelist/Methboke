import FrontierCanonicalPhysicalSymbols
import FrontierPublishedHelicalFormula

/-! Compose the audited weak-gradient Fourier-symbol bridge with the separately
written published helical matrix formula. This is a symbol-level result for
project-defined L² fields; it does not construct an independent self-adjoint
Stokes/curl operator or a Leray--Hopf solution. No local Lean run. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierPublishedFieldSymbols

abbrev Frequency := FrontierCanonicalPhysicalSymbols.Frequency
abbrev Fiber := FrontierCanonicalPhysicalSymbols.Fiber
abbrev Gradient := FrontierCanonicalPhysicalSymbols.Gradient

/-- The direct published positive helical matrix as a real-linear fiber map. -/
def publishedPlusOp (ξ : Frequency) : Fiber →L[ℝ] Fiber :=
  (matrixToComplex (FrontierPublishedHelicalFormula.directPlus (ξ 0) (ξ 1) (ξ 2))).restrictScalars ℝ

/-- The direct published negative helical matrix as a real-linear fiber map. -/
def publishedMinusOp (ξ : Frequency) : Fiber →L[ℝ] Fiber :=
  (matrixToComplex (FrontierPublishedHelicalFormula.directMinus (ξ 0) (ξ 1) (ξ 2))).restrictScalars ℝ

/-- A supplied real L² weak gradient implies that both canonical fields have
precisely the direct published helical Fourier symbols almost everywhere.
`velocitySymbol u ξ` is the existing explicit `2π|ξ| Fourier(u)(ξ)` expression.
No divergence or time-integrability premise is needed for this slice theorem. -/
theorem published_symbols_of_weak_gradient
    (u : FrontierAWeakTimeGram.Field) (g : Gradient)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) :
    ((FrontierPhysicalGramTransport.fourierCoordinateReal
      (FrontierPhysicalGramTransport.plusField g) : Frequency → Fiber) =ᵐ[volume]
      fun ξ => publishedPlusOp ξ (FrontierMultiplierBridge.velocitySymbol u ξ)) ∧
    ((FrontierPhysicalGramTransport.fourierCoordinateReal
      (FrontierPhysicalGramTransport.minusField g) : Frequency → Fiber) =ᵐ[volume]
      fun ξ => publishedMinusOp ξ (FrontierMultiplierBridge.velocitySymbol u ξ)) := by
  have hs := FrontierCanonicalPhysicalSymbols.canonical_symbols_of_weak_gradient u g hweak
  constructor
  · filter_upwards [hs.1, FrontierPublishedHelicalFormula.directPlus_eq_existing_ae] with ξ hfield hmatrix
    have hop : plusOp ξ = publishedPlusOp ξ := by
      unfold plusOp publishedPlusOp
      rw [hmatrix]
    rw [hop] at hfield
    exact hfield
  · filter_upwards [hs.2, FrontierPublishedHelicalFormula.directMinus_eq_existing_ae] with ξ hfield hmatrix
    have hop : minusOp ξ = publishedMinusOp ξ := by
      unfold minusOp publishedMinusOp
      rw [hmatrix]
    rw [hop] at hfield
    exact hfield

end FrontierPublishedFieldSymbols

#print axioms FrontierPublishedFieldSymbols.published_symbols_of_weak_gradient
