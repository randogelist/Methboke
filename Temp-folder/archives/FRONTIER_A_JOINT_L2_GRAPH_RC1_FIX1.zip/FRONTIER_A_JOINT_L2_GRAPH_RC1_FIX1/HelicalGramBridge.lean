import HopfGramProjected

/-!
Candidate bridge from a transverse pair of operators to the previously
verified abstract projected Gram bound.  The operator realization of the
helical matrices and the Leray--Hopf energy inequality are explicit premises.
No Fourier transform or physical solution is constructed here.
-/

noncomputable section
open MeasureTheory
open Filter

namespace HelicalGramAdapter

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- On a transverse vector, the negative component equals the complementary
    component of the positive projector. -/
theorem negative_eq_complement
    (P M Q : H →L[ℝ] H)
    (hsum : ∀ x : H, P x + M x = Q x)
    (x : H) (htrans : Q x = x) :
    x - P x = M x := by
  have h : P x + M x = x := by rw [hsum, htrans]
  calc
    x - P x = (P x + M x) - P x := by rw [h]
    _ = M x := by abel

/-- A transverse two-operator trajectory inherits the genuine vector-Gram
    square-root bound from the verified one-projector result. -/
theorem transverse_gram_integrable_and_bound
    {α : Type*} [MeasurableSpace α] [MeasurableSpace H] [BorelSpace H]
    (μ : Measure α) (P M Q : H →L[ℝ] H) (z : α → H)
    (nu initialEnergy : ℝ) (hnu : 0 < nu) (hz : MemLp z 2 μ)
    (hsym : ∀ x y : H, inner ℝ (P x) y = inner ℝ x (P y))
    (hid : ∀ x : H, P (P x) = P x)
    (hsum : ∀ x : H, P x + M x = Q x)
    (htrans : ∀ᵐ t ∂μ, Q (z t) = z t)
    (hEnergy : 2 * nu * (∫ t, ‖z t‖ ^ 2 ∂μ) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => P (z t)) (fun t => M (z t))) μ ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral μ
      (fun t => P (z t)) (fun t => M (z t))
      ≤ initialEnergy / (4 * nu) := by
  have hcore := HopfGramProjected.projected_gram_integrable_and_bound
    μ P z nu initialEnergy hnu hz hsym hid hEnergy
  have hgram : FeffermanAHopfGramIntegral.gramSqrt
        (fun t => P (z t)) (fun t => z t - P (z t))
      =ᵐ[μ] FeffermanAHopfGramIntegral.gramSqrt
        (fun t => P (z t)) (fun t => M (z t)) := by
    filter_upwards [htrans] with t ht
    simp only [FeffermanAHopfGramIntegral.gramSqrt,
      negative_eq_complement P M Q hsum (z t) ht]
  constructor
  · exact hcore.1.congr hgram
  · unfold FeffermanAHopfGramIntegral.gramSqrtIntegral
    rw [← integral_congr_ae hgram]
    exact hcore.2

end HelicalGramAdapter

#print axioms HelicalGramAdapter.negative_eq_complement
#print axioms HelicalGramAdapter.transverse_gram_integrable_and_bound
