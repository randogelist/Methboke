import FrontierPhysicalGramTransport
import FrontierEnergyBudget

/-!
Conditional terminal-energy-to-Fourier-pullback Gram chain. The inputs are
supplied data. This file does not construct a Leray–Hopf solution, derive its
energy inequality or weak derivative statements, or identify these complex
Fourier-pulled-back fields with the actual helical Stokes fields.
-/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierPhysicalClosure

local instance frequencyRealL2 (μ : Measure FrontierAWeakTimeGram.Frequency) :
    InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

local instance physicalRealL2 :
    InnerProductSpace ℝ FrontierPhysicalGramTransport.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierPhysicalGramTransport.PhysicalL2

/-- Derive the Gram bound for the explicitly defined complex Fourier
pullbacks from the supplied dissipation data and terminal-energy inequality.
All semantic and weak-gradient hypotheses remain explicit. -/
theorem pullback_gram_from_terminal_energy
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → FrontierAWeakTimeGram.Field)
    (g : τ → FrontierARealGradient.RealMatrix)
    (du : τ → Fin 3 → FrontierAWeakTimeGram.Field)
    (D : τ → ℝ) (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : AEStronglyMeasurable g η) (hD : Integrable D η)
    (hidentify : D =ᵐ[η] fun t => ‖g t‖ ^ 2)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, D t ∂η) ≤ ‖u0‖ ^ 2)
    (hcol : ∀ᵐ t ∂η, ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 (g t)) = du t j)
    (hweak : ∀ᵐ t ∂η, ∀ j, Lp.toTemperedDistribution (du t j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t))) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  obtain ⟨hlp, hbudget⟩ := FrontierEnergyBudget.gradient_inputs_from_energy
    η g D u0 uT nu hg hD hidentify henergy
  exact FrontierPhysicalGramTransport.real_gradient_pullback_gram_bound
    η u g du nu (‖u0‖ ^ 2) hnu hlp hbudget hcol hweak

end FrontierPhysicalClosure

#print axioms FrontierPhysicalClosure.pullback_gram_from_terminal_energy
