import FrontierPhysicalComposition

/-! Candidate real-linear bounded operators on the complex physical L² space.
They lift the previously defined Fourier pullback functions to continuous
linear maps and transfer the transverse splitting result. No claim is made
here that they have been identified with separately defined physical Stokes
projections or that the input is a Leray–Hopf solution. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierPhysicalProjectors

abbrev Frequency := FrontierPhysicalGramTransport.Frequency
abbrev Fiber := FeffermanHelicalOrthogonal.Fiber
abbrev PhysicalL2 := FrontierPhysicalGramTransport.PhysicalL2

local instance frequencyRealL2 : InnerProductSpace ℝ (Lp Fiber 2 (volume : Measure Frequency)) :=
  InnerProductSpace.rclikeToReal ℂ (Lp Fiber 2 (volume : Measure Frequency))
local instance physicalRealL2 : InnerProductSpace ℝ PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ PhysicalL2

/-- Bounded real-linear conjugate of the positive helical Fourier multiplier. -/
def plusProjector : PhysicalL2 →L[ℝ] PhysicalL2 :=
  HelicalFourierTransport.pullback FrontierPhysicalGramTransport.fourierCoordinateReal
    (plusMultiplier (volume : Measure Frequency))

/-- Bounded real-linear conjugate of the negative helical Fourier multiplier. -/
def minusProjector : PhysicalL2 →L[ℝ] PhysicalL2 :=
  HelicalFourierTransport.pullback FrontierPhysicalGramTransport.fourierCoordinateReal
    (minusMultiplier (volume : Measure Frequency))

theorem plus_fourier (f : PhysicalL2) :
    FrontierPhysicalGramTransport.fourierCoordinateReal (plusProjector f) =
      plusMultiplier (volume : Measure Frequency)
        (FrontierPhysicalGramTransport.fourierCoordinateReal f) := by
  exact HelicalFourierTransport.intertwines _ _ _

theorem minus_fourier (f : PhysicalL2) :
    FrontierPhysicalGramTransport.fourierCoordinateReal (minusProjector f) =
      minusMultiplier (volume : Measure Frequency)
        (FrontierPhysicalGramTransport.fourierCoordinateReal f) := by
  exact HelicalFourierTransport.intertwines _ _ _

theorem plus_matches_pullback (f : PhysicalL2) :
    plusProjector f = FrontierACoordinateEquiv.plusPullback f := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  rw [plus_fourier]
  exact (FrontierACoordinateEquiv.plus_intertwines f).symm

theorem minus_matches_pullback (f : PhysicalL2) :
    minusProjector f = FrontierACoordinateEquiv.minusPullback f := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  rw [minus_fourier]
  exact (FrontierACoordinateEquiv.minus_intertwines f).symm

/-- The two projectors sum to the identity on fields satisfying the explicit
frequency-space transversality condition. No such conclusion is claimed on
arbitrary vector fields. -/
theorem transverse_split (f : PhysicalL2)
    (htrans : ∀ᵐ ξ ∂(volume : Measure Frequency),
      Matrix.toEuclideanLin
        (FeffermanHelicalFrequency.projection (ξ 0) (ξ 1) (ξ 2))
        ((FrontierPhysicalGramTransport.fourierCoordinateReal f : Frequency → Fiber) ξ) =
        ((FrontierPhysicalGramTransport.fourierCoordinateReal f : Frequency → Fiber) ξ)) :
    plusProjector f + minusProjector f = f := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  rw [map_add, plus_fourier, minus_fourier]
  exact HelicalEnergyBridge.fiber_transverse_split (volume : Measure Frequency)
    (FrontierPhysicalGramTransport.fourierCoordinateReal f) htrans

end FrontierPhysicalProjectors

#print axioms FrontierPhysicalProjectors.plus_fourier
#print axioms FrontierPhysicalProjectors.minus_fourier
#print axioms FrontierPhysicalProjectors.plus_matches_pullback
#print axioms FrontierPhysicalProjectors.minus_matches_pullback
#print axioms FrontierPhysicalProjectors.transverse_split


/-!
A-TIER CANDIDATE, not locally compiled. A concrete L² representative for the
Fourier multiplier |∇|u is obtained from a supplied weak gradient. The
spectral domain below is defined by an explicit Fourier multiplier condition;
no identification with an independently defined Stokes square root is claimed.
The weak derivative condition and all Leray–Hopf realization steps remain open.
-/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierDissipationDomain

abbrev Frequency := FrontierMultiplierBridge.Frequency
abbrev Fiber := FrontierMultiplierBridge.Fiber
abbrev Field := FrontierMultiplierBridge.Field
abbrev PhysicalL2 := FrontierPhysicalGramTransport.PhysicalL2

/-- The Fourier multiplier 2π|ξ|û has an L² physical representative. -/
def HasDissipationSymbol (u : Field) : Prop :=
  ∃ v : PhysicalL2,
    (FrontierPhysicalGramTransport.fourierCoordinateReal v : Frequency → Fiber) =ᵐ[volume]
      FrontierMultiplierBridge.velocitySymbol u

/-- Construct the representative from the existing Riesz/gradient machinery. -/
def gradientDissipation (g : FrontierARealGradient.RealMatrix) : PhysicalL2 :=
  FrontierPhysicalGramTransport.fourierCoordinateReal.symm
    (FrontierARealGradient.realGradientSpectrum g)

theorem gradientDissipation_fourier (g : FrontierARealGradient.RealMatrix) :
    FrontierPhysicalGramTransport.fourierCoordinateReal (gradientDissipation g) =
      FrontierARealGradient.realGradientSpectrum g := by
  simp [gradientDissipation]

/-- The representatives of a given symbol are unique in physical L². -/
theorem symbol_representative_unique (u : Field) (v w : PhysicalL2)
    (hv : (FrontierPhysicalGramTransport.fourierCoordinateReal v : Frequency → Fiber) =ᵐ[volume]
      FrontierMultiplierBridge.velocitySymbol u)
    (hw : (FrontierPhysicalGramTransport.fourierCoordinateReal w : Frequency → Fiber) =ᵐ[volume]
      FrontierMultiplierBridge.velocitySymbol u) : v = w := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  apply Lp.ext
  exact hv.trans hw.symm

/-- A real L² weak gradient gives a representative of the Fourier |∇| symbol. -/
theorem weak_gradient_has_dissipation_symbol
    (u : Field) (g : FrontierARealGradient.RealMatrix)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) :
    HasDissipationSymbol u := by
  refine ⟨gradientDissipation g, ?_⟩
  rw [gradientDissipation_fourier]
  exact FrontierMultiplierBridge.real_gradient_spectrum_eq_symbol u g
    (fun j => FrontierGradientAdapter.gradientColumn g j) (fun _ => rfl) hweak

/-- The gradient-constructed representative is independent of the weak
matrix witness for the same velocity. -/
theorem gradientDissipation_unique
    (u : Field) (g h : FrontierARealGradient.RealMatrix)
    (hg : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (hh : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn h j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) :
    gradientDissipation g = gradientDissipation h := by
  apply symbol_representative_unique u
  · rw [gradientDissipation_fourier]
    exact FrontierMultiplierBridge.real_gradient_spectrum_eq_symbol u g
      (fun j => FrontierGradientAdapter.gradientColumn g j) (fun _ => rfl) hg
  · rw [gradientDissipation_fourier]
    exact FrontierMultiplierBridge.real_gradient_spectrum_eq_symbol u h
      (fun j => FrontierGradientAdapter.gradientColumn h j) (fun _ => rfl) hh

/-- The previously constructed Fourier-conjugate plus projector applied to the
representative is exactly the plus field of the existing Gram theorem. -/
theorem plus_projected_gradientDissipation (g : FrontierARealGradient.RealMatrix) :
    FrontierACoordinateEquiv.plusPullback (gradientDissipation g) =
      FrontierPhysicalGramTransport.plusField g := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  rw [FrontierPhysicalGramTransport.plusField_fourier]
  change FrontierACoordinateEquiv.fourierCoordinate
      (FrontierACoordinateEquiv.plusPullback (gradientDissipation g)) = _
  rw [FrontierACoordinateEquiv.plus_intertwines]
  change plusMultiplier (volume : Measure Frequency)
      (FrontierPhysicalGramTransport.fourierCoordinateReal (gradientDissipation g)) = _
  rw [gradientDissipation_fourier]

/-- The corresponding minus projector relation. -/
theorem minus_projected_gradientDissipation (g : FrontierARealGradient.RealMatrix) :
    FrontierACoordinateEquiv.minusPullback (gradientDissipation g) =
      FrontierPhysicalGramTransport.minusField g := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  rw [FrontierPhysicalGramTransport.minusField_fourier]
  change FrontierACoordinateEquiv.fourierCoordinate
      (FrontierACoordinateEquiv.minusPullback (gradientDissipation g)) = _
  rw [FrontierACoordinateEquiv.minus_intertwines]
  change minusMultiplier (volume : Measure Frequency)
      (FrontierPhysicalGramTransport.fourierCoordinateReal (gradientDissipation g)) = _
  rw [gradientDissipation_fourier]


local instance physicalRealL2 : InnerProductSpace ℝ PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ PhysicalL2

/-- The existing Gram estimate for the Fourier-conjugate projected
weak-gradient dissipation representative. This is conditional on all the
weak-gradient and energy hypotheses displayed below. -/
theorem projected_gradient_gram_from_energy
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → Field)
    (g : τ → FrontierARealGradient.RealMatrix)
    (D : τ → ℝ) (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : AEStronglyMeasurable g η) (hD : Integrable D η)
    (hidentify : D =ᵐ[η] fun t => ‖g t‖ ^ 2)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, D t ∂η) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂η, ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t))) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierACoordinateEquiv.plusPullback (gradientDissipation (g t)))
      (fun t => FrontierACoordinateEquiv.minusPullback (gradientDissipation (g t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierACoordinateEquiv.plusPullback (gradientDissipation (g t)))
      (fun t => FrontierACoordinateEquiv.minusPullback (gradientDissipation (g t))) ≤
        ‖u0‖ ^ 2 / (4 * nu) := by
  simpa only [plus_projected_gradientDissipation, minus_projected_gradientDissipation] using
    FrontierGradientAdapter.pullback_gram_from_gradient_columns
      η u g D u0 uT nu hnu hg hD hidentify henergy hweak

end FrontierDissipationDomain

#print axioms FrontierDissipationDomain.gradientDissipation_fourier
#print axioms FrontierDissipationDomain.symbol_representative_unique
#print axioms FrontierDissipationDomain.weak_gradient_has_dissipation_symbol
#print axioms FrontierDissipationDomain.gradientDissipation_unique
#print axioms FrontierDissipationDomain.plus_projected_gradientDissipation
#print axioms FrontierDissipationDomain.minus_projected_gradientDissipation

#print axioms FrontierDissipationDomain.projected_gradient_gram_from_energy
