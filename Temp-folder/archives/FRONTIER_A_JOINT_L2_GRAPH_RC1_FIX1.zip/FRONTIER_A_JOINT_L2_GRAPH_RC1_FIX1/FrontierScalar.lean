import Mathlib

/-!
# Scalar consequences of the Frontier_A physical estimates

Candidate only. These lemmas supply algebraic steps and deliberately do not
assert that the variables arise from an actual Leray–Hopf solution. The
physical realization, integrability and identities must be supplied by the
caller. No axioms or proof placeholders are introduced here.
-/

namespace FrontierScalar

/-- Algebra behind the pointwise helical discriminant. -/
theorem helical_discriminant (a b : ℝ) :
    (a ^ 2 + b ^ 2) ^ 2 - (a ^ 2 - b ^ 2) ^ 2 =
      4 * (a * b) ^ 2 := by
  ring

/-- The algebraic estimate underlying the physical Gram bound. -/
theorem helical_amgm (a b : ℝ) : 2 * (a * b) ≤ a ^ 2 + b ^ 2 := by
  nlinarith [sq_nonneg (a - b)]

/-- Exact normalized radial deficit. `a` and `b` stand for second moments,
`m` and `n` for means; this theorem imposes no probability assumptions. -/
theorem radial_deficit_identity (alpha m n a b : ℝ) (hab : a + b = 1) :
    1 - (alpha * m) ^ 2 - (alpha * n) ^ 2 =
      (1 - alpha ^ 2) + alpha ^ 2 * ((a - m ^ 2) + (b - n ^ 2)) := by
  calc
    1 - (alpha * m) ^ 2 - (alpha * n) ^ 2 =
        (1 - alpha ^ 2) + alpha ^ 2 * ((a - m ^ 2) + (b - n ^ 2)) +
          alpha ^ 2 * (1 - (a + b)) := by ring
    _ = (1 - alpha ^ 2) + alpha ^ 2 * ((a - m ^ 2) + (b - n ^ 2)) := by
      rw [hab]
      ring

/-- The quarter-disk bound from nonnegative variances and the energy budget. -/
theorem radial_bound (alpha m n a b : ℝ) (hab : a + b = 1)
    (ha0 : 0 ≤ alpha) (ha1 : alpha ≤ 1)
    (hm : 0 ≤ a - m ^ 2) (hn : 0 ≤ b - n ^ 2) :
    (alpha * m) ^ 2 + (alpha * n) ^ 2 ≤ 1 := by
  have hbudget : 0 ≤ 1 - alpha ^ 2 := by
    have h := mul_nonneg ha0 (sub_nonneg.mpr ha1)
    nlinarith
  have hvariance : 0 ≤ alpha ^ 2 * ((a - m ^ 2) + (b - n ^ 2)) :=
    mul_nonneg (sq_nonneg alpha) (add_nonneg hm hn)
  have hid := radial_deficit_identity alpha m n a b hab
  linarith

/-- One direction of the equality characterization for the scalar disk:
exhausted budget and zero variances force equality. -/
theorem radial_boundary_of_zero_variances (alpha m n a b : ℝ)
    (hab : a + b = 1) (halpha : alpha = 1)
    (hm : a = m ^ 2) (hn : b = n ^ 2) :
    (alpha * m) ^ 2 + (alpha * n) ^ 2 = 1 := by
  simpa [halpha, hm, hn] using hab

/-- Energy-defect decomposition implies the sharp scalar energy bound.
The decomposition and nonnegativity assumptions must be proved physically. -/
theorem energy_defect_bound (nu initial terminal h mismatch defect : ℝ)
    (hnu : 0 < nu) (hterminal : 0 ≤ terminal)
    (hmismatch : 0 ≤ mismatch) (hdefect : 0 ≤ defect)
    (henergy : initial = terminal + 4 * nu * h + 2 * nu * mismatch + defect) :
    h ≤ initial / (4 * nu) := by
  have hden : 0 < 4 * nu := by positivity
  apply (le_div_iff₀ hden).2
  have hnonneg : 0 ≤ 2 * nu * mismatch := by positivity
  nlinarith

end FrontierScalar
