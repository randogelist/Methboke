import FrontierAWeakMatrixColumns
import FrontierAMatrixFourierAE

/-! Untested candidate. The explicit hypotheses identify the columns of an
L² matrix with supplied distributional weak derivatives. The conclusion
identifies the existing conditional Gram input in frequency space. This does
not construct a Leray–Hopf solution or identify the physical helical Gram. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierAWeakGramInput
abbrev Space := FrontierAWeakMatrixColumns.Space
abbrev Frequency := HelicalConcreteSymbol.Frequency
abbrev MatrixL2 := FrontierAWeakMatrixColumns.MatrixL2
abbrev Field := FrontierAWeakMatrixColumns.Field
abbrev Fiber := FrontierARieszVectorSymbol.Fiber

/-- Under supplied weak-gradient equations and column identification, the
existing Gram input agrees a.e. with the Fourier symbol for |D|u. The
normalization is 2π, as in the preceding Fourier derivative identity. -/
theorem gram_input_eq_weak_velocity_symbol
    (u : Field) (g : MatrixL2) (du : Fin 3 → Field)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j g = du j)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u)) :
    ∀ᵐ ξ ∂(volume : Measure Frequency), ∀ i : Fin 3,
      (FrontierAConcreteFourier.coordinateFourier
        (FrontierARieszVectorL2.inverseFourierVectorCLM
          (FrontierAMatrixFourier.matrixFourier g)) : Frequency → Fiber) ξ i =
      ((2 * Real.pi : ℝ) : ℂ) *
        (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2) : ℂ) *
        (FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ) i := by
  have hmatrix : (fun ζ : Space => fun i j : Fin 3 =>
      (FourierTransform.fourier g : MatrixL2) ζ (i, j)) =ᵐ[volume]
      (fun ζ => FrontierARieszDerivativeAlgebra.derivativeMatrix (2 * Real.pi) ζ.ofLp
        (fun k => (FourierTransform.fourier u : Field) ζ k)) := by
    filter_upwards [FrontierAWeakMatrixColumns.matrix_fourier_eq_weak_derivative
      u g du hcol hweak] with ζ hζ
    funext i j
    exact hζ i j
  have hcoords := HelicalCoordinateBridge.toLp_preserves_volume.quasiMeasurePreserving.ae_eq_comp hmatrix
  filter_upwards [FrontierAMatrixFourierAE.gram_input_matrix_fourier_ae g, hcoords] with ξ hgram hmatrix
  intro i
  have hmat : (fun i j => (FourierTransform.fourier g : MatrixL2)
      (WithLp.toLp 2 ξ) (i, j)) =
      FrontierARieszDerivativeAlgebra.derivativeMatrix (2 * Real.pi) ξ
        (fun k => (FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ) k) := by
    simpa only [Function.comp_def, WithLp.ofLp_toLp] using hmatrix
  rw [hgram i, hmat]
  exact FrontierARieszDerivativeAlgebra.vectorRow_derivative_symbol (2 * Real.pi) ξ
    (fun k => (FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ) k) i

end FrontierAWeakGramInput

#print axioms FrontierAWeakGramInput.gram_input_eq_weak_velocity_symbol
