import HelicalL2Lift
import HelicalGramBridge

/-!
Candidate lift of pointwise operator identities to the actual L2 quotient
multipliers constructed by HelicalL2Lift. The operator-valued L-infinity
symbols and their a.e. algebraic identities are explicit inputs. This module
does not construct the concrete helical symbol or the Fourier transform.
External native compilation and theorem-level axiom audit are required.
-/

noncomputable section

open MeasureTheory
open Filter
open HelicalL2Lift

namespace HelicalMultiplierAlgebra

variable {α H : Type*} [MeasurableSpace α]
variable [NormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- An almost-everywhere pointwise partition lifts to L2. -/
theorem multiplier_partition (μ : Measure α)
    (P M Q : Lp (H →L[ℝ] H) ⊤ μ)
    (hsum : ∀ᵐ x ∂μ, ∀ v : H,
      (P : α → (H →L[ℝ] H)) x v + (M : α → (H →L[ℝ] H)) x v =
        (Q : α → (H →L[ℝ] H)) x v)
    (f : Lp H 2 μ) :
    multiplier μ P f + multiplier μ M f = multiplier μ Q f := by
  apply MeasureTheory.Lp.ext
  filter_upwards [MeasureTheory.Lp.coeFn_add (multiplier μ P f) (multiplier μ M f),
    multiplier_ae μ P f, multiplier_ae μ M f, multiplier_ae μ Q f, hsum]
    with x hadd hp hm hq hx
  calc
    ((multiplier μ P f + multiplier μ M f : Lp H 2 μ) : α → H) x =
        (multiplier μ P f : α → H) x + (multiplier μ M f : α → H) x := hadd
    _ = (P : α → (H →L[ℝ] H)) x ((f : α → H) x) +
        (M : α → (H →L[ℝ] H)) x ((f : α → H) x) := by rw [hp, hm]
    _ = (Q : α → (H →L[ℝ] H)) x ((f : α → H) x) := hx ((f : α → H) x)
    _ = (multiplier μ Q f : α → H) x := hq.symm

/-- Almost-everywhere self-adjointness of a symbol yields self-adjointness
    of its induced real-Hilbert-space L2 multiplier. -/
theorem multiplier_symmetric (μ : Measure α)
    (P : Lp (H →L[ℝ] H) ⊤ μ)
    (hsym : ∀ᵐ x ∂μ, ∀ u v : H,
      inner ℝ ((P : α → (H →L[ℝ] H)) x u) v =
        inner ℝ u ((P : α → (H →L[ℝ] H)) x v))
    (f g : Lp H 2 μ) :
    inner ℝ (multiplier μ P f) g = inner ℝ f (multiplier μ P g) := by
  rw [MeasureTheory.L2.inner_def, MeasureTheory.L2.inner_def]
  apply integral_congr_ae
  filter_upwards [multiplier_ae μ P f, multiplier_ae μ P g, hsym]
    with x hf hg hx
  rw [hf, hg]
  exact hx ((f : α → H) x) ((g : α → H) x)

/-- Vanishing of the pointwise cross-composition lifts to L2. -/
theorem multiplier_cross_zero (μ : Measure α)
    (P M : Lp (H →L[ℝ] H) ⊤ μ)
    (hzero : ∀ᵐ x ∂μ, ∀ v : H,
      (P : α → (H →L[ℝ] H)) x ((M : α → (H →L[ℝ] H)) x v) = 0)
    (f : Lp H 2 μ) : multiplier μ P (multiplier μ M f) = 0 := by
  apply MeasureTheory.Lp.ext
  filter_upwards [multiplier_ae μ P (multiplier μ M f), multiplier_ae μ M f,
    hzero, MeasureTheory.Lp.coeFn_zero H 2 μ] with x hp hm hz h0
  calc
    (multiplier μ P (multiplier μ M f) : α → H) x =
        (P : α → (H →L[ℝ] H)) x ((multiplier μ M f : α → H) x) := hp
    _ = (P : α → (H →L[ℝ] H)) x
        ((M : α → (H →L[ℝ] H)) x ((f : α → H) x)) := by rw [hm]
    _ = 0 := hz ((f : α → H) x)
    _ = ((0 : Lp H 2 μ) : α → H) x := h0.symm

/-- Orthogonality of the two multiplier ranges follows from symmetry and
    the pointwise vanishing cross-composition. -/
theorem multiplier_ranges_orthogonal (μ : Measure α)
    (P M : Lp (H →L[ℝ] H) ⊤ μ)
    (hsym : ∀ᵐ x ∂μ, ∀ u v : H,
      inner ℝ ((P : α → (H →L[ℝ] H)) x u) v =
        inner ℝ u ((P : α → (H →L[ℝ] H)) x v))
    (hzero : ∀ᵐ x ∂μ, ∀ v : H,
      (P : α → (H →L[ℝ] H)) x ((M : α → (H →L[ℝ] H)) x v) = 0)
    (f g : Lp H 2 μ) :
    inner ℝ (multiplier μ P f) (multiplier μ M g) = 0 := by
  have h := multiplier_symmetric μ P hsym f (multiplier μ M g)
  rw [multiplier_cross_zero μ P M hzero g, inner_zero_right] at h
  exact h

/-- A trajectory taking values in the transverse L2 range obeys the
    previously proved square-root Gram bound, provided its energy budget.
    All pointwise symbol identities are explicit premises. -/
theorem multiplier_transverse_gram_bound
    {τ : Type*} [MeasurableSpace τ]
    (μ : Measure α) (η : Measure τ)
    [MeasurableSpace (Lp H 2 μ)] [BorelSpace (Lp H 2 μ)]
    (P M Q : Lp (H →L[ℝ] H) ⊤ μ) (z : τ → Lp H 2 μ)
    (nu initialEnergy : ℝ) (hnu : 0 < nu) (hz : MemLp z 2 η)
    (hsym : ∀ᵐ x ∂μ, ∀ u v : H,
      inner ℝ ((P : α → (H →L[ℝ] H)) x u) v =
        inner ℝ u ((P : α → (H →L[ℝ] H)) x v))
    (hid : ∀ᵐ x ∂μ, ∀ v : H,
      (P : α → (H →L[ℝ] H)) x ((P : α → (H →L[ℝ] H)) x v) =
        (P : α → (H →L[ℝ] H)) x v)
    (hsum : ∀ᵐ x ∂μ, ∀ v : H,
      (P : α → (H →L[ℝ] H)) x v + (M : α → (H →L[ℝ] H)) x v =
        (Q : α → (H →L[ℝ] H)) x v)
    (htrans : ∀ᵐ t ∂η, multiplier μ Q (z t) = z t)
    (hEnergy : 2 * nu * (∫ t, ‖z t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => multiplier μ P (z t)) (fun t => multiplier μ M (z t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => multiplier μ P (z t)) (fun t => multiplier μ M (z t))
      ≤ initialEnergy / (4 * nu) := by
  apply HelicalGramAdapter.transverse_gram_integrable_and_bound
    η (multiplier μ P) (multiplier μ M) (multiplier μ Q) z nu initialEnergy
    hnu hz
  · intro f g
    exact multiplier_symmetric μ P hsym f g
  · intro f
    exact multiplier_idempotent μ P hid f
  · intro f
    exact multiplier_partition μ P M Q hsum f
  · exact htrans
  · exact hEnergy

end HelicalMultiplierAlgebra

#print axioms HelicalMultiplierAlgebra.multiplier_partition
#print axioms HelicalMultiplierAlgebra.multiplier_symmetric
#print axioms HelicalMultiplierAlgebra.multiplier_cross_zero
#print axioms HelicalMultiplierAlgebra.multiplier_ranges_orthogonal
#print axioms HelicalMultiplierAlgebra.multiplier_transverse_gram_bound
