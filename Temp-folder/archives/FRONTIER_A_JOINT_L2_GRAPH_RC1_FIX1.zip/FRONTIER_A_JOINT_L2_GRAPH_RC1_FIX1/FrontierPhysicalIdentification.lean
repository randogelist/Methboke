import FrontierAReuseRoot


/-!
A-TIER CANDIDATE, not externally compiled or audited.
The derivative-column fields are constructed from the supplied real matrix.
The distributional weak-derivative and energy assumptions remain explicit.
This does not construct a Leray–Hopf solution or identify the Fourier pullbacks
with the actual helical Stokes fields.
-/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierGradientAdapter

local instance physicalRealL2 :
    InnerProductSpace ℝ FrontierPhysicalGramTransport.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierPhysicalGramTransport.PhysicalL2

/-- The j-th complexified column of a supplied real L² matrix. -/
def gradientColumn (g : FrontierARealGradient.RealMatrix) (j : Fin 3) :
    FrontierAWeakTimeGram.Field :=
  FrontierAWeakMatrixColumns.columnL2 j (FrontierARealGradient.complexifyL2 g)

/-- A gradient-column transfer with no independent column fields or column
identification assumption. The weak derivative is still an explicit premise. -/
theorem pullback_gram_from_gradient_columns
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → FrontierAWeakTimeGram.Field)
    (g : τ → FrontierARealGradient.RealMatrix)
    (D : τ → ℝ) (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : AEStronglyMeasurable g η) (hD : Integrable D η)
    (hidentify : D =ᵐ[η] fun t => ‖g t‖ ^ 2)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, D t ∂η) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂η, ∀ j, Lp.toTemperedDistribution (gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t))) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  apply FrontierPhysicalClosure.pullback_gram_from_terminal_energy
    η u g (fun t j => gradientColumn (g t) j) D u0 uT nu hnu hg hD hidentify henergy
  · exact Filter.Eventually.of_forall (fun _ _ => rfl)
  · exact hweak

end FrontierGradientAdapter

#print axioms FrontierGradientAdapter.pullback_gram_from_gradient_columns


/-!
Conditional identification of separately supplied physical L² fields from
their Fourier symbols. The velocity, weak derivatives and physical fields
are still supplied; this module does not construct a Leray–Hopf solution,
the Stokes operator, or prove the physical helical Fourier formulas.
-/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierPhysicalIdentification

abbrev Frequency := FrontierMultiplierBridge.Frequency
abbrev Fiber := FrontierMultiplierBridge.Fiber
abbrev Field := FrontierMultiplierBridge.Field
abbrev PhysicalL2 := FrontierPhysicalGramTransport.PhysicalL2

local instance physicalRealL2 : InnerProductSpace ℝ PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ PhysicalL2

/-- Pointwise Fourier-symbol identifications imply equality with the
constructed pullbacks. These Fourier formulas remain explicit premises. -/
theorem fields_eq_pullbacks_of_symbols
    (u : Field) (g : FrontierARealGradient.RealMatrix) (du : Fin 3 → Field)
    (vp vm : PhysicalL2)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 g) = du j)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (hp : (FrontierPhysicalGramTransport.fourierCoordinateReal vp : Frequency → Fiber) =ᵐ[volume]
      fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol u ξ))
    (hm : (FrontierPhysicalGramTransport.fourierCoordinateReal vm : Frequency → Fiber) =ᵐ[volume]
      fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol u ξ)) :
    vp = FrontierPhysicalGramTransport.plusField g ∧
    vm = FrontierPhysicalGramTransport.minusField g := by
  have h := FrontierMultiplierBridge.helical_l2_of_velocity_symbol u g du
    (FrontierPhysicalGramTransport.fourierCoordinateReal vp)
    (FrontierPhysicalGramTransport.fourierCoordinateReal vm) hcol hweak hp hm
  constructor
  · apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
    rw [FrontierPhysicalGramTransport.plusField_fourier]
    exact h.1
  · apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
    rw [FrontierPhysicalGramTransport.minusField_fourier]
    exact h.2

/-- Transport any already established pullback Gram estimate to the supplied
physical trajectories. The solution and operator identifications remain
explicit assumptions. -/
theorem gram_bound_of_symbols
    {τ : Type*} [MeasurableSpace τ] (η : Measure τ)
    (u : τ → Field) (g : τ → FrontierARealGradient.RealMatrix)
    (du : τ → Fin 3 → Field) (vp vm : τ → PhysicalL2) (C : ℝ)
    (hcol : ∀ᵐ t ∂η, ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 (g t)) = du t j)
    (hweak : ∀ᵐ t ∂η, ∀ j, Lp.toTemperedDistribution (du t j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t)))
    (hp : ∀ᵐ t ∂η, (FrontierPhysicalGramTransport.fourierCoordinateReal (vp t) : Frequency → Fiber) =ᵐ[volume]
      fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol (u t) ξ))
    (hm : ∀ᵐ t ∂η, (FrontierPhysicalGramTransport.fourierCoordinateReal (vm t) : Frequency → Fiber) =ᵐ[volume]
      fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol (u t) ξ))
    (hbound : Integrable (FeffermanAHopfGramIntegral.gramSqrt
       (fun t => FrontierPhysicalGramTransport.plusField (g t))
       (fun t => FrontierPhysicalGramTransport.minusField (g t))) η ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral η
       (fun t => FrontierPhysicalGramTransport.plusField (g t))
       (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤ C) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt vp vm) η ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral η vp vm ≤ C := by
  have heq : FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) =ᵐ[η]
      FeffermanAHopfGramIntegral.gramSqrt vp vm := by
    filter_upwards [hcol, hweak, hp, hm] with t hc hw hpt hmt
    have h := fields_eq_pullbacks_of_symbols (u t) (g t) (du t) (vp t) (vm t)
      hc hw hpt hmt
    simp only [FeffermanAHopfGramIntegral.gramSqrt, h.1, h.2]
  constructor
  · exact hbound.1.congr heq
  · unfold FeffermanAHopfGramIntegral.gramSqrtIntegral at hbound ⊢
    rw [← integral_congr_ae heq]
    exact hbound.2

end FrontierPhysicalIdentification

#print axioms FrontierPhysicalIdentification.fields_eq_pullbacks_of_symbols
#print axioms FrontierPhysicalIdentification.gram_bound_of_symbols
