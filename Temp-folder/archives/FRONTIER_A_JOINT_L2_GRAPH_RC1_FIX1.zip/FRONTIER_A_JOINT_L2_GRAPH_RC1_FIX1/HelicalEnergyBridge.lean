import HelicalConcreteGram

/-!
Candidate: lift fiberwise transversality to the concrete L2 split, and derive
its projected-energy budget from a single trajectory-energy budget. This does
not construct Fourier--Plancherel, a Leray--Hopf solution, or its energy law.
External native compilation and theorem-level axiom auditing are required.
-/

noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace HelicalEnergyBridge

/-- A transverse representative splits in the two concrete L2 multipliers. -/
theorem fiber_transverse_split (μ : Measure Frequency) (f : Lp Fiber 2 μ)
    (hf : ∀ᵐ ξ ∂μ,
      Matrix.toEuclideanLin
        (FeffermanHelicalFrequency.projection (ξ 0) (ξ 1) (ξ 2))
        ((f : Frequency → Fiber) ξ) = ((f : Frequency → Fiber) ξ)) :
    plusMultiplier μ f + minusMultiplier μ f = f := by
  apply MeasureTheory.Lp.ext
  filter_upwards [MeasureTheory.Lp.coeFn_add (plusMultiplier μ f) (minusMultiplier μ f),
    plus_multiplier_ae μ f, minus_multiplier_ae μ f, hf] with ξ ha hp hm ht
  calc
    ((plusMultiplier μ f + minusMultiplier μ f : Lp Fiber 2 μ) : Frequency → Fiber) ξ =
        (plusMultiplier μ f : Frequency → Fiber) ξ +
          (minusMultiplier μ f : Frequency → Fiber) ξ := ha
    _ = FeffermanHelicalFiberFrequency.plusMap (ξ 0) (ξ 1) (ξ 2) ((f : Frequency → Fiber) ξ) +
          FeffermanHelicalFiberFrequency.minusMap (ξ 0) (ξ 1) (ξ 2) ((f : Frequency → Fiber) ξ) := by
      rw [hp, hm, plus_action, minus_action]
    _ = (f : Frequency → Fiber) ξ :=
      FeffermanHelicalFiberFrequency.transverse_split (ξ 0) (ξ 1) (ξ 2)
        ((f : Frequency → Fiber) ξ) ht

/-- For a split L2 vector, orthogonality gives the exact energy identity. -/
theorem split_energy (μ : Measure Frequency) (f : Lp Fiber 2 μ)
    (hf : plusMultiplier μ f + minusMultiplier μ f = f) :
    ‖plusMultiplier μ f‖ ^ 2 + ‖minusMultiplier μ f‖ ^ 2 = ‖f‖ ^ 2 := by
  have h := norm_add_sq (𝕜 := ℂ) (plusMultiplier μ f) (minusMultiplier μ f)
  rw [hf, HelicalConcreteGram.multiplier_complex_orthogonal μ f f] at h
  simp only [RCLike.zero_re, map_zero, mul_zero, add_zero] at h
  linarith

local instance realL2 (μ : Measure Frequency) : InnerProductSpace ℝ (Lp Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp Fiber 2 μ)

/-- A transverse trajectory needs only the energy budget of the unsplit vector. -/
theorem transverse_energy_gram_bound
    {τ : Type*} [MeasurableSpace τ] (μ : Measure Frequency) (η : Measure τ)
    [MeasurableSpace (Lp Fiber 2 μ)] [BorelSpace (Lp Fiber 2 μ)]
    (z : τ → Lp Fiber 2 μ) (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hz : MemLp z 2 η)
    (hsplit : ∀ᵐ t ∂η, plusMultiplier μ (z t) + minusMultiplier μ (z t) = z t)
    (hEnergy : 2 * nu * (∫ t, ‖z t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier μ (z t)) (fun t => minusMultiplier μ (z t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier μ (z t)) (fun t => minusMultiplier μ (z t))
      ≤ initialEnergy / (4 * nu) := by
  have heq : (∫ t, (‖plusMultiplier μ (z t)‖ ^ 2 +
      ‖minusMultiplier μ (z t)‖ ^ 2) ∂η) = ∫ t, ‖z t‖ ^ 2 ∂η := by
    apply integral_congr_ae
    filter_upwards [hsplit] with t ht
    exact split_energy μ (z t) ht
  apply HelicalConcreteGram.concrete_helical_gram_bound μ η z nu initialEnergy hnu hz
  rw [heq]
  exact hEnergy

/-- Fiberwise transversality for almost every time gives the same bound. -/
theorem fiber_transverse_energy_gram_bound
    {τ : Type*} [MeasurableSpace τ] (μ : Measure Frequency) (η : Measure τ)
    [MeasurableSpace (Lp Fiber 2 μ)] [BorelSpace (Lp Fiber 2 μ)]
    (z : τ → Lp Fiber 2 μ) (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hz : MemLp z 2 η)
    (htrans : ∀ᵐ t ∂η, ∀ᵐ ξ ∂μ,
      Matrix.toEuclideanLin
        (FeffermanHelicalFrequency.projection (ξ 0) (ξ 1) (ξ 2))
        ((z t : Frequency → Fiber) ξ) = ((z t : Frequency → Fiber) ξ))
    (hEnergy : 2 * nu * (∫ t, ‖z t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier μ (z t)) (fun t => minusMultiplier μ (z t))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier μ (z t)) (fun t => minusMultiplier μ (z t))
      ≤ initialEnergy / (4 * nu) := by
  apply transverse_energy_gram_bound μ η z nu initialEnergy hnu hz
  · filter_upwards [htrans] with t ht
    exact fiber_transverse_split μ (z t) ht
  · exact hEnergy

end HelicalEnergyBridge

#print axioms HelicalEnergyBridge.fiber_transverse_split
#print axioms HelicalEnergyBridge.split_energy
#print axioms HelicalEnergyBridge.transverse_energy_gram_bound
#print axioms HelicalEnergyBridge.fiber_transverse_energy_gram_bound
