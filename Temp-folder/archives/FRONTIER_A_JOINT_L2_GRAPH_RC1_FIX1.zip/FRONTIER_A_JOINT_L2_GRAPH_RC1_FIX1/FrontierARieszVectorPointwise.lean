import FrontierARieszFrequency
import HelicalConcreteSymbol

/-!
Candidate pointwise three-component Riesz row energy bound. The input is an
arbitrary 3 by 3 complex array, with indices (velocity, derivative). No
weak derivative, L2 operator, Navier--Stokes solution, or Fourier conjugation
is constructed in this module. External compilation and audit are required.
-/
noncomputable section
open scoped BigOperators

namespace FrontierARieszVectorPointwise

abbrev Frequency := HelicalConcreteSymbol.Frequency

/-- Apply the same normalized Riesz frequency row to each velocity component. -/
def vectorRow (ξ : Frequency) (g : Fin 3 → Fin 3 → ℂ) : Fin 3 → ℂ :=
  fun i => FrontierARieszFrequency.freqRow (ξ 0) (ξ 1) (ξ 2)
    (g i 0) (g i 1) (g i 2)

/-- The sum of the three output energies is bounded by the full matrix energy. -/
theorem vectorRow_normSq_bound (ξ : Frequency) (g : Fin 3 → Fin 3 → ℂ) :
    (∑ i, Complex.normSq (vectorRow ξ g i)) ≤
      ∑ i, ∑ j, Complex.normSq (g i j) := by
  apply Finset.sum_le_sum
  intro i hi
  simpa [vectorRow, Fin.sum_univ_succ, add_assoc] using
    FrontierARieszFrequency.freq_row_normSq_bound (ξ 0) (ξ 1) (ξ 2)
      (g i 0) (g i 1) (g i 2)

end FrontierARieszVectorPointwise

#print axioms FrontierARieszVectorPointwise.vectorRow_normSq_bound
