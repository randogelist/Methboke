import FrontierARieszVectorL2
import FrontierAContractiveTransfer

/-! Candidate composition of the concrete frequency matrix contraction,
inverse Fourier transport, and previous frequency Gram inequality. The supplied
matrix trajectory is arbitrary complex L² data with its own budget, and is NOT
yet proved to be the Fourier transform of a physical weak gradient. The Gram
integrand is the existing coordinate-frequency quantity; physical Leray–Hopf,
weak derivative, real-field and helical-semantic identifications remain open.
No local Lean compilation or axiom audit has been performed. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal
open FrontierARieszVectorSymbol FrontierARieszVectorL2

namespace FrontierARieszVectorGram

local instance realL2 (μ : Measure HelicalConcreteSymbol.Frequency) : InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

/-- Conditional on a supplied matrix trajectory and its own budget, the
concrete multiplier constructs the input for the established Gram estimate. -/
theorem gram_from_frequency_matrix
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace (Lp GradFiber 2 (volume : Measure HelicalConcreteSymbol.Frequency))]
    [BorelSpace (Lp GradFiber 2 (volume : Measure HelicalConcreteSymbol.Frequency))]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAConcreteFourier.CoordinateL2]
    [BorelSpace FrontierAConcreteFourier.CoordinateL2]
    (η : Measure τ) (grad : τ → Lp GradFiber 2 (volume : Measure HelicalConcreteSymbol.Frequency))
    (nu initialEnergy : ℝ) (hnu : 0 < nu)
    (hgrad : MemLp grad 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖grad t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (FrontierAConcreteFourier.coordinateFourier (inverseFourierVectorCLM (grad t))))
      (fun t => minusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (FrontierAConcreteFourier.coordinateFourier (inverseFourierVectorCLM (grad t))))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (FrontierAConcreteFourier.coordinateFourier (inverseFourierVectorCLM (grad t))))
      (fun t => minusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (FrontierAConcreteFourier.coordinateFourier (inverseFourierVectorCLM (grad t))))
      ≤ initialEnergy / (4 * nu) := by
  exact FrontierAContractiveTransfer.fourier_gram_from_contraction η inverseFourierVectorCLM
    grad nu initialEnergy hnu inverseFourierVectorCLM_contractive hgrad hEnergy

end FrontierARieszVectorGram

#print axioms FrontierARieszVectorGram.gram_from_frequency_matrix
