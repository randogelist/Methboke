import FrontierCanonicalFinalEnergy
import FrontierRealDistributionTrace

/-! The audited canonical final-energy theorem, with the supplied gradient's
column-based distributional divergence replacing its equivalent spatial trace
premise. The weak-gradient and energy data remain explicit. No local Lean run. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierDistributionalFinalEnergy

abbrev RealVelocity := FrontierRealSpectralEnergy.RealVelocity
abbrev Gradient := FrontierRealSpectralEnergy.Gradient
abbrev Space := FrontierRealSpectralEnergy.Space
abbrev RealFiber := FrontierRealSpectralEnergy.RealFiber

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

theorem gram_canonical_of_distributional_divergence
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → RealVelocity) (u0 : RealVelocity) (g : ℝ → Gradient)
    (T nu : ℝ) (hnu : 0 < nu)
    (hg : MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T))
    (henergy : ‖u T‖ ^ 2 + 2 * nu *
      (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      FrontierAEProjectedGraphEnergy.WeakAt (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
    (hdiv : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
      FrontierRealDistributionTrace.ColumnDivergenceZero (g t)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierSpectralTimeComposition.positiveField FrontierCanonicalInterface.canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField FrontierCanonicalInterface.canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)))
      (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (FrontierFiniteIntervalEnergy.timeMeasure T)
      (fun t => FrontierSpectralTimeComposition.positiveField FrontierCanonicalInterface.canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t))
      (fun t => FrontierSpectralTimeComposition.negativeField FrontierCanonicalInterface.canonical
        (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t)) ≤
          (‖u0‖ ^ 2 - ‖u T‖ ^ 2) / (4 * nu) := by
  apply FrontierCanonicalFinalEnergy.gram_canonical_with_final_energy
    u u0 g T nu hnu hg henergy hweak
  exact FrontierRealDistributionTrace.trace_zero_ae_of_column_divergence_zero_ae
    (FrontierFiniteIntervalEnergy.timeMeasure T) g hdiv

end FrontierDistributionalFinalEnergy
#print axioms FrontierDistributionalFinalEnergy.gram_canonical_of_distributional_divergence
