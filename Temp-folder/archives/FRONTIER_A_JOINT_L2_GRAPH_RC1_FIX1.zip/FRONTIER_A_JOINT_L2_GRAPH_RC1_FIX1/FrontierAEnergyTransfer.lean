import FrontierAConcreteFourier

/-!
Candidate reduction of trajectory inputs. The functions below are supplied:
the file does NOT define an actual Leray–Hopf solution, weak gradient, |D|,
physical projections, or a Fourier–Sobolev identity. The latter is an explicit
almost-everywhere norm equality. A.e. strong measurability of the supplied
dissipation trajectory and the gradient energy inequality are also hypotheses.
The theorem removes a separate time-L² and energy-budget hypothesis for that
trajectory by deriving them from the supplied gradient data. No external Lean
compilation or theorem audit has yet been performed.
-/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierAEnergyTransfer

abbrev ComplexField := FrontierAConcreteFourier.ComplexField
abbrev CoordinateL2 := FrontierAConcreteFourier.CoordinateL2

local instance realL2 (μ : Measure Frequency) : InnerProductSpace ℝ (Lp Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp Fiber 2 μ)

/-- Transfer time-L² and an energy budget along an a.e. equality of norms.
    The gradient and trajectory are arbitrary supplied fields. -/
theorem trajectory_inputs_from_gradient
    {τ G : Type*} [MeasurableSpace τ]
    [NormedAddCommGroup G] [MeasurableSpace G] [BorelSpace G]
    [MeasurableSpace ComplexField] [BorelSpace ComplexField]
    (η : Measure τ) (x : τ → ComplexField) (grad : τ → G)
    (nu initialEnergy : ℝ)
    (hxmeas : AEStronglyMeasurable x η) (hgrad : MemLp grad 2 η)
    (hnorm : ∀ᵐ t ∂η, ‖x t‖ = ‖grad t‖)
    (hEnergy : 2 * nu * (∫ t, ‖grad t‖ ^ 2 ∂η) ≤ initialEnergy) :
    MemLp x 2 η ∧
      2 * nu * (∫ t, ‖x t‖ ^ 2 ∂η) ≤ initialEnergy := by
  have hgradSq : Integrable (fun t => ‖grad t‖ ^ 2) η :=
    (memLp_two_iff_integrable_sq_norm hgrad.aestronglyMeasurable).1 hgrad
  have hsq : (fun t => ‖x t‖ ^ 2) =ᵐ[η] (fun t => ‖grad t‖ ^ 2) := by
    filter_upwards [hnorm] with t ht
    rw [ht]
  have hxSq : Integrable (fun t => ‖x t‖ ^ 2) η := hgradSq.congr hsq.symm
  have hx : MemLp x 2 η := (memLp_two_iff_integrable_sq_norm hxmeas).2 hxSq
  have heq : (∫ t, ‖x t‖ ^ 2 ∂η) = ∫ t, ‖grad t‖ ^ 2 ∂η :=
    integral_congr_ae hsq
  exact ⟨hx, by rw [heq]; exact hEnergy⟩

/-- The existing concrete frequency Gram bound, expressed using supplied
    gradient data and an explicit norm-identification hypothesis. -/
theorem fourier_gram_from_gradient
    {τ G : Type*} [MeasurableSpace τ]
    [NormedAddCommGroup G] [MeasurableSpace G] [BorelSpace G]
    [MeasurableSpace ComplexField] [BorelSpace ComplexField]
    [MeasurableSpace CoordinateL2] [BorelSpace CoordinateL2]
    (η : Measure τ) (x : τ → ComplexField) (grad : τ → G)
    (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hxmeas : AEStronglyMeasurable x η)
    (hgrad : MemLp grad 2 η)
    (hnorm : ∀ᵐ t ∂η, ‖x t‖ = ‖grad t‖)
    (hEnergy : 2 * nu * (∫ t, ‖grad t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier (volume : Measure Frequency)
        (FrontierAConcreteFourier.coordinateFourier (x t)))
      (fun t => minusMultiplier (volume : Measure Frequency)
        (FrontierAConcreteFourier.coordinateFourier (x t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier (volume : Measure Frequency)
        (FrontierAConcreteFourier.coordinateFourier (x t)))
      (fun t => minusMultiplier (volume : Measure Frequency)
        (FrontierAConcreteFourier.coordinateFourier (x t)))
      ≤ initialEnergy / (4 * nu) := by
  obtain ⟨hx, hbudget⟩ := trajectory_inputs_from_gradient η x grad nu initialEnergy
    hxmeas hgrad hnorm hEnergy
  exact FrontierAConcreteFourier.fourier_coordinate_gram_bound η x nu initialEnergy
    hnu hx hbudget

end FrontierAEnergyTransfer

#print axioms FrontierAEnergyTransfer.trajectory_inputs_from_gradient
#print axioms FrontierAEnergyTransfer.fourier_gram_from_gradient
