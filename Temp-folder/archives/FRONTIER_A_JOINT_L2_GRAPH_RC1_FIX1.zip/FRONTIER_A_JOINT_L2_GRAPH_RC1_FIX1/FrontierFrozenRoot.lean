import FrontierCanonicalGradientBudgetRoot

/-!
Candidate assembly for the frozen Frontier_A finite-time Gram inequality.

There are two distinct roots below.

* `canonical_matrix_frontierA` concerns the explicitly defined project Fourier
  pullbacks of supplied matrix data. It does not assume a velocity or PDE.
* `physical_frontierA_from_separated_tests` concerns independently supplied
  fields whose velocity Fourier symbols are assumed explicitly. It requires
  the displayed energy-class, separated-test and symbol hypotheses.

Neither theorem constructs a standard Leray--Hopf solution, proves that a
standard solution supplies the hypotheses, or identifies an independently
defined Stokes square root with these Fourier fields. Those are unresolved
physical-realization obligations. No local Lean run has been made.
-/

noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierFrozenRoot

abbrev Space := FrontierSeparatedPhysicalRoot.Space
abbrev Fiber := FrontierSeparatedPhysicalRoot.Fiber
abbrev Frequency := FrontierSeparatedPhysicalRoot.Frequency
abbrev RealVelocity := FrontierSeparatedPhysicalRoot.RealVelocity
abbrev Gradient := FrontierSeparatedPhysicalRoot.Gradient
abbrev PhysicalL2 := FrontierSeparatedPhysicalRoot.PhysicalL2
abbrev timeMeasure := FrontierFiniteIntervalEnergy.timeMeasure

local instance physicalRealL2 : InnerProductSpace ℝ PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ PhysicalL2

/-- Frozen numeric endpoint for the project's gradient-derived pullbacks,
conditional on the explicit gradient energy budget. -/
theorem canonical_matrix_frontierA
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2]
    [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (g : ℝ → Gradient) (u0 : RealVelocity) (T nu : ℝ)
    (hT : 0 ≤ T) (hnu : 0 < nu)
    (hg : MemLp g 2 (timeMeasure T))
    (hbudget : 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂(timeMeasure T)) ≤ ‖u0‖ ^ 2) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t))) (timeMeasure T) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (timeMeasure T)
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  have h := FrontierGradientOnlyFinalEnergy.gram_of_matrix_energy
    (timeMeasure T) g nu (‖u0‖ ^ 2) 0 hnu hg (by simpa using hbudget)
  simpa only [sub_zero] using h

/-- Frozen numeric endpoint for independently supplied L² fields satisfying
the displayed velocity-symbol assumptions. `timeMeasure T` is Lebesgue measure
restricted to `[0,T]`; for Lebesgue integration the endpoints are null.
The energy, separated-test, and symbol hypotheses remain explicit. -/
theorem physical_frontierA_from_separated_tests
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2]
    [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → RealVelocity) (u0 : RealVelocity) (g : ℝ → Gradient)
    (vp vm : ℝ → PhysicalL2) (T nu : ℝ)
    (hT : 0 ≤ T) (hnu : 0 < nu)
    (hu : MemLp u (⊤ : ENNReal) (timeMeasure T))
    (hg : MemLp g 2 (timeMeasure T))
    (hbudget : 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂(timeMeasure T)) ≤ ‖u0‖ ^ 2)
    (hsep : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SchwartzMap Space ℂ),
        (∫ t, φ t • ((FrontierWeakGradientSubspace.residual j (u t, g t)) ψ)
          ∂(timeMeasure T)) = 0)
    (hp : ∀ᵐ t ∂(timeMeasure T),
      (FrontierPhysicalGramTransport.fourierCoordinateReal (vp t) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ))
    (hm : ∀ᵐ t ∂(timeMeasure T),
      (FrontierPhysicalGramTransport.fourierCoordinateReal (vm t) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt vp vm) (timeMeasure T) ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral (timeMeasure T) vp vm ≤
        ‖u0‖ ^ 2 / (4 * nu) := by
  -- The project interval measure is a restricted finite Lebesgue measure.
  -- Expose the definition explicitly for Lean's typeclass search.
  letI : IsFiniteMeasure (timeMeasure T) := by
    change IsFiniteMeasure ((volume : Measure ℝ).restrict (Set.Icc 0 T))
    exact Real.isFiniteMeasure_restrict_Icc 0 T
  letI : IsLocallyFiniteMeasure (timeMeasure T) :=
    IsFiniteMeasure.toIsLocallyFiniteMeasure (timeMeasure T)
  have h := FrontierSeparatedPhysicalRoot.physical_gram_of_separated_tests
    (timeMeasure T) u g vp vm nu (‖u0‖ ^ 2) 0 hnu hu hg
    (by simpa using hbudget) hsep hp hm
  simpa only [sub_zero] using h

end FrontierFrozenRoot

#print FrontierFrozenRoot.canonical_matrix_frontierA
#print axioms FrontierFrozenRoot.canonical_matrix_frontierA
#print FrontierFrozenRoot.physical_frontierA_from_separated_tests
#print axioms FrontierFrozenRoot.physical_frontierA_from_separated_tests
