import FrontierNonzeroFrequency

/-! Candidate comparison with the pointwise helical multiplier formula of
Lerner–Vigneron, arXiv:2203.07950, Lemma 10. This compares matrix formulas
only. It does not construct a self-adjoint curl operator or identify a
Leray–Hopf solution. Fourier-frequency normalization and domain/realization
issues remain separate. No local Lean compilation has been performed. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierPublishedHelicalFormula

abbrev Frequency := FrontierNonzeroFrequency.Frequency

/-- Coordinates in the unnormalized frequency vector. -/
def coords (x y z : ℝ) : Fin 3 → ℝ := ![x, y, z]

/-- The unnormalized expression for the transverse symbol I - ξ⊗ξ/|ξ|². -/
def transverseDirect (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  fun i j => (if i = j then 1 else 0) -
    (((coords x y z i * coords x y z j /
      (FeffermanHelicalNormalize.radius x y z) ^ 2 : ℝ) : ℂ))

/-- The source formula Q±=(Πσ ± i ξ×/|ξ|)/2. -/
def directPlus (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  fun i j => (transverseDirect x y z i j +
    FeffermanHelicalGeneral.curlSymbol x y z i j /
      (FeffermanHelicalNormalize.radius x y z : ℂ)) / 2

def directMinus (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  fun i j => (transverseDirect x y z i j -
    FeffermanHelicalGeneral.curlSymbol x y z i j /
      (FeffermanHelicalNormalize.radius x y z : ℂ)) / 2

/-- On nonzero frequencies the published formula is the existing plus symbol. -/
theorem directPlus_eq_existing (x y z : ℝ)
    (h : 0 < FeffermanHelicalFrequency.lengthSq x y z) :
    directPlus x y z = FeffermanHelicalFrequency.plus x y z := by
  have hr : FeffermanHelicalNormalize.radius x y z ≠ 0 :=
    ne_of_gt (Real.sqrt_pos.2 h)
  have hrc : (FeffermanHelicalNormalize.radius x y z : ℂ) ≠ 0 := by
    exact_mod_cast hr
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    simp [directPlus, transverseDirect, coords, FeffermanHelicalFrequency.plus,
      h, FeffermanHelicalGeneral.positive, FeffermanHelicalGeneral.transverse,
      FeffermanHelicalGeneral.curlSymbol, Complex.ofReal_div,
      Complex.ofReal_mul, Complex.ofReal_pow] <;>
    field_simp [hr, hrc] <;> ring

theorem directMinus_eq_existing (x y z : ℝ)
    (h : 0 < FeffermanHelicalFrequency.lengthSq x y z) :
    directMinus x y z = FeffermanHelicalFrequency.minus x y z := by
  have hr : FeffermanHelicalNormalize.radius x y z ≠ 0 :=
    ne_of_gt (Real.sqrt_pos.2 h)
  have hrc : (FeffermanHelicalNormalize.radius x y z : ℂ) ≠ 0 := by
    exact_mod_cast hr
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    simp [directMinus, transverseDirect, coords, FeffermanHelicalFrequency.minus,
      h, FeffermanHelicalGeneral.negative, FeffermanHelicalGeneral.transverse,
      FeffermanHelicalGeneral.curlSymbol, Complex.ofReal_div,
      Complex.ofReal_mul, Complex.ofReal_pow] <;>
    field_simp [hr, hrc] <;> ring

/-- The frequency-zero discrepancy is irrelevant almost everywhere. -/
theorem directPlus_eq_existing_ae :
    ∀ᵐ ξ ∂(volume : Measure Frequency),
      directPlus (ξ 0) (ξ 1) (ξ 2) =
        FeffermanHelicalFrequency.plus (ξ 0) (ξ 1) (ξ 2) := by
  filter_upwards [FrontierNonzeroFrequency.lengthSq_pos_ae] with ξ hξ
  exact directPlus_eq_existing (ξ 0) (ξ 1) (ξ 2) hξ

theorem directMinus_eq_existing_ae :
    ∀ᵐ ξ ∂(volume : Measure Frequency),
      directMinus (ξ 0) (ξ 1) (ξ 2) =
        FeffermanHelicalFrequency.minus (ξ 0) (ξ 1) (ξ 2) := by
  filter_upwards [FrontierNonzeroFrequency.lengthSq_pos_ae] with ξ hξ
  exact directMinus_eq_existing (ξ 0) (ξ 1) (ξ 2) hξ

end FrontierPublishedHelicalFormula

#print axioms FrontierPublishedHelicalFormula.directPlus_eq_existing
#print axioms FrontierPublishedHelicalFormula.directMinus_eq_existing
#print axioms FrontierPublishedHelicalFormula.directPlus_eq_existing_ae
#print axioms FrontierPublishedHelicalFormula.directMinus_eq_existing_ae
