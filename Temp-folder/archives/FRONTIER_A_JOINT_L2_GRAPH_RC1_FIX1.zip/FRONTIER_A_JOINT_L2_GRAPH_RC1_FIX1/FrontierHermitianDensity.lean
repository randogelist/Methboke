import FrontierHermitianClosed

/-! Candidate L²-density transfer for Fourier Hermitian symmetry. It assumes
symmetry on a seed set and membership in its L² closure; neither real-field
seed symmetry nor density of that seed in the physical real subspace is proved
here. No Lean compiler has been run locally. -/
noncomputable section
open MeasureTheory
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierHermitianDensity
abbrev PhysicalL2 := HelicalR3Plancherel.ComplexField
abbrev Frequency := FrontierAESymmetry.Frequency

/-- Fourier symmetry extends from any seed set to its physical L² closure. -/
theorem fourier_hermitian_of_mem_closure
    (S : Set PhysicalL2)
    (hseed : ∀ u ∈ S, FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate u))
    (u : PhysicalL2) (hu : u ∈ closure S) :
    FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate u) := by
  have hc : IsClosed {v : PhysicalL2 | FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate v)} :=
    FrontierHermitianClosed.isClosed_hermitian.preimage
      FrontierACoordinateEquiv.fourierCoordinate.continuous
  exact closure_minimal hseed hc hu

/-- The plus pullback inherits the seed-closure symmetry. -/
theorem plus_pullback_hermitian_of_mem_closure
    (S : Set PhysicalL2)
    (hseed : ∀ u ∈ S, FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate u))
    (u : PhysicalL2) (hu : u ∈ closure S) :
    FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate
        (FrontierACoordinateEquiv.plusPullback u)) := by
  rw [FrontierACoordinateEquiv.plus_intertwines]
  exact FrontierVolumeSymmetry.plus_preserves _
    (fourier_hermitian_of_mem_closure S hseed u hu)

/-- The minus pullback inherits the seed-closure symmetry. -/
theorem minus_pullback_hermitian_of_mem_closure
    (S : Set PhysicalL2)
    (hseed : ∀ u ∈ S, FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate u))
    (u : PhysicalL2) (hu : u ∈ closure S) :
    FrontierAESymmetry.HermitianAE volume
      (FrontierACoordinateEquiv.fourierCoordinate
        (FrontierACoordinateEquiv.minusPullback u)) := by
  rw [FrontierACoordinateEquiv.minus_intertwines]
  exact FrontierVolumeSymmetry.minus_preserves _
    (fourier_hermitian_of_mem_closure S hseed u hu)

end FrontierHermitianDensity

#print axioms FrontierHermitianDensity.fourier_hermitian_of_mem_closure
#print axioms FrontierHermitianDensity.plus_pullback_hermitian_of_mem_closure
#print axioms FrontierHermitianDensity.minus_pullback_hermitian_of_mem_closure
