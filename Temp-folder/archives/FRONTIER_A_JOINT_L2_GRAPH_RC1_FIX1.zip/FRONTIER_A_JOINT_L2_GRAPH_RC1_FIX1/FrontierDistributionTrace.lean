import FrontierPhysicalDivergence

/-! Candidate distributional-to-L² gradient-trace bridge. The hypothesis
states that the tempered distribution induced by the supplied L² gradient
trace is zero. Identifying this distribution with the divergence of an
independently defined Leray--Hopf solution remains a separate obligation.
No local Lean compilation has been performed. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierDistributionTrace

abbrev Space := FrontierPhysicalDivergence.Space
abbrev Fiber := FrontierPhysicalDivergence.Fiber
abbrev MatrixL2 := FrontierPhysicalDivergence.MatrixL2
abbrev Field := FrontierPhysicalDivergence.Field

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩

/-- Vanishing as a tempered distribution forces the supplied L² gradient
trace to vanish as an L² equivalence class. -/
theorem traceL2_eq_zero_of_distribution_eq_zero
    (g : MatrixL2)
    (hdiv : Lp.toTemperedDistribution (FrontierPhysicalDivergence.traceL2 g) = 0) :
    FrontierPhysicalDivergence.traceL2 g = 0 := by
  have hinj : Function.Injective
      (Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2) := by
    apply LinearMap.ker_eq_bot.mp
    exact Lp.ker_toTemperedDistributionCLM_eq_bot
  apply hinj
  change Lp.toTemperedDistribution (FrontierPhysicalDivergence.traceL2 g) =
    (Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2) 0
  rw [map_zero]
  exact hdiv

/-- The helical projector split follows from a weak gradient with vanishing
distributional trace, subject to its column and weak derivative identities. -/
theorem split_of_distributional_gradient_trace_zero
    (u : Field) (g : MatrixL2) (du : Fin 3 → Field)
    (hcol : ∀ j, FrontierAWeakMatrixColumns.columnL2 j g = du j)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (hdiv : Lp.toTemperedDistribution (FrontierPhysicalDivergence.traceL2 g) = 0) :
    FrontierPhysicalProjectors.plusProjector u +
      FrontierPhysicalProjectors.minusProjector u = u := by
  exact FrontierPhysicalDivergence.split_of_weak_gradient_trace_zero u g du hcol hweak
    (traceL2_eq_zero_of_distribution_eq_zero g hdiv)

end FrontierDistributionTrace

#print axioms FrontierDistributionTrace.traceL2_eq_zero_of_distribution_eq_zero
#print axioms FrontierDistributionTrace.split_of_distributional_gradient_trace_zero
