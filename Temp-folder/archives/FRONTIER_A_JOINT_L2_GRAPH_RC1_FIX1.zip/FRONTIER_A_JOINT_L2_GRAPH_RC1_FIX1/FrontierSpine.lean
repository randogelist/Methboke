import FrontierARealWeakTimeGram

/-!
Conditional transport from the v0.28 real-gradient theorem to separately
supplied purported physical helical vectors. The two a.e. transport
hypotheses are explicit and are NOT proved here. The frequency identity is
retained so that future work can discharge them using the physical Stokes and
helical Fourier realization. No Leray--Hopf semantics are asserted here.
-/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierSpine
abbrev Frequency := FrontierAWeakTimeGram.Frequency
abbrev MatrixL2 := FrontierAWeakTimeGram.MatrixL2
abbrev Field := FrontierAWeakTimeGram.Field
abbrev CoordinateL2 := FrontierAWeakTimeGram.CoordinateL2
abbrev SpectralHilbert := Lp FeffermanHelicalOrthogonal.Fiber 2 (volume : Measure Frequency)

local instance realL2 (μ : Measure Frequency) :
    InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

/-- A conditional bridge. `vp` and `vm` may be interpreted as Fourier
transforms of physical vectors only after separately proving the hypotheses
`hp` and `hm` from their actual physical definitions. -/
theorem real_weak_gram_transport
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace MatrixL2] [BorelSpace MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace CoordinateL2] [BorelSpace CoordinateL2]
    (η : Measure τ) (u : τ → Field) (g : τ → FrontierARealGradient.RealMatrix)
    (du : τ → Fin 3 → Field) (vp vm : τ → SpectralHilbert)
    (nu initialEnergy : ℝ) (hnu : 0 < nu)
    (hgrad : MemLp g 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ initialEnergy)
    (hcol : ∀ᵐ t ∂η, ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 (g t)) = du t j)
    (hweak : ∀ᵐ t ∂η, ∀ j, Lp.toTemperedDistribution (du t j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t)))
    (hp : ∀ᵐ t ∂η, vp t = plusMultiplier (volume : Measure Frequency)
      (FrontierARealGradient.realGradientSpectrum (g t)))
    (hm : ∀ᵐ t ∂η, vm t = minusMultiplier (volume : Measure Frequency)
      (FrontierARealGradient.realGradientSpectrum (g t))) :
    (Integrable (FeffermanAHopfGramIntegral.gramSqrt vp vm) η ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral η vp vm ≤ initialEnergy / (4 * nu)) ∧
    (∀ᵐ t ∂η, ∀ᵐ ξ ∂(volume : Measure Frequency), ∀ i : Fin 3,
      (FrontierARealGradient.realGradientSpectrum (g t) : Frequency → FrontierAWeakTimeGram.Fiber) ξ i =
        ((2 * Real.pi : ℝ) : ℂ) *
        (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2) : ℂ) *
        (FourierTransform.fourier (u t) : Field) (WithLp.toLp 2 ξ) i) := by
  have hcore := FrontierARealWeakTimeGram.time_real_gram_and_weak_symbol
    η u g du nu initialEnergy hnu hgrad hEnergy hcol hweak
  have hGram :
      FeffermanAHopfGramIntegral.gramSqrt
        (fun t => plusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t)))
        (fun t => minusMultiplier (volume : Measure Frequency)
          (FrontierARealGradient.realGradientSpectrum (g t))) =ᵐ[η]
      FeffermanAHopfGramIntegral.gramSqrt vp vm := by
    filter_upwards [hp, hm] with t hpt hmt
    simp only [FeffermanAHopfGramIntegral.gramSqrt, hpt, hmt]
  constructor
  · constructor
    · exact hcore.1.1.congr hGram
    · unfold FeffermanAHopfGramIntegral.gramSqrtIntegral
      rw [← integral_congr_ae hGram]
      exact hcore.1.2
  · exact hcore.2

end FrontierSpine

#print axioms FrontierSpine.real_weak_gram_transport
