import HelicalFrequency
import HelicalOrthogonal

/-!
Candidate pointwise Hilbert-space action of the all-frequency symbols.
The zero matrix convention at zero frequency is inherited from
HelicalFrequency. These are individual finite-dimensional fibers, not an
operator on an L2 space or a construction of a Fourier transform.
-/

noncomputable section

namespace FeffermanHelicalFiberFrequency

open FeffermanHelicalNormalize FeffermanHelicalOrthogonal

def plusMap (x y z : ℝ) : Fiber →ₗ[ℂ] Fiber :=
  Matrix.toEuclideanLin (FeffermanHelicalFrequency.plus x y z)

def minusMap (x y z : ℝ) : Fiber →ₗ[ℂ] Fiber :=
  Matrix.toEuclideanLin (FeffermanHelicalFrequency.minus x y z)

theorem plus_map_zero : plusMap 0 0 0 = 0 := by
  simp [plusMap, FeffermanHelicalFrequency.plus_zero]

theorem minus_map_zero : minusMap 0 0 0 = 0 := by
  simp [minusMap, FeffermanHelicalFrequency.minus_zero]

theorem plus_contractive (x y z : ℝ) (v : Fiber) :
    ‖plusMap x y z v‖ ≤ ‖v‖ := by
  by_cases h : 0 < FeffermanHelicalFrequency.lengthSq x y z
  · simpa [plusMap, FeffermanHelicalFrequency.plus, h,
      FeffermanHelicalOrthogonal.plusMap] using
      FeffermanHelicalOrthogonal.plus_contractive
        (x / radius x y z) (y / radius x y z) (z / radius x y z)
        (normalized_unit x y z h) v
  · simp [plusMap, FeffermanHelicalFrequency.plus, h]

theorem minus_contractive (x y z : ℝ) (v : Fiber) :
    ‖minusMap x y z v‖ ≤ ‖v‖ := by
  by_cases h : 0 < FeffermanHelicalFrequency.lengthSq x y z
  · simpa [minusMap, FeffermanHelicalFrequency.minus, h,
      FeffermanHelicalOrthogonal.minusMap] using
      FeffermanHelicalOrthogonal.minus_contractive
        (x / radius x y z) (y / radius x y z) (z / radius x y z)
        (normalized_unit x y z h) v
  · simp [minusMap, FeffermanHelicalFrequency.minus, h]

theorem plus_idempotent (x y z : ℝ) (v : Fiber) :
    plusMap x y z (plusMap x y z v) = plusMap x y z v := by
  by_cases h : 0 < FeffermanHelicalFrequency.lengthSq x y z
  · simpa [plusMap, FeffermanHelicalFrequency.plus, h,
      FeffermanHelicalOrthogonal.plusMap] using
      FeffermanHelicalOrthogonal.plus_map_idempotent
        (x / radius x y z) (y / radius x y z) (z / radius x y z)
        (normalized_unit x y z h) v
  · simp [plusMap, FeffermanHelicalFrequency.plus, h]

theorem minus_idempotent (x y z : ℝ) (v : Fiber) :
    minusMap x y z (minusMap x y z v) = minusMap x y z v := by
  by_cases h : 0 < FeffermanHelicalFrequency.lengthSq x y z
  · simpa [minusMap, FeffermanHelicalFrequency.minus, h,
      FeffermanHelicalOrthogonal.minusMap] using
      FeffermanHelicalOrthogonal.minus_map_idempotent
        (x / radius x y z) (y / radius x y z) (z / radius x y z)
        (normalized_unit x y z h) v
  · simp [minusMap, FeffermanHelicalFrequency.minus, h]

theorem sectors_orthogonal (x y z : ℝ) (v w : Fiber) :
    inner ℂ (plusMap x y z v) (minusMap x y z w) = 0 := by
  by_cases h : 0 < FeffermanHelicalFrequency.lengthSq x y z
  · simpa [plusMap, minusMap, FeffermanHelicalFrequency.plus,
      FeffermanHelicalFrequency.minus, h, FeffermanHelicalOrthogonal.plusMap,
      FeffermanHelicalOrthogonal.minusMap] using
      FeffermanHelicalOrthogonal.helical_sectors_orthogonal
        (x / radius x y z) (y / radius x y z) (z / radius x y z)
        (normalized_unit x y z h) v w
  · simp [plusMap, minusMap, FeffermanHelicalFrequency.plus,
      FeffermanHelicalFrequency.minus, h]

/-- Under transversality the two sectors sum to the original amplitude. -/
theorem transverse_split (x y z : ℝ) (v : Fiber)
    (hv : Matrix.toEuclideanLin (FeffermanHelicalFrequency.projection x y z) v = v) :
    plusMap x y z v + minusMap x y z v = v := by
  have hm := congrArg
    (fun M : Matrix (Fin 3) (Fin 3) ℂ => Matrix.toEuclideanLin M)
    (FeffermanHelicalFrequency.partition x y z)
  have hf := congrArg (fun F : Fiber →ₗ[ℂ] Fiber => F v) hm
  simpa only [map_add, LinearMap.add_apply, plusMap, minusMap, hv] using hf

/-- The transverse amplitude's Euclidean energy is the sum of its two
    helical energies at each frequency. -/
theorem transverse_energy_split (x y z : ℝ) (v : Fiber)
    (hv : Matrix.toEuclideanLin (FeffermanHelicalFrequency.projection x y z) v = v) :
    ‖plusMap x y z v‖ ^ 2 + ‖minusMap x y z v‖ ^ 2 = ‖v‖ ^ 2 := by
  have hn := norm_add_sq (𝕜 := ℂ) (plusMap x y z v) (minusMap x y z v)
  rw [transverse_split x y z v hv, sectors_orthogonal x y z v v] at hn
  simp only [RCLike.zero_re, map_zero, mul_zero, add_zero] at hn
  linarith

end FeffermanHelicalFiberFrequency

#print axioms FeffermanHelicalFiberFrequency.plus_map_zero
#print axioms FeffermanHelicalFiberFrequency.minus_map_zero
#print axioms FeffermanHelicalFiberFrequency.plus_contractive
#print axioms FeffermanHelicalFiberFrequency.minus_contractive
#print axioms FeffermanHelicalFiberFrequency.plus_idempotent
#print axioms FeffermanHelicalFiberFrequency.minus_idempotent
#print axioms FeffermanHelicalFiberFrequency.sectors_orthogonal
#print axioms FeffermanHelicalFiberFrequency.transverse_split
#print axioms FeffermanHelicalFiberFrequency.transverse_energy_split
