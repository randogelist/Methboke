import FrontierPhysicalComposition
import FrontierFiniteIntervalEnergy
import FrontierRealVelocityEmbedding

/-! Candidate conditional physical-field implication.  The velocity is a real
L² trajectory; the two dissipation fields are independently supplied complex
L² trajectories.  Weak-gradient, energy, and the two explicit Fourier-symbol
identifications are hypotheses, not axioms or proved facts about every
Leray--Hopf solution.  In particular the symbol identifications require an
independent physical-to-Lean realization; merely supplying them does not prove
the frozen unconditional Frontier_A theorem. No local Lean run. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierLiteraturePhysicalImplication

abbrev RealVelocity := FrontierRealVelocityEmbedding.RealField
abbrev PhysicalField := FrontierPhysicalGramTransport.PhysicalL2
abbrev Gradient := FrontierARealGradient.RealMatrix
abbrev Frequency := FrontierPhysicalIdentification.Frequency
abbrev Fiber := FrontierPhysicalIdentification.Fiber

local instance physicalRealL2 : InnerProductSpace ℝ PhysicalField :=
  InnerProductSpace.rclikeToReal ℂ PhysicalField

/-- All finite-interval physical-field Gram bounds follow from the explicit
weak-gradient, energy and Fourier-identification premises. The latter must be
established for any independently specified physical fields before applying
the theorem to an actual Leray--Hopf solution. -/
theorem physical_gram_from_explicit_inputs
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2]
    [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → RealVelocity) (u0 : RealVelocity) (g : ℝ → Gradient)
    (dp dm : ℝ → PhysicalField) (nu : ℝ) (hnu : 0 < nu)
    (hinit : u 0 = u0)
    (hg : ∀ T : ℝ, 0 ≤ T → MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T))
    (henergy : ∀ T : ℝ, 0 ≤ T →
      ‖u T‖ ^ 2 + 2 * nu *
        (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ T : ℝ, 0 ≤ T →
      ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T), ∀ j,
        Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
        LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
          (Lp.toTemperedDistribution (FrontierRealVelocityEmbedding.complexifyL2 (u t))))
    (hp : ∀ T : ℝ, 0 ≤ T →
      ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
        (FrontierPhysicalGramTransport.fourierCoordinateReal (dp t) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => plusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ))
    (hm : ∀ T : ℝ, 0 ≤ T →
      ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T),
        (FrontierPhysicalGramTransport.fourierCoordinateReal (dm t) : Frequency → Fiber) =ᵐ[volume]
        fun ξ => minusOp ξ (FrontierMultiplierBridge.velocitySymbol
          (FrontierRealVelocityEmbedding.complexifyL2 (u t)) ξ)) :
    ∀ T : ℝ, 0 ≤ T →
      Integrable (FeffermanAHopfGramIntegral.gramSqrt dp dm)
          (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
      FeffermanAHopfGramIntegral.gramSqrtIntegral
          (FrontierFiniteIntervalEnergy.timeMeasure T) dp dm ≤ ‖u0‖ ^ 2 / (4 * nu) := by
  intro T hT
  have hgrad := hg T hT
  have hD : Integrable (fun t => ‖g t‖ ^ 2)
      (FrontierFiniteIntervalEnergy.timeMeasure T) :=
    (memLp_two_iff_integrable_sq_norm hgrad.aestronglyMeasurable).1 hgrad
  exact FrontierPhysicalComposition.physical_fields_gram_from_energy_and_symbols
    (FrontierFiniteIntervalEnergy.timeMeasure T)
    (fun t => FrontierRealVelocityEmbedding.complexifyL2 (u t)) g dp dm
    (fun t => ‖g t‖ ^ 2) u0 (u T) nu hnu hgrad.aestronglyMeasurable hD
    (Filter.Eventually.of_forall (fun _ => rfl)) (henergy T hT)
    (hweak T hT) (hp T hT) (hm T hT)

end FrontierLiteraturePhysicalImplication

#print axioms FrontierLiteraturePhysicalImplication.physical_gram_from_explicit_inputs
