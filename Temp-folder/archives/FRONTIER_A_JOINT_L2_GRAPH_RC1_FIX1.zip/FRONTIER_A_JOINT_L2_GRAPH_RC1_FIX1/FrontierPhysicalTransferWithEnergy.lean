import FrontierGradientBudgetGram

/-!
Transfer of the audited gradient-budget Gram estimate to externally supplied
fields, retaining the final kinetic-energy term. This is an abstract bridge:
the almost-everywhere field identities and energy class are hypotheses, not
proofs of the physical Leray--Hopf/Stokes realization. No local Lean run.
-/
noncomputable section
open MeasureTheory Filter

namespace FrontierPhysicalTransferWithEnergy

abbrev Gradient := FrontierARealGradient.RealMatrix
abbrev PhysicalL2 := FrontierPhysicalGramTransport.PhysicalL2

local instance physicalRealL2 : InnerProductSpace ℝ PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ PhysicalL2

/-- The two external fields are required to coincide almost everywhere with
the concrete project fields. The final energy is retained in the bound. -/
theorem gram_transfer_with_final_energy
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace Gradient] [BorelSpace Gradient]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2]
    [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (g : τ → Gradient) (plus minus : τ → PhysicalL2)
    (nu initialEnergy finalEnergy : ℝ) (hnu : 0 < nu)
    (hg : MemLp g 2 η)
    (henergy : finalEnergy + 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ initialEnergy)
    (hplus : plus =ᵐ[η] fun t => FrontierPhysicalGramTransport.plusField (g t))
    (hminus : minus =ᵐ[η] fun t => FrontierPhysicalGramTransport.minusField (g t)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt plus minus) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η plus minus ≤
      (initialEnergy - finalEnergy) / (4 * nu) := by
  have hb : 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ initialEnergy - finalEnergy := by
    linarith
  have hc := FrontierGradientBudgetGram.pullback_gram_of_gradient_budget
    η g nu (initialEnergy - finalEnergy) hnu hg hb
  have heq : FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierPhysicalGramTransport.plusField (g t))
      (fun t => FrontierPhysicalGramTransport.minusField (g t)) =ᵐ[η]
      FeffermanAHopfGramIntegral.gramSqrt plus minus := by
    filter_upwards [hplus, hminus] with t hp hm
    simp only [FeffermanAHopfGramIntegral.gramSqrt, hp, hm]
  constructor
  · exact hc.1.congr heq
  · unfold FeffermanAHopfGramIntegral.gramSqrtIntegral at hc ⊢
    rw [← integral_congr_ae heq]
    exact hc.2

end FrontierPhysicalTransferWithEnergy

#print axioms FrontierPhysicalTransferWithEnergy.gram_transfer_with_final_energy
