import FrontierSpectralOperatorInterface

/-! Candidate operator interface restricted to fields on which the audited
helical split holds. The split is an internal solenoidality criterion; its
identification with the literature's divergence-free space remains a separate
obligation. Unlike the earlier global interface, the projector laws are not
required on longitudinal fields and the dissipation laws are required only
on the two projected graph-domain lifts. The mathematical Fourier symbols
are discussed in Lerner--Vigneron, arXiv:2203.07950, Lemma 10, with the
appropriate 2π convention conversion. That citation does not by itself prove
that independently defined physical operators satisfy these Lean hypotheses.
No Leray--Hopf realization is asserted and no Lean compiler was run locally. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierSolenoidalSpectralInterface

abbrev Field := FrontierSpectralOperator.Field
abbrev Domain := FrontierSpectralOperator.Domain
abbrev Frequency := FrontierSpectralOperator.Frequency
abbrev Fiber := FrontierSpectralOperator.Fiber
abbrev Gradient := FrontierARealGradient.RealMatrix

/-- The already-defined projectors recover this field. A separate divergence
bridge is needed to establish that a physical velocity has this property. -/
def Solenoidal (u : Field) : Prop :=
  FrontierPhysicalProjectors.plusProjector u +
    FrontierPhysicalProjectors.minusProjector u = u

/-- Supplied spatial weak-gradient and distributional divergence identities
imply the internal split, using the previously audited divergence bridge. -/
theorem solenoidal_of_weak_divergence (u : Field) (g : Gradient)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (hdiv : Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 0
        (FrontierGradientAdapter.gradientColumn g 0)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 1
        (FrontierGradientAdapter.gradientColumn g 1)) +
      Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 2
        (FrontierGradientAdapter.gradientColumn g 2)) = 0) : Solenoidal u := by
  exact FrontierDivergenceTraceIdentity.split_of_distributional_divergence_zero
    u (FrontierARealGradient.complexifyL2 g)
    (fun j => FrontierGradientAdapter.gradientColumn g j) (fun _ => rfl) hweak hdiv

/-- Fourier laws only on split fields and their projected graph lifts. -/
structure Interface where
  positive : Field → Field
  negative : Field → Field
  dissipation : Domain → Field
  positive_fourier : ∀ u : Field, Solenoidal u →
    FrontierPhysicalGramTransport.fourierCoordinateReal (positive u) =
      plusMultiplier (volume : Measure Frequency)
        (FrontierPhysicalGramTransport.fourierCoordinateReal u)
  negative_fourier : ∀ u : Field, Solenoidal u →
    FrontierPhysicalGramTransport.fourierCoordinateReal (negative u) =
      minusMultiplier (volume : Measure Frequency)
        (FrontierPhysicalGramTransport.fourierCoordinateReal u)
  dissipation_plus_fourier : ∀ u : Domain, Solenoidal u.val →
    (FrontierPhysicalGramTransport.fourierCoordinateReal
      (dissipation (FrontierProjectedDissipation.plusDomain u)) : Frequency → Fiber) =ᵐ[volume]
      FrontierMultiplierBridge.velocitySymbol (FrontierProjectedDissipation.plusDomain u).val
  dissipation_minus_fourier : ∀ u : Domain, Solenoidal u.val →
    (FrontierPhysicalGramTransport.fourierCoordinateReal
      (dissipation (FrontierProjectedDissipation.minusDomain u)) : Frequency → Fiber) =ᵐ[volume]
      FrontierMultiplierBridge.velocitySymbol (FrontierProjectedDissipation.minusDomain u).val

theorem positive_eq_projector (S : Interface) (u : Field) (hu : Solenoidal u) :
    S.positive u = FrontierPhysicalProjectors.plusProjector u := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  rw [S.positive_fourier u hu, FrontierPhysicalProjectors.plus_fourier]

theorem negative_eq_projector (S : Interface) (u : Field) (hu : Solenoidal u) :
    S.negative u = FrontierPhysicalProjectors.minusProjector u := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  rw [S.negative_fourier u hu, FrontierPhysicalProjectors.minus_fourier]

def positiveDomain (S : Interface) (u : Domain) (hu : Solenoidal u.val) : Domain :=
  ⟨S.positive u.val, by
    rw [positive_eq_projector S u.val hu]
    exact FrontierProjectedDissipation.plus_has_dissipation u⟩

def negativeDomain (S : Interface) (u : Domain) (hu : Solenoidal u.val) : Domain :=
  ⟨S.negative u.val, by
    rw [negative_eq_projector S u.val hu]
    exact FrontierProjectedDissipation.minus_has_dissipation u⟩

theorem positive_dissipation_eq_canonical (S : Interface) (u : Domain)
    (hu : Solenoidal u.val) (g : Gradient)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u.val)) :
    S.dissipation (positiveDomain S u hu) = FrontierPhysicalGramTransport.plusField g := by
  have hd : positiveDomain S u hu = FrontierProjectedDissipation.plusDomain u := by
    apply Subtype.ext
    exact positive_eq_projector S u.val hu
  calc
    S.dissipation (positiveDomain S u hu) =
        S.dissipation (FrontierProjectedDissipation.plusDomain u) := congrArg S.dissipation hd
    _ = FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.plusDomain u) :=
      (FrontierSpectralOperator.dissipation_eq_of_symbol _ _ (S.dissipation_plus_fourier u hu)).symm
    _ = FrontierACoordinateEquiv.plusPullback (FrontierDissipationDomain.gradientDissipation g) :=
      FrontierProjectedGraphEnergy.projected_plus_of_weak_gradient u g hweak
    _ = FrontierPhysicalGramTransport.plusField g :=
      FrontierDissipationDomain.plus_projected_gradientDissipation g

theorem negative_dissipation_eq_canonical (S : Interface) (u : Domain)
    (hu : Solenoidal u.val) (g : Gradient)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u.val)) :
    S.dissipation (negativeDomain S u hu) = FrontierPhysicalGramTransport.minusField g := by
  have hd : negativeDomain S u hu = FrontierProjectedDissipation.minusDomain u := by
    apply Subtype.ext
    exact negative_eq_projector S u.val hu
  calc
    S.dissipation (negativeDomain S u hu) =
        S.dissipation (FrontierProjectedDissipation.minusDomain u) := congrArg S.dissipation hd
    _ = FrontierSpectralOperator.dissipation (FrontierProjectedDissipation.minusDomain u) :=
      (FrontierSpectralOperator.dissipation_eq_of_symbol _ _ (S.dissipation_minus_fourier u hu)).symm
    _ = FrontierACoordinateEquiv.minusPullback (FrontierDissipationDomain.gradientDissipation g) :=
      FrontierProjectedGraphEnergy.projected_minus_of_weak_gradient u g hweak
    _ = FrontierPhysicalGramTransport.minusField g :=
      FrontierDissipationDomain.minus_projected_gradientDissipation g

end FrontierSolenoidalSpectralInterface

#print axioms FrontierSolenoidalSpectralInterface.solenoidal_of_weak_divergence
#print axioms FrontierSolenoidalSpectralInterface.positive_eq_projector
#print axioms FrontierSolenoidalSpectralInterface.negative_eq_projector
#print axioms FrontierSolenoidalSpectralInterface.positive_dissipation_eq_canonical
#print axioms FrontierSolenoidalSpectralInterface.negative_dissipation_eq_canonical
