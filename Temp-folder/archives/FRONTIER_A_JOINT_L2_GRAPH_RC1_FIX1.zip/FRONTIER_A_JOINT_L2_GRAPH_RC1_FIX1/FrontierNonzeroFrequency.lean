import FrontierDivergence

/-! Candidate: the exceptional zero frequency has Lebesgue measure zero.
This discharges the nonzero-frequency premise of the conditional helical split;
the Fourier dot-product hypothesis and physical realization remain explicit.
No local Lean compilation was performed. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierNonzeroFrequency

abbrev Frequency := FrontierDivergence.Frequency
abbrev PhysicalL2 := FrontierDivergence.PhysicalL2
abbrev Fiber := FrontierDivergence.Fiber

/-- Away from the origin, the squared frequency length is strictly positive. -/
theorem lengthSq_pos_of_ne_zero (ξ : Frequency) (hξ : ξ ≠ 0) :
    0 < FeffermanHelicalFrequency.lengthSq (ξ 0) (ξ 1) (ξ 2) := by
  by_contra h
  have hx : ξ 0 = 0 := by
    dsimp [FeffermanHelicalFrequency.lengthSq] at h
    nlinarith [sq_nonneg (ξ 0), sq_nonneg (ξ 1), sq_nonneg (ξ 2)]
  have hy : ξ 1 = 0 := by
    dsimp [FeffermanHelicalFrequency.lengthSq] at h
    nlinarith [sq_nonneg (ξ 0), sq_nonneg (ξ 1), sq_nonneg (ξ 2)]
  have hz : ξ 2 = 0 := by
    dsimp [FeffermanHelicalFrequency.lengthSq] at h
    nlinarith [sq_nonneg (ξ 0), sq_nonneg (ξ 1), sq_nonneg (ξ 2)]
  apply hξ
  funext i
  fin_cases i <;> simp_all

/-- Lebesgue-almost every frequency has positive squared length. -/
theorem lengthSq_pos_ae :
    ∀ᵐ ξ ∂(volume : Measure Frequency),
      0 < FeffermanHelicalFrequency.lengthSq (ξ 0) (ξ 1) (ξ 2) := by
  filter_upwards [(volume : Measure Frequency).ae_ne 0] with ξ hξ
  exact lengthSq_pos_of_ne_zero ξ hξ

/-- The conditional helical split needs no separate zero-frequency premise. -/
theorem split_of_fourier_dot (f : PhysicalL2)
    (hdot : ∀ᵐ ξ ∂(volume : Measure Frequency),
      let v := (FrontierPhysicalGramTransport.fourierCoordinateReal f : Frequency → Fiber) ξ
      (ξ 0 : ℂ) * v 0 + (ξ 1 : ℂ) * v 1 + (ξ 2 : ℂ) * v 2 = 0) :
    FrontierPhysicalProjectors.plusProjector f +
      FrontierPhysicalProjectors.minusProjector f = f := by
  exact FrontierDivergence.split_of_fourier_dot f lengthSq_pos_ae hdot

end FrontierNonzeroFrequency

#print axioms FrontierNonzeroFrequency.lengthSq_pos_of_ne_zero
#print axioms FrontierNonzeroFrequency.lengthSq_pos_ae
#print axioms FrontierNonzeroFrequency.split_of_fourier_dot
