import FrontierAMatrixFourier

/-!
A-TIER CANDIDATE. Componentwise real-to-complex embedding for supplied
Euclidean 3x3 matrix L² trajectories. The input is arbitrary real matrix
L² data with time-L² and energy-budget hypotheses; it is NOT asserted to be
an actual weak gradient. No Leray-Hopf solution, Fourier weak-derivative
identity, or physical helical Gram identification is constructed. External
native Lean compilation, signature inspection, and axiom audit are required.
-/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal
namespace FrontierARealGradient

abbrev Space := HelicalCoordinateBridge.Space
abbrev RealFiber := EuclideanSpace ℝ (Fin 3 × Fin 3)
abbrev ComplexFiber := FrontierARieszVectorSymbol.GradFiber
abbrev RealMatrix := Lp RealFiber 2 (volume : Measure Space)

/-- Embed each real matrix entry into the corresponding complex entry. -/
def fiberToComplex : RealFiber →ₗ[ℝ] ComplexFiber where
  toFun g := WithLp.toLp 2 (fun i => (g i : ℂ))
  map_add' g h := by ext i; simp
  map_smul' c g := by ext i; simp

theorem fiberToComplex_norm (g : RealFiber) : ‖fiberToComplex g‖ = ‖g‖ := by
  have hs : ‖fiberToComplex g‖ ^ 2 = ‖g‖ ^ 2 := by
    simp [EuclideanSpace.norm_sq_eq, fiberToComplex]
  nlinarith [norm_nonneg (fiberToComplex g), norm_nonneg g]

def fiberCLM : RealFiber →L[ℝ] ComplexFiber :=
  fiberToComplex.toContinuousLinearMap

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩

/-- Spatial L² embedding built by pointwise application to equivalence classes. -/
def complexifyL2 : RealMatrix →L[ℝ] FrontierAMatrixFourier.PhysicalMatrix :=
  ContinuousLinearMap.compLpL 2 (volume : Measure Space) fiberCLM

theorem complexifyL2_ae (g : RealMatrix) :
    (complexifyL2 g : Space → ComplexFiber) =ᵐ[volume]
      fun x => fiberCLM ((g : Space → RealFiber) x) := by
  exact ContinuousLinearMap.coeFn_compLpL fiberCLM g

theorem complexifyL2_norm (g : RealMatrix) : ‖complexifyL2 g‖ = ‖g‖ := by
  apply le_antisymm
  · apply MeasureTheory.Lp.norm_le_norm_of_ae_le
    filter_upwards [complexifyL2_ae g] with x hx
    rw [hx]
    change ‖fiberToComplex ((g : Space → RealFiber) x)‖ ≤ ‖(g : Space → RealFiber) x‖
    exact le_of_eq (fiberToComplex_norm _)
  · apply MeasureTheory.Lp.norm_le_norm_of_ae_le
    filter_upwards [complexifyL2_ae g] with x hx
    rw [hx]
    change ‖(g : Space → RealFiber) x‖ ≤ ‖fiberToComplex ((g : Space → RealFiber) x)‖
    exact le_of_eq (fiberToComplex_norm _).symm

/-- Time-L² and energy budget transfer for arbitrary supplied real matrices. -/
theorem real_gradient_inputs
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace RealMatrix] [BorelSpace RealMatrix]
    [MeasurableSpace FrontierAMatrixFourier.PhysicalMatrix]
    [BorelSpace FrontierAMatrixFourier.PhysicalMatrix]
    (η : Measure τ) (grad : τ → RealMatrix) (nu initialEnergy : ℝ)
    (hgrad : MemLp grad 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖grad t‖ ^ 2 ∂η) ≤ initialEnergy) :
    MemLp (fun t => complexifyL2 (grad t)) 2 η ∧
      2 * nu * (∫ t, ‖complexifyL2 (grad t)‖ ^ 2 ∂η) ≤ initialEnergy := by
  constructor
  · simpa only [Function.comp_def] using complexifyL2.comp_memLp' hgrad
  · simpa only [complexifyL2_norm] using hEnergy


/-- Frequency-side dissipation constructed from a real matrix L² field. -/
def realGradientSpectrum (g : RealMatrix) : FrontierAConcreteFourier.CoordinateL2 :=
  FrontierAConcreteFourier.coordinateFourier
    (FrontierARieszVectorL2.inverseFourierVectorCLM
      (FrontierAMatrixFourier.matrixFourier (complexifyL2 g)))

local instance realL2 (μ : Measure HelicalConcreteSymbol.Frequency) :
    InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

/-- The existing frequency Gram bound from supplied real matrix data. -/
theorem gram_from_real_matrix
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace RealMatrix] [BorelSpace RealMatrix]
    [MeasurableSpace FrontierAMatrixFourier.PhysicalMatrix]
    [BorelSpace FrontierAMatrixFourier.PhysicalMatrix]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAConcreteFourier.CoordinateL2]
    [BorelSpace FrontierAConcreteFourier.CoordinateL2]
    (η : Measure τ) (grad : τ → RealMatrix) (nu initialEnergy : ℝ)
    (hnu : 0 < nu) (hgrad : MemLp grad 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖grad t‖ ^ 2 ∂η) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (realGradientSpectrum (grad t)))
      (fun t => minusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (realGradientSpectrum (grad t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (realGradientSpectrum (grad t)))
      (fun t => minusMultiplier (volume : Measure HelicalConcreteSymbol.Frequency)
        (realGradientSpectrum (grad t))) ≤ initialEnergy / (4 * nu) := by
  obtain ⟨hlp, hbudget⟩ := real_gradient_inputs η grad nu initialEnergy hgrad hEnergy
  simpa only [realGradientSpectrum] using
    FrontierAMatrixFourier.gram_from_physical_matrix η
      (fun t => complexifyL2 (grad t)) nu initialEnergy hnu hlp hbudget

end FrontierARealGradient

#print axioms FrontierARealGradient.fiberToComplex_norm
#print axioms FrontierARealGradient.complexifyL2_ae
#print axioms FrontierARealGradient.complexifyL2_norm
#print axioms FrontierARealGradient.real_gradient_inputs

#print axioms FrontierARealGradient.gram_from_real_matrix
