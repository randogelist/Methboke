import FrontierTimeTraceBridge
import FrontierDistributionTrace

/-! Conditional bridge for a supplied real matrix L² field. Vanishing of the
project's column-based distributional divergence is equivalent to a.e. vanishing
of its real trace. This does not define divergence directly from a velocity or
construct weak derivatives of a Leray–Hopf solution. No local Lean run. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierRealDistributionTrace

abbrev Space := FrontierARealGradient.Space
abbrev RealFiber := FrontierARealGradient.RealFiber
abbrev Gradient := FrontierARealGradient.RealMatrix
abbrev Fiber := FrontierPhysicalDivergence.Fiber
abbrev Field := FrontierPhysicalDivergence.Field

def ColumnDivergenceZero (g : Gradient) : Prop :=
  Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 0
    (FrontierGradientAdapter.gradientColumn g 0)) +
  Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 1
    (FrontierGradientAdapter.gradientColumn g 1)) +
  Lp.toTemperedDistribution (FrontierDivergenceTraceIdentity.diagonalL2 2
    (FrontierGradientAdapter.gradientColumn g 2)) = 0

def RealTraceZero (g : Gradient) : Prop :=
  ∀ᵐ x ∂(volume : Measure Space),
    (g : Space → RealFiber) x (0, 0) + (g : Space → RealFiber) x (1, 1) +
      (g : Space → RealFiber) x (2, 2) = 0

theorem trace_zero_of_column_divergence_zero (g : Gradient)
    (hdiv : ColumnDivergenceZero g) : RealTraceZero g := by
  have hdist : Lp.toTemperedDistribution
      (FrontierPhysicalDivergence.traceL2 (FrontierARealGradient.complexifyL2 g)) = 0 := by
    rw [FrontierDivergenceTraceIdentity.distributional_divergence_eq_trace
      (FrontierARealGradient.complexifyL2 g)
      (fun j => FrontierGradientAdapter.gradientColumn g j) (fun _ => rfl)]
    exact hdiv
  have hzero : FrontierPhysicalDivergence.traceL2
      (FrontierARealGradient.complexifyL2 g) = 0 :=
    FrontierDistributionTrace.traceL2_eq_zero_of_distribution_eq_zero _ hdist
  have hcomp := ContinuousLinearMap.coeFn_compLpL FrontierPhysicalDivergence.traceCLM
    (FrontierARealGradient.complexifyL2 g)
  have hc := FrontierARealGradient.complexifyL2_ae g
  have hz := Lp.coeFn_zero Fiber 2 (volume : Measure Space)
  change ((FrontierPhysicalDivergence.traceL2 (FrontierARealGradient.complexifyL2 g) : Field) :
    Space → Fiber) =ᵐ[volume] _ at hcomp
  rw [hzero] at hcomp
  filter_upwards [hcomp, hc, hz] with x hcomp hc hz
  have hvalue := congrArg (fun v : Fiber => v 0) (hcomp.symm.trans hz)
  rw [hc, FrontierPhysicalDivergence.traceCLM_apply] at hvalue
  change (((g : Space → RealFiber) x (0, 0) : ℝ) : ℂ) +
    (((g : Space → RealFiber) x (1, 1) : ℝ) : ℂ) +
    (((g : Space → RealFiber) x (2, 2) : ℝ) : ℂ) = 0 at hvalue
  have hr := congrArg Complex.re hvalue
  simpa using hr

theorem column_divergence_zero_iff_trace_zero (g : Gradient) :
    ColumnDivergenceZero g ↔ RealTraceZero g := by
  constructor
  · exact trace_zero_of_column_divergence_zero g
  · intro htrace
    exact FrontierTimeTraceBridge.divergence_zero_of_real_trace g htrace

theorem trace_zero_ae_of_column_divergence_zero_ae {τ : Type*} [MeasurableSpace τ]
    (η : Measure τ) (g : τ → Gradient)
    (hdiv : ∀ᵐ t ∂η, ColumnDivergenceZero (g t)) :
    ∀ᵐ t ∂η, RealTraceZero (g t) := by
  filter_upwards [hdiv] with t ht
  exact trace_zero_of_column_divergence_zero (g t) ht

end FrontierRealDistributionTrace
#print axioms FrontierRealDistributionTrace.trace_zero_of_column_divergence_zero
#print axioms FrontierRealDistributionTrace.column_divergence_zero_iff_trace_zero
#print axioms FrontierRealDistributionTrace.trace_zero_ae_of_column_divergence_zero_ae
