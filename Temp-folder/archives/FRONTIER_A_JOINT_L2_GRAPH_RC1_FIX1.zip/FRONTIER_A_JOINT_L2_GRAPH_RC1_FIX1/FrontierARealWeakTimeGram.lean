import FrontierAWeakTimeGram
import FrontierARealGradient

/-! Untested conditional candidate. The real matrix trajectory and its energy
budget are supplied. This theorem does not construct a Leray–Hopf solution
or prove physical helical operator or energy identities. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierARealWeakTimeGram
abbrev Space := FrontierAWeakTimeGram.Space
abbrev Frequency := FrontierAWeakTimeGram.Frequency
abbrev MatrixL2 := FrontierAWeakTimeGram.MatrixL2
abbrev Field := FrontierAWeakTimeGram.Field
abbrev Fiber := FrontierAWeakTimeGram.Fiber
abbrev CoordinateL2 := FrontierAWeakTimeGram.CoordinateL2

local instance realL2 (μ : Measure Frequency) :
    InnerProductSpace ℝ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ) :=
  InnerProductSpace.rclikeToReal ℂ (Lp FeffermanHelicalOrthogonal.Fiber 2 μ)

/-- The same conditional result starting from a supplied real matrix trajectory. -/
theorem time_real_gram_and_weak_symbol
    {τ : Type*} [MeasurableSpace τ]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace MatrixL2] [BorelSpace MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace CoordinateL2] [BorelSpace CoordinateL2]
    (η : Measure τ) (u : τ → Field) (g : τ → FrontierARealGradient.RealMatrix)
    (du : τ → Fin 3 → Field) (nu initialEnergy : ℝ) (hnu : 0 < nu)
    (hgrad : MemLp g 2 η)
    (hEnergy : 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ initialEnergy)
    (hcol : ∀ᵐ t ∂η, ∀ j, FrontierAWeakMatrixColumns.columnL2 j
      (FrontierARealGradient.complexifyL2 (g t)) = du t j)
    (hweak : ∀ᵐ t ∂η, ∀ j, Lp.toTemperedDistribution (du t j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t))) :
    (Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => plusMultiplier (volume : Measure Frequency)
        (FrontierARealGradient.realGradientSpectrum (g t)))
      (fun t => minusMultiplier (volume : Measure Frequency)
        (FrontierARealGradient.realGradientSpectrum (g t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => plusMultiplier (volume : Measure Frequency)
        (FrontierARealGradient.realGradientSpectrum (g t)))
      (fun t => minusMultiplier (volume : Measure Frequency)
        (FrontierARealGradient.realGradientSpectrum (g t)))
      ≤ initialEnergy / (4 * nu)) ∧
    (∀ᵐ t ∂η, ∀ᵐ ξ ∂(volume : Measure Frequency), ∀ i : Fin 3,
      (FrontierARealGradient.realGradientSpectrum (g t) : Frequency → Fiber) ξ i =
        ((2 * Real.pi : ℝ) : ℂ) *
        (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2) : ℂ) *
        (FourierTransform.fourier (u t) : Field) (WithLp.toLp 2 ξ) i) := by
  obtain ⟨hlp, hbudget⟩ := FrontierARealGradient.real_gradient_inputs η g nu initialEnergy hgrad hEnergy
  simpa only [FrontierAWeakTimeGram.gramInput, FrontierARealGradient.realGradientSpectrum] using
    FrontierAWeakTimeGram.time_gram_and_weak_symbol η u (fun t => FrontierARealGradient.complexifyL2 (g t))
      du nu initialEnergy hnu hlp hbudget hcol hweak


end FrontierARealWeakTimeGram

#print axioms FrontierARealWeakTimeGram.time_real_gram_and_weak_symbol
