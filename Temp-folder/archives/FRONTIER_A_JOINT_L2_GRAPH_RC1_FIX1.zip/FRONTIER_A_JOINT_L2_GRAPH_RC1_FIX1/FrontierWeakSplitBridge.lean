import FrontierNonzeroFrequency
import FrontierDomainLinear

/-! Candidate composition: transport the Fourier-dot result from Euclidean
frequency space to the coordinate-frequency helical split. The Fourier trace
of the supplied weak derivatives is still a hypothesis; this does not prove
distributional divergence-free character or a Leray--Hopf realization. -/
noncomputable section
open MeasureTheory Filter FourierTransform
namespace FrontierWeakSplitBridge

abbrev Space := FrontierDivergence.Space
abbrev Field := FrontierDivergence.Field
abbrev Frequency := FrontierDivergence.Frequency
abbrev Fiber := FrontierDivergence.Fiber

theorem split_of_weak_derivatives_and_fourier_trace
    (u : Field) (du : Fin 3 → Field)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (htrace : ∀ᵐ ξ ∂(volume : Measure Space),
      FrontierAWeakRieszBridge.weakFourierMatrix du ξ 0 0 +
      FrontierAWeakRieszBridge.weakFourierMatrix du ξ 1 1 +
      FrontierAWeakRieszBridge.weakFourierMatrix du ξ 2 2 = 0) :
    FrontierPhysicalProjectors.plusProjector u +
      FrontierPhysicalProjectors.minusProjector u = u := by
  have he := FrontierDivergence.weak_derivatives_fourier_trace_zero u du hweak htrace
  have hc := HelicalCoordinateBridge.toLp_preserves_volume.quasiMeasurePreserving.ae he
  have hf := FrontierDomainLinear.fourierCoordinate_ae u
  apply FrontierNonzeroFrequency.split_of_fourier_dot u
  filter_upwards [hc, hf] with ξ hc hf
  change (ξ 0 : ℂ) * (FrontierACoordinateEquiv.fourierCoordinate u : Frequency → Fiber) ξ 0 +
      (ξ 1 : ℂ) * (FrontierACoordinateEquiv.fourierCoordinate u : Frequency → Fiber) ξ 1 +
      (ξ 2 : ℂ) * (FrontierACoordinateEquiv.fourierCoordinate u : Frequency → Fiber) ξ 2 = 0
  rw [hf]
  exact hc

end FrontierWeakSplitBridge

#print axioms FrontierWeakSplitBridge.split_of_weak_derivatives_and_fourier_trace
