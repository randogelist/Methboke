import FrontierSpectralClosure

/-! Candidate adapter: use the square-integrable weak gradient directly as the
dissipation density. The weak-gradient relation and energy inequality remain
assumptions; no Leray--Hopf solution is constructed here. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierTrajectoryEnergy

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

/-- An L²-in-time weak gradient and its energy inequality supply the density
required by the existing conditional spectral Gram estimate. -/
theorem spectral_gram_from_gradient_energy
    {τ V : Type*} [MeasurableSpace τ] [NormedAddCommGroup V]
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (η : Measure τ) (u : τ → FrontierSpectralOperator.Domain)
    (g : τ → FrontierARealGradient.RealMatrix)
    (u0 uT : V) (nu : ℝ) (hnu : 0 < nu)
    (hg : MemLp g 2 η)
    (henergy : ‖uT‖ ^ 2 + 2 * nu * (∫ t, ‖g t‖ ^ 2 ∂η) ≤ ‖u0‖ ^ 2)
    (hweak : ∀ᵐ t ∂η, ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (u t).val)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierACoordinateEquiv.plusPullback (FrontierSpectralOperator.dissipation (u t)))
      (fun t => FrontierACoordinateEquiv.minusPullback (FrontierSpectralOperator.dissipation (u t)))) η ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral η
      (fun t => FrontierACoordinateEquiv.plusPullback (FrontierSpectralOperator.dissipation (u t)))
      (fun t => FrontierACoordinateEquiv.minusPullback (FrontierSpectralOperator.dissipation (u t))) ≤
        ‖u0‖ ^ 2 / (4 * nu) := by
  have hD : Integrable (fun t => ‖g t‖ ^ 2) η :=
    (memLp_two_iff_integrable_sq_norm hg.aestronglyMeasurable).1 hg
  exact FrontierSpectralOperator.spectral_projected_gram_from_energy
    η u g (fun t => ‖g t‖ ^ 2) u0 uT nu hnu hg.aestronglyMeasurable hD
    (Filter.Eventually.of_forall fun _ => rfl) henergy hweak

end FrontierTrajectoryEnergy

#print axioms FrontierTrajectoryEnergy.spectral_gram_from_gradient_energy
