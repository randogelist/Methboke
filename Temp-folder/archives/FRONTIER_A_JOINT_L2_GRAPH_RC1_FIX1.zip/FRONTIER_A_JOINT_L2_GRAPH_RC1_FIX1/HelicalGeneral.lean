import Mathlib

/-!
Candidate finite-dimensional helical symbols for an arbitrary real unit direction.
No Fourier transform or multiplier on functions is constructed here.
The supplied unit-direction equation is an explicit premise. Native compilation
and theorem-level axiom auditing are required before treating these as A-tier.
-/

noncomputable section
set_option maxHeartbeats 2000000

namespace FeffermanHelicalGeneral

/-- Leray symbol I - n n^T, for a real direction n = (x,y,z). -/
def transverse (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  !![1 - (x : ℂ) * x, -(x : ℂ) * y, -(x : ℂ) * z;
     -(y : ℂ) * x, 1 - (y : ℂ) * y, -(y : ℂ) * z;
     -(z : ℂ) * x, -(z : ℂ) * y, 1 - (z : ℂ) * z]

/-- The normalized curl symbol i(n cross .). -/
def curlSymbol (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  !![0, -Complex.I * z, Complex.I * y;
     Complex.I * z, 0, -Complex.I * x;
     -Complex.I * y, Complex.I * x, 0]

def positive (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  fun i j => (transverse x y z i j + curlSymbol x y z i j) / 2

def negative (x y z : ℝ) : Matrix (Fin 3) (Fin 3) ℂ :=
  fun i j => (transverse x y z i j - curlSymbol x y z i j) / 2

/-- Polynomial consequences of the unit-vector relation, used only in the
    finite coordinate calculation. -/
private theorem unit_multiples (x y z : ℝ) (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) :
    x * (x ^ 2 + y ^ 2 + z ^ 2 - 1) = 0 ∧
    y * (x ^ 2 + y ^ 2 + z ^ 2 - 1) = 0 ∧
    z * (x ^ 2 + y ^ 2 + z ^ 2 - 1) = 0 ∧
    x ^ 2 * (x ^ 2 + y ^ 2 + z ^ 2 - 1) = 0 ∧
    (x * y) * (x ^ 2 + y ^ 2 + z ^ 2 - 1) = 0 ∧
    (x * z) * (x ^ 2 + y ^ 2 + z ^ 2 - 1) = 0 ∧
    y ^ 2 * (x ^ 2 + y ^ 2 + z ^ 2 - 1) = 0 ∧
    (y * z) * (x ^ 2 + y ^ 2 + z ^ 2 - 1) = 0 ∧
    z ^ 2 * (x ^ 2 + y ^ 2 + z ^ 2 - 1) = 0 := by
  have hh : x ^ 2 + y ^ 2 + z ^ 2 - 1 = 0 := by linarith
  simp [hh]

theorem helicity_partition (x y z : ℝ) (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) :
    positive x y z + negative x y z = transverse x y z := by
  rcases unit_multiples x y z h with ⟨hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz⟩
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [positive, negative, transverse, curlSymbol, Matrix.mul_apply,
      Fin.sum_univ_succ, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;>
    nlinarith only [h, hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz]

theorem positive_idempotent (x y z : ℝ) (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) :
    positive x y z * positive x y z = positive x y z := by
  rcases unit_multiples x y z h with ⟨hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz⟩
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [positive, negative, transverse, curlSymbol, Matrix.mul_apply,
      Fin.sum_univ_succ, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;>
    nlinarith only [h, hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz]

theorem negative_idempotent (x y z : ℝ) (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) :
    negative x y z * negative x y z = negative x y z := by
  rcases unit_multiples x y z h with ⟨hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz⟩
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [positive, negative, transverse, curlSymbol, Matrix.mul_apply,
      Fin.sum_univ_succ, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;>
    nlinarith only [h, hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz]

theorem helicity_cross_zero (x y z : ℝ) (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) :
    positive x y z * negative x y z = 0 := by
  rcases unit_multiples x y z h with ⟨hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz⟩
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [positive, negative, transverse, curlSymbol, Matrix.mul_apply,
      Fin.sum_univ_succ, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;>
    nlinarith only [h, hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz]

theorem positive_curl_eigen (x y z : ℝ) (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) :
    curlSymbol x y z * positive x y z = positive x y z := by
  rcases unit_multiples x y z h with ⟨hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz⟩
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [positive, negative, transverse, curlSymbol, Matrix.mul_apply,
      Fin.sum_univ_succ, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;>
    nlinarith only [h, hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz]

theorem negative_curl_eigen (x y z : ℝ) (h : x ^ 2 + y ^ 2 + z ^ 2 = 1) :
    curlSymbol x y z * negative x y z = -negative x y z := by
  rcases unit_multiples x y z h with ⟨hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz⟩
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [positive, negative, transverse, curlSymbol, Matrix.mul_apply,
      Fin.sum_univ_succ, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;>
    nlinarith only [h, hx, hy, hz, hxx, hxy, hxz, hyy, hyz, hzz]

/- These two pointwise identities express Hermiticity without requiring any
   spectral or Fourier theory. -/
theorem positive_hermitian (x y z : ℝ) (i j : Fin 3) :
    star (positive x y z j i) = positive x y z i j := by
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [positive, transverse, curlSymbol, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;> ring

theorem negative_hermitian (x y z : ℝ) (i j : Fin 3) :
    star (negative x y z j i) = negative x y z i j := by
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [negative, transverse, curlSymbol, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;> ring

/-- Reversing the direction conjugates the positive-helicity symbol. -/
theorem positive_conjugate_reversal (x y z : ℝ) (i j : Fin 3) :
    star (positive x y z i j) = positive (-x) (-y) (-z) i j := by
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [positive, transverse, curlSymbol, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;> ring

theorem negative_conjugate_reversal (x y z : ℝ) (i j : Fin 3) :
    star (negative x y z i j) = negative (-x) (-y) (-z) i j := by
  fin_cases i <;> fin_cases j <;>
    apply Complex.ext <;>
    norm_num [negative, transverse, curlSymbol, Complex.mul_re, Complex.mul_im,
      Complex.div_re, Complex.div_im, Complex.normSq] <;> ring

end FeffermanHelicalGeneral

#print axioms FeffermanHelicalGeneral.helicity_partition
#print axioms FeffermanHelicalGeneral.positive_idempotent
#print axioms FeffermanHelicalGeneral.negative_idempotent
#print axioms FeffermanHelicalGeneral.helicity_cross_zero
#print axioms FeffermanHelicalGeneral.positive_curl_eigen
#print axioms FeffermanHelicalGeneral.negative_curl_eigen
#print axioms FeffermanHelicalGeneral.positive_hermitian
#print axioms FeffermanHelicalGeneral.negative_hermitian
#print axioms FeffermanHelicalGeneral.positive_conjugate_reversal
#print axioms FeffermanHelicalGeneral.negative_conjugate_reversal
