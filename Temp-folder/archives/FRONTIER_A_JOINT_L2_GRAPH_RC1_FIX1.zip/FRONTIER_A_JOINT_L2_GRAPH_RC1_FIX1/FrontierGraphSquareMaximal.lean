import FrontierGraphSquared

/-!
An exact Fourier characterization of the *square* of the existing graph
operator, relative to its first-order domain. In particular, the converse is
proved from an independently supplied L² representative of the squared
multiplier rather than assumed from the definition of the composite domain.
This does not prove that every squared-symbol representative automatically
places its input in the first-order domain; nor does it construct the
variational Stokes operator, prove self-adjointness, or identify a solution.
No local Lean compiler has been run.
-/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierGraphSquareMaximal

abbrev Field := FrontierSpectralOperator.Field
abbrev Frequency := FrontierSpectralOperator.Frequency
abbrev Fiber := FrontierSpectralOperator.Fiber
abbrev Domain := FrontierSpectralOperator.Domain

/-- The squared multiplier, specified directly in the Fourier representation,
has an L² physical representative. No composite-domain hypothesis appears. -/
def HasLaplacianSymbol (u : Field) : Prop :=
  ∃ w : Field,
    (FrontierPhysicalGramTransport.fourierCoordinateReal w : Frequency → Fiber) =ᵐ[volume]
      FrontierGraphSquared.laplacianSymbol u

/-- Uniqueness of an L² physical representative of the squared symbol. -/
theorem laplacian_representative_unique (u w₁ w₂ : Field)
    (h₁ : (FrontierPhysicalGramTransport.fourierCoordinateReal w₁ : Frequency → Fiber) =ᵐ[volume]
      FrontierGraphSquared.laplacianSymbol u)
    (h₂ : (FrontierPhysicalGramTransport.fourierCoordinateReal w₂ : Frequency → Fiber) =ᵐ[volume]
      FrontierGraphSquared.laplacianSymbol u) : w₁ = w₂ := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  apply Lp.ext
  exact h₁.trans h₂.symm

/-- On the first-order graph domain, the symbol of its output after formal
application of the same weight is exactly the squared symbol. This pointwise
statement does not itself claim the resulting function is in L². -/
theorem velocitySymbol_dissipation (u : Domain) :
    FrontierMultiplierBridge.velocitySymbol (FrontierSpectralOperator.dissipation u) =ᵐ[volume]
      FrontierGraphSquared.laplacianSymbol u.val := by
  have hd := FrontierSpectralOperator.dissipation_fourier u
  have hc := FrontierDomainLinear.fourierCoordinate_ae (FrontierSpectralOperator.dissipation u)
  change (FrontierPhysicalGramTransport.fourierCoordinateReal
    (FrontierSpectralOperator.dissipation u) : Frequency → Fiber) =ᵐ[volume] _ at hc
  filter_upwards [hd, hc] with ξ hd hc
  calc
    _ = FrontierProjectedDissipation.weight ξ •
        (FourierTransform.fourier (FrontierSpectralOperator.dissipation u) : Field)
          (WithLp.toLp 2 ξ) :=
      FrontierProjectedDissipation.velocitySymbol_eq_weight _ _
    _ = FrontierProjectedDissipation.weight ξ •
        FrontierMultiplierBridge.velocitySymbol u.val ξ := by
      rw [← hc, hd]
    _ = FrontierGraphSquared.laplacianSymbol u.val ξ := by
      rw [FrontierProjectedDissipation.velocitySymbol_eq_weight]
      simp only [FrontierGraphSquared.laplacianSymbol, smul_smul]

/-- On the given first-order graph domain, the square can be applied exactly
when the explicit squared Fourier multiplier has an L² representative. -/
theorem compositeDomain_iff_hasLaplacianSymbol (u : Domain) :
    FrontierGraphSquared.CompositeDomain u ↔ HasLaplacianSymbol u.val := by
  constructor
  · intro hu
    exact FrontierGraphSquared.laplacian_representative_of_composite_domain u hu
  · rintro ⟨w, hw⟩
    change FrontierDissipationDomain.HasDissipationSymbol
      (FrontierSpectralOperator.dissipation u)
    exact ⟨w, hw.trans (velocitySymbol_dissipation u).symm⟩

/-- A graph-square application equals every L² representative of the squared
symbol. Together with the previous iff, this characterizes both the operator
and its composite domain relative to the original first-order domain. -/
theorem square_eq_laplacian_representative
    (u : Domain) (hu : FrontierGraphSquared.CompositeDomain u) (w : Field)
    (hw : (FrontierPhysicalGramTransport.fourierCoordinateReal w : Frequency → Fiber) =ᵐ[volume]
      FrontierGraphSquared.laplacianSymbol u.val) :
    FrontierSpectralOperator.dissipation ⟨FrontierSpectralOperator.dissipation u, hu⟩ = w := by
  apply laplacian_representative_unique u.val
  · exact FrontierGraphSquared.second_dissipation_fourier u hu
  · exact hw

end FrontierGraphSquareMaximal

#print axioms FrontierGraphSquareMaximal.laplacian_representative_unique
#print axioms FrontierGraphSquareMaximal.velocitySymbol_dissipation
#print axioms FrontierGraphSquareMaximal.compositeDomain_iff_hasLaplacianSymbol
#print axioms FrontierGraphSquareMaximal.square_eq_laplacian_representative
