import FrontierProjectedGraphEnergy
import FrontierFiniteIntervalEnergy

/-! Candidate: derive an almost-everywhere graph lift of a supplied velocity
from its weak-gradient identity, then transport the existing projected-graph
energy bound to a finite interval with the same trajectory's endpoint values.
The weak-gradient identity, gradient integrability and energy inequality are
still explicit assumptions. No physical Leray--Hopf realization or independent
Stokes-square-root identification is asserted. No Lean compiler was run locally. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierAEProjectedGraphEnergy

local instance physicalRealL2 : InnerProductSpace ℝ FrontierSpectralOperator.PhysicalL2 :=
  InnerProductSpace.rclikeToReal ℂ FrontierSpectralOperator.PhysicalL2

def WeakAt (u : FrontierSpectralOperator.Field) (g : FrontierARealGradient.RealMatrix) : Prop :=
  ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
    LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
      (Lp.toTemperedDistribution u)

/-- A concrete fallback graph element used only outside the weak-gradient set. -/
def zeroGraph : FrontierSpectralOperator.Domain :=
  FrontierSpectralOperator.ofWeakGradient 0 0 (by
    intro j
    have hz : Lp.toTemperedDistribution (0 : FrontierSpectralOperator.Field) = 0 := by
      change (Lp.toTemperedDistributionCLM FrontierPhysicalDivergence.Fiber
        (volume : Measure FrontierPhysicalDivergence.Space) 2) 0 = 0
      exact map_zero _
    simp only [FrontierGradientAdapter.gradientColumn, map_zero, hz, LineDeriv.lineDerivOp_zero])

/-- Lift a velocity wherever its supplied weak gradient is valid; use zero elsewhere. -/
def graphLift (u : FrontierSpectralOperator.Field) (g : FrontierARealGradient.RealMatrix) :
    FrontierSpectralOperator.Domain := by
  classical
  exact if h : WeakAt u g then FrontierSpectralOperator.ofWeakGradient u g h else zeroGraph

theorem graphLift_val_of_weak (u : FrontierSpectralOperator.Field)
    (g : FrontierARealGradient.RealMatrix) (h : WeakAt u g) :
    (graphLift u g).val = u := by
  unfold graphLift
  split
  · rfl
  · contradiction

/-- The lift represents the original supplied velocity almost everywhere. -/
theorem graphLift_val_ae {τ : Type*} [MeasurableSpace τ] (η : Measure τ)
    (u : τ → FrontierSpectralOperator.Field) (g : τ → FrontierARealGradient.RealMatrix)
    (hweak : ∀ᵐ t ∂η, WeakAt (u t) (g t)) :
    ∀ᵐ t ∂η, (graphLift (u t) (g t)).val = u t := by
  filter_upwards [hweak] with t ht
  exact graphLift_val_of_weak (u t) (g t) ht

/-- Conditional finite-interval graph estimate with no supplied graph-domain
trajectory: the graph lift is obtained from the a.e. weak-gradient relation.
The initial and terminal terms are the supplied velocity's values at 0 and T. -/
theorem finite_interval_projected_graph_from_weak_gradient
    [MeasurableSpace FrontierARealGradient.RealMatrix] [BorelSpace FrontierARealGradient.RealMatrix]
    [MeasurableSpace FrontierAWeakTimeGram.MatrixL2] [BorelSpace FrontierAWeakTimeGram.MatrixL2]
    [MeasurableSpace FrontierAMatrixFourier.FrequencyMatrix]
    [BorelSpace FrontierAMatrixFourier.FrequencyMatrix]
    [MeasurableSpace FrontierAConcreteFourier.ComplexField]
    [BorelSpace FrontierAConcreteFourier.ComplexField]
    [MeasurableSpace FrontierAWeakTimeGram.CoordinateL2]
    [BorelSpace FrontierAWeakTimeGram.CoordinateL2]
    (u : ℝ → FrontierSpectralOperator.Field) (g : ℝ → FrontierARealGradient.RealMatrix)
    (T nu : ℝ) (hnu : 0 < nu)
    (hg : MemLp g 2 (FrontierFiniteIntervalEnergy.timeMeasure T))
    (henergy : ‖u T‖ ^ 2 + 2 * nu *
      (∫ t, ‖g t‖ ^ 2 ∂(FrontierFiniteIntervalEnergy.timeMeasure T)) ≤ ‖u 0‖ ^ 2)
    (hweak : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T), WeakAt (u t) (g t)) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => FrontierSpectralOperator.dissipation
        (FrontierProjectedDissipation.plusDomain (graphLift (u t) (g t))))
      (fun t => FrontierSpectralOperator.dissipation
        (FrontierProjectedDissipation.minusDomain (graphLift (u t) (g t)))))
      (FrontierFiniteIntervalEnergy.timeMeasure T) ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral (FrontierFiniteIntervalEnergy.timeMeasure T)
      (fun t => FrontierSpectralOperator.dissipation
        (FrontierProjectedDissipation.plusDomain (graphLift (u t) (g t))))
      (fun t => FrontierSpectralOperator.dissipation
        (FrontierProjectedDissipation.minusDomain (graphLift (u t) (g t)))) ≤
      ‖u 0‖ ^ 2 / (4 * nu) := by
  have hlift : ∀ᵐ t ∂(FrontierFiniteIntervalEnergy.timeMeasure T), ∀ j,
      Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn (g t) j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution (graphLift (u t) (g t)).val) := by
    filter_upwards [hweak] with t ht
    rw [graphLift_val_of_weak (u t) (g t) ht]
    exact ht
  exact FrontierProjectedGraphEnergy.projected_graph_gram_from_gradient_energy
    (FrontierFiniteIntervalEnergy.timeMeasure T) (fun t => graphLift (u t) (g t))
    g (u 0) (u T) nu hnu hg henergy hlift

end FrontierAEProjectedGraphEnergy

#print axioms FrontierAEProjectedGraphEnergy.graphLift_val_of_weak
#print axioms FrontierAEProjectedGraphEnergy.graphLift_val_ae
#print axioms FrontierAEProjectedGraphEnergy.finite_interval_projected_graph_from_weak_gradient
