import FrontierProjectedGraphEnergy
import FrontierCanonicalPhysicalSymbols

/-! An explicit operator-level interface for independently supplied helical
projections and a dissipation graph operator. The Fourier-action hypotheses
are not proved here or claimed to be quotations from literature; applying them
to spectral curl/Stokes operators requires an independent verification,
including their domains, normalizations and the longitudinal extension.
No Leray--Hopf solution is constructed. No local Lean run. -/
noncomputable section
open MeasureTheory Filter
open HelicalConcreteSymbol FeffermanHelicalOrthogonal

namespace FrontierSpectralOperatorInterface

abbrev Field := FrontierSpectralOperator.Field
abbrev Domain := FrontierSpectralOperator.Domain
abbrev Frequency := FrontierSpectralOperator.Frequency
abbrev Fiber := FrontierSpectralOperator.Fiber
abbrev Gradient := FrontierARealGradient.RealMatrix

/-- Independently supplied operators satisfy these global Fourier action laws.
These are explicit operator-identification premises, not established facts
about the mathematical Stokes operator. The projector laws cover the entire
complex L² space, including its longitudinal subspace. -/
structure SpectralInterface where
  positive : Field → Field
  negative : Field → Field
  dissipation : Domain → Field
  positive_fourier : ∀ u : Field,
    FrontierPhysicalGramTransport.fourierCoordinateReal (positive u) =
      plusMultiplier (volume : Measure Frequency)
        (FrontierPhysicalGramTransport.fourierCoordinateReal u)
  negative_fourier : ∀ u : Field,
    FrontierPhysicalGramTransport.fourierCoordinateReal (negative u) =
      minusMultiplier (volume : Measure Frequency)
        (FrontierPhysicalGramTransport.fourierCoordinateReal u)
  dissipation_fourier : ∀ u : Domain,
    (FrontierPhysicalGramTransport.fourierCoordinateReal (dissipation u) : Frequency → Fiber) =ᵐ[volume]
      FrontierMultiplierBridge.velocitySymbol u.val

/-- A supplied operator with the stipulated positive multiplier agrees with
the project's positive projector. -/
theorem positive_eq_projector (S : SpectralInterface) (u : Field) :
    S.positive u = FrontierPhysicalProjectors.plusProjector u := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  rw [S.positive_fourier, FrontierPhysicalProjectors.plus_fourier]

theorem negative_eq_projector (S : SpectralInterface) (u : Field) :
    S.negative u = FrontierPhysicalProjectors.minusProjector u := by
  apply FrontierPhysicalGramTransport.fourierCoordinateReal.injective
  rw [S.negative_fourier, FrontierPhysicalProjectors.minus_fourier]

/-- The stipulated Fourier graph law determines dissipation uniquely. -/
theorem dissipation_eq_graph (S : SpectralInterface) (u : Domain) :
    S.dissipation u = FrontierSpectralOperator.dissipation u := by
  exact (FrontierSpectralOperator.dissipation_eq_of_symbol u (S.dissipation u)
    (S.dissipation_fourier u)).symm

/-- The graph-domain lift of the supplied positive projection. -/
def positiveDomain (S : SpectralInterface) (u : Domain) : Domain :=
  ⟨S.positive u.val, by
    rw [positive_eq_projector S u.val]
    exact FrontierProjectedDissipation.plus_has_dissipation u⟩

def negativeDomain (S : SpectralInterface) (u : Domain) : Domain :=
  ⟨S.negative u.val, by
    rw [negative_eq_projector S u.val]
    exact FrontierProjectedDissipation.minus_has_dissipation u⟩

/-- Once the global operator laws and weak-gradient premise hold, the supplied
positive spectral dissipation equals the previously constructed gradient field. -/
theorem positive_dissipation_eq_canonical (S : SpectralInterface) (u : Domain)
    (g : Gradient)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u.val)) :
    S.dissipation (positiveDomain S u) = FrontierPhysicalGramTransport.plusField g := by
  have hd : positiveDomain S u = FrontierProjectedDissipation.plusDomain u := by
    apply Subtype.ext
    exact positive_eq_projector S u.val
  rw [dissipation_eq_graph, hd]
  rw [FrontierProjectedGraphEnergy.projected_plus_of_weak_gradient u g hweak]
  exact FrontierDissipationDomain.plus_projected_gradientDissipation g

theorem negative_dissipation_eq_canonical (S : SpectralInterface) (u : Domain)
    (g : Gradient)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u.val)) :
    S.dissipation (negativeDomain S u) = FrontierPhysicalGramTransport.minusField g := by
  have hd : negativeDomain S u = FrontierProjectedDissipation.minusDomain u := by
    apply Subtype.ext
    exact negative_eq_projector S u.val
  rw [dissipation_eq_graph, hd]
  rw [FrontierProjectedGraphEnergy.projected_minus_of_weak_gradient u g hweak]
  exact FrontierDissipationDomain.minus_projected_gradientDissipation g

end FrontierSpectralOperatorInterface

#print axioms FrontierSpectralOperatorInterface.positive_eq_projector
#print axioms FrontierSpectralOperatorInterface.negative_eq_projector
#print axioms FrontierSpectralOperatorInterface.dissipation_eq_graph
#print axioms FrontierSpectralOperatorInterface.positive_dissipation_eq_canonical
#print axioms FrontierSpectralOperatorInterface.negative_dissipation_eq_canonical
