import FrontierProjectedDissipation

/-! The composite of the existing graph operator with itself has Fourier
symbol (2π|ξ|)² on its composite graph domain. This is a purely spectral
square identity; it does not prove self-adjointness or identify an independently
defined distributional Laplacian, Stokes operator or Leray–Hopf solution.
No local Lean run. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierGraphSquared

abbrev Field := FrontierSpectralOperator.Field
abbrev Frequency := FrontierSpectralOperator.Frequency
abbrev Fiber := FrontierSpectralOperator.Fiber
abbrev Domain := FrontierSpectralOperator.Domain

/-- Fourier symbol of the nonnegative Laplacian in the package's normalization. -/
def laplacianSymbol (u : Field) (ξ : Frequency) : Fiber :=
  (FrontierProjectedDissipation.weight ξ * FrontierProjectedDissipation.weight ξ) •
    (FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ)

/-- The squared weight is the standard positive Fourier multiplier for
the negative Laplacian, including the zero frequency. -/
theorem weight_mul_weight (ξ : Frequency) :
    FrontierProjectedDissipation.weight ξ * FrontierProjectedDissipation.weight ξ =
      ((((2 * Real.pi) ^ 2 * (ξ 0 ^ 2 + ξ 1 ^ 2 + ξ 2 ^ 2) : ℝ)) : ℂ) := by
  have hsum : 0 ≤ ξ 0 ^ 2 + ξ 1 ^ 2 + ξ 2 ^ 2 := by positivity
  have hrad : (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2)) ^ 2 =
      ξ 0 ^ 2 + ξ 1 ^ 2 + ξ 2 ^ 2 := Real.sq_sqrt hsum
  calc
    _ = ((((2 * Real.pi) ^ 2 *
      (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2)) ^ 2 : ℝ)) : ℂ) := by
        simp only [FrontierProjectedDissipation.weight, Complex.ofReal_mul, Complex.ofReal_pow]
        ring
    _ = _ := by rw [hrad]

/-- Expanded coordinate form of the Fourier symbol. -/
theorem laplacianSymbol_explicit (u : Field) (ξ : Frequency) :
    laplacianSymbol u ξ =
      ((((2 * Real.pi) ^ 2 * (ξ 0 ^ 2 + ξ 1 ^ 2 + ξ 2 ^ 2) : ℝ)) : ℂ) •
        (FourierTransform.fourier u : Field) (WithLp.toLp 2 ξ) := by
  rw [laplacianSymbol, weight_mul_weight]

/-- The composite graph domain consists of vectors in the graph domain whose
first dissipation output is also in that domain. -/
def CompositeDomain (u : Domain) : Prop :=
  FrontierDissipationDomain.HasDissipationSymbol (FrontierSpectralOperator.dissipation u)

/-- The second graph application has the direct squared Fourier symbol. -/
theorem second_dissipation_fourier (u : Domain) (h : CompositeDomain u) :
    let v : Domain := ⟨FrontierSpectralOperator.dissipation u, h⟩
    (FrontierPhysicalGramTransport.fourierCoordinateReal
      (FrontierSpectralOperator.dissipation v) : Frequency → Fiber) =ᵐ[volume]
      laplacianSymbol u.val := by
  let v : Domain := ⟨FrontierSpectralOperator.dissipation u, h⟩
  have h₁ := FrontierSpectralOperator.dissipation_fourier u
  have h₂ := FrontierSpectralOperator.dissipation_fourier v
  have h₃ := FrontierDomainLinear.fourierCoordinate_ae (FrontierSpectralOperator.dissipation u)
  filter_upwards [h₁, h₂, h₃] with ξ h₁ h₂ h₃
  change (FrontierPhysicalGramTransport.fourierCoordinateReal
    (FrontierSpectralOperator.dissipation v) : Frequency → Fiber) ξ = _
  change (FrontierPhysicalGramTransport.fourierCoordinateReal
    (FrontierSpectralOperator.dissipation u) : Frequency → Fiber) ξ = _ at h₃
  calc
    _ = FrontierMultiplierBridge.velocitySymbol v.val ξ := h₂
    _ = FrontierProjectedDissipation.weight ξ •
        (FourierTransform.fourier (FrontierSpectralOperator.dissipation u) : Field)
          (WithLp.toLp 2 ξ) := by
      exact FrontierProjectedDissipation.velocitySymbol_eq_weight _ _
    _ = FrontierProjectedDissipation.weight ξ •
        FrontierMultiplierBridge.velocitySymbol u.val ξ := by
      rw [← h₃, h₁]
    _ = laplacianSymbol u.val ξ := by
      rw [FrontierProjectedDissipation.velocitySymbol_eq_weight]
      simp only [laplacianSymbol, smul_smul]

/-- Consequently the direct Laplacian Fourier symbol has an L²
representative whenever the graph operator may be applied twice. -/
theorem laplacian_representative_of_composite_domain (u : Domain)
    (h : CompositeDomain u) :
    ∃ w : Field,
      (FrontierPhysicalGramTransport.fourierCoordinateReal w : Frequency → Fiber) =ᵐ[volume]
        laplacianSymbol u.val := by
  exact ⟨FrontierSpectralOperator.dissipation ⟨FrontierSpectralOperator.dissipation u, h⟩,
    second_dissipation_fourier u h⟩

/-- Direct form of the graph-square identity with the coordinate multiplier. -/
theorem second_dissipation_fourier_explicit (u : Domain) (h : CompositeDomain u) :
    let v : Domain := ⟨FrontierSpectralOperator.dissipation u, h⟩
    (FrontierPhysicalGramTransport.fourierCoordinateReal
      (FrontierSpectralOperator.dissipation v) : Frequency → Fiber) =ᵐ[volume]
      fun ξ => ((((2 * Real.pi) ^ 2 * (ξ 0 ^ 2 + ξ 1 ^ 2 + ξ 2 ^ 2) : ℝ)) : ℂ) •
        (FourierTransform.fourier u.val : Field) (WithLp.toLp 2 ξ) := by
  filter_upwards [second_dissipation_fourier u h] with ξ hx
  exact hx.trans (laplacianSymbol_explicit u.val ξ)

end FrontierGraphSquared

#print axioms FrontierGraphSquared.weight_mul_weight
#print axioms FrontierGraphSquared.laplacianSymbol_explicit
#print axioms FrontierGraphSquared.second_dissipation_fourier
#print axioms FrontierGraphSquared.laplacian_representative_of_composite_domain
#print axioms FrontierGraphSquared.second_dissipation_fourier_explicit
