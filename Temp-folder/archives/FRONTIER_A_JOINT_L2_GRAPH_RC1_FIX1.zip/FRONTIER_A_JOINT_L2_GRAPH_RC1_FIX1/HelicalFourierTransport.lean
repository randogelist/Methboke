import HopfGramProjected

/-!
Candidate isometric conjugation interface. An isometric equivalence U is an
explicit input. This file does not construct U, identify it with the Fourier
transform, prove Plancherel, or realize a Leray--Hopf solution. The intended
use is later instantiation once those independent constructions are proved.
-/

noncomputable section
open MeasureTheory

namespace HelicalFourierTransport

variable {E F : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
  [NormedAddCommGroup F] [InnerProductSpace ℝ F]

/-- Conjugation of an operator on F through an isometric equivalence E ≃ F. -/
def pullback (U : E ≃ₗᵢ[ℝ] F) (P : F →L[ℝ] F) : E →L[ℝ] E :=
  U.symm.toLinearIsometry.toContinuousLinearMap.comp
    (P.comp U.toLinearIsometry.toContinuousLinearMap)

theorem pullback_apply (U : E ≃ₗᵢ[ℝ] F) (P : F →L[ℝ] F) (x : E) :
    pullback U P x = U.symm (P (U x)) := rfl

/-- U intertwines the pulled-back and original operators. -/
theorem intertwines (U : E ≃ₗᵢ[ℝ] F) (P : F →L[ℝ] F) (x : E) :
    U (pullback U P x) = P (U x) := by
  rw [pullback_apply, U.apply_symm_apply]

theorem pullback_idempotent (U : E ≃ₗᵢ[ℝ] F) (P : F →L[ℝ] F)
    (hid : ∀ x : F, P (P x) = P x) (x : E) :
    pullback U P (pullback U P x) = pullback U P x := by
  apply U.injective
  simp only [intertwines, hid]

theorem pullback_symmetric (U : E ≃ₗᵢ[ℝ] F) (P : F →L[ℝ] F)
    (hsym : ∀ x y : F, inner ℝ (P x) y = inner ℝ x (P y))
    (x y : E) : inner ℝ (pullback U P x) y = inner ℝ x (pullback U P y) := by
  calc
    inner ℝ (pullback U P x) y = inner ℝ (U (pullback U P x)) (U y) :=
      (U.inner_map_map _ _).symm
    _ = inner ℝ (P (U x)) (U y) := by rw [intertwines]
    _ = inner ℝ (U x) (P (U y)) := hsym _ _
    _ = inner ℝ (U x) (U (pullback U P y)) := by rw [intertwines]
    _ = inner ℝ x (pullback U P y) := U.inner_map_map _ _

theorem pullback_norm (U : E ≃ₗᵢ[ℝ] F) (P : F →L[ℝ] F) (x : E) :
    ‖pullback U P x‖ = ‖P (U x)‖ := by
  rw [pullback_apply, U.symm.norm_map]

/-- The previously verified abstract Gram bound transfers to the isometric
    pullback. The isometry, symmetry, idempotence and energy are premises. -/
theorem pullback_gram_bound
    {α : Type*} [MeasurableSpace α] [MeasurableSpace E] [BorelSpace E]
    (μ : Measure α) (U : E ≃ₗᵢ[ℝ] F) (P : F →L[ℝ] F) (z : α → E)
    (nu initialEnergy : ℝ) (hnu : 0 < nu) (hz : MemLp z 2 μ)
    (hsym : ∀ x y : F, inner ℝ (P x) y = inner ℝ x (P y))
    (hid : ∀ x : F, P (P x) = P x)
    (hEnergy : 2 * nu * (∫ t, ‖z t‖ ^ 2 ∂μ) ≤ initialEnergy) :
    Integrable (FeffermanAHopfGramIntegral.gramSqrt
      (fun t => pullback U P (z t)) (fun t => z t - pullback U P (z t))) μ ∧
    FeffermanAHopfGramIntegral.gramSqrtIntegral μ
      (fun t => pullback U P (z t)) (fun t => z t - pullback U P (z t))
      ≤ initialEnergy / (4 * nu) := by
  exact HopfGramProjected.projected_gram_integrable_and_bound
    μ (pullback U P) z nu initialEnergy hnu hz
    (pullback_symmetric U P hsym) (pullback_idempotent U P hid) hEnergy

end HelicalFourierTransport

#print axioms HelicalFourierTransport.pullback_apply
#print axioms HelicalFourierTransport.intertwines
#print axioms HelicalFourierTransport.pullback_idempotent
#print axioms HelicalFourierTransport.pullback_symmetric
#print axioms HelicalFourierTransport.pullback_norm
#print axioms HelicalFourierTransport.pullback_gram_bound
