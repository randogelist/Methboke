import HelicalConcreteSymbol
import Mathlib.Analysis.Fourier.LpSpace

/-!
Candidate specialization of Mathlib's vector-valued L2 Fourier transform to
Euclidean R3 and complex Euclidean 3-vectors. The physical-space L2 here is
complex-valued; no real-field subspace, Sobolev gradient, weak divergence,
Leray--Hopf solution, or energy law is constructed. The Fourier convention is
Mathlib's; matching the frequency multiplier package requires a further
EuclideanSpace-to-Fin-function measure-preserving identification, with the
2*pi normalization checked at the derivative/dissipation step.

The availability and signatures of this Mathlib module in the user's cached
Lean 4.33.0 environment are unverified. External compilation/audit is required.
-/

noncomputable section
open MeasureTheory
open FeffermanHelicalOrthogonal

namespace HelicalR3Plancherel

abbrev Space := EuclideanSpace ℝ (Fin 3)
abbrev ComplexField := Lp Fiber 2 (volume : Measure Space)

/-- The L2 Fourier isometry furnished by Mathlib, for complex vector fields. -/
def fourierComplex : ComplexField ≃ₗᵢ[ℂ] ComplexField :=
  MeasureTheory.Lp.fourierTransformₗᵢ Space Fiber

/-- The same isometry, viewed as a real-linear map on the complexified space. -/
def fourierReal : ComplexField ≃ₗᵢ[ℝ] ComplexField where
  toLinearEquiv := fourierComplex.toLinearEquiv.restrictScalars ℝ
  norm_map' := by
    intro f
    exact fourierComplex.norm_map f

theorem fourierReal_apply (f : ComplexField) : fourierReal f = fourierComplex f := rfl

theorem fourier_norm (f : ComplexField) : ‖fourierReal f‖ = ‖f‖ :=
  fourierReal.norm_map f

theorem inverse_fourier (f : ComplexField) : fourierReal.symm (fourierReal f) = f :=
  fourierReal.symm_apply_apply f

theorem fourier_inverse (f : ComplexField) : fourierReal (fourierReal.symm f) = f :=
  fourierReal.apply_symm_apply f

end HelicalR3Plancherel

#print axioms HelicalR3Plancherel.fourierReal_apply
#print axioms HelicalR3Plancherel.fourier_norm
#print axioms HelicalR3Plancherel.inverse_fourier
#print axioms HelicalR3Plancherel.fourier_inverse
