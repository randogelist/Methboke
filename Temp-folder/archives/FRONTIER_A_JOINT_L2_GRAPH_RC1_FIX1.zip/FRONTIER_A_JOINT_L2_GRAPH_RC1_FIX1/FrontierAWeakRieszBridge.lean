import FrontierAWeakFourierAE
import FrontierASchwartzRieszBridge

/-! Candidate: the Fourier transforms of three supplied L² weak directional
    derivatives assemble almost everywhere into the already audited Riesz-row
    algebra. This does not construct the weak derivatives, a matrix-valued L²
    gradient, or a Leray–Hopf solution. Native compilation and axiom audit
    remain required. -/
noncomputable section
open MeasureTheory Filter FourierTransform

namespace FrontierAWeakRieszBridge

abbrev Space := FrontierAWeakFourierAE.Space
abbrev Fiber := FrontierAWeakFourierAE.Fiber
abbrev Field := FrontierAWeakFourierAE.Field

def unitDirection (j : Fin 3) : Space := EuclideanSpace.single j (1 : ℝ)

def weakFourierMatrix (du : Fin 3 → Field) (ξ : Space) : Fin 3 → Fin 3 → ℂ :=
  fun i j => (FourierTransform.fourier (du j) : Field) ξ i

/-- The Fourier transforms of supplied coordinate weak derivatives agree
    almost everywhere with the algebraic derivative matrix. -/
theorem weak_fourier_matrix_eq
    (u : Field) (du : Fin 3 → Field)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (unitDirection j) (Lp.toTemperedDistribution u)) :
    ∀ᵐ ξ ∂(volume : Measure Space),
      weakFourierMatrix du ξ = FrontierARieszDerivativeAlgebra.derivativeMatrix
        (2 * Real.pi) ξ.ofLp (fun i => (FourierTransform.fourier u : Field) ξ i) := by
  have h0 := FrontierAWeakFourierAE.fourier_weak_derivative_ae u (du 0)
    (unitDirection 0) (hweak 0)
  have h1 := FrontierAWeakFourierAE.fourier_weak_derivative_ae u (du 1)
    (unitDirection 1) (hweak 1)
  have h2 := FrontierAWeakFourierAE.fourier_weak_derivative_ae u (du 2)
    (unitDirection 2) (hweak 2)
  filter_upwards [h0, h1, h2] with ξ h0 h1 h2
  have hj (j : Fin 3) :
      (FourierTransform.fourier (du j) : Field) ξ =
        (FrontierAWeakFourierAE.derivativeConstant *
          (inner ℝ ξ (unitDirection j) : ℂ)) •
          (FourierTransform.fourier u : Field) ξ := by
    fin_cases j <;> assumption
  funext i j
  have h := congrArg (fun v : Fiber => v i) (hj j)
  simpa [weakFourierMatrix, FrontierARieszDerivativeAlgebra.derivativeMatrix,
    FrontierAWeakFourierAE.derivativeConstant, unitDirection,
    EuclideanSpace.inner_single_right, smul_eq_mul, mul_assoc] using! h

/-- Riesz row applied to the Fourier transforms of the supplied weak gradient. -/
theorem weak_riesz_derivative_identity
    (u : Field) (du : Fin 3 → Field)
    (hweak : ∀ j, Lp.toTemperedDistribution (du j) =
      LineDeriv.lineDerivOp (unitDirection j) (Lp.toTemperedDistribution u)) :
    ∀ᵐ ξ ∂(volume : Measure Space), ∀ i : Fin 3,
      FrontierARieszVectorPointwise.vectorRow ξ.ofLp (weakFourierMatrix du ξ) i =
        ((2 * Real.pi : ℝ) : ℂ) *
          (FeffermanHelicalNormalize.radius (ξ.ofLp 0) (ξ.ofLp 1) (ξ.ofLp 2) : ℂ) *
          (FourierTransform.fourier u : Field) ξ i := by
  filter_upwards [weak_fourier_matrix_eq u du hweak] with ξ hξ
  intro i
  rw [hξ]
  exact FrontierARieszDerivativeAlgebra.vectorRow_derivative_symbol (2 * Real.pi)
    ξ.ofLp (fun i => (FourierTransform.fourier u : Field) ξ i) i

end FrontierAWeakRieszBridge

#print axioms FrontierAWeakRieszBridge.weak_fourier_matrix_eq
#print axioms FrontierAWeakRieszBridge.weak_riesz_derivative_identity
