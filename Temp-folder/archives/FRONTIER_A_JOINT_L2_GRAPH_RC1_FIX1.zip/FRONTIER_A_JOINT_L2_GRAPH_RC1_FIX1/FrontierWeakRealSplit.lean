import FrontierRealHelicalSplit
import FrontierRealDistributionTrace
import FrontierAEProjectedGraphEnergy

/-!
The project-defined real helical projectors split a real velocity and its
L² energy when the explicitly supplied real gradient satisfies the project
weak-derivative identities and has vanishing repeated distributional
divergence. The almost-everywhere time version requires those hypotheses
on almost every time slice. This does not construct a Leray--Hopf solution,
prove its energy inequality, or identify an independent Stokes operator.
No local Lean compiler was run.
-/
noncomputable section
open MeasureTheory Filter
open FrontierRealVelocityEmbedding FrontierRealHelicalOperators

namespace FrontierWeakRealSplit

abbrev Gradient := FrontierARealGradient.RealMatrix
abbrev Space := FrontierARealGradient.Space
abbrev RealFiber := FrontierARealGradient.RealFiber

/-- Repeated scalar divergence distribution of the supplied gradient columns. -/
abbrev GradientDivergenceZero := FrontierRealDistributionTrace.ColumnDivergenceZero

/-- A supplied weak gradient and zero distributional divergence give the
real helical splitting without a separate Fourier dot-product premise. -/
theorem split_of_weak_gradient_and_divergence
    (u : RealField) (g : Gradient)
    (hw : FrontierAEProjectedGraphEnergy.WeakAt (complexifyL2 u) g)
    (hd : GradientDivergenceZero g) :
    plusReal u + minusReal u = u := by
  apply complexify_injective
  rw [map_add, complexify_plusReal, complexify_minusReal]
  exact FrontierDivergenceTraceIdentity.split_of_distributional_divergence_zero
    (complexifyL2 u) (FrontierARealGradient.complexifyL2 g)
    (fun j => FrontierGradientAdapter.gradientColumn g j) (fun _ => rfl) hw hd

/-- Under the same premises, the real L² energy splits exactly. -/
theorem energy_of_weak_gradient_and_divergence
    (u : RealField) (g : Gradient)
    (hw : FrontierAEProjectedGraphEnergy.WeakAt (complexifyL2 u) g)
    (hd : GradientDivergenceZero g) :
    ‖plusReal u‖ ^ 2 + ‖minusReal u‖ ^ 2 = ‖u‖ ^ 2 := by
  have h := norm_add_sq_real (plusReal u) (minusReal u)
  rw [split_of_weak_gradient_and_divergence u g hw hd,
    FrontierRealHelicalSplit.real_ranges_orthogonal] at h
  linarith

/-- Pointwise trace zero for the supplied real gradient implies the
explicit distributional divergence premise. -/
theorem gradient_divergence_zero_of_real_trace (g : Gradient)
    (ht : ∀ᵐ x ∂(volume : Measure Space),
      (g : Space → RealFiber) x (0, 0) + (g : Space → RealFiber) x (1, 1) +
        (g : Space → RealFiber) x (2, 2) = 0) :
    GradientDivergenceZero g := by
  exact FrontierTimeTraceBridge.divergence_zero_of_real_trace g ht

/-- At almost every time slice, the project real helical operators split both
velocity and energy, provided the supplied slice data satisfy the stated
weak-derivative and distributional-divergence hypotheses. -/
theorem split_and_energy_ae {τ : Type*} [MeasurableSpace τ]
    (η : Measure τ) (u : τ → RealField) (g : τ → Gradient)
    (hw : ∀ᵐ t ∂η, FrontierAEProjectedGraphEnergy.WeakAt (complexifyL2 (u t)) (g t))
    (hd : ∀ᵐ t ∂η, GradientDivergenceZero (g t)) :
    ∀ᵐ t ∂η, plusReal (u t) + minusReal (u t) = u t ∧
      ‖plusReal (u t)‖ ^ 2 + ‖minusReal (u t)‖ ^ 2 = ‖u t‖ ^ 2 := by
  filter_upwards [hw, hd] with t hwt hdt
  exact ⟨split_of_weak_gradient_and_divergence (u t) (g t) hwt hdt,
    energy_of_weak_gradient_and_divergence (u t) (g t) hwt hdt⟩

/-- The almost-everywhere time conclusion also follows from spatial
trace-zero hypotheses on the supplied real gradient. -/
theorem split_and_energy_ae_of_real_trace {τ : Type*} [MeasurableSpace τ]
    (η : Measure τ) (u : τ → RealField) (g : τ → Gradient)
    (hw : ∀ᵐ t ∂η, FrontierAEProjectedGraphEnergy.WeakAt (complexifyL2 (u t)) (g t))
    (ht : ∀ᵐ t ∂η, ∀ᵐ x ∂(volume : Measure Space),
      (g t : Space → RealFiber) x (0, 0) + (g t : Space → RealFiber) x (1, 1) +
        (g t : Space → RealFiber) x (2, 2) = 0) :
    ∀ᵐ t ∂η, plusReal (u t) + minusReal (u t) = u t ∧
      ‖plusReal (u t)‖ ^ 2 + ‖minusReal (u t)‖ ^ 2 = ‖u t‖ ^ 2 := by
  apply split_and_energy_ae η u g hw
  filter_upwards [ht] with t htt
  exact gradient_divergence_zero_of_real_trace (g t) htt

end FrontierWeakRealSplit

#print axioms FrontierWeakRealSplit.split_of_weak_gradient_and_divergence
#print axioms FrontierWeakRealSplit.energy_of_weak_gradient_and_divergence
#print axioms FrontierWeakRealSplit.gradient_divergence_zero_of_real_trace
#print axioms FrontierWeakRealSplit.split_and_energy_ae
#print axioms FrontierWeakRealSplit.split_and_energy_ae_of_real_trace
