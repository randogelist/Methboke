import FrontierARieszVectorSymbol
import FrontierARieszL2Lift
import FrontierACoordinateEquiv

/-! A-TIER CANDIDATE. Frequency-space vector Riesz lift and inverse-Fourier
transport. Gradient input is a supplied nine-component complex frequency L²
field, not yet the Fourier transform of a physical weak derivative. No
Leray–Hopf or real-field identification is asserted. No local Lean run. -/
noncomputable section
open MeasureTheory Filter
open FrontierARieszVectorSymbol

namespace FrontierARieszVectorL2

theorem vectorOp_memLp_top (μ : Measure Frequency) : MemLp vectorOp ⊤ μ := by
  apply FrontierARieszL2Lift.symbol_memLp_top μ vectorOp
  · exact measurable_vectorOp.aestronglyMeasurable
  · exact Filter.Eventually.of_forall vectorOp_contractive

def vectorMultiplier (μ : Measure Frequency) : Lp GradFiber 2 μ →L[ℝ] Lp Fiber 2 μ :=
  FrontierARieszL2Lift.lift μ vectorOp (vectorOp_memLp_top μ)

theorem vectorMultiplier_ae (μ : Measure Frequency) (f : Lp GradFiber 2 μ) :
    (vectorMultiplier μ f : Frequency → Fiber) =ᵐ[μ]
      fun ξ => vectorOp ξ ((f : Frequency → GradFiber) ξ) := by
  exact FrontierARieszL2Lift.lift_ae μ vectorOp (vectorOp_memLp_top μ) f

theorem vectorMultiplier_contractive (μ : Measure Frequency) (f : Lp GradFiber 2 μ) :
    ‖vectorMultiplier μ f‖ ≤ ‖f‖ := by
  apply FrontierARieszL2Lift.lift_contractive μ vectorOp (vectorOp_memLp_top μ)
  exact Filter.Eventually.of_forall vectorOp_contractive

/-- Map supplied frequency-domain matrix data back into complex physical-coordinate L². -/
def inverseFourierVector (g : Lp GradFiber 2 (volume : Measure Frequency)) :
    HelicalR3Plancherel.ComplexField :=
  FrontierACoordinateEquiv.fourierCoordinate.symm
    (vectorMultiplier (volume : Measure Frequency) g)

theorem inverseFourierVector_contractive (g : Lp GradFiber 2 (volume : Measure Frequency)) :
    ‖inverseFourierVector g‖ ≤ ‖g‖ := by
  rw [inverseFourierVector, FrontierACoordinateEquiv.fourierCoordinate.symm.norm_map]
  exact vectorMultiplier_contractive (volume : Measure Frequency) g

/-- The inverse Fourier transport bundled as a real continuous linear map. -/
def inverseFourierVectorCLM :
    Lp GradFiber 2 (volume : Measure Frequency) →L[ℝ] HelicalR3Plancherel.ComplexField :=
  (FrontierACoordinateEquiv.fourierCoordinate.symm.toLinearIsometry.toContinuousLinearMap.restrictScalars ℝ).comp
    (vectorMultiplier (volume : Measure Frequency))

theorem inverseFourierVectorCLM_contractive
    (g : Lp GradFiber 2 (volume : Measure Frequency)) :
    ‖inverseFourierVectorCLM g‖ ≤ ‖g‖ := by
  simpa [inverseFourierVectorCLM, inverseFourierVector] using inverseFourierVector_contractive g

end FrontierARieszVectorL2

#print axioms FrontierARieszVectorL2.vectorOp_memLp_top
#print axioms FrontierARieszVectorL2.vectorMultiplier_ae
#print axioms FrontierARieszVectorL2.vectorMultiplier_contractive
#print axioms FrontierARieszVectorL2.inverseFourierVector_contractive
#print axioms FrontierARieszVectorL2.inverseFourierVectorCLM_contractive
