import Mathlib

/-!
  FEFFERMAN_A_HOPF_GRAM -- analytic/algebraic adapter.

  This file does NOT define or construct a Leray--Hopf solution. Its precise
  hypothesis is the physical Hopf energy inequality for two measurable,
  nonnegative helical enstrophy functions. From that hypothesis it derives,
  without assuming integrability of the target, the selected square-root
  Gram-determinant bound. A separate physical realization theorem is needed
  to supply these hypotheses for an actual Leray--Hopf trajectory.
-/

noncomputable section

open scoped BigOperators
open MeasureTheory
open Filter

namespace FeffermanAHopfGram

/-- The Gram matrix of two orthogonal vectors with squared norms `p` and `m`.
    Physical identification of those vectors is a separate analytic input. -/
def energyGram (p m : ℝ) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![p, 0; 0, m]

theorem energyGram_det (p m : ℝ) :
    (energyGram p m).det = p * m := by
  simp [energyGram, Matrix.det_fin_two]

/-- Pointwise geometric-mean bound with the actual 2 by 2 determinant. -/
theorem sqrt_energyGram_det_le (p m : ℝ) (hp : 0 ≤ p) (hm : 0 ≤ m) :
    Real.sqrt ((energyGram p m).det) ≤ (1 / 2 : ℝ) * (p + m) := by
  rw [energyGram_det]
  apply (Real.sqrt_le_left (by nlinarith [hp, hm] : 0 ≤ (1 / 2 : ℝ) * (p + m))).2
  nlinarith [sq_nonneg (p - m)]

/--
  Measure-theoretic core. `energyBound` is precisely the ordinary Hopf energy
  input `2 * nu * ∫ (ePlus + eMinus) ≤ initialEnergy`. Measurability,
  nonnegativity and integrability are the analytic hypotheses to be supplied
  by a physical Leray--Hopf realization. The conclusion proves both target
  integrability and the explicit bound; neither is assumed.
-/
theorem hopf_gram_sqrt_integrable_and_bound
    {α : Type*} [MeasurableSpace α] (μ : Measure α)
    (ePlus eMinus : α → ℝ) (nu initialEnergy : ℝ)
    (hnu : 0 < nu)
    (hPlusMeas : Measurable ePlus)
    (hMinusMeas : Measurable eMinus)
    (hPlusNonneg : ∀ᵐ t ∂μ, 0 ≤ ePlus t)
    (hMinusNonneg : ∀ᵐ t ∂μ, 0 ≤ eMinus t)
    (hDissInt : Integrable (fun t => ePlus t + eMinus t) μ)
    (hEnergy : 2 * nu * (∫ t, (ePlus t + eMinus t) ∂μ) ≤ initialEnergy) :
    Integrable (fun t => Real.sqrt ((energyGram (ePlus t) (eMinus t)).det)) μ ∧
      (∫ t, Real.sqrt ((energyGram (ePlus t) (eMinus t)).det) ∂μ)
        ≤ initialEnergy / (4 * nu) := by
  have hMeas : Measurable
      (fun t => Real.sqrt ((energyGram (ePlus t) (eMinus t)).det)) := by
    simpa only [energyGram_det, Pi.mul_apply] using (hPlusMeas.mul hMinusMeas).sqrt
  have hPoint : ∀ᵐ t ∂μ,
      Real.sqrt ((energyGram (ePlus t) (eMinus t)).det)
        ≤ (1 / 2 : ℝ) * (ePlus t + eMinus t) := by
    filter_upwards [hPlusNonneg, hMinusNonneg] with t hp hm
    exact sqrt_energyGram_det_le (ePlus t) (eMinus t) hp hm
  have hDom : Integrable (fun t => (1 / 2 : ℝ) * (ePlus t + eMinus t)) μ :=
    hDissInt.const_mul (1 / 2 : ℝ)
  have hTargetInt : Integrable
      (fun t => Real.sqrt ((energyGram (ePlus t) (eMinus t)).det)) μ := by
    apply hDom.mono' hMeas.aestronglyMeasurable
    filter_upwards [hPoint] with t ht
    simpa only [Real.norm_eq_abs, abs_of_nonneg (Real.sqrt_nonneg _)] using ht
  refine ⟨hTargetInt, ?_⟩
  have hIntegral := integral_mono_ae hTargetInt hDom hPoint
  rw [integral_const_mul] at hIntegral
  have hFourNu : 0 < 4 * nu := by positivity
  have hScaled := mul_le_mul_of_nonneg_left hIntegral (le_of_lt hFourNu)
  apply (le_div_iff₀ hFourNu).2
  nlinarith [hEnergy, hScaled]

/-- The selected bound on the physical time interval, conditional exactly on
    the stated scalar Hopf/physical-realization hypotheses. -/
theorem FEFFERMAN_A_UNCONDITIONAL_CANDIDATE_HOPF_BOUND
    (T nu initialEnergy : ℝ) (ePlus eMinus : ℝ → ℝ)
    (hnu : 0 < nu)
    (hPlusMeas : Measurable ePlus)
    (hMinusMeas : Measurable eMinus)
    (hPlusNonneg : ∀ᵐ t ∂(volume.restrict (Set.Ioc (0 : ℝ) T)), 0 ≤ ePlus t)
    (hMinusNonneg : ∀ᵐ t ∂(volume.restrict (Set.Ioc (0 : ℝ) T)), 0 ≤ eMinus t)
    (hDissInt : Integrable (fun t => ePlus t + eMinus t)
      (volume.restrict (Set.Ioc (0 : ℝ) T)))
    (hEnergy : 2 * nu *
      (∫ t in Set.Ioc (0 : ℝ) T, (ePlus t + eMinus t)) ≤ initialEnergy) :
    Integrable (fun t => Real.sqrt ((energyGram (ePlus t) (eMinus t)).det))
      (volume.restrict (Set.Ioc (0 : ℝ) T)) ∧
    (∫ t in Set.Ioc (0 : ℝ) T,
      Real.sqrt ((energyGram (ePlus t) (eMinus t)).det))
      ≤ initialEnergy / (4 * nu) := by
  exact hopf_gram_sqrt_integrable_and_bound
    (volume.restrict (Set.Ioc (0 : ℝ) T)) ePlus eMinus nu initialEnergy
    hnu hPlusMeas hMinusMeas hPlusNonneg hMinusNonneg hDissInt hEnergy

end FeffermanAHopfGram

#print axioms FeffermanAHopfGram.energyGram_det
#print axioms FeffermanAHopfGram.sqrt_energyGram_det_le
#print axioms FeffermanAHopfGram.hopf_gram_sqrt_integrable_and_bound
#print axioms FeffermanAHopfGram.FEFFERMAN_A_UNCONDITIONAL_CANDIDATE_HOPF_BOUND
