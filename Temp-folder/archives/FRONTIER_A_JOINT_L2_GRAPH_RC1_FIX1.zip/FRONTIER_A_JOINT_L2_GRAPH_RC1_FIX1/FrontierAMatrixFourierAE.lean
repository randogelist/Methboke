import FrontierAMatrixFourier

/-! A-TIER CANDIDATE. Almost-everywhere representatives for the existing
matrix Fourier transform and the Riesz multiplier used in the conditional
Gram estimate. The matrix is arbitrary L² data. This does not identify it
with a weak gradient or establish a Leray–Hopf solution or energy inequality.
No local Lean compilation or axiom audit has been performed. -/
noncomputable section
open MeasureTheory Filter FourierTransform
open HelicalConcreteSymbol FrontierARieszVectorSymbol

namespace FrontierAMatrixFourierAE

abbrev Space := FrontierAMatrixFourier.Space
abbrev Frequency := HelicalConcreteSymbol.Frequency
abbrev GradFiber := FrontierAMatrixFourier.GradFiber
abbrev PhysicalMatrix := FrontierAMatrixFourier.PhysicalMatrix
abbrev FrequencyMatrix := FrontierAMatrixFourier.FrequencyMatrix

/-- The coordinate-frequency representative is the pullback of the actual
    Euclidean-frequency L² Fourier transform of the supplied matrix. -/
theorem matrix_fourier_ae (g : PhysicalMatrix) :
    ((FrontierAMatrixFourier.matrixFourier g : FrequencyMatrix) : Frequency → GradFiber) =ᵐ[volume]
      (fun ξ => (FourierTransform.fourier g : PhysicalMatrix) (WithLp.toLp 2 ξ)) := by
  change ((Lp.compMeasurePreserving (WithLp.toLp 2)
      HelicalCoordinateBridge.toLp_preserves_volume
      (FourierTransform.fourier g) : FrequencyMatrix) : Frequency → GradFiber) =ᵐ[volume] _
  simpa only [Function.comp_def] using
    Lp.coeFn_compMeasurePreserving (FourierTransform.fourier g)
      HelicalCoordinateBridge.toLp_preserves_volume

/-- The inverse Fourier map and subsequent Fourier-coordinate transform in
    the Gram theorem cancel, leaving the concrete frequency Riesz multiplier. -/
theorem gram_input_eq_riesz_multiplier (g : FrequencyMatrix) :
    FrontierAConcreteFourier.coordinateFourier
      (FrontierARieszVectorL2.inverseFourierVectorCLM g) =
        FrontierARieszVectorL2.vectorMultiplier (volume : Measure Frequency) g := by
  change FrontierACoordinateEquiv.fourierCoordinate
    (FrontierACoordinateEquiv.fourierCoordinate.symm
      (FrontierARieszVectorL2.vectorMultiplier (volume : Measure Frequency) g)) = _
  exact FrontierACoordinateEquiv.fourierCoordinate.apply_symm_apply _

/-- The input to the helical multipliers is a.e. the concrete Riesz row of
    the Fourier transform of the supplied matrix, component by component. -/
theorem gram_input_matrix_fourier_ae (g : PhysicalMatrix) :
    ∀ᵐ ξ ∂(volume : Measure Frequency), ∀ i : Fin 3,
      (FrontierAConcreteFourier.coordinateFourier
        (FrontierARieszVectorL2.inverseFourierVectorCLM
          (FrontierAMatrixFourier.matrixFourier g)) : Frequency →
            FrontierARieszVectorSymbol.Fiber) ξ i =
      FrontierARieszVectorPointwise.vectorRow ξ
        (fun i j => (FourierTransform.fourier g : PhysicalMatrix)
          (WithLp.toLp 2 ξ) (i, j)) i := by
  rw [gram_input_eq_riesz_multiplier]
  filter_upwards [FrontierARieszVectorL2.vectorMultiplier_ae
    (volume : Measure Frequency) (FrontierAMatrixFourier.matrixFourier g),
    matrix_fourier_ae g] with ξ hrow hmat
  intro i
  have hi := congrArg (fun v : FrontierARieszVectorSymbol.Fiber => v i) hrow
  rw [hmat] at hi
  simpa only [FrontierARieszVectorSymbol.vectorOp_apply] using hi

end FrontierAMatrixFourierAE

#print axioms FrontierAMatrixFourierAE.matrix_fourier_ae
#print axioms FrontierAMatrixFourierAE.gram_input_eq_riesz_multiplier
#print axioms FrontierAMatrixFourierAE.gram_input_matrix_fourier_ae
