import FrontierARieszDerivativeAlgebra
import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier

/-!
A-TIER CANDIDATE: Schwartz-space Fourier-derivative-to-Riesz bridge.
The actual input is an arbitrary complex vector-valued Schwartz function on
Euclidean R3, not an arbitrary Leray--Hopf solution. The proof uses Mathlib's
Schwartz directional Fourier derivative theorem and the existing pointwise
Riesz algebra. No weak-L2 extension, physical helical Gram identification, or
Navier--Stokes energy inequality is established here. Availability and exact
signatures of Mathlib APIs need external native Windows Lean 4.33.0 checking.
-/
noncomputable section
open FourierTransform
open FrontierARieszDerivativeAlgebra FrontierARieszVectorPointwise

namespace FrontierASchwartzRieszBridge

abbrev Space := EuclideanSpace ℝ (Fin 3)
abbrev Fiber := EuclideanSpace ℂ (Fin 3)
abbrev Frequency := HelicalConcreteSymbol.Frequency

def unitDirection (j : Fin 3) : Space := EuclideanSpace.single j (1 : ℝ)

/-- Coordinate Fourier derivative formula for a Schwartz vector field. -/
theorem schwartz_fourier_coordinate_derivative
    (f : SchwartzMap Space Fiber) (ξ : Frequency) (i j : Fin 3) :
    (FourierTransform.fourier (LineDeriv.lineDerivOp (unitDirection j) f))
      (WithLp.toLp 2 ξ) i =
    ((2 * Real.pi : ℝ) : ℂ) * Complex.I * (ξ j : ℂ) *
      ((FourierTransform.fourier f) (WithLp.toLp 2 ξ) i) := by
  have h := congrArg (fun g : SchwartzMap Space Fiber => g (WithLp.toLp 2 ξ) i)
    (SchwartzMap.fourier_lineDerivOp_eq f (unitDirection j))
  have hmap :
      ((SchwartzMap.smulLeftCLM Fiber (fun x : Space => inner ℝ x (unitDirection j)))
        (FourierTransform.fourier f)) (WithLp.toLp 2 ξ) =
      (inner ℝ (WithLp.toLp 2 ξ) (unitDirection j)) •
        (FourierTransform.fourier f) (WithLp.toLp 2 ξ) :=
    SchwartzMap.smulLeftCLM_apply_apply
      (Function.hasTemperateGrowth_inner_left (unitDirection j))
      (FourierTransform.fourier f) (WithLp.toLp 2 ξ)
  simp only [SchwartzMap.smul_apply] at h
  rw [hmap] at h
  simpa [unitDirection, EuclideanSpace.inner_single_right, smul_eq_mul, mul_assoc] using h

/-- Matrix of the Fourier transforms of the three directional derivatives. -/
def schwartzDerivativeMatrix (f : SchwartzMap Space Fiber) (ξ : Frequency) :
    Fin 3 → Fin 3 → ℂ :=
  fun i j => (FourierTransform.fourier (LineDeriv.lineDerivOp (unitDirection j) f))
    (WithLp.toLp 2 ξ) i

/-- The explicit matrix really is the derivative symbol for Schwartz data. -/
theorem schwartz_derivative_matrix_eq
    (f : SchwartzMap Space Fiber) (ξ : Frequency) :
    schwartzDerivativeMatrix f ξ = derivativeMatrix (2 * Real.pi) ξ
      (fun i => (FourierTransform.fourier f) (WithLp.toLp 2 ξ) i) := by
  funext i j
  exact schwartz_fourier_coordinate_derivative f ξ i j

/-- The Riesz row applied to Schwartz directional derivatives yields the
    Fourier amplitude multiplied by 2π times the frequency radius. -/
theorem schwartz_riesz_derivative_identity
    (f : SchwartzMap Space Fiber) (ξ : Frequency) (i : Fin 3) :
    vectorRow ξ (schwartzDerivativeMatrix f ξ) i =
      ((2 * Real.pi : ℝ) : ℂ) *
        (FeffermanHelicalNormalize.radius (ξ 0) (ξ 1) (ξ 2) : ℂ) *
        (FourierTransform.fourier f) (WithLp.toLp 2 ξ) i := by
  rw [schwartz_derivative_matrix_eq]
  exact vectorRow_derivative_symbol (2 * Real.pi) ξ
    (fun i => (FourierTransform.fourier f) (WithLp.toLp 2 ξ) i) i

end FrontierASchwartzRieszBridge

#print axioms FrontierASchwartzRieszBridge.schwartz_fourier_coordinate_derivative
#print axioms FrontierASchwartzRieszBridge.schwartz_derivative_matrix_eq
#print axioms FrontierASchwartzRieszBridge.schwartz_riesz_derivative_identity
