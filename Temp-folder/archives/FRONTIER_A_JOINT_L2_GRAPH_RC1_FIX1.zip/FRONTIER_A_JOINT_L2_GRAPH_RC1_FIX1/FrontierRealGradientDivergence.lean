import FrontierPhysicalDivergence
import FrontierPhysicalIdentification

/-! Candidate bridge from a pointwise trace-free real L² gradient to the
previously conditional projector splitting theorem. The real gradient,
its weak-derivative identities and its trace-free property are supplied;
no Leray--Hopf solution or physical energy inequality is constructed. -/
noncomputable section
open MeasureTheory Filter
namespace FrontierRealGradientDivergence

abbrev Space := FrontierARealGradient.Space
abbrev RealFiber := FrontierARealGradient.RealFiber
abbrev RealMatrix := FrontierARealGradient.RealMatrix
abbrev Fiber := FrontierPhysicalDivergence.Fiber
abbrev Field := FrontierPhysicalDivergence.Field

/-- A real L² matrix whose trace vanishes almost everywhere has zero complex
L² trace after the established complexification. -/
theorem complex_trace_zero_of_ae_real_trace_zero (g : RealMatrix)
    (htrace : ∀ᵐ x ∂(volume : Measure Space),
      (g : Space → RealFiber) x (0, 0) + (g : Space → RealFiber) x (1, 1) +
        (g : Space → RealFiber) x (2, 2) = 0) :
    FrontierPhysicalDivergence.traceL2 (FrontierARealGradient.complexifyL2 g) = 0 := by
  apply Lp.ext
  have hcomp := ContinuousLinearMap.coeFn_compLpL FrontierPhysicalDivergence.traceCLM
    (FrontierARealGradient.complexifyL2 g)
  have hc := FrontierARealGradient.complexifyL2_ae g
  have hz := Lp.coeFn_zero Fiber 2 (volume : Measure Space)
  change ((FrontierPhysicalDivergence.traceL2 (FrontierARealGradient.complexifyL2 g) : Field) :
    Space → Fiber) =ᵐ[volume] _ at hcomp
  filter_upwards [hcomp, hc, hz, htrace] with x hcomp hc hz htrace
  rw [hcomp, hc, hz]
  ext i
  simp only [FrontierPhysicalDivergence.traceCLM_apply]
  change (((g : Space → RealFiber) x (0, 0) : ℝ) : ℂ) +
      (((g : Space → RealFiber) x (1, 1) : ℝ) : ℂ) +
      (((g : Space → RealFiber) x (2, 2) : ℝ) : ℂ) = 0
  have hh := congrArg (fun y : ℝ => (y : ℂ)) htrace
  simpa only [Complex.ofReal_add, Complex.ofReal_zero] using hh

/-- A supplied trace-free real weak gradient gives the helical split of the
corresponding velocity in the existing Fourier-conjugate construction. -/
theorem split_of_real_weak_gradient_trace_zero (u : Field) (g : RealMatrix)
    (hweak : ∀ j, Lp.toTemperedDistribution (FrontierGradientAdapter.gradientColumn g j) =
      LineDeriv.lineDerivOp (FrontierAWeakRieszBridge.unitDirection j)
        (Lp.toTemperedDistribution u))
    (htrace : ∀ᵐ x ∂(volume : Measure Space),
      (g : Space → RealFiber) x (0, 0) + (g : Space → RealFiber) x (1, 1) +
        (g : Space → RealFiber) x (2, 2) = 0) :
    FrontierPhysicalProjectors.plusProjector u +
      FrontierPhysicalProjectors.minusProjector u = u := by
  exact FrontierPhysicalDivergence.split_of_weak_gradient_trace_zero u
    (FrontierARealGradient.complexifyL2 g)
    (fun j => FrontierGradientAdapter.gradientColumn g j) (fun _ => rfl) hweak
    (complex_trace_zero_of_ae_real_trace_zero g htrace)

end FrontierRealGradientDivergence

#print axioms FrontierRealGradientDivergence.complex_trace_zero_of_ae_real_trace_zero
#print axioms FrontierRealGradientDivergence.split_of_real_weak_gradient_trace_zero
