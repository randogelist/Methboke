import Mathlib
import HOPF_GRAM_INTEGRAL

/-!
# Integrated scalar energy-defect bridge

Candidate only, with explicit integrability and energy-identity inputs. The
functions `a` and `b` are abstract; no claim is made here that they are norms
of the physical helical projections of a Leray--Hopf solution. The energy
identity's derivation and all physical identifications remain separate.
-/

noncomputable section
open MeasureTheory
open Filter

namespace FrontierEnergyDefect

/-- Integrating the algebraic decomposition of the sum of two squares.
The cross product and squared difference are explicitly integrable. -/
theorem integrated_square_decomposition
    {α : Type*} [MeasurableSpace α] (μ : Measure α) (a b : α → ℝ)
    (hab : Integrable (fun t => a t * b t) μ)
    (hdiff : Integrable (fun t => (a t - b t) ^ 2) μ) :
    (∫ t, (a t ^ 2 + b t ^ 2) ∂μ) =
      2 * (∫ t, a t * b t ∂μ) + (∫ t, (a t - b t) ^ 2 ∂μ) := by
  have hpoint : (fun t => a t ^ 2 + b t ^ 2) =
      (fun t => 2 * (a t * b t) + (a t - b t) ^ 2) := by
    funext t
    ring
  rw [hpoint, integral_add (hab.const_mul 2) hdiff, integral_const_mul]

/-- Exact integrated deficit. The energy balance and the two integrability
conditions are premises; no hidden physical realization is asserted. -/
theorem integrated_energy_defect
    {α : Type*} [MeasurableSpace α] (μ : Measure α) (a b : α → ℝ)
    (nu initial terminal defect : ℝ)
    (hab : Integrable (fun t => a t * b t) μ)
    (hdiff : Integrable (fun t => (a t - b t) ^ 2) μ)
    (henergy : initial = terminal + 2 * nu *
      (∫ t, (a t ^ 2 + b t ^ 2) ∂μ) + defect) :
    initial = terminal + 4 * nu * (∫ t, a t * b t ∂μ) +
      2 * nu * (∫ t, (a t - b t) ^ 2 ∂μ) + defect := by
  have hid := integrated_square_decomposition μ a b hab hdiff
  rw [hid] at henergy
  nlinarith [henergy]

/-- The integrated mismatch is nonnegative. -/
theorem mismatch_nonneg
    {α : Type*} [MeasurableSpace α] (μ : Measure α) (a b : α → ℝ) :
    0 ≤ (∫ t, (a t - b t) ^ 2 ∂μ) := by
  apply integral_nonneg
  intro t
  exact sq_nonneg (a t - b t)

/-- The square root of the determinant of the actual two-vector Gram matrix
is the norm product when the vectors are orthogonal. -/
theorem orthogonal_gramSqrt_eq_norm_mul
    {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (x y : H) (hxy : inner ℝ x y = 0) :
    Real.sqrt ((FeffermanAHopfGramIntegral.vectorGram x y).det) = ‖x‖ * ‖y‖ := by
  rw [FeffermanAHopfGramIntegral.vectorGram_det_of_orthogonal x y hxy,
    FeffermanAHopfGram.energyGram_det,
    Real.sqrt_mul (sq_nonneg ‖x‖), Real.sqrt_sq_eq_abs, Real.sqrt_sq_eq_abs]
  simp only [abs_of_nonneg (norm_nonneg x), abs_of_nonneg (norm_nonneg y)]

/-- Exact integrated Gram energy deficit for an explicitly supplied pair of
orthogonal Hilbert-space trajectories. Physical helical realization and the
stated energy identity remain premises. -/
theorem vector_gram_energy_defect
    {α H : Type*} [MeasurableSpace α] [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (μ : Measure α) (vPlus vMinus : α → H) (nu initial terminal defect : ℝ)
    (horth : ∀ᵐ t ∂μ, inner ℝ (vPlus t) (vMinus t) = 0)
    (hprod : Integrable (fun t => ‖vPlus t‖ * ‖vMinus t‖) μ)
    (hdiff : Integrable (fun t => (‖vPlus t‖ - ‖vMinus t‖) ^ 2) μ)
    (henergy : initial = terminal + 2 * nu *
      (∫ t, (‖vPlus t‖ ^ 2 + ‖vMinus t‖ ^ 2) ∂μ) + defect) :
    initial = terminal + 4 * nu *
      (∫ t, FeffermanAHopfGramIntegral.gramSqrt vPlus vMinus t ∂μ) +
      2 * nu * (∫ t, (‖vPlus t‖ - ‖vMinus t‖) ^ 2 ∂μ) + defect := by
  have heq : FeffermanAHopfGramIntegral.gramSqrt vPlus vMinus =ᵐ[μ]
      (fun t => ‖vPlus t‖ * ‖vMinus t‖) := by
    filter_upwards [horth] with t ht
    exact orthogonal_gramSqrt_eq_norm_mul (vPlus t) (vMinus t) ht
  rw [integral_congr_ae heq]
  exact integrated_energy_defect μ (fun t => ‖vPlus t‖) (fun t => ‖vMinus t‖)
    nu initial terminal defect hprod hdiff henergy

end FrontierEnergyDefect
