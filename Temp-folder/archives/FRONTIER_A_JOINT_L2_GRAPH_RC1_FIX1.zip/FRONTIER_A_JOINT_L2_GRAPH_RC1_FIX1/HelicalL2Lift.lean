import Mathlib

/-!
A candidate concrete L2 multiplication operator for an essentially bounded
operator-valued symbol. This is an actual operator on Mathlib's Lp quotient,
not an assumed operator. The L-infinity symbol is an explicit input: this
module does not yet identify the helical matrices with such a symbol, nor
does it construct the Fourier transform or a Leray-Hopf solution.

These declarations require external native compilation and axiom auditing.
-/

noncomputable section

open MeasureTheory
open Filter

namespace HelicalL2Lift

variable {α H : Type*} [MeasurableSpace α]
  [NormedAddCommGroup H] [NormedSpace ℝ H]

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩
local instance : Fact (1 ≤ (⊤ : ENNReal)) := ⟨le_top⟩

/-- Multiplication by an L-infinity operator-valued symbol, obtained from
    Mathlib's continuous bilinear Hölder map. -/
noncomputable def multiplier (μ : Measure α)
    (symbol : Lp (H →L[ℝ] H) ⊤ μ) : Lp H 2 μ →L[ℝ] Lp H 2 μ :=
  (ContinuousLinearMap.holderL μ ⊤ 2 2
    (ContinuousLinearMap.id ℝ (H →L[ℝ] H))) symbol

/-- The abstract quotient operator acts by applying the symbol almost
    everywhere to the representative of the input. -/
theorem multiplier_ae (μ : Measure α)
    (symbol : Lp (H →L[ℝ] H) ⊤ μ) (f : Lp H 2 μ) :
    (multiplier μ symbol f : α → H) =ᵐ[μ]
      fun x => (symbol : α → (H →L[ℝ] H)) x ((f : α → H) x) := by
  simpa only [multiplier, ContinuousLinearMap.holderL_apply_apply,
    ContinuousLinearMap.id_apply] using
    (ContinuousLinearMap.coeFn_holder (r := (2 : ENNReal))
      (ContinuousLinearMap.id ℝ (H →L[ℝ] H)) symbol f)

/-- Pointwise idempotence of the symbol almost everywhere lifts to an
    idempotent operator on the L2 quotient. -/
theorem multiplier_idempotent (μ : Measure α)
    (symbol : Lp (H →L[ℝ] H) ⊤ μ)
    (hid : ∀ᵐ x ∂μ, ∀ v : H,
      (symbol : α → (H →L[ℝ] H)) x ((symbol : α → (H →L[ℝ] H)) x v) =
        (symbol : α → (H →L[ℝ] H)) x v)
    (f : Lp H 2 μ) :
    multiplier μ symbol (multiplier μ symbol f) = multiplier μ symbol f := by
  apply MeasureTheory.Lp.ext
  filter_upwards [multiplier_ae μ symbol (multiplier μ symbol f),
    multiplier_ae μ symbol f, hid] with x h1 h2 hx
  calc
    (multiplier μ symbol (multiplier μ symbol f) : α → H) x =
        (symbol : α → (H →L[ℝ] H)) x ((multiplier μ symbol f : α → H) x) := h1
    _ = (symbol : α → (H →L[ℝ] H)) x
        ((symbol : α → (H →L[ℝ] H)) x ((f : α → H) x)) :=
      congrArg ((symbol : α → (H →L[ℝ] H)) x) h2
    _ = (symbol : α → (H →L[ℝ] H)) x ((f : α → H) x) := hx ((f : α → H) x)
    _ = (multiplier μ symbol f : α → H) x := h2.symm

/-- The L2 operator obeys the Hölder norm estimate. -/
theorem multiplier_norm_bound (μ : Measure α)
    (symbol : Lp (H →L[ℝ] H) ⊤ μ) (f : Lp H 2 μ) :
    ‖multiplier μ symbol f‖ ≤
      ‖ContinuousLinearMap.id ℝ (H →L[ℝ] H)‖ * ‖symbol‖ * ‖f‖ := by
  simpa only [multiplier, ContinuousLinearMap.holderL_apply_apply] using
    (ContinuousLinearMap.norm_holder_apply_apply_le (r := (2 : ENNReal))
      (ContinuousLinearMap.id ℝ (H →L[ℝ] H)) symbol f)

/-- The induced operator itself has finite operator norm, bounded by the
    norm of the symbol times the evaluation-map factor. -/
theorem multiplier_op_norm_bound (μ : Measure α)
    (symbol : Lp (H →L[ℝ] H) ⊤ μ) :
    ‖multiplier μ symbol‖ ≤ ‖ContinuousLinearMap.id ℝ (H →L[ℝ] H)‖ * ‖symbol‖ := by
  apply ContinuousLinearMap.opNorm_le_bound
  · exact mul_nonneg
      (ContinuousLinearMap.opNorm_nonneg (ContinuousLinearMap.id ℝ (H →L[ℝ] H)))
      (norm_nonneg symbol)
  · intro f
    exact multiplier_norm_bound μ symbol f

/-- A representative-level L2 closure result, without any finite-measure
    assumption on the underlying frequency space. -/
theorem applied_symbol_memLp (μ : Measure α)
    (symbol : α → (H →L[ℝ] H)) (f : α → H)
    (hs : MemLp symbol ⊤ μ) (hf : MemLp f 2 μ) :
    MemLp (fun x => symbol x (f x)) 2 μ := by
  simpa only [ContinuousLinearMap.id_apply] using
    (ContinuousLinearMap.memLp_of_bilin (2 : ENNReal)
      (ContinuousLinearMap.id ℝ (H →L[ℝ] H)) hs hf)

end HelicalL2Lift

#print axioms HelicalL2Lift.multiplier_ae
#print axioms HelicalL2Lift.multiplier_idempotent
#print axioms HelicalL2Lift.multiplier_norm_bound
#print axioms HelicalL2Lift.multiplier_op_norm_bound
#print axioms HelicalL2Lift.applied_symbol_memLp
