import FrontierWeakGradientSlicing

/-! Candidate bridge from separated time–Schwartz tests to the slice-wise
weak gradient. This does not prove that independently defined Leray–Hopf
spacetime data satisfy the separated-test hypothesis, nor an interchange
with a jointly measurable spatial representative. No local Lean run. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierSeparatedWeakSlicing

abbrev Space := FrontierWeakGradientSubspace.Space
abbrev Fiber := FrontierWeakGradientSubspace.Fiber
abbrev RealVelocity := FrontierWeakGradientSubspace.RealVelocity
abbrev Gradient := FrontierWeakGradientSubspace.Gradient
abbrev Distribution := FrontierWeakGradientSubspace.Distribution

local instance : Fact (1 ≤ (2 : ENNReal)) := ⟨by norm_num⟩

/-- The previously defined weak-derivative residual, now as a continuous
real-linear map. The target has the pointwise convergence topology. -/
def residualCLM (j : Fin 3) : (RealVelocity × Gradient) →L[ℝ] Distribution :=
  (((Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2).restrictScalars ℝ).comp
    (((FrontierAWeakMatrixColumns.columnL2 j).restrictScalars ℝ).comp
      (FrontierARealGradient.complexifyL2.comp
        (ContinuousLinearMap.snd ℝ RealVelocity Gradient)))) -
  (((LineDeriv.lineDerivOpCLM ℂ Distribution
      (FrontierAWeakRieszBridge.unitDirection j)).restrictScalars ℝ).comp
    (((Lp.toTemperedDistributionCLM Fiber (volume : Measure Space) 2).restrictScalars ℝ).comp
      (FrontierRealVelocityEmbedding.complexifyL2.comp
        (ContinuousLinearMap.fst ℝ RealVelocity Gradient))))

/-- A spatial Schwartz test produces a continuous real-linear functional
with values in the finite-dimensional complex velocity fiber. -/
def testedResidual (j : Fin 3) (ψ : SchwartzMap Space ℂ) :
    (RealVelocity × Gradient) →L[ℝ] Fiber :=
  ((PointwiseConvergenceCLM.evalCLM (RingHom.id ℂ) Fiber ψ).restrictScalars ℝ).comp
    (residualCLM j)

theorem testedResidual_apply (j : Fin 3) (ψ : SchwartzMap Space ℂ)
    (p : RealVelocity × Gradient) :
    testedResidual j ψ p = (FrontierWeakGradientSubspace.residual j p) ψ := by
  rfl

/-- If all separated tests vanish, the smooth time averages lie in the
existing spatial weak-gradient graph. The equation is understood through
Bochner integration in time of the distribution evaluated on a fixed test. -/
theorem averages_in_graph_of_separated_tests
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (μ : Measure ℝ)
    (hlocal : LocallyIntegrable (fun t => (u t, g t)) μ)
    (hsep : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SchwartzMap Space ℂ),
        (∫ t, φ t • ((FrontierWeakGradientSubspace.residual j (u t, g t)) ψ) ∂μ) = 0) :
    ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      (∫ t, φ t • (u t, g t) ∂μ) ∈ FrontierWeakGradientSubspace.graph := by
  intro φ hφ hφc
  have hint : Integrable (fun t => φ t • (u t, g t)) μ :=
    hlocal.integrable_smul_left_of_hasCompactSupport hφ.continuous hφc
  rw [FrontierWeakGradientSubspace.graph, Submodule.mem_iInf]
  intro j
  rw [LinearMap.mem_ker]
  apply DFunLike.ext
  intro ψ
  change (FrontierWeakGradientSubspace.residual j
    (∫ t, φ t • (u t, g t) ∂μ)) ψ = 0
  have hcomm : testedResidual j ψ (∫ t, φ t • (u t, g t) ∂μ) =
      ∫ t, φ t • ((FrontierWeakGradientSubspace.residual j (u t, g t)) ψ) ∂μ := by
    simpa only [map_smul, testedResidual_apply] using
      ((testedResidual j ψ).integral_comp_comm hint).symm
  rw [← testedResidual_apply]
  exact hcomm.trans (hsep φ hφ hφc j ψ)

/-- Separated test identities imply the weak-gradient identities at almost
every time, conditional on the stated local Bochner integrability. -/
theorem weak_at_ae_of_separated_tests
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (μ : Measure ℝ)
    (hlocal : LocallyIntegrable (fun t => (u t, g t)) μ)
    (hsep : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      ∀ (j : Fin 3) (ψ : SchwartzMap Space ℂ),
        (∫ t, φ t • ((FrontierWeakGradientSubspace.residual j (u t, g t)) ψ) ∂μ) = 0) :
    ∀ᵐ t ∂μ, FrontierAEProjectedGraphEnergy.WeakAt
      (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t) := by
  exact FrontierWeakGradientSlicing.weak_at_ae_of_smooth_time_averages
    u g μ hlocal (averages_in_graph_of_separated_tests u g μ hlocal hsep)

end FrontierSeparatedWeakSlicing

#print axioms FrontierSeparatedWeakSlicing.testedResidual_apply
#print axioms FrontierSeparatedWeakSlicing.averages_in_graph_of_separated_tests
#print axioms FrontierSeparatedWeakSlicing.weak_at_ae_of_separated_tests
