import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.MeasureTheory.Function.L2Space

/-! Product L² data have L² spatial sections almost everywhere, and the
spatial squared-norm integral is time-integrable with the expected Fubini
identity. This does not prove strong measurability of the L²-valued section
map, the product-to-Bochner L² isometry, or an NSE solution realization.
No local Lean run. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierSpacetimeL2Sections

variable {X Y E : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    [NormedAddCommGroup E]

/-- Every L² product-space representative has L² second-variable sections
for almost every first-variable point. -/
theorem memLp_two_sections_ae (μ : Measure X) (ν : Measure Y) [SFinite μ] [SFinite ν]
    (f : X × Y → E) (hf : MemLp f 2 (μ.prod ν)) :
    ∀ᵐ x ∂μ, MemLp (fun y => f (x, y)) 2 ν := by
  have hsm := hf.aestronglyMeasurable.prodMk_left
  have hsq : Integrable (fun z => ‖f z‖ ^ 2) (μ.prod ν) :=
    (memLp_two_iff_integrable_sq_norm hf.aestronglyMeasurable).1 hf
  have hsec := hsq.prod_right_ae
  filter_upwards [hsm, hsec] with x hx hsqx
  exact (memLp_two_iff_integrable_sq_norm hx).2 hsqx

/-- The spatial integral of the squared section norm is integrable in the
first variable, and its integral is the product-space squared norm integral. -/
theorem section_sq_norm_integrable_and_integral
    (μ : Measure X) (ν : Measure Y) [SFinite μ] [SFinite ν]
    (f : X × Y → E) (hf : MemLp f 2 (μ.prod ν)) :
    Integrable (fun x => ∫ y, ‖f (x, y)‖ ^ 2 ∂ν) μ ∧
      (∫ x, ∫ y, ‖f (x, y)‖ ^ 2 ∂ν ∂μ) =
        ∫ z, ‖f z‖ ^ 2 ∂(μ.prod ν) := by
  have hsq : Integrable (fun z => ‖f z‖ ^ 2) (μ.prod ν) :=
    (memLp_two_iff_integrable_sq_norm hf.aestronglyMeasurable).1 hf
  exact ⟨hsq.integral_prod_left, (integral_prod (fun z => ‖f z‖ ^ 2) hsq).symm⟩

end FrontierSpacetimeL2Sections

#print axioms FrontierSpacetimeL2Sections.memLp_two_sections_ae
#print axioms FrontierSpacetimeL2Sections.section_sq_norm_integrable_and_integral
