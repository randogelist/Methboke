import FrontierARieszRowSymbol
import HelicalFrequency

/-!
A-TIER CANDIDATE: normalized frequency row and its measurable scalar action.
Division in the real field is total, so at zero frequency all three normalized
coordinates are zero. The row acts on one velocity component; no vector-field
L² multiplier, Fourier derivative identity, or physical Leray–Hopf solution is
constructed here. External compilation and named axiom audits are required.
-/
noncomputable section
open MeasureTheory
open FeffermanHelicalNormalize

namespace FrontierARieszFrequency

def normalizedX (x y z : ℝ) : ℝ := x / radius x y z
def normalizedY (x y z : ℝ) : ℝ := y / radius x y z
def normalizedZ (x y z : ℝ) : ℝ := z / radius x y z

/-- The normalized vector is a unit vector off the origin and zero at it. -/
theorem normalized_sum_sq_le_one (x y z : ℝ) :
    normalizedX x y z ^ 2 + normalizedY x y z ^ 2 + normalizedZ x y z ^ 2 ≤ 1 := by
  by_cases h : 0 < x ^ 2 + y ^ 2 + z ^ 2
  · have hn := normalized_unit x y z h
    simpa [normalizedX, normalizedY, normalizedZ, hn]
  · have hs : x ^ 2 + y ^ 2 + z ^ 2 = 0 := by
      apply le_antisymm (le_of_not_gt h)
      positivity
    have hr : radius x y z = 0 := by simp [radius, hs]
    simp [normalizedX, normalizedY, normalizedZ, hr]

/-- Actual frequency-dependent row for one complex velocity component. -/
def freqRow (x y z : ℝ) (u v w : ℂ) : ℂ :=
  FrontierARieszRowSymbol.row (normalizedX x y z) (normalizedY x y z)
    (normalizedZ x y z) u v w

theorem freq_row_normSq_bound (x y z : ℝ) (u v w : ℂ) :
    Complex.normSq (freqRow x y z u v w) ≤
      Complex.normSq u + Complex.normSq v + Complex.normSq w := by
  exact FrontierARieszRowSymbol.row_normSq_bound _ _ _ u v w
    (normalized_sum_sq_le_one x y z)

/-- Scalar row action is measurable for measurable frequencies and inputs. -/
theorem measurable_freqRow {α : Type*} [MeasurableSpace α]
    (x y z : α → ℝ) (u v w : α → ℂ)
    (hx : Measurable x) (hy : Measurable y) (hz : Measurable z)
    (hu : Measurable u) (hv : Measurable v) (hw : Measurable w) :
    Measurable (fun a => freqRow (x a) (y a) (z a) (u a) (v a) (w a)) := by
  unfold freqRow FrontierARieszRowSymbol.row normalizedX normalizedY normalizedZ radius
  fun_prop

end FrontierARieszFrequency

#print axioms FrontierARieszFrequency.normalized_sum_sq_le_one
#print axioms FrontierARieszFrequency.freq_row_normSq_bound
#print axioms FrontierARieszFrequency.measurable_freqRow
