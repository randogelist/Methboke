import FrontierClosedGraphSlicing
import FrontierWeakGradientSubspace

/-! If every smooth compactly supported time average of the supplied
real L² velocity/gradient pair belongs to the weak-gradient subspace, then
the project's weak-gradient relation holds at almost every time. This is
one direction of the time-slicing bridge. The hypotheses do not establish
membership of the averages from an independent spacetime weak formulation.
No local Lean run. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierWeakGradientSlicing

abbrev RealVelocity := FrontierWeakGradientSubspace.RealVelocity
abbrev Gradient := FrontierWeakGradientSubspace.Gradient

/-- Time-average graph membership gives the slice-wise weak-gradient identities. -/
theorem weak_at_ae_of_smooth_time_averages
    (u : ℝ → RealVelocity) (g : ℝ → Gradient) (μ : Measure ℝ)
    (hlocal : LocallyIntegrable (fun t => (u t, g t)) μ)
    (havg : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      (∫ t, φ t • (u t, g t) ∂μ) ∈ FrontierWeakGradientSubspace.graph) :
    ∀ᵐ t ∂μ, FrontierAEProjectedGraphEnergy.WeakAt
      (FrontierRealVelocityEmbedding.complexifyL2 (u t)) (g t) := by
  letI : IsClosed (FrontierWeakGradientSubspace.graph : Set (RealVelocity × Gradient)) :=
    FrontierWeakGradientSubspace.isClosed_graph
  have hmem := FrontierClosedGraphSlicing.ae_mem_closed_submodule_of_smooth_averages
    FrontierWeakGradientSubspace.graph (fun t => (u t, g t)) μ hlocal havg
  filter_upwards [hmem] with t ht
  exact (FrontierWeakGradientSubspace.mem_graph_iff (u t, g t)).1 ht

end FrontierWeakGradientSlicing

#print axioms FrontierWeakGradientSlicing.weak_at_ae_of_smooth_time_averages
