// Native Windows .NET Framework 4.x. Built with the scheduler by stock csc.exe.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

internal sealed class BuildCache : IDisposable
{
    // Changing the key scheme or what the compiler reads requires a new protocol.
    const string Protocol = "FRONTIER-A-NATIVE-CACHE-1";
    static readonly StringComparer Paths = StringComparer.OrdinalIgnoreCase;
    static readonly string[] Suffixes = { ".olean", ".olean.private", ".olean.server", ".ir", ".ir.sig", ".ilean" };
    readonly string store, work, recipe, transaction;
    readonly List<Pending> pending = new List<Pending>();
    sealed class Pending { public string Stage, Key, Hash, Name; }
    readonly List<string> rolePaths = new List<string>();
    readonly List<string> physicalRoots = new List<string>();
    readonly List<FileSystemWatcher> watchers = new List<FileSystemWatcher>();
    List<string> originalNames;
    Dictionary<string, Stamp> originalStamps;
    volatile bool changed;
    public string AmbientId { get; private set; }

    sealed class Stamp
    {
        public long Length, WriteTime;
        public string Hash;
    }

    public BuildCache(string cacheDir, string leanExe, string basePath, string workDir)
        : this(cacheDir, leanExe, basePath, workDir, "direct -j N -o MODULE.olean MODULE.lean; no plugins or setup")
    { }

    public BuildCache(string cacheDir, string leanExe, string basePath, string workDir, string actionRecipe)
    {
        work = Absolute(workDir);
        recipe = actionRecipe ?? "";
        if (String.IsNullOrWhiteSpace(cacheDir) || Environment.GetEnvironmentVariable("KTF_FRESH") == "1") {
            AmbientId = "NO-CACHE";
            Console.WriteLine("CACHE_MODE=FRESH; no ambient fingerprint, restore, or publication");
            return;
        }
        store = Path.Combine(Absolute(cacheDir), Protocol);
        transaction = Path.Combine(store, ".pending-" + Guid.NewGuid().ToString("N"));
        string exe = Absolute(leanExe);
        string bin = Path.GetDirectoryName(exe);
        string prefix = Directory.GetParent(bin).FullName;
        if (!File.Exists(exe)) throw new FileNotFoundException("Lean executable missing", exe);
        rolePaths.Add("compiler=" + exe);
        AddRoot("native-bin", bin);
        // Includes the standard library's olean/IR data and native libraries below lib.
        AddRoot("native-lib", Path.Combine(prefix, "lib"));
        string sysroot = Environment.GetEnvironmentVariable("LEAN_SYSROOT");
        if (!String.IsNullOrWhiteSpace(sysroot) && !Paths.Equals(Absolute(sysroot), prefix))
            AddRoot("alternate-sysroot-lib", Path.Combine(Absolute(sysroot), "lib"));
        string[] roots = (basePath ?? "").Split(';');
        for (int i = 0; i < roots.Length; i++)
        {
            string p = roots[i].Trim().Trim('"');
            if (p.Length != 0) AddRoot("import-" + i.ToString(CultureInfo.InvariantCulture), p);
        }
        try
        {
            foreach (string dir in physicalRoots) Watch(dir);
            Console.WriteLine("DEPENDENCY_HASH=SHA256_CONTENT; enumerating ordered native and import roots");
            originalNames = Inventory();
            originalStamps = new Dictionary<string, Stamp>(Paths);
            Stamp[] snapshot = new Stamp[originalNames.Count];
            int done = 0;
            long bytes = 0, lastPrinted = -5000;
            Stopwatch clock = Stopwatch.StartNew();
            var options = new ParallelOptions { MaxDegreeOfParallelism = Math.Max(1, Math.Min(8, Environment.ProcessorCount)) };
            Console.WriteLine("DEPENDENCY_CONTENT_FILES=" + originalNames.Count);
            Parallel.For(0, snapshot.Length, options, delegate(int i) {
                string file = originalNames[i];
                Stamp s = ReadStamp(file);
                s.Hash = FileHash(file);
                Stamp after = ReadStamp(file);
                if (s.Length != after.Length || s.WriteTime != after.WriteTime)
                    throw new IOException("Dependency changed while hashing: " + file);
                snapshot[i] = s;
                long seen = Interlocked.Add(ref bytes, s.Length);
                int count = Interlocked.Increment(ref done);
                long now = clock.ElapsedMilliseconds, last = Interlocked.Read(ref lastPrinted);
                if (now - last >= 5000 && Interlocked.CompareExchange(ref lastPrinted, now, last) == last)
                    Console.WriteLine("DEPENDENCY_HASH_PROGRESS=" + count + "/" + snapshot.Length + "; MiB=" + (seen >> 20));
            });
            using (var m = new MemoryStream())
            using (var w = new BinaryWriter(m, Encoding.UTF8))
            {
                w.Write(Protocol); w.Write(rolePaths.Count);
                foreach (string role in rolePaths) w.Write(role);
                w.Write(originalNames.Count);
                for (int i = 0; i < snapshot.Length; i++) {
                    string path = originalNames[i]; Stamp s = snapshot[i];
                    originalStamps.Add(path, s); w.Write(path); w.Write(s.Length); w.Write(s.Hash);
                }
                w.Flush(); AmbientId = HashBytes(m.ToArray());
            }
            if (changed) throw new IOException("A dependency tree changed during the identity scan.");
            Directory.CreateDirectory(store);
            Console.WriteLine("DEPENDENCY_SHA256=" + AmbientId + "; MiB=" + (bytes >> 20)
                              + "; milliseconds=" + clock.ElapsedMilliseconds);
        }
        catch { Dispose(); throw; }
    }

    static string Absolute(string s)
    {
        if (String.IsNullOrWhiteSpace(s)) throw new ArgumentException("An absolute Windows path is required.");
        string full = Path.GetFullPath(s);
        if (!Path.IsPathRooted(s) || String.IsNullOrEmpty(Path.GetPathRoot(s))
            || Path.GetPathRoot(s).Length < 3)
            throw new ArgumentException("Relative or drive-relative path: " + s);
        return full.Length == Path.GetPathRoot(full).Length ? full : full.TrimEnd('\\', '/');
    }

    static bool Within(string child, string parent)
    {
        return Paths.Equals(child, parent) || child.StartsWith(parent.TrimEnd('\\', '/') + "\\", StringComparison.OrdinalIgnoreCase);
    }

    void AddRoot(string role, string path)
    {
        string full = Absolute(path);
        if (!Directory.Exists(full)) throw new DirectoryNotFoundException(full);
        if (Within(work, full) || Within(full, work) || Within(store, full) || Within(full, store))
            throw new IOException("External dependency tree overlaps runner output/cache: " + full);
        rolePaths.Add(role + "=" + full);
        // All paths are framed in search order in rolePaths. Scan nested physical files only once.
        foreach (string p in physicalRoots) if (Within(full, p)) return;
        physicalRoots.RemoveAll(delegate(string p) { return Within(p, full); });
        physicalRoots.Add(full);
    }

    void Watch(string dir)
    {
        // Directory renames can move a whole module subtree. On queue overflow fail closed.
        var f = new FileSystemWatcher(dir);
        f.IncludeSubdirectories = true;
        f.InternalBufferSize = 32768;
        f.NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.LastWrite | NotifyFilters.Size;
        f.Changed += delegate { changed = true; };
        f.Created += delegate { changed = true; };
        f.Deleted += delegate { changed = true; };
        f.Renamed += delegate { changed = true; };
        f.Error += delegate { changed = true; };
        watchers.Add(f); f.EnableRaisingEvents = true;
    }

    static bool Relevant(string filename)
    {
        string n = Path.GetFileName(filename);
        foreach (string ext in Suffixes) if (n.EndsWith(ext, StringComparison.OrdinalIgnoreCase)) return true;
        return n.EndsWith(".dll", StringComparison.OrdinalIgnoreCase) || n.EndsWith(".exe", StringComparison.OrdinalIgnoreCase);
    }

    List<string> Inventory()
    {
        var files = new List<string>();
        var todo = new Stack<string>(physicalRoots);
        while (todo.Count > 0)
        {
            string dir = todo.Pop();
            if ((File.GetAttributes(dir) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Linked dependency directories require a real physical path: " + dir);
            foreach (string sub in Directory.GetDirectories(dir)) todo.Push(sub);
            foreach (string name in Directory.GetFiles(dir)) if (Relevant(name)) {
                if ((File.GetAttributes(name) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Linked dependency files cannot be frozen: " + name);
                files.Add(name);
            }
        }
        // Ordinal order is independent of enumeration order and current thread culture.
        files.Sort(StringComparer.Ordinal);
        return files;
    }

    static Stamp ReadStamp(string path)
    {
        var fi = new FileInfo(path);
        return new Stamp { Length = fi.Length, WriteTime = fi.LastWriteTimeUtc.Ticks };
    }

    // Call after the mandatory fresh audit, before recording PASS. No second full reads.
    public void VerifyAmbient()
    {
        if (store == null) return;
        if (changed) throw new IOException("External dependency tree changed during the run; retry with a quiescent cache.");
        List<string> current = Inventory();
        if (current.Count != originalNames.Count) throw new IOException("External dependency inventory changed.");
        for (int i = 0; i < current.Count; i++) {
            if (!String.Equals(current[i], originalNames[i], StringComparison.Ordinal))
                throw new IOException("External dependency path set changed.");
            Stamp a = originalStamps[current[i]], b = ReadStamp(current[i]);
            if (a.Length != b.Length || a.WriteTime != b.WriteTime) throw new IOException("External dependency changed: " + current[i]);
        }
        if (changed) throw new IOException("External dependency tree changed during final verification.");
        // All workers must have joined. Only the successfully verified input snapshot can
        // make staged generations visible to other runs.
        lock (pending) {
            foreach (Pending item in pending) Publish(item);
            pending.Clear();
        }
    }

    public void Dispose()
    {
        foreach (FileSystemWatcher f in watchers) f.Dispose();
        watchers.Clear();
        if (!String.IsNullOrEmpty(transaction)) RemoveTemp(transaction);
    }

    static string Hex(byte[] h) { return BitConverter.ToString(h).Replace("-", "").ToLowerInvariant(); }
    static string HashBytes(byte[] b) { using (var h = new SHA256CryptoServiceProvider()) return Hex(h.ComputeHash(b)); }
    static string FileHash(string path)
    {
        using (var h = new SHA256CryptoServiceProvider())
        using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read,
                                       131072, FileOptions.SequentialScan))
            return Hex(h.ComputeHash(fs));
    }

    static void CheckDigest(string s)
    {
        if (s == null || s.Length != 64) throw new InvalidDataException("Invalid SHA-256 token.");
        foreach (char c in s) if (!(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'f') && !(c >= 'A' && c <= 'F'))
            throw new InvalidDataException("Malformed SHA-256 token.");
    }

    string Key(string module, string sourceSha, IDictionary<string, string> imports)
    {
        CheckDigest(sourceSha);
        var keys = new List<string>(imports.Keys);
        keys.Sort(StringComparer.Ordinal);
        using (var ms = new MemoryStream())
        using (var w = new BinaryWriter(ms, Encoding.UTF8)) {
            w.Write(Protocol); w.Write(AmbientId); w.Write(recipe); w.Write(module);
            w.Write(sourceSha.ToLowerInvariant()); w.Write(keys.Count);
            foreach (string name in keys) { CheckDigest(imports[name]); w.Write(name); w.Write(imports[name].ToLowerInvariant()); }
            w.Flush(); return HashBytes(ms.ToArray());
        }
    }

    // Propagate both ancestor input keys and output bytes. A pure re-exporting
    // module can produce identical .olean bytes after one of its imports changes.
    public string Lineage(string name, string sourceSha, IDictionary<string, string> parentLineages, string outputIdentity)
    {
        CheckDigest(outputIdentity);
        using (var ms = new MemoryStream())
        using (var w = new BinaryWriter(ms, Encoding.UTF8)) {
            w.Write(Protocol); w.Write("transitive-lineage");
            w.Write(Key(name, sourceSha, parentLineages));
            w.Write(outputIdentity.ToLowerInvariant());
            w.Flush(); return HashBytes(ms.ToArray());
        }
    }

    // The argument is the full path ending in ".olean"; the other files are peers.
    static string Stem(string output)
    {
        string path = Absolute(output);
        if (!path.EndsWith(".olean", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Expected the actual .olean output path: " + output);
        return path.Substring(0, path.Length - ".olean".Length);
    }

    public static string OutputIdentity(string output)
    {
        string stem = Stem(output);
        if (!File.Exists(output) || new FileInfo(output).Length == 0)
            throw new InvalidDataException("Missing/empty main olean: " + output);
        using (var ms = new MemoryStream())
        using (var w = new BinaryWriter(ms, Encoding.UTF8)) {
            w.Write(Protocol); w.Write("artifact-set");
            foreach (string suffix in Suffixes) {
                string p = stem + suffix;
                w.Write(suffix); bool exists = File.Exists(p); w.Write(exists);
                if (exists) { w.Write(new FileInfo(p).Length); w.Write(FileHash(p)); }
            }
            w.Flush(); return HashBytes(ms.ToArray());
        }
    }

    static void CopySet(string from, string to)
    {
        string a = Stem(from), b = Stem(to);
        foreach (string ext in Suffixes) if (File.Exists(a + ext)) File.Copy(a + ext, b + ext, false);
    }

    static void RemoveTemp(string dir)
    {
        if (Directory.Exists(dir)) Directory.Delete(dir, true);
    }

    static string VerifiedId(string dir, string key)
    {
        string[] r = File.ReadAllLines(Path.Combine(dir, "receipt.txt"), Encoding.UTF8);
        if (r.Length != 3 || r[0] != Protocol || r[1] != key) throw new InvalidDataException("Cache receipt/key mismatch.");
        CheckDigest(r[2]);
        if (!String.Equals(r[2], Path.GetFileName(dir), StringComparison.Ordinal))
            throw new InvalidDataException("Cache object/generation mismatch.");
        return r[2];
    }

    public bool TryRestore(string name, string sourceSha, IDictionary<string, string> imports, string output)
    {
        if (store == null) return false;
        if (changed) throw new IOException("External dependency tree changed before cache lookup.");
        string key = Key(name, sourceSha, imports);
        string parent = Path.Combine(store, key.Substring(0, 2), key);
        if (!Directory.Exists(parent)) return false;
        string destStem = Stem(output);
        Directory.CreateDirectory(Path.GetDirectoryName(output));
        foreach (string ext in Suffixes)
            if (File.Exists(destStem + ext)) throw new IOException("Restore destination must be empty: " + destStem + ext);
        string[] generations = Directory.GetDirectories(parent);
        Array.Sort(generations, StringComparer.Ordinal);
        foreach (string gen in generations) {
            if (Path.GetFileName(gen).Length != 64) continue;
            string tmp = Path.Combine(Path.GetDirectoryName(output), ".kth-read-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(tmp);
            try {
                string tmpMain = Path.Combine(tmp, "object.olean");
                try {
                    string expected = VerifiedId(gen, key);
                    CopySet(Path.Combine(gen, "object.olean"), tmpMain);
                    if (OutputIdentity(tmpMain) != expected) throw new InvalidDataException("Cache artifact SHA-256 mismatch.");
                } catch (InvalidDataException ex) {
                    Console.WriteLine("CACHE_CORRUPT_MISS=" + name + "; " + ex.Message); continue;
                } catch (IOException ex) {
                    Console.WriteLine("CACHE_CORRUPT_MISS=" + name + "; " + ex.Message); continue;
                } catch (UnauthorizedAccessException ex) {
                    Console.WriteLine("CACHE_READ_MISS=" + name + "; " + ex.Message); continue;
                }
                string tmpStem = Stem(tmpMain);
                // Publish peers first. The scheduler publishes graph readiness only after this returns.
                for (int i = Suffixes.Length - 1; i >= 0; i--)
                    if (File.Exists(tmpStem + Suffixes[i])) File.Move(tmpStem + Suffixes[i], destStem + Suffixes[i]);
                return true;
            } finally { RemoveTemp(tmp); }
        }
        return false;
    }

    public void Store(string name, string sourceSha, IDictionary<string, string> imports, string output)
    {
        if (store == null) return;
        if (changed) throw new IOException("External dependency tree changed before cache publication.");
        string key = Key(name, sourceSha, imports);
        Directory.CreateDirectory(transaction);
        string tmp = Path.Combine(transaction, ".write-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(tmp);
        try {
            string staged = Path.Combine(tmp, "object.olean");
            CopySet(output, staged);
            string hash = OutputIdentity(staged);
            if (hash != OutputIdentity(output)) throw new IOException("Shard output changed before staging: " + name);
            File.WriteAllLines(Path.Combine(tmp, "receipt.txt"), new string[] { Protocol, key, hash }, Encoding.UTF8);
            lock (pending) pending.Add(new Pending { Stage = tmp, Key = key, Hash = hash, Name = name });
        } catch { RemoveTemp(tmp); throw; }
    }

    void Publish(Pending o)
    {
        string parent = Path.Combine(store, o.Key.Substring(0, 2), o.Key);
        Directory.CreateDirectory(parent);
        string dest = Path.Combine(parent, o.Hash);
        // A named lock covers rare repair and competing atomically published generations.
        using (Mutex gate = new Mutex(false, "Local\\KThetaCache4-" + o.Key)) {
            bool entered = false;
            try {
                try { entered = gate.WaitOne(60000); } catch (AbandonedMutexException) { entered = true; }
                if (!entered) throw new IOException("Timed out waiting for cache publisher: " + o.Name);
                if (Directory.Exists(dest)) {
                    bool good = false;
                    try { good = VerifiedId(dest, o.Key) == OutputIdentity(Path.Combine(dest, "object.olean")); }
                    catch (InvalidDataException) { }
                    catch (IOException) { }
                    if (good) { RemoveTemp(o.Stage); return; }
                    Directory.Move(dest, Path.Combine(parent, ".bad-" + Guid.NewGuid().ToString("N")));
                }
                Directory.Move(o.Stage, dest);
            } finally { if (entered) gate.ReleaseMutex(); }
        }
    }
}
