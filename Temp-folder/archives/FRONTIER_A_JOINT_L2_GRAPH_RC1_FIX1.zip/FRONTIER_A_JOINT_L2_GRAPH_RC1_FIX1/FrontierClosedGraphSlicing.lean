import Mathlib.Analysis.Normed.Group.Quotient
import Mathlib.Topology.Algebra.Module.ContinuousLinearMap.Quotient
import Mathlib.Analysis.Distribution.AEEqOfIntegralContDiff
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

/-! A Banach-valued time-slicing principle. Smoothly weighted time averages
in a closed linear subspace imply a.e. pointwise membership. This theorem does
not derive those time-average hypotheses from the spacetime formulation of NSE.
No local Lean run. -/
noncomputable section
open MeasureTheory Filter

namespace FrontierClosedGraphSlicing

/-- Fundamental-lemma argument in the Banach quotient. This applies to the
closed weak-gradient graph once its real-linear subspace structure and the
spacetime-to-test-average bridge are provided. -/
theorem ae_mem_closed_submodule_of_smooth_averages
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    (S : Submodule ℝ E) [IsClosed (S : Set E)]
    (f : ℝ → E) (μ : Measure ℝ) (hf : LocallyIntegrable f μ)
    (havg : ∀ (φ : ℝ → ℝ), ContDiff ℝ (⊤ : ℕ∞) φ → HasCompactSupport φ →
      (∫ t, φ t • f t ∂μ) ∈ S) :
    ∀ᵐ t ∂μ, f t ∈ S := by
  let Q : E →L[ℝ] E ⧸ S := S.mkQL
  have hloc : LocallyIntegrable (fun t => Q (f t)) μ := by
    apply locallyIntegrableOn_univ.mp
    exact Q.locallyIntegrableOn_comp (hf.locallyIntegrableOn Set.univ)
  have hq : ∀ᵐ t ∂μ, Q (f t) = 0 := by
    apply ae_eq_zero_of_integral_contDiff_smul_eq_zero hloc
    intro φ hφ hφc
    have hint : Integrable (fun t => φ t • f t) μ :=
      hf.integrable_smul_left_of_hasCompactSupport hφ.continuous hφc
    have havg0 : Q (∫ t, φ t • f t ∂μ) = 0 := by
      change Submodule.Quotient.mk (∫ t, φ t • f t ∂μ) = 0
      exact (Submodule.Quotient.mk_eq_zero S).2 (havg φ hφ hφc)
    simpa only [map_smul] using (Q.integral_comp_comm hint).trans havg0
  filter_upwards [hq] with t ht
  change Submodule.Quotient.mk (f t) = 0 at ht
  exact (Submodule.Quotient.mk_eq_zero S).1 ht

end FrontierClosedGraphSlicing

#print axioms FrontierClosedGraphSlicing.ae_mem_closed_submodule_of_smooth_averages
