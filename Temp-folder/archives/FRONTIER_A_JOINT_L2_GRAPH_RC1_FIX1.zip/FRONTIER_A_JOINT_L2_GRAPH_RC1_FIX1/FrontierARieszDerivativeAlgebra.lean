import FrontierARieszVectorPointwise

/-!
A-TIER CANDIDATE: pointwise frequency algebra for the existing Riesz row.
This file does not define an actual weak derivative or a Fourier transform.
The entries of `derivativeMatrix` are defined algebraically; no claim is made
that they are Fourier transforms of derivatives. External native Lean 4.33.0
compilation, signature checking, and theorem-level axiom audit are required.
-/
noncomputable section
open FeffermanHelicalNormalize FrontierARieszFrequency

namespace FrontierARieszDerivativeAlgebra

/-- The normalized frequency has dot product equal to the radius, including
    at zero frequency. -/
theorem normalized_dot_radius (x y z : ℝ) :
    normalizedX x y z * x + normalizedY x y z * y +
      normalizedZ x y z * z = radius x y z := by
  have hs : (radius x y z) ^ 2 = x ^ 2 + y ^ 2 + z ^ 2 := by
    simpa [radius] using Real.sq_sqrt (show 0 ≤ x ^ 2 + y ^ 2 + z ^ 2 by positivity)
  by_cases hr : radius x y z = 0
  · have hz : x ^ 2 + y ^ 2 + z ^ 2 = 0 := by nlinarith [hs]
    have hx : x = 0 := by nlinarith [sq_nonneg y, sq_nonneg z]
    have hy : y = 0 := by nlinarith [sq_nonneg x, sq_nonneg z]
    have hz' : z = 0 := by nlinarith [sq_nonneg x, sq_nonneg y]
    simp [hx, hy, hz', radius, normalizedX, normalizedY, normalizedZ]
  · unfold normalizedX normalizedY normalizedZ
    field_simp [hr] <;> nlinarith [hs]

/-- Algebraic derivative symbol with an arbitrary real normalization factor.
    For the Fourier convention exp(-2πix·ξ), set `scale = 2 * Real.pi`. -/
def derivativeMatrix (scale : ℝ) (ξ : HelicalConcreteSymbol.Frequency)
    (u : Fin 3 → ℂ) : Fin 3 → Fin 3 → ℂ :=
  fun i j => (scale : ℂ) * Complex.I * (ξ j : ℂ) * u i

/-- Applying the existing vector Riesz row to the algebraic derivative
    symbol yields the radius multiplier, at every frequency including zero. -/
theorem vectorRow_derivative_symbol (scale : ℝ)
    (ξ : HelicalConcreteSymbol.Frequency) (u : Fin 3 → ℂ) (i : Fin 3) :
    FrontierARieszVectorPointwise.vectorRow ξ (derivativeMatrix scale ξ u) i =
      (scale : ℂ) * (radius (ξ 0) (ξ 1) (ξ 2) : ℂ) * u i := by
  have hi : -Complex.I * Complex.I = (1 : ℂ) := by
    simp only [neg_mul, Complex.I_mul_I, neg_neg]
  have hd : ((normalizedX (ξ 0) (ξ 1) (ξ 2) * ξ 0 +
      normalizedY (ξ 0) (ξ 1) (ξ 2) * ξ 1 +
      normalizedZ (ξ 0) (ξ 1) (ξ 2) * ξ 2 : ℝ) : ℂ) =
      (radius (ξ 0) (ξ 1) (ξ 2) : ℂ) := by
    exact_mod_cast normalized_dot_radius (ξ 0) (ξ 1) (ξ 2)
  calc
    _ = (-Complex.I * Complex.I) *
        ((normalizedX (ξ 0) (ξ 1) (ξ 2) * ξ 0 +
          normalizedY (ξ 0) (ξ 1) (ξ 2) * ξ 1 +
          normalizedZ (ξ 0) (ξ 1) (ξ 2) * ξ 2 : ℝ) : ℂ) *
        (scale : ℂ) * u i := by
      simp only [FrontierARieszVectorPointwise.vectorRow, derivativeMatrix,
        freqRow, FrontierARieszRowSymbol.row, Complex.ofReal_add, Complex.ofReal_mul]
      ring
    _ = _ := by rw [hi, one_mul, hd]; ring

end FrontierARieszDerivativeAlgebra

#print axioms FrontierARieszDerivativeAlgebra.normalized_dot_radius
#print axioms FrontierARieszDerivativeAlgebra.vectorRow_derivative_symbol
