import Lake
open Lake DSL

package qfa_endpoints where
  version := v!"0.3.0"

require mathlib from git
  "https://github.com/leanprover-community/mathlib4" @
  "db584cd6d46c92f209a44c0f1c829460d327499d"

@[default_target]
lean_lib QFA
