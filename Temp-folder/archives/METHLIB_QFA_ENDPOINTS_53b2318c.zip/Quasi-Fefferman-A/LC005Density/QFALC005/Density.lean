/-
Copyright (c) 2026 Terence Tao. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Terence Tao

The cutoff-density argument below is a namespace-isolated backport of
Mathlib PR #43046 / commit b2115b96757894e56b53fd0f94bd63acd64d8025,
adapted to the pinned QFA Mathlib revision
`db584cd6d46c92f209a44c0f1c829460d327499d`.
-/

import QFALC004.CompactSchwartz
import Mathlib.Analysis.Calculus.BumpFunction.FiniteDimension
import Mathlib.Analysis.Calculus.ContDiff.Bounds
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.Normed.Group.Bounded

set_option autoImplicit false
set_option Elab.async true

open scoped Topology ContDiff
open Filter Metric Real Finset Function

noncomputable section

namespace QFA.LC005.Backport

variable {𝕜 E F : Type*} [NontriviallyNormedField 𝕜]
  [NormedAddCommGroup E] [NormedSpace 𝕜 E]
  [NormedAddCommGroup F] [NormedSpace 𝕜 F]

/-- Uniform derivative bound needed by the October cutoff-density argument.
This is the exact short lemma later added to Mathlib's `ContDiff.Basic`. -/
lemma exists_bound_iteratedFDeriv {f : E → F}
    (hf : HasCompactSupport f) (hf' : ContDiff 𝕜 ∞ f) (m : ℕ) :
    ∃ C, 0 ≤ C ∧ ∀ i ≤ m, ∀ y, ‖iteratedFDeriv 𝕜 i f y‖ ≤ C := by
  have key i : ∃ C, ∀ y, ‖iteratedFDeriv 𝕜 i f y‖ ≤ C :=
    (hf'.continuous_iteratedFDeriv (mod_cast le_top)).bounded_above_of_compact_support
      (hf.iteratedFDeriv i)
  choose A hA using key
  refine ⟨max 0 ((Finset.range (m + 1)).sup' ⟨0, by simp⟩ A), le_max_left _ _, fun i hi y => ?_⟩
  grw [hA i y, ← le_max_right]
  exact Finset.le_sup' A (by grind)

end QFA.LC005.Backport

namespace SchwartzMap

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
variable {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F]

variable {φ : E → ℝ} (hφ : ContDiff ℝ ∞ φ) (hφc : HasCompactSupport φ)
  (hφ1 : φ =ᶠ[𝓝 0] 1) (f : 𝓢(E, F))

include hφ hφc hφ1 in
/-- Backported seminorm convergence for rescaled compact cutoffs. -/
lemma qfa_tendsto_seminorm_cutoff_sub (k n : ℕ) :
    Tendsto
      (fun ε : ℝ => (smulLeftCLM F (fun x => φ (ε • x)) f - f).seminorm ℝ k n)
      (𝓝 0) (𝓝 0) := by
  obtain ⟨r, hr, hφr⟩ := eventually_nhds_iff_ball.mp hφ1
  obtain ⟨A, hA0, hA⟩ := QFA.LC005.Backport.exists_bound_iteratedFDeriv hφc hφ n
  have hψ : ∀ i ≤ n, ∀ y, ‖iteratedFDeriv ℝ i (fun z => φ z - 1) y‖ ≤ A + 1 := by
    rintro (- | i) hi y
    · grind [norm_iteratedFDeriv_zero, norm_sub_le, norm_one, hA 0 hi y]
    · rw [fun_iteratedFDeriv_sub_apply (hφ.contDiffAt.of_le (mod_cast le_top)) contDiffAt_const,
        iteratedFDeriv_succ_const, Pi.zero_apply, sub_zero]
      linarith [hA _ hi y]
  refine squeeze_zero' (g := fun ε =>
      ‖ε‖ * (∑ i ∈ range (n + 1), n.choose i * (A + 1) * f.seminorm ℝ (k + 1) (n - i)) / r)
    (.of_forall fun _ => apply_nonneg _ _) ?_
    (by simpa only [zero_mul, zero_div] using (tendsto_norm_zero.mul_const _).div_const r)
  filter_upwards [closedBall_mem_nhds (0 : ℝ) one_pos] with ε hε
  have hg : ∀ i ≤ n, ∀ x, ‖iteratedFDeriv ℝ i (fun y => φ (ε • y) - 1) x‖ ≤ A + 1 := by
    intro i hi x
    rw [iteratedFDeriv_comp_const_smul (f := fun z => φ z - 1) _
      ((hφ.sub contDiff_const).of_le (mod_cast le_top)), norm_smul, norm_pow]
    exact (mul_le_of_le_one_left (norm_nonneg _)
      (pow_le_one₀ (norm_nonneg _) (mem_closedBall_zero_iff.mp hε))).trans (hψ i hi _)
  have hsmul : ⇑(smulLeftCLM F (fun x => φ (ε • x)) f - f) =
      fun x => (φ (ε • x) - 1) • f x := by
    ext x
    simp [show (fun x => φ (ε • x)).HasTemperateGrowth by fun_prop, sub_smul]
  refine seminorm_le_bound ℝ k n _ (by positivity) fun x => ?_
  rw [hsmul, le_div_iff₀ hr]
  rcases lt_or_ge ‖ε • x‖ r with hx | hx
  · have : (fun y => (φ (ε • y) - 1) • f y) =ᶠ[𝓝 x] 0 := by
      filter_upwards [(isOpen_ball.preimage (continuous_const_smul ε)).mem_nhds
        (mem_ball_zero_iff.mpr hx)] with y hy
      simp [hφr (ε • y) hy]
    calc
      _ = (0 : ℝ) := by simp [(this.iteratedFDeriv ℝ n).eq_of_nhds]
      _ ≤ _ := by positivity
  · rw [norm_smul] at hx
    calc
      _ ≤ ‖x‖ ^ k * ‖iteratedFDeriv ℝ n (fun y => (φ (ε • y) - 1) • f y) x‖ *
          (‖ε‖ * ‖x‖) := by
            gcongr
      _ ≤ ‖ε‖ * ∑ i ∈ range (n + 1), n.choose i *
            ‖iteratedFDeriv ℝ i (fun y => φ (ε • y) - 1) x‖ *
            (‖x‖ ^ (k + 1) * ‖iteratedFDeriv ℝ (n - i) f x‖) := by
          grw [norm_iteratedFDeriv_smul_le (by fun_prop) (f.smooth ⊤) x (mod_cast le_top)]
          simp only [mul_sum, sum_mul]
          exact (sum_congr rfl fun _ _ => by ring).le
      _ ≤ _ := by
          gcongr with i hi
          · exact hg i (by grind) x
          · exact le_seminorm ℝ _ _ f x

include hφ hφc hφ1 in
/-- Backported convergence in the full Schwartz topology. -/
theorem qfa_tendsto_cutoff :
    Tendsto (fun ε : ℝ => smulLeftCLM F (fun x => φ (ε • x)) f) (𝓝 0) (𝓝 f) := by
  rw [(schwartz_withSeminorms ℝ E F).tendsto_nhds]
  rintro ⟨k, n⟩ δ hδ
  simpa using (qfa_tendsto_seminorm_cutoff_sub hφ hφc hφ1 f k n).eventually
    (isOpen_Iio.mem_nhds hδ)

/-- Backport of compact-support density in Schwartz space. -/
theorem qfa_dense_hasCompactSupport [FiniteDimensional ℝ E] :
    Dense {f : 𝓢(E, F) | HasCompactSupport (f : E → F)} := by
  intro f
  set b : ContDiffBump (0 : E) := ⟨1, 2, one_pos, one_lt_two⟩ with hb
  refine mem_closure_of_tendsto ((qfa_tendsto_cutoff b.contDiff b.hasCompactSupport
    b.eventuallyEq_one f).mono_left (nhdsWithin_le_nhds (s := {0}ᶜ))) ?_
  filter_upwards [self_mem_nhdsWithin] with ε hε
  have hcs : HasCompactSupport (fun x => b (ε • x)) := b.hasCompactSupport.comp_smul hε
  rw [smulLeftCLM_apply <| hcs.hasTemperateGrowth <| b.contDiff.comp <| contDiff_const_smul _]
  exact hcs.smul_right

end SchwartzMap

namespace QFA.Endpoints.Representation.CompactSchwartz

open QFA.Endpoints.Agmon

/-- LC005: compactly supported scalar Schwartz tests are dense for the actual
whole-space QFA test domain. -/
theorem denseCompactSchwartzTests : DenseCompactSchwartzTests := by
  simpa only [DenseCompactSchwartzTests, compactSchwartzTests] using
    (SchwartzMap.qfa_dense_hasCompactSupport (E := Space) (F := ℂ))

/-- The corrected derivative witness bridge with LC005 discharged. -/
theorem schwartzDerivativeWitnesses_of_compactSchwartz_unconditional
    {v : ComplexL2} {G : Fin 3 → ComplexL2} {L : ComplexL2}
    (h : CompactSchwartzDerivativeWitnesses v G L) :
    SchwartzDerivativeWitnesses v G L :=
  schwartzDerivativeWitnesses_of_compactSchwartz denseCompactSchwartzTests h

/-- Unconditional corrected endpoint; unlike the old endpoint, its input test
class is mathematically separating. -/
def CompactSchwartzToSchwartzEndpoint : Prop :=
  ∀ (v : ComplexL2) (G : Fin 3 → ComplexL2) (L : ComplexL2),
    CompactSchwartzDerivativeWitnesses v G L →
      SchwartzDerivativeWitnesses v G L

/-- LC005 plus the previously verified corrected bridge. -/
theorem compactSchwartzToSchwartzEndpoint :
    CompactSchwartzToSchwartzEndpoint := by
  intro v G L h
  exact schwartzDerivativeWitnesses_of_compactSchwartz_unconditional h

end QFA.Endpoints.Representation.CompactSchwartz
